package takeyourminestream.ijustseen.minigames;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import takeyourminestream.ijustseen.integration.chat.ChatEventType;
import takeyourminestream.ijustseen.integration.chat.IncomingChatMessage;

import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Local-world-only streamer event actions and gift alert HUD. */
public final class InteractiveMinigames {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type MAP_TYPE = new TypeToken<LinkedHashMap<String, String>>() {}.getType();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("keitok-interactive-minigames.json");
    private static final Map<String, String> commands = new LinkedHashMap<>();
    private static final Deque<Alert> alerts = new ArrayDeque<>();
    private static boolean enabled;
    private static boolean registered;
    private static int alertSeconds = 6;
    private static int maxAlerts = 8;
    private static int nextId;

    private InteractiveMinigames() {}

    public static synchronized void load() {
        if (!Files.exists(FILE)) {
            commands.put("FOLLOW", "say {user} followed!");
            commands.put("LIKE", "say {user} liked the stream!");
            commands.put("SUBSCRIBE", "say {user} subscribed!");
            commands.put("GIFT", "give @p minecraft:diamond 1");
            commands.put("RAID", "say Raid from {user}!");
            commands.put("BITS", "say {user} sent bits!");
            save();
            return;
        }
        try (Reader reader = Files.newBufferedReader(FILE)) {
            Config data = GSON.fromJson(reader, Config.class);
            if (data != null) {
                enabled = data.enabled;
                alertSeconds = Math.max(1, Math.min(30, data.alertSeconds));
                maxAlerts = Math.max(1, Math.min(16, data.maxAlerts));
                if (data.commands != null) commands.putAll(data.commands);
                if (data.giftCommands != null) commands.putAll(data.giftCommands);
                commands.putIfAbsent("LIKE", "say {user} liked the stream!");
            }
        } catch (Exception ignored) { }
    }

    public static synchronized void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Config data = new Config();
            data.enabled = enabled;
            data.alertSeconds = alertSeconds;
            data.maxAlerts = maxAlerts;
            data.commands = new LinkedHashMap<>();
            for (String key : List.of("FOLLOW", "LIKE", "SUBSCRIBE", "GIFT", "RAID", "BITS")) {
                data.commands.put(key, commands.getOrDefault(key, ""));
            }
            data.giftCommands = new LinkedHashMap<>();
            for (Map.Entry<String, String> entry : commands.entrySet()) {
                if (entry.getKey().startsWith("GIFT:")) data.giftCommands.put(entry.getKey().substring(5), entry.getValue());
            }
            try (Writer writer = Files.newBufferedWriter(FILE)) { GSON.toJson(data, writer); }
        } catch (Exception ignored) { }
    }

    public static synchronized boolean isEnabled() { return enabled; }
    public static synchronized void setEnabled(boolean value) { enabled = value; if (!value) alerts.clear(); save(); }
    public static synchronized int getAlertSeconds() { return alertSeconds; }
    public static synchronized void setAlertSeconds(int value) { alertSeconds = Math.max(1, Math.min(30, value)); save(); }
    public static synchronized int getMaxAlerts() { return maxAlerts; }
    public static synchronized void setMaxAlerts(int value) { maxAlerts = Math.max(1, Math.min(16, value)); save(); }
    public static synchronized String getCommand(String key) { return commands.getOrDefault(key, ""); }
    public static synchronized void setCommand(String key, String value) { commands.put(key, value == null ? "" : value.trim()); save(); }
    public static synchronized void clearGiftCommands() { commands.keySet().removeIf(key -> key.startsWith("GIFT:")); save(); }
    public static synchronized String getGiftRules() {
        StringBuilder result = new StringBuilder();
        for (Map.Entry<String, String> entry : commands.entrySet()) {
            if (!entry.getKey().startsWith("GIFT:")) continue;
            if (result.length() > 0) result.append("; ");
            result.append(entry.getKey().substring(5)).append("=").append(entry.getValue());
        }
        return result.toString();
    }

    public static void registerHud() {
        synchronized (InteractiveMinigames.class) {
            if (registered) return;
            registered = true;
        }
        HudRenderCallback.EVENT.register((context, tickDelta) -> render(context));
    }

    /** Called for every incoming stream event, before normal chat filtering. */
    public static void handle(IncomingChatMessage message) {
        if (message == null || message.eventType() == null || !message.eventType().isEvent()) return;
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) return;
        client.execute(() -> {
            synchronized (InteractiveMinigames.class) {
                if (!enabled || !eligible(client)) return;
                String user = cleanPlaceholder(safe(message.displayName(), safe(message.authorLogin(), "Viewer")));
                String detail = cleanPlaceholder(safe(message.text(), ""));
                String event = message.eventType().name();
                String giftName = detail.trim();
                String command = "";
                if (message.eventType() == ChatEventType.GIFT && !giftName.isBlank()) {
                    String normalizedGift = giftName.toLowerCase(Locale.ROOT);
                    int longestMatch = -1;
                    for (Map.Entry<String, String> entry : commands.entrySet()) {
                        if (!entry.getKey().startsWith("GIFT:")) continue;
                        String giftKey = entry.getKey().substring(5);
                        if (!giftKey.isBlank() && normalizedGift.contains(giftKey) && giftKey.length() > longestMatch) {
                            command = entry.getValue();
                            longestMatch = giftKey.length();
                        }
                    }
                }
                if (command.isBlank()) command = commands.getOrDefault(event, "");
                runCommand(client, command, user, event, detail, 1);
                String title = message.eventType() == ChatEventType.GIFT && !giftName.isBlank() ? giftName : titleFor(event);
                alerts.addLast(new Alert(++nextId, title, user, event, System.currentTimeMillis()));
                while (alerts.size() > maxAlerts) alerts.removeFirst();
            }
        });
    }

    /** Simulates a stream event from an in-game test command. */
    public static synchronized boolean simulateTest(String event, String giftName, int count) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!enabled || client == null || !eligible(client)) return false;
        String normalizedEvent = event == null ? "" : event.toUpperCase(Locale.ROOT);
        if (!List.of("FOLLOW", "LIKE", "SUBSCRIBE", "GIFT", "RAID", "BITS").contains(normalizedEvent)) return false;
        int safeCount = Math.max(1, Math.min(64, count));
        String user = "TestViewer";
        String detail = normalizedEvent.equals("GIFT")
            ? safe(giftName, "rose") + (safeCount > 1 ? " x" + safeCount : "")
            : (normalizedEvent.equals("LIKE") ? "Test likes" : "Test " + normalizedEvent.toLowerCase(Locale.ROOT));
        String command = "";
        if (normalizedEvent.equals("GIFT")) {
            String normalizedGift = safe(giftName, "rose").toLowerCase(Locale.ROOT);
            int longestMatch = -1;
            for (Map.Entry<String, String> entry : commands.entrySet()) {
                if (!entry.getKey().startsWith("GIFT:")) continue;
                String giftKey = entry.getKey().substring(5).toLowerCase(Locale.ROOT);
                if (!giftKey.isBlank() && normalizedGift.contains(giftKey) && giftKey.length() > longestMatch) {
                    command = entry.getValue();
                    longestMatch = giftKey.length();
                }
            }
        }
        if (command.isBlank()) command = commands.getOrDefault(normalizedEvent, "");
        runCommand(client, command, user, normalizedEvent, detail, safeCount);
        String title = normalizedEvent.equals("GIFT") ? detail : titleFor(normalizedEvent);
        alerts.addLast(new Alert(++nextId, title, user, normalizedEvent, System.currentTimeMillis()));
        while (alerts.size() > maxAlerts) alerts.removeFirst();
        return true;
    }

    private static boolean eligible(MinecraftClient client) {
        return client.isInSingleplayer() && client.world != null && client.player != null
            && client.player.hasPermissionLevel(2);
    }

    private static void runCommand(MinecraftClient client, String template, String user, String event, String detail, int count) {
        if (template == null || template.isBlank() || !eligible(client)) return;
        String command = template.trim();
        if (command.startsWith("/")) command = command.substring(1);
        if (command.isBlank() || command.contains("\n") || command.contains("\r")) return;
        command = command.replace("{user}", user).replace("{event}", event).replace("{message}", detail).replace("{count}", Integer.toString(count));
        // Execute only through the integrated server's permission-checked command path.
        try { client.player.networkHandler.sendChatCommand(command); }
        catch (Exception ignored) { }
    }

    private static void render(DrawContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.player == null || client.world == null || !client.isInSingleplayer()) return;
        List<Alert> visible = new ArrayList<>();
        long now = System.currentTimeMillis();
        synchronized (InteractiveMinigames.class) {
            if (!enabled) return;
            while (!alerts.isEmpty() && now - alerts.peekFirst().createdAt > alertSeconds * 1000L) alerts.removeFirst();
            visible.addAll(alerts);
        }
        int screenWidth = client.getWindow().getScaledWidth();
        int cardWidth = Math.min(164, Math.max(112, (screenWidth - 24) / 3));
        int cardHeight = 34;
        int gap = 5;
        int startX = 8;
        int startY = 8;
        for (int i = 0; i < visible.size(); i++) {
            Alert alert = visible.get(i);
            int col = i % Math.max(1, (screenWidth - 16) / (cardWidth + gap));
            int row = i / Math.max(1, (screenWidth - 16) / (cardWidth + gap));
            int x = startX + col * (cardWidth + gap); // left-to-right, then next row
            int y = startY + row * (cardHeight + gap);
            context.fill(x, y, x + cardWidth, y + cardHeight, 0xE91D1D1D);
            context.fill(x, y, x + 3, y + cardHeight, color(alert.kind));
            context.drawText(client.textRenderer, Text.literal(alert.title), x + 9, y + 5, 0xFFFFE76B, true);
            context.drawText(client.textRenderer, Text.literal(alert.user), x + 9, y + 19, 0xFFFFFFFF, true);
            context.drawBorder(x, y, cardWidth, cardHeight, 0xFF777777);
        }
    }

    private static int color(String kind) {
        return switch (kind) {
            case "FOLLOW" -> 0xFF3DDC97;
            case "LIKE" -> 0xFFFF6688;
            case "SUBSCRIBE" -> 0xFFC77DFF;
            case "GIFT" -> 0xFFFFB347;
            case "RAID" -> 0xFF5B8CFF;
            case "BITS" -> 0xFF9B59B6;
            default -> 0xFFFFFFFF;
        };
    }

    private static String titleFor(String event) { return switch (event) {
        case "FOLLOW" -> "New Follower";
        case "LIKE" -> "New Like";
        case "SUBSCRIBE" -> "New Subscriber";
        case "GIFT" -> "New Gift";
        case "RAID" -> "New Raid";
        case "BITS" -> "New Bits";
        default -> event;
    }; }

    private static String safe(String value, String fallback) { return value == null || value.isBlank() ? fallback : value; }
    private static String cleanPlaceholder(String value) {
        return value == null ? "" : value.replace("\r", " ").replace("\n", " ").trim();
    }

    private static final class Alert {
        final int id; final String title, user, kind; final long createdAt;
        Alert(int id, String title, String user, String kind, long createdAt) {
            this.id = id; this.title = title; this.user = user; this.kind = kind; this.createdAt = createdAt;
        }
    }
    private static final class Config {
        boolean enabled; int alertSeconds = 6; int maxAlerts = 8;
        Map<String, String> commands = new LinkedHashMap<>();
        Map<String, String> giftCommands = new LinkedHashMap<>();
    }
}
