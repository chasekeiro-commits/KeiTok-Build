package net.fabricmc.fabric.api.entity.event.v1;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.event.Event;
import net.minecraft.class_3222;

/** Test double of Fabric's ServerPlayerEvents. */
public final class ServerPlayerEvents {
    private ServerPlayerEvents() {}

    public interface Leave {
        void onPlayerLeave(class_3222 player);
    }

    private static final class Simple implements Event<Leave> {
        final List<Leave> listeners = new ArrayList<>();

        @Override
        public void register(Leave listener) {
            listeners.add(listener);
        }
    }

    public static final Event<Leave> LEAVE = new Simple();

    /** Test helper: a player leaves, and every registered listener is told. */
    public static void fireLeave(class_3222 player) {
        for (Leave l : ((Simple) LEAVE).listeners) {
            l.onPlayerLeave(player);
        }
    }
}
