package net.fabricmc.fabric.api.client.networking.v1;

import java.util.HashMap;
import java.util.Map;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_8710;

/** Test double of Fabric's client networking. */
public final class ClientPlayNetworking {
    private ClientPlayNetworking() {}

    public interface Context {}

    public interface PlayPayloadHandler<T extends class_8710> {
        void receive(T payload, Context context);
    }

    /** Client handlers by channel id (server to client). */
    public static final Map<Object, Object> RECEIVERS = new HashMap<>();

    public static boolean canSend(class_8710.Id<?> id) {
        return ServerPlayNetworking.RECEIVERS.containsKey(id);
    }

    public static void send(class_8710 payload) {
        ServerPlayNetworking.deliverFromClient(payload);
    }

    public static <T extends class_8710> void registerGlobalReceiver(class_8710.Id<T> id, PlayPayloadHandler<T> handler) {
        RECEIVERS.put(id, handler);
    }
}
