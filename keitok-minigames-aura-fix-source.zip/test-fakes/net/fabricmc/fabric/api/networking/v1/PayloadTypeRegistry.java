package net.fabricmc.fabric.api.networking.v1;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/** Test double of Fabric's payload registry: remembers the codec of each channel. */
public interface PayloadTypeRegistry {
    static PayloadTypeRegistry playC2S() {
        return Registry.C2S;
    }

    static PayloadTypeRegistry playS2C() {
        return Registry.S2C;
    }

    <T extends class_8710> void register(class_8710.Id<T> id, class_9139<?, T> codec);

    final class Registry implements PayloadTypeRegistry {
        static final Registry C2S = new Registry();
        static final Registry S2C = new Registry();
        final Map<Object, class_9139<?, ?>> codecs = new HashMap<>();

        @Override
        public <T extends class_8710> void register(class_8710.Id<T> id, class_9139<?, T> codec) {
            if (codecs.containsKey(id)) throw new IllegalArgumentException("already registered: " + id);
            codecs.put(id, codec);
        }
    }
}
