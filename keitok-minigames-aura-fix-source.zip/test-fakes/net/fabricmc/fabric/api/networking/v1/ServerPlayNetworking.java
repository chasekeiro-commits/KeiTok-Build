package net.fabricmc.fabric.api.networking.v1;

import fakes.TestBuf;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9139;

/** Test double of Fabric's server networking. Payloads really go through the codecs and back, as on the wire. */
public final class ServerPlayNetworking {
    private ServerPlayNetworking() {}

    public interface Context {
        class_3222 player();
    }

    public interface PlayPayloadHandler<T extends class_8710> {
        void receive(T payload, Context context);
    }

    /** Server handlers by channel id (client to server). */
    public static final Map<Object, Object> RECEIVERS = new HashMap<>();
    /** Players whose client accepts the roster channel. */
    public static final Set<Object> CAN_RECEIVE = new HashSet<>();
    /** The player whose client sends the next payload. Set by the test. */
    public static class_3222 sender;

    public static <T extends class_8710> void registerGlobalReceiver(class_8710.Id<T> id, PlayPayloadHandler<T> handler) {
        RECEIVERS.put(id, handler);
    }

    public static boolean canSend(class_3222 player, class_8710.Id<?> id) {
        return CAN_RECEIVE.contains(player) && ClientPlayNetworking.RECEIVERS.containsKey(id);
    }

    public static void send(class_3222 player, class_8710 payload) {
        Object id = payload.getId();
        Object decoded = roundTrip(PayloadTypeRegistry.Registry.S2C.codecs.get(id), payload);
        Object handler = ClientPlayNetworking.RECEIVERS.get(id);
        if (handler == null) throw new IllegalStateException("no client handler for " + id);
        ((ClientPlayNetworking.PlayPayloadHandler) handler).receive((class_8710) decoded, new ClientPlayNetworking.Context() {});
    }

    /** The fake client sends a payload: it goes through the C2S codec and into the server handler. */
    public static void deliverFromClient(class_8710 payload) {
        Object id = payload.getId();
        Object decoded = roundTrip(PayloadTypeRegistry.Registry.C2S.codecs.get(id), payload);
        Object handler = RECEIVERS.get(id);
        if (handler == null) return;
        final class_3222 who = sender;
        ((PlayPayloadHandler) handler).receive((class_8710) decoded, () -> who);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static Object roundTrip(class_9139 codec, class_8710 payload) {
        TestBuf buf = new TestBuf();
        codec.encode(buf, payload);
        buf.flip();
        return codec.decode(buf);
    }
}
