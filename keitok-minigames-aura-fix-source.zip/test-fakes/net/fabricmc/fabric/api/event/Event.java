package net.fabricmc.fabric.api.event;

/** Test double of Fabric's Event: listeners are added with register. */
public interface Event<T> {
    void register(T listener);
}
