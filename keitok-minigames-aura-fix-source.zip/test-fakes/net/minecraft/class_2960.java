package net.minecraft;

/** Test double of Identifier: only the factory the presence code calls. */
public final class class_2960 {
    private final String ns;
    private final String path;

    private class_2960(String ns, String path) {
        this.ns = ns;
        this.path = path;
    }

    public static class_2960 method_60655(String ns, String path) {
        return new class_2960(ns, path);
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof class_2960 && ((class_2960) o).ns.equals(ns) && ((class_2960) o).path.equals(path);
    }

    @Override
    public int hashCode() {
        return ns.hashCode() * 31 + path.hashCode();
    }

    @Override
    public String toString() {
        return ns + ":" + path;
    }
}
