package net.minecraft;

/** Test double of PacketCodec: a static factory from an encoder and a decoder, and encode/decode that call them. */
public final class class_9139<B, T> {
    public interface Encoder<B, T> {
        void encode(B buf, T value);
    }

    public interface Decoder<B, T> {
        T decode(B buf);
    }

    private final Encoder<B, T> encoder;
    private final Decoder<B, T> decoder;

    private class_9139(Encoder<B, T> encoder, Decoder<B, T> decoder) {
        this.encoder = encoder;
        this.decoder = decoder;
    }

    public static <B, T> class_9139<B, T> of(Encoder<B, T> encoder, Decoder<B, T> decoder) {
        return new class_9139<>(encoder, decoder);
    }

    public void encode(B buf, T value) {
        encoder.encode(buf, value);
    }

    public T decode(B buf) {
        return decoder.decode(buf);
    }
}
