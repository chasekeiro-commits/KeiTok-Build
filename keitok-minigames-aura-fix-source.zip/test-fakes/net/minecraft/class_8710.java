package net.minecraft;

/** Test double of CustomPayload: the one abstract method is getId(), and Id is nested the same way. */
public interface class_8710 {
    Id<? extends class_8710> getId();

    final class Id<T extends class_8710> {
        public final class_2960 identifier;

        public Id(class_2960 identifier) {
            this.identifier = identifier;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof Id && ((Id<?>) o).identifier.equals(identifier);
        }

        @Override
        public int hashCode() {
            return identifier.hashCode();
        }

        @Override
        public String toString() {
            return "Id[" + identifier + "]";
        }
    }
}
