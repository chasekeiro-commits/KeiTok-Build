package net.minecraft;

import com.mojang.authlib.GameProfile;
import java.util.UUID;

/** Test double of ServerPlayerEntity: only the profile getter the presence code uses. */
public class class_3222 {
    private final GameProfile profile;

    public class_3222(String name, UUID id) {
        this.profile = new GameProfile(id, name);
    }

    public GameProfile getGameProfile() {
        return profile;
    }
}
