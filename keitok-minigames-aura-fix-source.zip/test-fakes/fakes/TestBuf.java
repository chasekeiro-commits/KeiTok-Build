package fakes;

import io.netty.buffer.ByteBuf;
import java.io.ByteArrayOutputStream;

/** Test double of the network buffer: written bytes are read back after flip(). */
public final class TestBuf extends ByteBuf {
    private final ByteArrayOutputStream out = new ByteArrayOutputStream();
    private byte[] in = new byte[0];
    private int pos;

    public void flip() {
        in = out.toByteArray();
        pos = 0;
    }

    @Override
    public int readableBytes() {
        return in.length - pos;
    }

    @Override
    public ByteBuf readBytes(byte[] dst) {
        System.arraycopy(in, pos, dst, 0, dst.length);
        pos += dst.length;
        return this;
    }

    @Override
    public ByteBuf writeBytes(byte[] src) {
        out.write(src, 0, src.length);
        return this;
    }
}
