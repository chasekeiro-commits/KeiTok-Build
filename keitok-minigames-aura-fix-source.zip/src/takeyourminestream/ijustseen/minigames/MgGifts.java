package takeyourminestream.ijustseen.minigames;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * Built-in list of well-known TikTok gift names so they can be picked in the editor.
 * Any gift that arrives live is added automatically to the known list, so new gifts never need an update.
 */
public final class MgGifts {
    private MgGifts() {}

    public static final List<String> CATALOG = Collections.unmodifiableList(Arrays.asList(
        "Rose", "Rosa", "TikTok", "GG", "Heart Me", "Finger Heart", "Ice Cream Cone", "Hand Hearts", "Love You",
        "Thumbs Up", "Heart", "Doughnut", "Perfume", "Cap", "Hat and Mustache", "Sunglasses", "Corgi", "Confetti",
        "Paper Crane", "Galaxy", "Fire", "Little Crown", "Swan", "Money Gun", "Gem Gun", "Birthday Cake", "Glow Stick",
        "Hands Up", "Mirror", "Cheer You Up", "Pumpkin", "Pinch Face", "Music Play", "Marvelous Confetti", "Sceptre",
        "Boxing Gloves", "Wink Charm", "Flower Heart", "Lock and Key", "Hearts", "Love Painting", "Balloon Gift Box",
        "Gift Box", "Facial Mask", "Football", "Basketball", "Bowling", "Train", "Coral", "Star", "Diamond", "Crown",
        "Lion", "Universe", "TikTok Universe", "Drama Queen", "Sports Car", "Lamborghini", "Yacht", "Castle",
        "Rocket", "Interstellar", "Phoenix", "Dragon", "Falcon", "Whale Diving", "Flying Jets", "Leon the Kitten",
        "Gold Mine", "Garland", "Fireworks", "Concert", "Trumpet", "Guitar", "Piano", "Microphone", "Teddy Bear",
        "Panda", "Unicorn", "Butterfly", "Rainbow", "Sun", "Moon", "Lightning", "Cupid", "Love Bomb", "Kiss", "Wedding",
        "Party Horn", "Good Night", "Heart Hug", "TGIF", "Love Heart", "Dumbbell", "Happy Day", "Friday", "Coffee", "Photo", "Lollipop", "Seashell", "Hi", "Boombox", "I Heart U", "Game Controller", "Tennis Ball", "Hug", "Chocolate", "Going Viral", "Twin Hearts", "VR Glasses", "Ring", "Pastel Heart", "Seal", "Swing", "Flip Phone", "Inflatable Dancer", "Cactus", "Helmet", "Music Notes", "Gold Chain", "Ring Box", "Pool Party", "Cookie", "Crystal", "Love Wreath", "Happy Corgi", "Sailboat", "Astronaut", "Tropical Drinks", "Winner Podium", "Pearl", "Bunny", "Retro PC", "Dancing Corgi", "Blue Whale",
        "Ice cream", "Hand Heart", "Love you so much", "Ice Lolly", "SEA Shell", "Soccer", "Soccer Ball", "Applause", "I love you", "Press Start", "Tennis Love", "Power hug", "Fireball", "VR Goggles", "Diamond ring of love", "Budding Heart", "United Heart", "Heart Love Plate", "Cotton the Seal", "Naughty Chicken", "Relaxed Goose", "Butterfly for You", "Air Dancer", "Cactus Shuffle", "Hero's Helmet", "Anniversary Cake", "Golden Chain", "Gold necklace", "Beach Date", "Take My Rose!", "Astrobear"
    ));
}
