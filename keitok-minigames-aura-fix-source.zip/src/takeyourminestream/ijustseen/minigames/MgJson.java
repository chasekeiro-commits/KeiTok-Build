package takeyourminestream.ijustseen.minigames;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Tiny dependency-free JSON reader/writer used for the minigames config file. */
final class MgJson {
    private MgJson() {}

    static Object parse(String s) {
        P p = new P(s);
        Object v = p.value();
        return v;
    }

    private static final class P {
        final String s;
        int i;

        P(String s) { this.s = s; }

        void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }

        RuntimeException err(String m) { return new IllegalArgumentException("JSON: " + m + " at " + i); }

        void expect(char c) {
            ws();
            if (i >= s.length() || s.charAt(i) != c) throw err("expected '" + c + "'");
            i++;
        }

        Object value() {
            ws();
            if (i >= s.length()) throw err("unexpected end");
            char c = s.charAt(i);
            if (c == '{') {
                i++;
                Map<String, Object> m = new LinkedHashMap<>();
                ws();
                if (s.charAt(i) == '}') { i++; return m; }
                while (true) {
                    ws();
                    String k = str();
                    expect(':');
                    m.put(k, value());
                    ws();
                    char d = s.charAt(i++);
                    if (d == '}') break;
                    if (d != ',') throw err("expected ',' or '}'");
                }
                return m;
            }
            if (c == '[') {
                i++;
                List<Object> l = new ArrayList<>();
                ws();
                if (s.charAt(i) == ']') { i++; return l; }
                while (true) {
                    l.add(value());
                    ws();
                    char d = s.charAt(i++);
                    if (d == ']') break;
                    if (d != ',') throw err("expected ',' or ']'");
                }
                return l;
            }
            if (c == '"') return str();
            if (s.startsWith("true", i)) { i += 4; return Boolean.TRUE; }
            if (s.startsWith("false", i)) { i += 5; return Boolean.FALSE; }
            if (s.startsWith("null", i)) { i += 4; return null; }
            int st = i;
            while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
            if (st == i) throw err("unexpected character");
            String num = s.substring(st, i);
            try {
                if (num.indexOf('.') < 0 && num.indexOf('e') < 0 && num.indexOf('E') < 0) return Long.parseLong(num);
                return Double.parseDouble(num);
            } catch (NumberFormatException e) {
                throw err("bad number");
            }
        }

        String str() {
            ws();
            if (s.charAt(i) != '"') throw err("expected string");
            i++;
            StringBuilder b = new StringBuilder();
            while (true) {
                if (i >= s.length()) throw err("unterminated string");
                char c = s.charAt(i++);
                if (c == '"') break;
                if (c == '\\') {
                    char e = s.charAt(i++);
                    switch (e) {
                        case 'n': b.append('\n'); break;
                        case 't': b.append('\t'); break;
                        case 'r': b.append('\r'); break;
                        case 'b': b.append('\b'); break;
                        case 'f': b.append('\f'); break;
                        case 'u':
                            b.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                            i += 4;
                            break;
                        default: b.append(e);
                    }
                } else {
                    b.append(c);
                }
            }
            return b.toString();
        }
    }

    static String write(Object o) {
        StringBuilder b = new StringBuilder();
        w(b, o, 0);
        b.append('\n');
        return b.toString();
    }

    @SuppressWarnings("unchecked")
    private static void w(StringBuilder b, Object o, int ind) {
        if (o == null) { b.append("null"); return; }
        if (o instanceof String) { q(b, (String) o); return; }
        if (o instanceof Boolean || o instanceof Integer || o instanceof Long) { b.append(o); return; }
        if (o instanceof Number) { b.append(o); return; }
        if (o instanceof Map) {
            Map<String, Object> m = (Map<String, Object>) o;
            if (m.isEmpty()) { b.append("{}"); return; }
            b.append("{\n");
            int n = 0;
            for (Map.Entry<String, Object> e : m.entrySet()) {
                pad(b, ind + 1);
                q(b, e.getKey());
                b.append(": ");
                w(b, e.getValue(), ind + 1);
                if (++n < m.size()) b.append(',');
                b.append('\n');
            }
            pad(b, ind);
            b.append('}');
            return;
        }
        if (o instanceof List) {
            List<Object> l = (List<Object>) o;
            if (l.isEmpty()) { b.append("[]"); return; }
            b.append("[\n");
            for (int k = 0; k < l.size(); k++) {
                pad(b, ind + 1);
                w(b, l.get(k), ind + 1);
                if (k + 1 < l.size()) b.append(',');
                b.append('\n');
            }
            pad(b, ind);
            b.append(']');
            return;
        }
        q(b, String.valueOf(o));
    }

    private static void pad(StringBuilder b, int n) { for (int i = 0; i < n; i++) b.append("  "); }

    private static void q(StringBuilder b, String s) {
        b.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                default:
                    if (c < 0x20) b.append(String.format("\\u%04x", (int) c));
                    else b.append(c);
            }
        }
        b.append('"');
    }
}
