package takeyourminestream.ijustseen.minigames;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

/** Turns a rule + live event into the vanilla commands that get run as the player. */
public final class MgActions {
    private MgActions() {}

    public static String sub(String s, MgCtx c) {
        if (s == null) return "";
        return s.replace("{user}", c.user)
            .replace("{login}", c.login)
            .replace("{gift}", MgCtx.clean(c.gift, ""))
            .replace("{count}", Integer.toString(c.count))
            .replace("{likes}", Long.toString(c.likes))
            .replace("{amount}", "");
    }

    /** Message shown to the streamer (action bar). */
    public static String announceText(MgRule r, MgCtx c) {
        String m = r.message == null ? "" : r.message.trim();
        if (m.isEmpty()) {
            if (r.trigger == MgTrigger.GIFT) m = "{user} sent {gift} x{count}: " + r.action.label;
            else m = "{user}: " + r.trigger.label + " -> " + r.action.label;
        }
        return "§a[Minigames] §f" + sub(m, c).replace('§', '?');
    }

    public static List<String> build(MgRule r, MgCtx c, MgConfig cfg) {
        List<String> out = new ArrayList<>();
        int mult = r.perGiftCount ? Math.max(1, c.count) : 1;
        long total = (long) Math.max(1, r.amount) * mult;
        int n = (int) Math.min(total, Math.max(1, cfg.maxPerAction));
        int dur = Math.max(0, Math.min(r.duration, 3600));
        String arg = sub(r.arg == null ? "" : r.arg.trim(), c);

        switch (r.action) {
            case GIVE:
                if (!arg.isEmpty()) out.add("give @s " + id(arg) + " " + n);
                break;
            case SPAWN: {
                String ent = arg;
                String nbt = "";
                int bar = arg.indexOf('|');
                if (bar >= 0) {
                    ent = arg.substring(0, bar).trim();
                    nbt = " " + arg.substring(bar + 1).trim();
                }
                if (!ent.isEmpty()) {
                    for (int i = 0; i < n; i++) {
                        out.add("execute at @s run summon " + id(ent) + " " + off() + " ~ " + off() + nbt);
                    }
                }
                break;
            }
            case TNT: {
                // TNT explodes on its own when the fuse runs out: 0 seconds = right away. The fuse is a short (max 32767 ticks).
                int fuse = dur <= 0 ? 1 : Math.min(dur, 1600) * 20;
                for (int i = 0; i < n; i++) {
                    out.add("execute at @s run summon minecraft:tnt " + off() + " ~1 " + off() + " {fuse:" + fuse + "s}");
                }
                break;
            }
            case FREEZE: {
                int d = Math.max(1, dur);
                out.add("effect give @s minecraft:slowness " + d + " 255 true");
                out.add("attribute @s minecraft:jump_strength modifier remove minecraft:keitok_freeze");
                out.add("attribute @s minecraft:jump_strength modifier add minecraft:keitok_freeze -1 add_multiplied_total");
                out.add("#after " + (d * 1000L) + " attribute @s minecraft:jump_strength modifier remove minecraft:keitok_freeze");
                break;
            }
            case CLEAR_INVENTORY:
                out.add(arg.isEmpty() ? "clear @s" : "clear @s " + id(arg));
                break;
            case EFFECT: {
                if (!arg.isEmpty()) {
                    int level = Math.max(1, Math.min(r.amount, 255)) - 1;
                    out.add("effect give @s " + id(arg) + " " + Math.max(1, dur) + " " + level + " true");
                }
                break;
            }
            case RANDOM_TP: {
                int radius = 1000;
                try { radius = Integer.parseInt(arg.trim()); } catch (NumberFormatException ignored) { }
                radius = Math.max(64, Math.min(radius, 29999000));
                // spreadplayers only picks solid, non-liquid, non-fire ground; the effects are a safety net
                out.add("effect give @s minecraft:resistance 8 4 true");
                out.add("effect give @s minecraft:slow_falling 8 0 true");
                out.add("effect give @s minecraft:fire_resistance 8 0 true");
                out.add("effect give @s minecraft:water_breathing 8 0 true");
                out.add("execute at @s run spreadplayers ~ ~ 32 " + radius + " false @s");
                break;
            }
            case LIGHTNING:
                for (int i = 0; i < n; i++) {
                    out.add("execute at @s run summon minecraft:lightning_bolt ~ ~ ~");
                }
                break;
            case LAUNCH: {
                int d = Math.max(1, dur);
                int power = Math.max(1, Math.min(r.amount, 100));
                out.add("effect give @s minecraft:levitation " + d + " " + power + " true");
                out.add("effect give @s minecraft:slow_falling " + (d + 15) + " 0 true");
                break;
            }
            case HEAL:
                out.add("effect give @s minecraft:instant_health 1 10 true");
                out.add("effect give @s minecraft:saturation 1 20 true");
                break;
            case HURT:
                out.add("damage @s " + n + " minecraft:generic");
                break;
            case KILL:
                out.add("kill @s");
                break;
            case TIME: {
                String t = arg.toLowerCase(Locale.ROOT);
                if (t.isEmpty()) t = "day";
                out.add("time set " + t);
                break;
            }
            case WEATHER: {
                String w = arg.toLowerCase(Locale.ROOT);
                if (!w.equals("clear") && !w.equals("rain") && !w.equals("thunder")) w = "clear";
                out.add("weather " + w);
                break;
            }
            case XP: {
                boolean points = arg.toLowerCase(Locale.ROOT).startsWith("p");
                out.add("xp add @s " + n + (points ? " points" : " levels"));
                break;
            }
            case TITLE: {
                String text = arg.isEmpty() ? sub(r.message, c) : arg;
                if (text.isEmpty()) text = c.user;
                out.add("title @s title {\"text\":\"" + jsonEsc(text) + "\"}");
                break;
            }
            case SOUND:
                if (!arg.isEmpty()) out.add("playsound " + id(arg) + " master @s ~ ~ ~ 1 1");
                break;
            case COMMAND: {
                String raw = r.arg == null ? "" : r.arg;
                for (int rep = 0; rep < n; rep++) {
                    for (String part : raw.split(";;")) {
                        String cmd = sub(part.trim(), c).trim();
                        while (cmd.startsWith("/")) cmd = cmd.substring(1).trim();
                        if (!cmd.isEmpty()) out.add(cmd);
                    }
                }
                break;
            }
            case ALERT:
            default:
                break;
        }
        return out;
    }

    static String id(String s) {
        String v = s.trim().toLowerCase(Locale.ROOT).replace(' ', '_');
        return v.indexOf(':') >= 0 ? v : "minecraft:" + v;
    }

    private static String off() {
        ThreadLocalRandom r = ThreadLocalRandom.current();
        int v = r.nextInt(2, 6);
        return "~" + (r.nextBoolean() ? v : -v);
    }

    private static String jsonEsc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
}
