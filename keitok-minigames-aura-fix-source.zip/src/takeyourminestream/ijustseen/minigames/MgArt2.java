package takeyourminestream.ijustseen.minigames;

import static takeyourminestream.ijustseen.minigames.MgArt.TAU;
import static takeyourminestream.ijustseen.minigames.MgArt.cloud;
import static takeyourminestream.ijustseen.minigames.MgArt.wave;
import static takeyourminestream.ijustseen.minigames.MgSprites.A;
import static takeyourminestream.ijustseen.minigames.MgSprites.C;
import static takeyourminestream.ijustseen.minigames.MgSprites.mix;
import static takeyourminestream.ijustseen.minigames.MgSprites.rnd;
import static takeyourminestream.ijustseen.minigames.MgSprites.shade;

import takeyourminestream.ijustseen.minigames.MgSprites.Builder;
import takeyourminestream.ijustseen.minigames.MgSprites.Cv;

/** Pixel art for sakura bloom, emerald grove and solar flare. */
final class MgArt2 {
    private MgArt2() {}

    // ------------------------------------------------------------------ sakura bloom

    private static final int[] PINK = {C(0xD9719D), C(0xF28CB4), C(0xFFB3D1), C(0xFFE0EC)};
    private static final int BARK = C(0x5C3A2A), BARK2 = C(0x7A4E36), BARK3 = C(0x9A6A48);

    private static void sakuraTree(Cv c, int w, int h, double s, int seed) {
        // all numbers are for the big tree (80x86); s scales them for the small one
        int bx = (int) (50 * s), by = h - 1;
        c.thick(bx, by, bx - 1 * s, 62 * s, 3.2 * s, BARK);
        c.thick(bx - 1 * s, 62 * s, 46 * s, 44 * s, 2.4 * s, BARK);
        c.thick(46 * s, 44 * s, 44 * s, 30 * s, 1.6 * s, BARK);
        c.thick(49 * s, 58 * s, 30 * s, 40 * s, 1.6 * s, BARK); c.thick(30 * s, 40 * s, 22 * s, 30 * s, 1.0, BARK);
        c.thick(48 * s, 50 * s, 66 * s, 34 * s, 1.6 * s, BARK); c.thick(66 * s, 34 * s, 72 * s, 26 * s, 1.0, BARK);
        c.thick(46 * s, 40 * s, 58 * s, 22 * s, 1.4 * s, BARK);
        c.thick(bx, by, bx - 9 * s, by, 1.2, BARK); c.thick(bx, by, bx + 8 * s, by, 1.2, BARK);
        c.vl(bx - 1, (int) (62 * s), by, BARK3); c.vl((int) (bx - 2 * s), (int) (66 * s), by - 2, BARK3);
        c.vl(bx + (int) (2 * s), (int) (66 * s), by, shade(BARK, 0.7));
        int[][] bl = {{22, 28, 8}, {66, 38, 11}, {30, 40, 11}, {40, 26, 13}, {58, 22, 12}, {47, 12, 11}, {48, 36, 13}, {70, 24, 8}, {58, 34, 10}, {36, 14, 8}};
        for (int i = 0; i < bl.length; i++) c.blob((int) (bl[i][0] * s), (int) (bl[i][1] * s), Math.max(3, (int) (bl[i][2] * s)), PINK, seed + i * 7);
        // a few bark branches in front, falling petals around
        c.thick(44 * s, 40 * s, 52 * s, 30 * s, 1.0, BARK);
        for (int i = 0; i < (int) (26 * s); i++) {
            int x = (int) (rnd(i, 1, seed) * w), y = (int) (30 * s + rnd(i, 2, seed) * (h - 30 * s));
            if ((c.get(x, y) >>> 24) == 0) c.px(x, y, i % 3 == 0 ? C(0xFFE0EC) : C(0xFFB3D1));
        }
    }

    static void sakura(Builder b) {
        b.add("tree", 80, 86, c -> sakuraTree(c, 80, 86, 1.0, 3));
        b.add("treeS", 44, 48, c -> sakuraTree(c, 44, 48, 0.55, 9));
        b.add("branchT", 64, 24, c -> {
            c.wrap = true;
            for (int x = 0; x < 64; x++) {
                int y = 2 + (int) Math.round(wave(x, 64, 0, new double[]{1.2, 0.8}, new int[]{1, 3}, new double[]{0, 1.4}));
                c.px(x, y, BARK); c.px(x, y + 1, BARK2); if (x % 3 == 0) c.px(x, y - 1, BARK3);
            }
            int[] hx = {8, 24, 41, 56}, hl = {8, 12, 7, 10};
            for (int i = 0; i < 4; i++) {
                int x = hx[i], y0 = 4;
                for (int j = 0; j < hl[i]; j++) c.px(x + (int) Math.round(Math.sin(j * 0.5 + i) * 0.8), y0 + j, C(0x4C8F56));
                c.blob(x, y0 + hl[i] + 1, 3, PINK, 11 + i);
                c.blob(x - 3, y0 + hl[i] - 3, 2, PINK, 21 + i);
                c.blob(x + 3, y0 + hl[i] - 5, 2, PINK, 31 + i);
                c.px(x - 4, y0 + 3, C(0x5BAA64)); c.px(x - 5, y0 + 2, C(0x5BAA64)); c.px(x + 4, y0 + 4, C(0x3E8A4E)); c.px(x + 5, y0 + 3, C(0x5BAA64));
            }
            for (int i = 0; i < 9; i++) c.px((int) (rnd(i, 3, 5) * 64), 3 + (int) (rnd(i, 4, 5) * 3), C(0xFFD0E2));
        });
        b.add("ground", 64, 14, c -> {
            c.wrap = true;
            for (int x = 0; x < 64; x++) {
                int top = 7 + (int) Math.round(Math.sin(TAU * x / 64.0) * 1.3 + Math.sin(TAU * 4 * x / 64.0 + 1) * 0.8);
                for (int y = top; y < 14; y++) c.px(x, y, mix(C(0x58A662), C(0x2F6A3E), (y - top) / (double) Math.max(1, 14 - top)));
                int blade = 1 + (int) (rnd(x, 1, 8) * 3.5);
                for (int k = 1; k <= blade; k++) c.px(x, top - k, k == blade ? C(0x8AD488) : C(0x58A662));
            }
            for (int i = 0; i < 18; i++) {
                int x = (int) (rnd(i, 1, 13) * 64), y = 7 + (int) (rnd(i, 2, 13) * 6);
                c.px(x, y, C(0xFFC4DD)); if (i % 2 == 0) c.px(x + 1, y, C(0xFFE0EC));
            }
            c.px(12, 3, C(0xFFFFFF)); c.px(12, 4, C(0xFFE066)); c.px(33, 2, C(0xFFE0EC)); c.px(33, 3, C(0xFFB3D1)); c.px(53, 3, C(0xFFFFFF)); c.px(53, 4, C(0xFFE066));
        });
        b.add("torii", 32, 38, c -> {
            int v = C(0xD8412F), vl = C(0xF0614A), vd = C(0xA02A1E), k = C(0x241818);
            for (int y = 11; y < 38; y++) {
                c.rect(5, y, 4, 1, v); c.px(5, y, vl); c.px(8, y, vd);
                c.rect(23, y, 4, 1, v); c.px(23, y, vl); c.px(26, y, vd);
            }
            c.rect(4, 35, 6, 3, k); c.rect(22, 35, 6, 3, k);
            for (int x = 0; x < 32; x++) {
                int up = (x < 4 || x > 27) ? 1 : (x < 7 || x > 24 ? 0 : 0);
                c.rect(x, 3 - up, 1, 3, v); c.px(x, 3 - up, vl); c.px(x, 5 - up, vd);
                c.px(x, 2 - up, k);
                if (x > 1 && x < 30) c.px(x, 1, k);
            }
            c.rect(3, 10, 26, 3, v); c.hl(3, 28, 10, vl); c.hl(3, 28, 12, vd);
            c.rect(14, 6, 4, 6, k); c.rect(15, 7, 2, 4, C(0xE8C050));
        });
        b.add("lantern", 12, 22, c -> {
            int g = C(0x9A9AA6), d = C(0x6A6A78), l = C(0xC0C0CC);
            c.rect(2, 19, 8, 3, d); c.rect(3, 18, 6, 1, g);
            c.rect(5, 11, 2, 7, g); c.px(5, 11, l);
            c.rect(2, 6, 8, 5, d); c.rect(3, 7, 6, 3, C(0xFFD98A)); c.px(4, 8, C(0xFFF2C8)); c.vl(6, 7, 9, C(0x6A4A20));
            c.tri(6, 0, 0, 6, 12, 6, g); c.tri(6, 0, 0, 6, 5, 6, l); c.hl(0, 11, 6, d);
            c.px(6, 0, d);
        });
        b.add("fuji", 80, 28, c -> {
            for (int x = 0; x < 80; x++) {
                double p = 1 - Math.abs(x - 40) / 40.0;
                int top = 27 - (int) Math.round(25 * Math.pow(Math.max(0, p), 1.25) + (rnd(x, 1, 6) - 0.5) * 1.4);
                for (int y = Math.max(0, top); y < 28; y++) {
                    int col = x > 40 ? C(0x6B79AA) : C(0x8392C0);
                    if (y < top + 9 + (int) (rnd(x, 2, 6) * 4 - 2) && p > 0.34) col = x > 40 ? C(0xDDE3F6) : C(0xFAFBFF);
                    c.px(x, y, col);
                }
            }
        });
        b.add("sun", 26, 26, c -> {
            c.disc(13, 13, 11, C(0xFFD9E6));
            for (int y = 0; y < 26; y++) for (int x = 0; x < 26; x++) {
                int p = c.get(x, y);
                if ((p >>> 24) == 0) continue;
                double d = Math.hypot(x - 13, y - 13) / 11.0;
                c.set(x, y, mix(C(0xFFF4F8), C(0xFFC4D8), d * d));
            }
        });
        b.add("cloudP", 36, 11, c -> cloud(c, new int[]{8, 16, 24, 30}, new int[]{7, 5, 6, 8}, new int[]{5, 6, 5, 4}, C(0xFFEAF3), 0xE0A8C4, 9));
        b.frames("petal", 4, 5, 5, (c, f) -> {
            double a = f * Math.PI / 4;
            for (int y = 0; y < 5; y++) for (int x = 0; x < 5; x++) {
                double dx = x - 2, dy = y - 2;
                double u = dx * Math.cos(a) + dy * Math.sin(a), v = -dx * Math.sin(a) + dy * Math.cos(a);
                if ((u / 2.4) * (u / 2.4) + (v / 1.4) * (v / 1.4) <= 1.0) c.px(x, y, v > 0 ? C(0xFFB3D1) : C(0xFFD6E6));
            }
        });
        b.add("edgeT", 64, 6, c -> {
            c.wrap = true;
            for (int x = 0; x < 64; x++) { int y = (int) Math.round(Math.sin(TAU * 2 * x / 64.0) * 0.8); c.px(x, y, BARK); if (x % 3 == 0) c.px(x, y + 1, BARK2); }
            for (int x : new int[]{10, 31, 52}) {
                c.px(x, 1, C(0x4C8F56)); c.px(x, 2, C(0x4C8F56));
                c.disc(x, 4, 1, C(0xFFB3D1)); c.px(x, 4, C(0xFFE0EC)); c.px(x - 2, 3, C(0xFFD0E2)); c.px(x + 2, 4, C(0xFFB3D1));
            }
        });
        b.add("edgeB", 64, 6, c -> {
            c.wrap = true;
            for (int x = 0; x < 64; x++) {
                int top = 3 + (int) Math.round(Math.sin(TAU * 3 * x / 64.0) * 0.8);
                for (int y = top; y < 6; y++) c.px(x, y, mix(C(0x58A662), C(0x2F6A3E), (y - top) / 3.0));
                int blade = 1 + (int) (rnd(x, 1, 8) * 2.5);
                for (int k = 1; k <= blade; k++) c.px(x, top - k, k == blade ? C(0x8AD488) : C(0x58A662));
            }
            for (int i = 0; i < 10; i++) c.px((int) (rnd(i, 1, 14) * 64), 3 + (int) (rnd(i, 2, 14) * 3), i % 2 == 0 ? C(0xFFC4DD) : C(0xFFE0EC));
        });
        b.corners("cs", 11, 11, c -> {
            for (int k = 0; k < 5; k++) {
                double a = -Math.PI / 2 + k * TAU / 5;
                c.disc(4 + (int) Math.round(Math.cos(a) * 2.4), 4 + (int) Math.round(Math.sin(a) * 2.4), 1, k % 2 == 0 ? C(0xFFB3D1) : C(0xFFD0E2));
            }
            c.px(4, 4, C(0xFFE066)); c.px(4, 3, C(0xFFC84A));
            c.hl(7, 10, 0, A(0xFFFFFF, 0.6)); c.vl(0, 7, 10, A(0xFFFFFF, 0.6));
        });
    }

    // ------------------------------------------------------------------ emerald grove

    private static final int[] LEAF = {C(0x1F7A3C), C(0x2F9E4F), C(0x4CC468), C(0x8BE88A)};

    private static void oak(Cv c, int w, int h, double s, int seed) {
        int bx = (int) (48 * s), by = h - 1;
        c.thick(bx, by, bx, 58 * s, 4.2 * s, C(0x4A3320));
        c.thick(bx, 58 * s, 46 * s, 44 * s, 3.0 * s, C(0x4A3320));
        c.thick(bx - 1, 52 * s, 28 * s, 36 * s, 2.0 * s, C(0x4A3320)); c.thick(bx + 1, 50 * s, 68 * s, 34 * s, 2.0 * s, C(0x4A3320));
        c.thick(bx, by, bx - 11 * s, by, 1.5, C(0x4A3320)); c.thick(bx, by, bx + 11 * s, by, 1.5, C(0x4A3320));
        c.vl(bx - (int) (3 * s), (int) (60 * s), by, C(0x7A5A38)); c.vl(bx - (int) (2 * s), (int) (66 * s), by - 2, C(0x6A4A2E));
        c.vl(bx + (int) (3 * s), (int) (62 * s), by, C(0x34240F));
        c.rect(bx - 1, (int) (70 * s), 3, 4, C(0x1F150A));
        int[][] bl = {{44, 30, 17}, {66, 34, 15}, {26, 42, 13}, {58, 16, 13}, {20, 28, 10}, {76, 22, 9}, {80, 46, 8}, {12, 50, 8}, {40, 8, 9}, {50, 44, 12}};
        for (int i = 0; i < bl.length; i++) c.blob((int) (bl[i][0] * s), (int) (bl[i][1] * s), Math.max(4, (int) (bl[i][2] * s)), LEAF, seed + i * 5);
        // hanging moss / vines under the canopy
        for (int i = 0; i < (int) (9 * s) + 2; i++) {
            int x = (int) (rnd(i, 3, seed) * (w - 6)) + 3, y0 = (int) (30 * s + rnd(i, 4, seed) * 22 * s);
            int len = 4 + (int) (rnd(i, 5, seed) * 10 * s);
            for (int j = 0; j < len; j++) c.px(x + (int) Math.round(Math.sin(j * 0.6 + i)), y0 + j, j % 4 == 3 ? C(0x8BE88A) : C(0x3FB85A));
        }
    }

    static void grove(Builder b) {
        b.add("oak", 90, 94, c -> oak(c, 90, 94, 1.0, 5));
        b.add("oakS", 50, 52, c -> oak(c, 50, 52, 0.55, 11));
        b.frames("vines", 3, 64, 30, (c, f) -> {
            c.wrap = true;
            for (int x = 0; x < 64; x++) {
                int hgt = 2 + (int) Math.round(vn(x, 7) * 2.4);
                for (int y = 0; y < hgt; y++) c.px(x, y, LEAF[Math.min(3, (int) (rnd(x, y, 4) * 3.2) + (y == hgt - 1 ? 0 : 1))]);
            }
            int[] vx = {4, 12, 21, 29, 37, 46, 54, 61}, vl = {10, 22, 14, 27, 12, 20, 9, 17};
            for (int i = 0; i < vx.length; i++) {
                for (int j = 0; j < vl[i]; j++) {
                    int x = vx[i] + (int) Math.round(Math.sin(f * 2.09 + j * 0.28 + i) * Math.min(1.6, j * 0.12));
                    c.px(x, 3 + j, j % 5 == 4 ? C(0x8BE88A) : C(0x3FB85A));
                    if (j % 6 == 3) { c.px(x + 1, 3 + j, C(0x4CC468)); c.px(x + 2, 3 + j + 1, C(0x2F9E4F)); }
                    if (j % 6 == 0 && j > 0) { c.px(x - 1, 3 + j, C(0x4CC468)); c.px(x - 2, 3 + j + 1, C(0x2F9E4F)); }
                }
                int ex = vx[i] + (int) Math.round(Math.sin(f * 2.09 + vl[i] * 0.28 + i) * Math.min(1.6, vl[i] * 0.12));
                c.px(ex, 3 + vl[i], i % 3 == 0 ? C(0xFF6A8A) : C(0x8BE88A)); c.px(ex, 4 + vl[i], i % 3 == 0 ? C(0xC02A5A) : C(0x4CC468));
            }
        });
        b.add("ground", 64, 20, c -> {
            c.wrap = true;
            for (int x = 0; x < 64; x++) {
                int top = 9 + (int) Math.round(Math.sin(TAU * x / 64.0) * 1.4 + Math.sin(TAU * 3 * x / 64.0 + 2) * 1.0);
                for (int y = top; y < 20; y++) c.px(x, y, mix(C(0x3FA650), C(0x1D5A2E), (y - top) / (double) Math.max(1, 20 - top)));
                int blade = 1 + (int) (rnd(x, 1, 3) * 4.5);
                for (int k = 1; k <= blade; k++) c.px(x, top - k, k == blade ? C(0x8BE88A) : (k % 2 == 0 ? C(0x4CC468) : C(0x2F9E4F)));
            }
            // red mushroom
            c.rect(19, 9, 2, 5, C(0xF2E8D0)); c.ell(20, 8, 3, 2, C(0xE23A3A)); c.px(18, 7, C(0xFFFFFF)); c.px(21, 8, C(0xFFFFFF)); c.px(20, 6, C(0xFFFFFF));
            // glowing blue mushroom (the glow is drawn on top while the picture runs)
            c.rect(46, 9, 2, 5, C(0xD6F5F0)); c.ell(47, 8, 3, 2, C(0x4FE0D0)); c.px(46, 7, C(0xCFFFF8)); c.px(48, 8, C(0xCFFFF8));
            // little flowers
            c.px(8, 4, C(0xFFE066)); c.px(8, 5, C(0x2F9E4F)); c.px(33, 3, C(0xFFFFFF)); c.px(33, 4, C(0x2F9E4F)); c.px(57, 5, C(0xFF8AB0)); c.px(57, 6, C(0x2F9E4F));
        });
        b.add("fern", 24, 18, c -> {
            for (int k = 0; k < 7; k++) {
                double a = -Math.PI / 2 - 1.15 + k * 0.38;
                for (int r = 1; r < 14 - Math.abs(k - 3); r++) {
                    int x = 12 + (int) Math.round(Math.cos(a) * r), y = 17 + (int) Math.round(Math.sin(a) * r * 0.9);
                    c.px(x, y, r % 2 == 0 ? C(0x2F9E4F) : C(0x4CC468));
                    if (r % 2 == 0) { c.px(x - 1, y, C(0x1F7A3C)); c.px(x + 1, y, C(0x8BE88A)); }
                }
            }
        });
        b.add("log", 32, 12, c -> {
            c.rect(4, 3, 26, 8, C(0x5A3C22)); c.hl(4, 29, 3, C(0x7A5A38)); c.hl(4, 29, 10, C(0x3A2412));
            for (int x = 5; x < 29; x += 3) c.px(x, 6 + (x % 2), C(0x4A3018));
            c.ell(4, 7, 3, 4, C(0xC89A64)); c.ring(4, 7, 2, C(0x8A6240)); c.px(4, 7, C(0x8A6240));
            for (int x = 8; x < 28; x++) if (rnd(x, 1, 3) < 0.55) c.px(x, 2, C(0x5FA83A));
            c.rect(20, 0, 2, 3, C(0xF2E8D0)); c.ell(21, 0, 2, 1, C(0xE23A3A)); c.px(20, 0, C(0xFFFFFF));
        });
        b.framesPair("bird", 3, 11, 8, (c, f) -> {
            int body = C(0x3FB0C8), belly = C(0xE8F6D0), dk = C(0x1F6A80);
            c.ell(6, 4, 3, 2, body); c.hl(4, 8, 5, belly);
            c.px(9, 3, body); c.px(10, 3, C(0xFFB84D)); c.px(9, 2, C(0x102030));
            c.tri(3, 3, 0, 5, 3, 5, dk);
            if (f == 0) c.tri(6, 3, 3, -1, 7, 2, dk); else if (f == 1) c.tri(6, 3, 2, 3, 6, 4, dk); else c.tri(6, 5, 3, 8, 7, 5, dk);
        });
        b.frames("leaf", 4, 6, 5, (c, f) -> {
            double a = f * Math.PI / 4;
            for (int y = 0; y < 5; y++) for (int x = 0; x < 6; x++) {
                double dx = x - 2.5, dy = y - 2;
                double u = dx * Math.cos(a) + dy * Math.sin(a), v = -dx * Math.sin(a) + dy * Math.cos(a);
                if ((u / 2.8) * (u / 2.8) + (v / 1.4) * (v / 1.4) <= 1.0) c.px(x, y, v > 0.3 ? C(0x2F9E4F) : C(0x6AD07A));
            }
        });
        b.add("edgeT", 64, 6, c -> {
            c.wrap = true;
            for (int x = 0; x < 64; x++) {
                int hgt = 2 + (int) Math.round(MgSprites.vnoise(x / 4.0, 16, 9) * 3);
                for (int y = 0; y < hgt; y++) c.px(x, y, LEAF[Math.min(3, (int) (rnd(x, y, 6) * 3.2) + (y == hgt - 1 ? 0 : 1))]);
            }
        });
        b.add("edgeB", 64, 6, c -> {
            c.wrap = true;
            for (int x = 0; x < 64; x++) {
                int top = 3 + (int) Math.round(Math.sin(TAU * 2 * x / 64.0) * 0.8);
                for (int y = top; y < 6; y++) c.px(x, y, mix(C(0x3FA650), C(0x1D5A2E), (y - top) / 3.0));
                int blade = 1 + (int) (rnd(x, 1, 3) * 3.5);
                for (int k = 1; k <= blade; k++) c.px(x, top - k, k == blade ? C(0x8BE88A) : (k % 2 == 0 ? C(0x4CC468) : C(0x2F9E4F)));
            }
            c.px(12, 0, C(0xFFE066)); c.px(34, 1, C(0xFFFFFF)); c.px(50, 0, C(0xFF8AB0)); c.px(23, 1, C(0xFFE066));
        });
        b.corners("cg", 11, 11, c -> {
            c.hl(0, 9, 0, A(0xFFFFFF, 0.8)); c.vl(0, 0, 9, A(0xFFFFFF, 0.8));
            c.ell(4, 3, 2, 1, 0xFFFFFFFF); c.ell(3, 5, 1, 2, A(0xFFFFFF, 0.85)); c.px(2, 2, A(0xFFFFFF, 0.6)); c.px(6, 5, A(0xFFFFFF, 0.4));
        });
    }

    private static double vn(int x, int seed) { return MgSprites.vnoise(x / 4.0, 16, seed); }

    // ------------------------------------------------------------------ solar flare

    static void solar(Builder b) {
        b.add("sun", 36, 36, c -> {
            c.disc(18, 18, 14, C(0xFF9A22));
            for (int y = 0; y < 36; y++) for (int x = 0; x < 36; x++) {
                int p = c.get(x, y);
                if ((p >>> 24) == 0) continue;
                double d = Math.hypot(x - 18, y - 18) / 14.0;
                int col = mix(C(0xFFF6C8), C(0xFF8A1A), Math.pow(d, 1.6));
                if (rnd(x, y, 5) < 0.10) col = shade(col, 0.9);
                c.set(x, y, col);
            }
            c.ring(18, 18, 14, C(0xFF6A14));
            c.disc(22, 14, 1, C(0xE87A18)); c.px(13, 21, C(0xE87A18)); c.px(14, 21, C(0xE87A18));
        });
        b.frames("rays", 3, 64, 64, (c, f) -> {
            for (int k = 0; k < 16; k++) {
                double a = k * TAU / 16 + f * TAU / 48;
                double r0 = 16.5, r1 = (k % 2 == 0) ? 29 : 24;
                double wdt = 0.11;
                double ax = 32 + Math.cos(a - wdt) * r0, ay = 32 + Math.sin(a - wdt) * r0;
                double bx = 32 + Math.cos(a + wdt) * r0, by = 32 + Math.sin(a + wdt) * r0;
                double tx = 32 + Math.cos(a) * r1, ty = 32 + Math.sin(a) * r1;
                c.tri(ax, ay, bx, by, tx, ty, C(0xFF8A1A));
                double r2 = r0 + (r1 - r0) * 0.55;
                double ix = 32 + Math.cos(a) * r2, iy = 32 + Math.sin(a) * r2;
                c.tri(32 + Math.cos(a - wdt * 0.5) * r0, 32 + Math.sin(a - wdt * 0.5) * r0, 32 + Math.cos(a + wdt * 0.5) * r0, 32 + Math.sin(a + wdt * 0.5) * r0, ix, iy, C(0xFFD060));
            }
        });
        b.add("volcano", 72, 48, c -> {
            for (int x = 0; x < 72; x++) {
                double p = 1 - Math.abs(x - 36) / 40.0;
                int top = 47 - (int) Math.round(Math.min(40, 62 * Math.pow(Math.max(0, p), 1.1)) + (rnd(x, 1, 7) - 0.5) * 1.6);
                if (x > 28 && x < 44) top = Math.max(top, 8 + Math.abs(x - 36) / 3);
                for (int y = Math.max(0, top); y < 48; y++) {
                    double t = (y - top) / 40.0;
                    int col = mix(x < 36 ? C(0x5A382C) : C(0x3A2018), C(0x1E0E0A), Math.min(1, t));
                    if (rnd(x, y, 3) < 0.12) col = shade(col, 0.82);
                    c.px(x, y, col);
                }
            }
            c.ell(36, 9, 6, 2, C(0xFFB02E)); c.ell(36, 9, 3, 1, C(0xFFEB8A));
            int[][] st = {{34, 10}, {32, 20}, {35, 30}, {30, 40}, {37, 12}, {40, 24}, {38, 36}, {44, 46}};
            for (int i = 0; i + 1 < 4; i++) c.thick(st[i][0], st[i][1], st[i + 1][0], st[i + 1][1], 0.6, C(0xFF7A1A));
            c.thick(37, 12, 40, 24, 0.6, C(0xFF7A1A)); c.thick(40, 24, 38, 36, 0.6, C(0xFF7A1A)); c.thick(38, 36, 44, 46, 0.6, C(0xFF7A1A));
            for (int i = 0; i + 1 < 4; i++) c.line(st[i][0], st[i][1], st[i + 1][0], st[i + 1][1], C(0xFFD060));
        });
        b.frames("flame", 4, 64, 26, (c, f) -> {
            c.wrap = true;
            double[] h = new double[8];
            for (int k = 0; k < 8; k++) h[k] = 7 + rnd(k, f, 21) * 13;
            for (int x = 0; x < 64; x++) {
                double top = 0;
                for (int k = -1; k <= 8; k++) {
                    int idx = Math.floorMod(k, 8);
                    double cx = k * 8 + 4 + (rnd(idx, f, 22) - 0.5) * 3;
                    double dx = Math.abs(x - cx) / 4.6;
                    if (dx < 1) top = Math.max(top, h[idx] * Math.pow(1 - dx, 0.8));
                }
                top = Math.max(top, 4 + rnd(x, f, 23) * 2);
                for (int y = 0; y < top; y++) {
                    double t = y / Math.max(1, top);
                    int col = t < 0.28 ? C(0xFFF2B0) : (t < 0.55 ? C(0xFFB02E) : (t < 0.8 ? C(0xFF5A14) : C(0xC02A0A)));
                    if (t > 0.75 && rnd(x, y, 24 + f) < 0.4) continue;
                    c.px(x, 25 - y, col);
                }
            }
        });
        b.add("rock", 64, 14, c -> {
            c.wrap = true;
            for (int x = 0; x < 64; x++) {
                int top = 4 + (int) Math.round(Math.sin(TAU * x / 64.0) * 1.5 + Math.sin(TAU * 5 * x / 64.0 + 1) * 1.1);
                for (int y = top; y < 14; y++) {
                    int col = mix(C(0x4A2A20), C(0x1E0E0A), (y - top) / (double) Math.max(1, 14 - top));
                    if (rnd(x, y, 8) < 0.15) col = shade(col, 0.8);
                    c.px(x, y, col);
                }
                c.px(x, top, C(0x7A4A38));
            }
            int cy = 9;
            for (int x = 0; x < 64; x++) {
                int y = cy + (int) Math.round(Math.sin(TAU * 2 * x / 64.0) * 1.6);
                c.px(x, y, C(0xFF7A1A)); if (x % 3 == 0) c.px(x, y - 1, A(0xFFC247, 0.7));
            }
        });
        b.frames("phoenix", 3, 32, 18, (c, f) -> {
            int red = C(0xE23A14), org = C(0xFF8A1A), yel = C(0xFFD060);
            c.tri(12, 9, 0, 6, 1, 12, red); c.tri(12, 9, 2, 9, 4, 15, org); c.tri(12, 9, 3, 4, 5, 8, org);
            c.ell(15, 9, 5, 2, org); c.hl(12, 18, 9, yel);
            c.ell(21, 7, 2, 2, org); c.px(24, 7, yel); c.px(25, 7, C(0xFFE9A0)); c.px(22, 6, C(0x300A00));
            c.tri(21, 5, 20, 2, 23, 5, red);
            if (f == 0) { c.tri(13, 8, 7, 0, 18, 7, red); c.tri(14, 8, 10, 1, 18, 7, org); }
            else if (f == 1) { c.tri(13, 9, 4, 6, 18, 9, red); c.tri(14, 9, 8, 7, 18, 9, org); }
            else { c.tri(13, 10, 6, 17, 18, 10, red); c.tri(14, 10, 9, 15, 18, 10, org); }
        });
        b.add("ash", 36, 11, c -> cloud(c, new int[]{8, 16, 24, 30}, new int[]{7, 5, 6, 8}, new int[]{5, 6, 5, 4}, C(0x7A3A2C), 0x2A1210, 9));
        b.add("edgeT", 64, 6, c -> {
            c.wrap = true;
            for (int i = 0; i < 10; i++) {
                int x = (int) (rnd(i, 1, 51) * 64), len = 1 + (int) (rnd(i, 2, 51) * 4);
                for (int j = 0; j < len; j++) c.px(x, j, mix(C(0xFFB02E), C(0xFF5A14), j / (double) Math.max(1, len)));
                c.px(x, len, C(0xFFE066));
            }
        });
        b.frames("edgeB", 2, 64, 7, (c, f) -> {
            c.wrap = true;
            for (int x = 0; x < 64; x++) {
                double hh = 2 + 4 * Math.max(0, Math.sin(x * 0.9 + f * 2.4) * Math.sin(x * 0.37 + f * 1.1)) + rnd(x, f, 9) * 1.2;
                hh = Math.min(7, hh);
                for (int y = 0; y < hh; y++) {
                    double t = y / hh;
                    c.px(x, 6 - y, t < 0.3 ? C(0xFFE066) : (t < 0.65 ? C(0xFF8A1F) : C(0xFF4A1A)));
                }
            }
        });
        b.corners("cf", 11, 11, c -> {
            c.hl(0, 9, 0, 0xFFFFFFFF); c.vl(0, 0, 9, 0xFFFFFFFF);
            c.px(2, 3, 0xFFFFFFFF); c.px(2, 2, A(0xFFFFFF, 0.8)); c.px(3, 2, A(0xFFFFFF, 0.8)); c.px(3, 3, A(0xFFFFFF, 0.6)); c.px(2, 4, A(0xFFFFFF, 0.5)); c.px(4, 3, A(0xFFFFFF, 0.4));
        });
    }
}
