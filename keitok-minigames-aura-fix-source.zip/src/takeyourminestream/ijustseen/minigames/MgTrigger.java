package takeyourminestream.ijustseen.minigames;

/** What kind of live event starts a rule. */
public enum MgTrigger {
    GIFT("Gift", "Gift name (Rose, Galaxy...). Use * for ANY gift. Separate several with commas.", "*"),
    FOLLOW("New follower", "Not used.", ""),
    SHARE("Stream share", "Not used.", ""),
    LIKES("Likes milestone", "Fire every N likes (e.g. 100, 1000, 10000).", "1000"),
    SUBSCRIBE("Subscriber", "Not used.", ""),
    JOIN("Viewer joins", "Not used (can be spammy in big streams).", ""),
    CHAT("Chat keyword", "Word or command in chat, e.g. !tnt . Commas = alternatives.", "!tnt"),
    BITS("Bits / cheer", "Not used.", ""),
    RAID("Raid", "Not used.", "");

    public final String label;
    public final String matchHint;
    public final String defaultMatch;

    MgTrigger(String label, String matchHint, String defaultMatch) {
        this.label = label;
        this.matchHint = matchHint;
        this.defaultMatch = defaultMatch;
    }

    public MgTrigger next() {
        MgTrigger[] v = values();
        return v[(ordinal() + 1) % v.length];
    }

    public MgTrigger prev() {
        MgTrigger[] v = values();
        return v[(ordinal() + v.length - 1) % v.length];
    }

    public static MgTrigger parse(String s) {
        if (s != null) {
            for (MgTrigger t : values()) {
                if (t.name().equalsIgnoreCase(s.trim())) return t;
            }
        }
        return GIFT;
    }
}
