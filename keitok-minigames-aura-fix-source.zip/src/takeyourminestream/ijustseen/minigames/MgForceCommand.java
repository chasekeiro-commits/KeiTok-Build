package takeyourminestream.ijustseen.minigames;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.context.CommandContext;

/** /keitok force - turns Interactive Minigames on and skips the cheats check (for when it wrongly thinks cheats are off). */
@SuppressWarnings({"rawtypes", "unchecked"})
public final class MgForceCommand implements Command {
    @Override
    public int run(CommandContext ctx) {
        MgConfig cfg = MgConfig.get();
        cfg.enabled = true;
        cfg.save();
        MgBridge.forced = true;
        String st = MgBridge.status();
        if (MgBridge.READY.equals(st)) {
            if (MgBridge.onMultiplayer()) {
                MgBridge.chat("§a[Minigames] Forced ON on this server. Alerts, win counter and HUD work; commands need operator rights.");
            } else {
                MgBridge.chat("§a[Minigames] Forced ON - cheats check skipped. Rules will now run as you.");
            }
        } else {
            MgBridge.chat("§c[Minigames] Force set, but: " + MgBridge.statusText(st));
        }
        return 1;
    }
}
