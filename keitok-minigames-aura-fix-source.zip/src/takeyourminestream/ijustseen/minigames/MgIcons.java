package takeyourminestream.ijustseen.minigames;

import java.util.Locale;
import net.minecraft.class_332;

/** Tiny pixel-art icons drawn with plain rectangles (no textures needed). */
public final class MgIcons {
    private MgIcons() {}

    private static final String[] HEART = {".aa..aa.", "aaaaaaaa", "aaaaaaaa", "aaaaaaaa", ".aaaaaa.", "..aaaa..", "...aa...", "........"};
    private static final String[] PERSON = {"..aaaa..", ".aaaaaa.", ".aaaaaa.", "..aaaa..", ".aaaaaa.", "aaaaaaaa", "aaaaaaaa", "aaaaaaaa"};
    private static final String[] FACE = {"aaaaaaaa", "aaaaaaaa", "akkaakka", "akkaakka", "aaaaaaaa", "aakkkkaa", "aakaakaa", "aaaaaaaa"};
    private static final String[] BOX = {"..b..b..", "...bb...", "aaaabaaa", "aaaabaaa", "bbbbbbbb", "aaaabaaa", "aaaabaaa", "aaaabaaa"};
    private static final String[] TNT = {"aaaaaaaa", "aaaaaaaa", "bbbbbbbb", "bkkbkkbk", "bbbbbbbb", "aaaaaaaa", "aaaaaaaa", "aaaaaaaa"};
    private static final String[] BOLT = {"...aaa..", "..aaa...", ".aaa....", ".aaaaaa.", "...aaa..", "..aa....", ".a......", "a......."};
    private static final String[] SNOW = {"a..a..a.", ".a.a.a..", "..aaa...", "aaaaaaa.", "..aaa...", ".a.a.a..", "a..a..a.", "........"};
    private static final String[] GRID = {"aa.aa.aa", "aa.aa.aa", "........", "aa.aa.aa", "aa.aa.aa", "........", "aa.aa.aa", "aa.aa.aa"};
    private static final String[] STAR = {"...aa...", "...aa...", "aaaaaaaa", ".aaaaaa.", "..aaaa..", ".aaaaaa.", ".aa..aa.", "........"};
    private static final String[] BUBBLE = {"aaaaaaaa", "aaaaaaaa", "aaaaaaaa", "aaaaaaaa", "aaaaaaaa", ".aaa....", "..aa....", "..a....."};
    private static final String[] GEM = {"...aa...", "..aaaa..", ".aaaaaa.", "aaaaaaaa", ".aaaaaa.", "..aaaa..", "...aa...", "........"};

    private static volatile java.util.Map<String, int[]> GIFT_ICONS;

    private static java.util.Map<String, int[]> giftIcons() {
        java.util.Map<String, int[]> m = GIFT_ICONS;
        if (m != null) return m;
        m = new java.util.HashMap<>();
        try (java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(
            MgIcons.class.getResourceAsStream("/keitok_gift_icons.txt"), java.nio.charset.StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                int t = line.indexOf('\t');
                if (t < 0) continue;
                String[] tok = line.substring(t + 1).split(" ");
                int[] px = new int[1024];
                for (int i = 0; i < 1024 && i < tok.length; i++) px[i] = tok[i].equals("-") ? 0 : (int) Long.parseLong(tok[i], 16);
                m.put(line.substring(0, t), px);
            }
        } catch (Throwable t) {
            // no icons -> fall back to the pixel-art ones
        }
        GIFT_ICONS = m;
        return m;
    }

    static String normName(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = Character.toLowerCase(s.charAt(i));
            if (Character.isLetterOrDigit(c)) b.append(c);
        }
        return b.toString();
    }

    /** The real gift picture for a gift rule (first name in its match list), or null. */
    static int[] giftIconFor(MgRule r) {
        if (r.trigger != MgTrigger.GIFT || r.match == null) return null;
        String first = r.match.split("[,|]")[0].trim();
        if (first.isEmpty() || first.equals("*")) return null;
        return giftIcons().get(normName(first));
    }

    public static boolean hasGiftIcon(MgRule r) { return giftIconFor(r) != null; }

    private static final java.util.Map<int[], Object> TEX = new java.util.IdentityHashMap<>();

    /** Uploads a gift picture to the GPU once and returns its texture id (null if that failed). Render thread only. */
    static net.minecraft.class_2960 texFor(int[] px) {
        Object o = TEX.get(px);
        if (o instanceof net.minecraft.class_2960) return (net.minecraft.class_2960) o;
        if (o != null) return null;
        try {
            net.minecraft.class_2960 id = net.minecraft.class_2960.method_60655("keitok", "mg_gift_" + TEX.size());
            takeyourminestream.ijustseen.core.render.PanelTextureUpload.upload(id, px, 32);
            TEX.put(px, id);
            return id;
        } catch (Throwable t) {
            TEX.put(px, Boolean.FALSE);
            return null;
        }
    }

    /** Draws a gift picture as one textured quad. */
    static boolean drawTex(class_332 g, int[] px, int x, int y, int size) {
        net.minecraft.class_2960 id = texFor(px);
        if (id == null) return false;
        g.method_25293(net.minecraft.class_10799.field_56883, id, x, y, 0f, 0f, size, size, 32, 32, 32, 32, -1);
        return true;
    }

    public static void draw(class_332 g, String[] pat, int x, int y, int s, int a, int b) {
        for (int r = 0; r < pat.length; r++) {
            String row = pat[r];
            for (int c = 0; c < row.length(); c++) {
                char ch = row.charAt(c);
                int col;
                if (ch == 'a') col = a;
                else if (ch == 'b') col = b;
                else if (ch == 'k') col = 0xFF111111;
                else continue;
                g.method_25294(x + c * s, y + r * s, x + (c + 1) * s, y + (r + 1) * s, col);
            }
        }
    }

    // ---- cached pixel-art textures: an icon is one textured quad, not ~64 rectangles per frame
    private static final java.util.LinkedHashMap<String, Object> PIX = new java.util.LinkedHashMap<>();
    private static int pixSeq;

    /** Texture of an 8x8 pattern drawn at 4 texels per cell (32x32). Null if it could not be made. Render thread only. */
    static net.minecraft.class_2960 patTex(String[] pat, int a, int b) {
        String key = System.identityHashCode(pat) + ":" + a + ":" + b;
        Object o = PIX.get(key);
        if (o instanceof net.minecraft.class_2960) return (net.minecraft.class_2960) o;
        if (o != null) return null;
        try {
            int[] px = new int[32 * 32];
            for (int r = 0; r < pat.length && r < 8; r++) {
                for (int c = 0; c < pat[r].length() && c < 8; c++) {
                    char ch = pat[r].charAt(c);
                    int col;
                    if (ch == 'a') col = a;
                    else if (ch == 'b') col = b;
                    else if (ch == 'k') col = 0xFF111111;
                    else continue;
                    for (int yy = r * 4; yy < r * 4 + 4; yy++) for (int xx = c * 4; xx < c * 4 + 4; xx++) px[yy * 32 + xx] = col;
                }
            }
            if (PIX.size() >= 64) {
                java.util.Iterator<java.util.Map.Entry<String, Object>> it = PIX.entrySet().iterator();
                Object old = it.next().getValue();
                it.remove();
                if (old instanceof net.minecraft.class_2960) takeyourminestream.ijustseen.core.render.PanelTextureUpload.free((net.minecraft.class_2960) old);
            }
            net.minecraft.class_2960 id = net.minecraft.class_2960.method_60655("keitok", "mg_pix_" + (pixSeq++));
            takeyourminestream.ijustseen.core.render.PanelTextureUpload.upload(id, px, 32);
            PIX.put(key, id);
            return id;
        } catch (Throwable t) {
            PIX.put(key, Boolean.FALSE);
            return null;
        }
    }

    /** Icon for what starts the rule. */
    public static void drawTrigger(class_332 g, MgRule r, int x, int y, int s) {
        int[] gi = giftIconFor(r);
        if (gi != null && drawTex(g, gi, x, y, s >= 2 ? 32 : 16)) return;
        String[] pat;
        int a;
        int b = 0;
        switch (r.trigger) {
            case LIKES: pat = HEART; a = 0xFFFF2D55; break;
            case FOLLOW: pat = PERSON; a = 0xFFEDEDED; break;
            case SHARE: pat = BUBBLE; a = 0xFF4FC3F7; break;
            case SUBSCRIBE: pat = STAR; a = 0xFFFFC83D; break;
            case JOIN: pat = PERSON; a = 0xFF6BE675; break;
            case CHAT: pat = BUBBLE; a = 0xFFFFFFFF; break;
            case BITS: pat = GEM; a = 0xFFB46BFF; break;
            case RAID: pat = BOLT; a = 0xFFFFC83D; break;
            default: pat = BOX; a = hash(r.match); b = 0xFFFFFFFF; break;
        }
        net.minecraft.class_2960 id = patTex(pat, a, b);
        if (id != null) {
            g.method_25293(net.minecraft.class_10799.field_56883, id, x, y, 0f, 0f, 8 * s, 8 * s, 32, 32, 32, 32, -1);
        } else {
            draw(g, pat, x, y, s, a, b);
        }
    }

    /** Icon for what the rule does. */
    public static void drawAction(class_332 g, MgRule r, int x, int y, int s) {
        String arg = r.arg == null ? "" : r.arg.toLowerCase(Locale.ROOT);
        switch (r.action) {
            case SPAWN: draw(g, FACE, x, y, s, mobColor(arg), 0); break;
            case GIVE:
                if (arg.contains("diamond")) draw(g, GEM, x, y, s, 0xFF4EE5E0, 0);
                else if (arg.contains("apple")) draw(g, HEART, x, y, s, arg.contains("enchanted") ? 0xFFFFC83D : 0xFFE8A93A, 0);
                else if (arg.contains("totem")) draw(g, STAR, x, y, s, 0xFFC9D94A, 0);
                else draw(g, BOX, x, y, s, hash(arg), 0xFFD9B77A);
                break;
            case TNT: draw(g, TNT, x, y, s, 0xFFD43B2F, 0xFFFFFFFF); break;
            case FREEZE: draw(g, SNOW, x, y, s, 0xFF8FDBFF, 0); break;
            case CLEAR_INVENTORY: draw(g, GRID, x, y, s, 0xFFE0E0E0, 0); break;
            case EFFECT: draw(g, GEM, x, y, s, 0xFFFF7BD5, 0); break;
            case RANDOM_TP: draw(g, GEM, x, y, s, 0xFFA855F7, 0); break;
            case LIGHTNING: draw(g, BOLT, x, y, s, 0xFFFFE94D, 0); break;
            case LAUNCH: draw(g, BOLT, x, y, s, 0xFF4FC3F7, 0); break;
            case HEAL: draw(g, HEART, x, y, s, 0xFFFF8FB1, 0); break;
            case HURT: case KILL: draw(g, FACE, x, y, s, 0xFFD43B2F, 0); break;
            case TIME: case WEATHER: draw(g, STAR, x, y, s, 0xFF9FD3FF, 0); break;
            case XP: draw(g, STAR, x, y, s, 0xFF7CFC5A, 0); break;
            case WIN: draw(g, STAR, x, y, s, 0xFFFFC83D, 0); break;
            case ALERT: draw(g, BUBBLE, x, y, s, 0xFF9AA0A6, 0); break;
            default: draw(g, BUBBLE, x, y, s, 0xFFFFFFFF, 0); break;
        }
    }

    static int mobColor(String m) {
        if (m.contains("zombie")) return 0xFF4F9B4F;
        if (m.contains("creeper")) return 0xFF5BC55B;
        if (m.contains("skeleton")) return 0xFFCFCFCF;
        if (m.contains("warden")) return 0xFF1F5560;
        if (m.contains("spider")) return 0xFF4A3A3A;
        if (m.contains("enderman")) return 0xFF2A1F3D;
        if (m.contains("blaze")) return 0xFFF2B33D;
        if (m.contains("witch")) return 0xFF7B4FA0;
        if (m.contains("golem")) return 0xFFB8B0A0;
        if (m.contains("pig")) return 0xFFF0A0A0;
        return hash(m);
    }

    static int hash(String s) {
        int h = s == null ? 0 : s.toLowerCase(Locale.ROOT).hashCode();
        int r = 90 + (h & 0x7F);
        int g = 90 + ((h >> 7) & 0x7F);
        int b = 90 + ((h >> 14) & 0x7F);
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    /** Nice title for a rule's action, like "Zombie" or "Diamond". */
    public static String actionTitle(MgRule r) {
        String arg = r.arg == null ? "" : r.arg.trim();
        int bar = arg.indexOf('|');
        if (bar >= 0) arg = arg.substring(0, bar).trim();
        if ((r.action == MgAction.SPAWN || r.action == MgAction.GIVE) && !arg.isEmpty()) return pretty(arg);
        if (r.action == MgAction.TNT) return "TNT";
        return r.action.label;
    }

    static String pretty(String id) {
        int c = id.indexOf(':');
        if (c >= 0) id = id.substring(c + 1);
        StringBuilder b = new StringBuilder();
        for (String w : id.replace('_', ' ').split(" ")) {
            if (w.isEmpty()) continue;
            if (b.length() > 0) b.append(' ');
            b.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return b.toString();
    }
}
