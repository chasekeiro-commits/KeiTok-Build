package takeyourminestream.ijustseen.minigames;

import takeyourminestream.ijustseen.integration.chat.ChatEventType;
import takeyourminestream.ijustseen.integration.chat.ChatPlatform;
import takeyourminestream.ijustseen.integration.chat.IncomingChatMessage;
import takeyourminestream.ijustseen.integration.tiktok.proto.TikTokProto;
import takeyourminestream.ijustseen.utils.Logger;

/**
 * Entry points that are wired into the existing KeiTok classes at build time.
 * Everything here swallows its own errors so a minigame problem can never break the chat overlay.
 */
public final class MgHooks {
    private MgHooks() {}

    // ---- TikTok gift / follow / subscribe (called at the top of the TikTok chat handler)

    public static void onTikTokGift(long msgId, String login, String display, String gift, int count) {
        try {
            if (msgId != 0L && !MgEngine.firstSeen("gift:" + msgId)) return;
            MgEngine.onGift(login, display, gift, count);
        } catch (Throwable t) {
            warn(t);
        }
    }

    public static void onTikTokFollow(long msgId, String login, String display) {
        try {
            if (msgId != 0L && !MgEngine.firstSeen("follow:" + msgId)) return;
            MgEngine.onSimple(MgTrigger.FOLLOW, login, display);
        } catch (Throwable t) {
            warn(t);
        }
    }

    public static void onTikTokSubscribe(long msgId, String login, String display) {
        try {
            if (msgId != 0L && !MgEngine.firstSeen("sub:" + msgId)) return;
            MgEngine.onSimple(MgTrigger.SUBSCRIBE, login, display);
        } catch (Throwable t) {
            warn(t);
        }
    }

    // ---- TikTok raw protobuf messages (likes, shares, joins)

    public static void onTikTokRaw(TikTokProto.ProtoMap msg) {
        try {
            if (msg == null) return;
            String method = msg.getString(1);
            byte[] body = msg.getRawBytes(2);
            if (method == null || body == null || body.length == 0) return;
            long id = msg.getVarint(3);
            boolean wanted = method.endsWith("WebcastLikeMessage") || method.endsWith("WebcastSocialMessage")
                || method.endsWith("WebcastMemberMessage");
            if (!wanted || !MgConfig.get().enabled) return;
            if (method.endsWith("WebcastLikeMessage")) {
                if (id != 0L && !MgEngine.firstSeen("like:" + id)) return;
                TikTokProto.ProtoMap m = TikTokProto.decode(body);
                int count = (int) Math.max(1L, Math.min(m.getVarint(2), 100000L));
                long total = m.getVarint(3);
                String[] u = user(m, 5);
                MgEngine.onLikes(u[0], u[1], count, total);
            } else if (method.endsWith("WebcastSocialMessage")) {
                TikTokProto.ProtoMap m = TikTokProto.decode(body);
                TikTokProto.ProtoMap disp = m.getMessage(1).getMessage(8);
                String key = (disp.getString(1) + disp.getString(2)).toLowerCase(java.util.Locale.ROOT);
                if (key.contains("share")) {
                    if (id != 0L && !MgEngine.firstSeen("share:" + id)) return;
                    String[] u = user(m, 2);
                    MgEngine.onSimple(MgTrigger.SHARE, u[0], u[1]);
                }
            } else if (method.endsWith("WebcastMemberMessage")) {
                if (id != 0L && !MgEngine.firstSeen("join:" + id)) return;
                TikTokProto.ProtoMap m = TikTokProto.decode(body);
                String[] u = user(m, 2);
                MgEngine.onSimple(MgTrigger.JOIN, u[0], u[1]);
            }
        } catch (Throwable t) {
            warn(t);
        }
    }

    private static String[] user(TikTokProto.ProtoMap m, int field) {
        try {
            TikTokProto.ProtoMap u = m.getMessage(field);
            String login = u.getString(38);
            String nick = u.getString(3);
            if (login == null || login.isEmpty()) login = nick;
            if (nick == null || nick.isEmpty()) nick = login;
            return new String[] {login == null ? "viewer" : login, nick == null ? "viewer" : nick};
        } catch (Throwable t) {
            return new String[] {"viewer", "viewer"};
        }
    }

    // ---- everything else (chat commands on every platform, events on Twitch/Kick/YouTube)

    public static void onMessageBatch(java.util.List<?> list) {
        try {
            if (list == null) return;
            for (Object o : list) {
                if (o instanceof IncomingChatMessage) onMessage((IncomingChatMessage) o);
            }
        } catch (Throwable t) {
            warn(t);
        }
    }

    public static void onMessage(IncomingChatMessage m) {
        try {
            if (m == null) return;
            ChatEventType et = m.eventType();
            String login = m.authorLogin();
            String name = m.displayName();
            if (et == null || et == ChatEventType.CHAT) {
                MgEngine.onChat(login, name, m.text());
                return;
            }
            if (m.platform() == ChatPlatform.TIKTOK) return; // handled from the raw TikTok hooks, avoid double fire
            switch (et) {
                case FOLLOW:
                    MgEngine.onSimple(MgTrigger.FOLLOW, login, name);
                    break;
                case SUBSCRIBE:
                    MgEngine.onSimple(MgTrigger.SUBSCRIBE, login, name);
                    break;
                case RAID:
                    MgEngine.onSimple(MgTrigger.RAID, login, name);
                    break;
                case BITS:
                    MgEngine.onSimple(MgTrigger.BITS, login, name);
                    break;
                case GIFT:
                    MgEngine.onGift(login, name, m.text(), 1);
                    break;
                default:
                    break;
            }
        } catch (Throwable t) {
            warn(t);
        }
    }

    private static void warn(Throwable t) {
        Logger.warning("[Minigames] hook error: " + t);
    }
}
