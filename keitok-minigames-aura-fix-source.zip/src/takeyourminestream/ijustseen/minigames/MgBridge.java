package takeyourminestream.ijustseen.minigames;

import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_1132;
import takeyourminestream.ijustseen.utils.Logger;

/**
 * The only place that touches Minecraft. Commands are sent as the local player. In a singleplayer world they work
 * when cheats are on. In a multiplayer server they work after /keitok force, and only if the server gives you
 * operator rights (the server decides which commands it accepts).
 */
public final class MgBridge {
    private MgBridge() {}

    public static final String READY = "READY";
    public static final String NO_WORLD = "NO_WORLD";
    public static final String NOT_SINGLEPLAYER = "NOT_SINGLEPLAYER";
    public static final String CHEATS_OFF = "CHEATS_OFF";

    /** Set by /keitok force: skip the cheats check (still needs a singleplayer world). */
    public static volatile boolean forced;

    private static boolean warnedCheatProbe;

    public static String status() {
        try {
            class_310 mc = class_310.method_1551();
            if (mc == null || mc.field_1724 == null || mc.field_1687 == null) {
                forced = false;
                return NO_WORLD;
            }
            if (!mc.method_1542()) return forced ? READY : NOT_SINGLEPLAYER;
            class_1132 server = mc.method_1576();
            if (server == null) return forced ? READY : NOT_SINGLEPLAYER;
            if (forced) return READY;
            boolean allowed = false;
            boolean probed = false;
            try {
                allowed |= server.method_27728().method_194();
                probed = true;
            } catch (Throwable t) {
                logProbe(t);
            }
            try {
                allowed |= server.method_3760().method_14579();
                probed = true;
            } catch (Throwable t) {
                logProbe(t);
            }
            if (probed && !allowed) return CHEATS_OFF;
            return READY;
        } catch (Throwable t) {
            return NO_WORLD;
        }
    }

    private static void logProbe(Throwable t) {
        if (!warnedCheatProbe) {
            warnedCheatProbe = true;
            Logger.warning("[Minigames] Could not read the cheats flag, assuming cheats are on: " + t);
        }
    }

    /** True when the player is on a multiplayer server (not the integrated singleplayer server). */
    public static boolean onMultiplayer() {
        try {
            class_310 mc = class_310.method_1551();
            return mc != null && mc.field_1724 != null && !mc.method_1542();
        } catch (Throwable t) {
            return false;
        }
    }

    public static String statusText(String status) {
        switch (status) {
            case READY:
                if (onMultiplayer()) return "Ready on a multiplayer server (forced). Commands need operator rights there.";
                return "Ready: singleplayer world with cheats ON";
            case CHEATS_OFF: return "Cheats are OFF in this world (turn on Allow Cheats / commands)";
            case NOT_SINGLEPLAYER: return "Multiplayer: type /keitok force once to turn it on here (needs operator rights on the server)";
            default: return "Open a singleplayer world with cheats ON to use this";
        }
    }

    /** Run on the Minecraft client thread. */
    public static void runOnClient(Runnable r) {
        try {
            class_310 mc = class_310.method_1551();
            if (mc != null) mc.execute(r);
        } catch (Throwable t) {
            Logger.warning("[Minigames] Could not schedule on client thread: " + t);
        }
    }

    /** Must be called on the client thread. Returns true if sent. */
    public static boolean sendCommand(String cmd) {
        try {
            class_310 mc = class_310.method_1551();
            if (mc == null || mc.field_1724 == null || mc.field_1724.field_3944 == null) return false;
            String c = cmd.startsWith("/") ? cmd.substring(1) : cmd;
            mc.field_1724.field_3944.method_45730(c);
            return true;
        } catch (Throwable t) {
            Logger.warning("[Minigames] Command failed (" + cmd + "): " + t);
            return false;
        }
    }

    /** Must be called on the client thread. Shows text over the hotbar. */
    public static void actionBar(String msg) {
        try {
            class_310 mc = class_310.method_1551();
            if (mc != null && mc.field_1724 != null) {
                mc.field_1724.method_7353(class_2561.method_30163(msg), true);
            }
        } catch (Throwable t) {
            // cosmetic only
        }
    }

    /** Must be called on the client thread. Shows text in chat (only the local player sees it). */
    public static void chat(String msg) {
        try {
            class_310 mc = class_310.method_1551();
            if (mc != null && mc.field_1724 != null) {
                mc.field_1724.method_7353(class_2561.method_30163(msg), false);
            }
        } catch (Throwable t) {
            // cosmetic only
        }
    }
}
