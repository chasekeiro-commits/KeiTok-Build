package takeyourminestream.ijustseen.minigames;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.class_10799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;

/**
 * Two HUD panels. Panel 0: big gift logo with "-what it does" under it, 4 at a time; with more than 4 the list slides
 * top to bottom over 5 s, then bottom to top over 5 s. Panel 1: chat mobs + chunk swap timer.
 * Everything is cached (layout, texts, textures, timer ring) so a frame costs only a handful of draw calls.
 */
public final class MgHud {
    private MgHud() {}

    private static final int PAD = 4;
    private static final int ICON = 32;
    private static final int ENTRY_H = 46;
    private static final int VISIBLE = 4;
    private static final long SLIDE_MS = 5000L;
    private static final int LINE_H = 12;

    private static final class Entry {
        MgRule rule;
        String text;
        class_2561 comp;
        int tw;
        int[] icon;
    }

    private static final class Cache {
        long builtAt;
        List<Entry> entries = new ArrayList<>();
        String wins;
        List<String> modeLines = new ArrayList<>();
        int w0;
        int w1;
    }

    private static final Cache C = new Cache();
    private static final Map<String, class_2561> COMPS = new HashMap<>();

    // panel 0 = gifts / rules list, panel 1 = chat mobs + chunk swap timer
    private static final int[] lastW = {120, 120};
    private static final int[] lastH = {60, 60};
    /** Where each panel was last drawn in the game (default spot unless it was moved). */
    private static final int[] lastX = {4, 4};
    private static final int[] lastY = {28, 28};

    public static int lastWidth(int panel) { return lastW[panel]; }
    public static int lastHeight(int panel) { return lastH[panel]; }

    /** Current top-left corner of a panel: its custom spot, or the default spot from the last frame. */
    public static int[] spot(int panel) {
        MgConfig cfg = MgConfig.get();
        if (panel == 0 ? cfg.hudCustom : cfg.modeCustom) {
            return panel == 0 ? new int[] {cfg.hudX, cfg.hudY} : new int[] {cfg.modeX, cfg.modeY};
        }
        return new int[] {lastX[panel], lastY[panel]};
    }

    /** Draws a panel at a given spot even outside a world (used by the "Move HUD" screen). */
    public static void renderPreview(class_332 g, int x, int y, int panel) {
        doRender(g, true, x, y, panel);
    }

    public static void render(class_332 g) {
        doRender(g, false, 0, 0, 0);
        doRender(g, false, 0, 0, 1);
    }

    private static class_2561 comp(String s) {
        class_2561 c = COMPS.get(s);
        if (c == null) {
            if (COMPS.size() > 300) COMPS.clear();
            c = class_2561.method_30163(s);
            COMPS.put(s, c);
        }
        return c;
    }

    /** Rebuilds the cached layout at most twice a second. */
    private static void refresh(MgConfig cfg, class_327 font, boolean force) {
        long now = System.currentTimeMillis();
        if (!force && now - C.builtAt < 750) return;
        C.builtAt = now;
        List<Entry> list = new ArrayList<>();
        List<MgRule> general = new ArrayList<>();
        List<MgRule> likes = new ArrayList<>();
        List<MgRule> gifts = new ArrayList<>();
        for (MgRule r : cfg.rules) {
            if (!r.enabled) continue;
            if (r.trigger == MgTrigger.GIFT) gifts.add(r);
            else if (r.trigger == MgTrigger.LIKES) likes.add(r);
            else general.add(r);
        }
        general.addAll(likes);
        general.addAll(gifts);
        int w0 = ICON;
        for (MgRule r : general) {
            Entry e = new Entry();
            e.rule = r;
            e.icon = MgIcons.giftIconFor(r);
            String act = actionText(r).toLowerCase(Locale.ROOT);
            e.text = e.icon != null ? "-" + act : "-" + shortName(r) + ": " + act;
            e.comp = comp(e.text);
            e.tw = font.method_1727(e.text);
            if (e.tw > w0) w0 = e.tw;
            list.add(e);
        }
        C.entries = list;
        C.wins = "WINS: " + cfg.wins;
        int ww = font.method_1727(C.wins);
        if (ww > w0) w0 = ww;
        C.w0 = w0;
        List<String> ml = MgChatModes.hudLines();
        int w1 = (cfg.chunkSwap || cfg.chunkDelete) ? 110 : 0;
        for (String l : ml) w1 = Math.max(w1, font.method_1727(l));
        C.modeLines = ml;
        C.w1 = w1;
    }

    private static String shortName(MgRule r) {
        switch (r.trigger) {
            case GIFT: {
                String m = r.match == null ? "" : r.match.trim();
                return m.isEmpty() || m.equals("*") ? "any gift" : m.toLowerCase(Locale.ROOT);
            }
            case LIKES: return r.match + " likes";
            case CHAT: return (r.match == null || r.match.trim().equals("*")) ? "any comment" : r.match.toLowerCase(Locale.ROOT);
            default: return r.trigger.label.toLowerCase(Locale.ROOT);
        }
    }

    private static void doRender(class_332 g, boolean preview, int fx, int fy, int panel) {
        try {
            MgConfig cfg = MgConfig.get();
            boolean modes = cfg.chatMobs || cfg.chunkSwap || cfg.chunkDelete;
            if (!preview && panel == 0 && !cfg.enabled) return;
            if (!preview && panel == 1 && !modes) return;
            class_310 mc = class_310.method_1551();
            if (mc == null || mc.method_22683() == null) return;
            if (!preview && (mc.field_1724 == null || !(mc.method_1542() || MgBridge.forced))) return;
            if (!preview && panel == 0 && !cfg.hudEnabled && !cfg.winCounter) return;
            class_327 font = mc.field_1772;
            refresh(cfg, font, preview);
            final float sc = Math.max(40, Math.min(300, panel == 0 ? cfg.hudScale : cfg.modeScale)) / 100f;
            int sw = mc.method_22683().method_4486();
            int sh = mc.method_22683().method_4502();

            // ---- size of this panel
            boolean showWins = panel == 0 && (cfg.enabled || preview) && cfg.winCounter;
            boolean showList = panel == 0 && (cfg.enabled || preview) && cfg.hudEnabled && !C.entries.isEmpty();
            int n = showList ? C.entries.size() : 0;
            int vh = Math.min(n, VISIBLE) * ENTRY_H;
            int w;
            int h;
            int extra = 0;
            if (panel == 0) {
                if (!showWins && !showList) {
                    if (!preview) return;
                    w = 110;
                    h = 24;
                } else {
                    w = C.w0 + PAD * 2;
                    h = PAD * 2 + (showWins ? LINE_H : 0) + vh;
                    if (showList && showWins) h += 2;
                }
            } else {
                extra = (cfg.chunkSwap ? 38 : 0) + (cfg.chunkDelete ? 38 : 0);
                if (C.modeLines.isEmpty() && !preview) return;
                w = Math.max(C.w1, 100) + PAD * 2;
                h = PAD * 2 + extra + C.modeLines.size() * LINE_H;
                if (C.modeLines.isEmpty()) h = 24;
            }
            int pw = (int) (w * sc);
            int ph = (int) (h * sc);
            lastW[panel] = pw;
            lastH[panel] = ph;

            int px;
            int py;
            boolean custom = panel == 0 ? cfg.hudCustom : cfg.modeCustom;
            if (preview) {
                px = fx;
                py = fy;
            } else if (custom) {
                px = panel == 0 ? cfg.hudX : cfg.modeX;
                py = panel == 0 ? cfg.hudY : cfg.modeY;
            } else if (panel == 0) {
                px = cfg.hudRight ? sw - pw - 4 : 4;
                py = cfg.hudOffsetY;
            } else {
                px = cfg.hudRight ? 4 : sw - pw - 4;
                py = cfg.hudOffsetY;
            }
            if (preview || custom) {
                px = Math.max(0, Math.min(px, Math.max(0, sw - pw)));
                py = Math.max(0, Math.min(py, Math.max(0, sh - ph)));
            }
            if (!preview) {
                lastX[panel] = px;
                lastY[panel] = py;
            }

            g.method_51448().pushMatrix();
            g.method_51448().translate((float) px, (float) py);
            g.method_51448().scale(sc, sc);
            g.method_25294(0, 0, w, h, 0xA0000000);
            g.method_25294(0, 0, w, 1, 0xFF2D7DFF);

            if (panel == 0) {
                int y = PAD;
                if (showWins) {
                    g.method_27535(font, comp(C.wins), PAD, y, 0xFFFFD84D);
                    y += LINE_H + 2;
                }
                if (showList) drawList(g, font, y, vh, n);
                else if (!showWins) g.method_27535(font, comp("HUD PREVIEW"), PAD, 8, 0xFF5599FF);
            } else {
                int y = PAD;
                if (cfg.chunkSwap) {
                    timer(g, font, PAD, y, MgChatModes.fractionLeft(), MgChatModes.secondsToSwap());
                    g.method_27535(font, comp("NEXT CHUNK SWAP"), PAD + 38, y + 12, 0xFFFFFFFF);
                    y += 38;
                }
                if (cfg.chunkDelete) {
                    timer(g, font, PAD, y, MgChatModes.fractionLeftDelete(), MgChatModes.secondsToDelete());
                    g.method_27535(font, comp("NEXT CHUNK DELETE"), PAD + 38, y + 12, 0xFFFF6666);
                    y += 38;
                }
                for (String l : C.modeLines) {
                    g.method_27535(font, comp(l), PAD, y, 0xFF5599FF);
                    y += LINE_H;
                }
                if (C.modeLines.isEmpty()) g.method_27535(font, comp("HUD PREVIEW"), PAD, 8, 0xFF5599FF);
            }
            g.method_51448().popMatrix();
        } catch (Throwable t) {
            // never break the HUD
        }
    }

    /** The big-logo list: 4 visible entries, sliding down 5 s then up 5 s when there are more than 4. */
    private static void drawList(class_332 g, class_327 font, int top, int vh, int n) {
        int total = n * ENTRY_H;
        int scroll = 0;
        if (n > VISIBLE) {
            long slide = Math.max(1, MgConfig.get().hudSlideSec) * 1000L;
            double t = (System.currentTimeMillis() % (slide * 2)) / (double) slide;
            double p = t < 1 ? t : 2 - t;
            p = p * p * (3 - 2 * p);
            scroll = (int) Math.round(p * (total - vh));
        }
        int x = PAD;
        g.method_44379(0, top, 4000, top + vh);
        for (int i = 0; i < n; i++) {
            int y = top + i * ENTRY_H - scroll;
            if (y + ENTRY_H < top || y > top + vh) continue; // off screen: no draw calls at all
            Entry e = C.entries.get(i);
            if (e.icon == null || !MgIcons.drawTex(g, e.icon, x, y, ICON)) MgIcons.drawTrigger(g, e.rule, x, y, 4);
            g.method_27535(font, e.comp, x, y + ICON + 3, 0xFFFFFFFF);
        }
        g.method_44380();
    }

    // ---- countdown ring: 60 pre-rendered pictures, one textured quad per frame
    private static final int RING_STEPS = 30;
    private static final class_2960[] RING = new class_2960[RING_STEPS * 2 + 2];
    private static final boolean[] RING_FAILED = new boolean[RING_STEPS * 2 + 2];

    private static class_2960 ringTex(int key) {
        if (key < 0 || key >= RING.length) return null;
        if (RING[key] != null || RING_FAILED[key]) return RING[key];
        try {
            int step = key >> 1;
            boolean warn = (key & 1) == 1;
            float f = step / (float) RING_STEPS;
            int on = warn ? 0xFFFF9F1A : 0xFF2D7DFF;
            int off = 0xFF3A3A44;
            final int R = 16;
            int[] px = new int[32 * 32];
            for (int y = 0; y < 32; y++) {
                for (int x = 0; x < 32; x++) {
                    double dx = x - R + 0.5, dy = y - R + 0.5;
                    double d = Math.sqrt(dx * dx + dy * dy);
                    int color = 0;
                    if (d <= R && d >= R - 5) {
                        double a = Math.atan2(dx, -dy);
                        if (a < 0) a += Math.PI * 2;
                        color = (a / (Math.PI * 2) <= f) ? on : off;
                    } else if (d < R - 5) {
                        color = 0x50000000;
                    }
                    px[y * 32 + x] = color;
                }
            }
            class_2960 id = class_2960.method_60655("keitok", "mg_ring_" + key);
            takeyourminestream.ijustseen.core.render.PanelTextureUpload.upload(id, px, 32);
            RING[key] = id;
            return id;
        } catch (Throwable t) {
            RING_FAILED[key] = true;
            return null;
        }
    }

    private static void timer(class_332 g, class_327 font, int x, int y, float frac, int secs) {
        final int R = 16;
        int step = Math.round(Math.max(0f, Math.min(1f, frac)) * RING_STEPS);
        int key = step * 2 + (secs <= 3 ? 1 : 0);
        class_2960 id = ringTex(key);
        if (id != null) g.method_25293(class_10799.field_56883, id, x, y, 0f, 0f, 2 * R, 2 * R, 32, 32, 32, 32, -1);
        String s = secs < 100 ? SECS[Math.max(0, secs)] : Integer.toString(secs);
        g.method_27535(font, comp(s), x + R - font.method_1727(s) / 2, y + R - 4, 0xFFFFFFFF);
    }

    private static final String[] SECS = new String[100];

    static {
        for (int i = 0; i < SECS.length; i++) SECS[i] = Integer.toString(i);
    }

    /** Text for one rule (kept for the unit tests / other screens). */
    /** "ROSE -> FREEZE 3s" style text for one rule. */
    public static String entryText(MgRule r) {
        String left;
        switch (r.trigger) {
            case GIFT: {
                String m = r.match == null ? "" : r.match.trim();
                left = m.isEmpty() || m.equals("*") ? "ANY GIFT" : m.toUpperCase(Locale.ROOT);
                if (r.minCount > 1) left += " x" + r.minCount;
                break;
            }
            case LIKES: left = r.match + " LIKES"; break;
            case CHAT: left = (r.match == null || r.match.trim().equals("*")) ? "ANY COMMENT" : r.match; break;
            default: left = r.trigger.label.toUpperCase(Locale.ROOT);
        }
        if (MgIcons.hasGiftIcon(r)) return actionText(r);
        return left + " - " + actionText(r);
    }

    public static String actionText(MgRule r) {
        String arg = r.arg == null ? "" : r.arg.trim();
        int bar = arg.indexOf('|');
        if (bar >= 0) arg = arg.substring(0, bar).trim();
        String a = arg.toUpperCase(Locale.ROOT).replace('_', ' ');
        int c = a.indexOf(':');
        if (c >= 0) a = a.substring(c + 1);
        switch (r.action) {
            case GIVE: return "GIVE " + a + (r.amount > 1 ? " " + r.amount : "");
            case SPAWN: return "SPAWN " + a + (r.amount > 1 ? " " + r.amount : "");
            case TNT: return "SPAWN TNT " + r.amount + "X";
            case FREEZE: return "FREEZE " + r.duration + " SECS";
            case CLEAR_INVENTORY: return "REMOVE INVENTORY";
            case RANDOM_TP: return "RUN * RTP";
            case EFFECT: return a + " " + r.duration + "S";
            case LIGHTNING: return "LIGHTNING " + r.amount;
            case COMMAND: return "RUN " + (arg.length() > 18 ? arg.substring(0, 18) + ".." : arg);
            case WIN: return "+" + r.amount + " WIN";
            default: return r.action.label.toUpperCase(Locale.ROOT);
        }
    }
}
