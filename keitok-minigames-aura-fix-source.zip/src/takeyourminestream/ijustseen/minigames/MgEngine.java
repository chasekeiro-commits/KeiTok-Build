package takeyourminestream.ijustseen.minigames;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import takeyourminestream.ijustseen.utils.Logger;

/** Matches live stream events against the rules and runs the resulting commands, paced out over time. */
public final class MgEngine {
    private MgEngine() {}

    private static final ScheduledThreadPoolExecutor EXEC = new ScheduledThreadPoolExecutor(1, r -> {
        Thread t = new Thread(r, "KeiTok-Minigames");
        t.setDaemon(true);
        return t;
    });

    private static final Map<String, Boolean> SEEN = Collections.synchronizedMap(new LinkedHashMap<String, Boolean>() {
        @Override
        protected boolean removeEldestEntry(Map.Entry<String, Boolean> e) {
            return size() > 4000;
        }
    });

    private static volatile long lastWarnMs;
    private static volatile long likeTotal;

    static {
        EXEC.setRemoveOnCancelPolicy(true);
    }

    /** Returns true the first time a key is seen (used to drop duplicates from the websocket + poll fallback). */
    static boolean firstSeen(String key) {
        return SEEN.put(key, Boolean.TRUE) == null;
    }

    public static long likeTotal() { return likeTotal; }

    // ------------------------------------------------------------------ event entry points

    public static void onGift(String login, String display, String gift, int count) {
        MgConfig cfg = MgConfig.get();
        String g = gift == null ? "" : gift.trim();
        if (!g.isEmpty()) cfg.rememberGift(g);
        if (!cfg.enabled) return;
        MgCtx c = MgCtx.of(login, display);
        c.gift = g;
        c.count = Math.max(1, count);
        dispatch(MgTrigger.GIFT, c);
    }

    public static void onSimple(MgTrigger t, String login, String display) {
        if (!MgConfig.get().enabled) return;
        dispatch(t, MgCtx.of(login, display));
    }

    public static void onChat(String login, String display, String text) {
        MgConfig cfg = MgConfig.get();
        try {
            MgChatModes.onChat(text);
        } catch (Throwable t) {
            Logger.warning("[Minigames] chat modes failed: " + t);
        }
        if (!cfg.enabled || text == null) return;
        MgCtx c = MgCtx.of(login, display);
        c.text = text;
        dispatch(MgTrigger.CHAT, c);
    }

    public static void onLikes(String login, String display, int count, long total) {
        MgConfig cfg = MgConfig.get();
        int add = Math.max(1, count);
        likeTotal = total > 0 ? total : likeTotal + add;
        if (!cfg.enabled) return;
        MgCtx c = MgCtx.of(login, display);
        c.likes = likeTotal;
        long now = System.currentTimeMillis();
        for (MgRule r : cfg.rules) {
            if (!r.enabled || r.trigger != MgTrigger.LIKES) continue;
            long every;
            try {
                every = Long.parseLong(r.match.trim());
            } catch (Exception e) {
                continue;
            }
            if (every <= 0) continue;
            r.progress += add;
            int fires = 0;
            while (r.progress >= every && fires < 5) {
                r.progress -= every;
                fires++;
            }
            if (r.progress >= every) r.progress %= every;
            if (fires > 0) {
                if (r.cooldown > 0 && now - r.lastFireMs < r.cooldown * 1000L) continue;
                r.lastFireMs = now;
                for (int i = 0; i < fires; i++) execute(r, c);
            }
        }
    }

    /** Used by the Test button: ignores enabled flags and cooldowns. */
    public static void test(MgRule r) {
        MgCtx c = MgCtx.of("TestViewer", "TestViewer");
        if (r.trigger == MgTrigger.GIFT) {
            String first = r.match == null ? "" : r.match.split("[,|]")[0].trim();
            c.gift = first.isEmpty() || first.equals("*") ? "Rose" : first;
            c.count = Math.max(1, r.minCount);
        }
        c.likes = likeTotal;
        execute(r, c);
    }

    // ------------------------------------------------------------------ internals

    private static void dispatch(MgTrigger t, MgCtx c) {
        MgConfig cfg = MgConfig.get();
        long now = System.currentTimeMillis();
        for (MgRule r : cfg.rules) {
            if (!r.enabled || r.trigger != t) continue;
            if (!matches(r, c)) continue;
            if (r.cooldown > 0 && now - r.lastFireMs < r.cooldown * 1000L) continue;
            r.lastFireMs = now;
            execute(r, c);
        }
    }

    static boolean matches(MgRule r, MgCtx c) {
        switch (r.trigger) {
            case GIFT: {
                if (c.count < Math.max(1, r.minCount)) return false;
                String m = r.match == null ? "" : r.match.trim();
                if (m.isEmpty() || m.equals("*")) return true;
                String g = norm(c.gift);
                for (String alt : m.split("[,|]")) {
                    String a = alt.trim();
                    if (a.equals("*") || (!a.isEmpty() && norm(a).equals(g))) return true;
                }
                return false;
            }
            case CHAT: {
                String m = r.match == null ? "" : r.match.trim();
                if (m.isEmpty() || m.equals("*")) return true;
                String text = c.text == null ? "" : c.text.toLowerCase(Locale.ROOT);
                for (String alt : m.split(",")) {
                    String a = alt.trim().toLowerCase(Locale.ROOT);
                    if (a.equals("*") || (!a.isEmpty() && text.contains(a))) return true;
                }
                return false;
            }
            default:
                return true;
        }
    }

    static String norm(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = Character.toLowerCase(s.charAt(i));
            if (Character.isLetterOrDigit(ch)) b.append(ch);
        }
        return b.toString();
    }

    static void execute(MgRule r, MgCtx c) {
        execute(r, c, false);
    }

    static void execute(MgRule r, MgCtx c, boolean audioOnly) {
        MgConfig cfg = MgConfig.get();
        List<String> cmds = new java.util.ArrayList<>();
        try {
            if (!audioOnly) cmds.addAll(MgActions.build(r, c, cfg));
            String snd = r.audio == null ? "" : MgActions.sub(r.audio.trim(), c);
            if (!snd.isEmpty()) cmds.add("playsound " + MgActions.id(snd) + " master @s ~ ~ ~ 1 1");
        } catch (Throwable t) {
            Logger.warning("[Minigames] Could not build action: " + t);
            return;
        }
        if (r.action == MgAction.WIN && !audioOnly) {
            int mult = r.perGiftCount ? Math.max(1, c.count) : 1;
            addWins((int) Math.min(100000L, (long) Math.max(1, r.amount) * mult));
        }
        final String announce = (cfg.announce && !audioOnly) ? MgActions.announceText(r, c) : null;
        final MgRule rule = r;
        long step = r.interval > 0 ? r.interval : Math.max(0, cfg.commandDelayMs);
        long start = Math.max(0, Math.min(r.delay, 600000));

        schedule(start, () -> {
            String st = MgBridge.status();
            if (!MgBridge.READY.equals(st)) {
                warnNotReady(st);
                return;
            }
            if (announce != null) MgBridge.actionBar(announce);
        });
        long delay = start;
        for (String cmd : cmds) {
            if (cmd.startsWith("#after ")) {
                int sp = cmd.indexOf(' ', 7);
                long wait = 0;
                try { wait = Long.parseLong(cmd.substring(7, sp)); } catch (Exception ignored) { }
                final String later = cmd.substring(sp + 1);
                schedule(start + Math.max(0, wait), () -> {
                    if (MgBridge.READY.equals(MgBridge.status())) MgBridge.sendCommand(later);
                });
                continue;
            }
            final String command = cmd;
            schedule(delay, () -> {
                if (!MgBridge.READY.equals(MgBridge.status())) return;
                MgBridge.sendCommand(command);
            });
            delay += step;
        }
        Logger.info("[Minigames] " + rule.trigger + " -> " + rule.action + " for " + c.user + " (" + cmds.size() + " command(s))");
    }

    public static synchronized void addWins(int n) {
        MgConfig cfg = MgConfig.get();
        cfg.wins = Math.max(0, cfg.wins + n);
        cfg.save();
    }

    /** Blue play button: only plays the rule's audio. */
    public static void testAudio(MgRule r) {
        execute(r, MgCtx.of("TestViewer", "TestViewer"), true);
    }

    private static void schedule(long delayMs, Runnable onClient) {
        EXEC.schedule(() -> MgBridge.runOnClient(onClient), delayMs, TimeUnit.MILLISECONDS);
    }

    private static void warnNotReady(String status) {
        long now = System.currentTimeMillis();
        if (now - lastWarnMs < 20000L) return;
        lastWarnMs = now;
        MgBridge.chat("§c[Minigames] §f" + MgBridge.statusText(status));
    }
}
