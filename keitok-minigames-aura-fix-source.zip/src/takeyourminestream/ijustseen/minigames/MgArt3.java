package takeyourminestream.ijustseen.minigames;

import static takeyourminestream.ijustseen.minigames.MgArt.TAU;
import static takeyourminestream.ijustseen.minigames.MgArt.cloud;
import static takeyourminestream.ijustseen.minigames.MgArt.wave;
import static takeyourminestream.ijustseen.minigames.MgArt.pine;
import static takeyourminestream.ijustseen.minigames.MgSprites.A;
import static takeyourminestream.ijustseen.minigames.MgSprites.C;
import static takeyourminestream.ijustseen.minigames.MgSprites.mix;
import static takeyourminestream.ijustseen.minigames.MgSprites.rnd;
import static takeyourminestream.ijustseen.minigames.MgSprites.shade;
import static takeyourminestream.ijustseen.minigames.MgSprites.vnoise;

import takeyourminestream.ijustseen.minigames.MgSprites.Builder;
import takeyourminestream.ijustseen.minigames.MgSprites.Cv;

/** Pixel art for midnight blue and cyberpunk. */
final class MgArt3 {
    private MgArt3() {}

    private static double tri(double x, int cycles, double ph, int period) {
        double t = x * cycles / period + ph;
        t = t - Math.floor(t);
        return Math.abs(t - 0.5) * 2;
    }

    // ------------------------------------------------------------------ midnight blue

    static void midnight(Builder b) {
        b.add("moonF", 32, 32, c -> {
            c.disc(16, 16, 14, C(0xE8F0FF));
            for (int y = 0; y < 32; y++) for (int x = 0; x < 32; x++) {
                int p = c.get(x, y);
                if ((p >>> 24) == 0) continue;
                double d = Math.hypot(x - 14.5, y - 14.5) / 15.0;
                c.set(x, y, mix(C(0xFAFCFF), C(0xB4C6EE), Math.pow(Math.min(1, d), 1.8)));
            }
            int cr = C(0xA9BCE6), cr2 = C(0xC2D2F2);
            c.disc(10, 10, 3, cr); c.disc(11, 9, 2, cr2); c.disc(20, 14, 2, cr); c.disc(14, 21, 3, cr); c.disc(15, 20, 2, cr2);
            c.disc(22, 22, 1, cr); c.disc(8, 18, 1, cr); c.px(19, 7, cr); c.px(24, 17, cr); c.px(18, 26, cr);
        });
        b.add("aurora", 64, 48, c -> {
            c.wrap = true;
            for (int x = 0; x < 64; x++) {
                int top = 4 + (int) Math.round(10 * vnoise(x / 16.0, 4, 2));
                int len = 16 + (int) Math.round(24 * vnoise(x / 8.0, 8, 3));
                double streak = 0.4 + 0.6 * vnoise(x / 2.0, 32, 4);
                for (int y = 0; y < len; y++) {
                    double t = y / (double) len;
                    double a = Math.pow(1 - t, 1.5) * streak;
                    if (a < 0.03) continue;
                    int col = mix(C(0x4CFFB0), C(0x5A86FF), Math.min(1, t * 1.15));
                    if (y < 2) col = mix(col, C(0xC09CFF), 0.55);
                    c.px(x, top + y, A(col, Math.min(0.9, a)));
                }
            }
        });
        b.add("stars", 64, 40, c -> {
            c.wrap = true;
            for (int i = 0; i < 26; i++) {
                int x = (int) (rnd(i, 1, 31) * 64), y = (int) (rnd(i, 2, 31) * 40);
                double a = 0.35 + 0.65 * rnd(i, 3, 31);
                int col = i % 4 == 0 ? 0xFFE6B0 : (i % 3 == 0 ? 0xBFD4FF : 0xFFFFFF);
                c.px(x, y, A(col, a));
                if (i % 7 == 0) { c.px(x - 1, y, A(col, a * 0.5)); c.px(x + 1, y, A(col, a * 0.5)); c.px(x, y - 1, A(col, a * 0.5)); c.px(x, y + 1, A(col, a * 0.5)); }
            }
        });
        b.add("mtn", 64, 36, c -> {
            c.wrap = true;
            int[] hgt = new int[64];
            for (int x = 0; x < 64; x++) hgt[x] = 15 + (int) Math.round(12 * tri(x, 2, 0.15, 64) + 6 * tri(x, 5, 0.4, 64) + 1.4 * Math.sin(TAU * 11 * x / 64.0));
            for (int x = 0; x < 64; x++) {
                int top = 36 - hgt[x];
                boolean rightSlope = hgt[(x + 1) % 64] < hgt[x] || hgt[(x + 2) % 64] < hgt[x] - 1;
                for (int y = top; y < 36; y++) {
                    int col = mix(C(0x3A579A), C(0x1A2A5E), (y - top) / (double) Math.max(1, 36 - top));
                    if (rightSlope) col = shade(col, 0.78);
                    if (y - top < 5 + (int) (rnd(x, 1, 9) * 3) && hgt[x] > 17) col = rightSlope ? C(0xB8C8EE) : C(0xEAF2FF);
                    c.px(x, y, col);
                }
            }
        });
        b.add("pines", 64, 30, c -> {
            c.wrap = true;
            int[] xs = {3, 10, 17, 25, 31, 39, 46, 53, 60}, hs = {17, 22, 14, 24, 18, 21, 15, 23, 16};
            for (int i = 0; i < xs.length; i++) pine(c, xs[i], 27, hs[i], i % 2 == 0 ? C(0x0C183A) : C(0x13235A), C(0xC8D8F8), C(0x24367A));
            for (int x = 0; x < 64; x++) {
                int top = 27 + (int) Math.round(Math.sin(TAU * 3 * x / 64.0) * 0.8);
                c.px(x, top, C(0xDCE8FF));
                for (int y = top + 1; y < 30; y++) c.px(x, y, mix(C(0x9FB4E6), C(0x6C84C8), (y - top) / 3.0));
            }
        });
        b.add("cabin", 28, 24, c -> {
            c.rect(4, 11, 20, 11, C(0x3A2A26));
            for (int y = 12; y < 22; y += 2) c.hl(4, 23, y, C(0x2A1C1A));
            c.vl(4, 11, 21, C(0x4E3A34)); c.vl(23, 11, 21, C(0x241816));
            c.tri(14, 2, 0, 12, 28, 12, C(0xDCE8FF)); c.tri(14, 2, 2, 12, 26, 12, C(0x4A3A5A)); c.tri(14, 2, 0, 12, 14, 12, C(0xB8C8EE));
            c.hl(2, 25, 11, C(0xF4F8FF)); c.hl(3, 24, 12, C(0xB8C8EE));
            c.rect(19, 2, 3, 6, C(0x5A4A50)); c.hl(19, 21, 2, C(0xF4F8FF));
            c.rect(7, 14, 5, 5, C(0xFFC870)); c.vl(9, 14, 18, C(0x6A4A20)); c.hl(7, 11, 16, C(0x6A4A20)); c.px(8, 15, C(0xFFF2C8));
            c.rect(16, 15, 4, 7, C(0x24160F)); c.px(18, 18, C(0xE8C050));
        });
        b.frames("fire", 4, 11, 14, (c, f) -> {
            c.thick(1, 12, 9, 10, 0.8, C(0x4A2E1A)); c.thick(1, 10, 9, 12, 0.8, C(0x5E3E24));
            double[] hh = {7 + (f % 2), 9 - (f == 2 ? 2 : 0), 6 + (f == 1 ? 2 : 0)};
            int[] xs = {3, 5, 7};
            for (int k = 0; k < 3; k++)
                for (int y = 0; y < hh[k]; y++) {
                    double t = y / hh[k];
                    int col = t < 0.3 ? C(0xFFF2B0) : (t < 0.65 ? C(0xFFB02E) : C(0xFF5A14));
                    int w = t < 0.5 ? 2 : 1;
                    c.rect(xs[k] - (w == 2 ? 1 : 0), 9 - y, w, 1, col);
                }
        });
        b.add("wolf", 26, 18, c -> {
            int col = C(0x070C1E), rim = C(0x2A3E80);
            c.ell(9, 11, 6, 3, col);                       // body
            c.ell(14, 10, 3, 3, col);                      // chest
            c.thick(15, 9, 18.5, 5.5, 1.7, col);           // neck rising to the moon
            c.ell(19, 4, 2, 2, col);                       // head
            c.tri(20, 2.6, 25, -0.4, 21.4, 5.6, col);      // snout
            c.tri(18, 2, 17, -1, 19.5, 1.2, col);          // ear
            c.tri(3, 10, -1, 12, 3, 14, col); c.thick(3, 11, 1, 14, 1.2, col); // tail
            for (int x : new int[]{5, 7, 12, 14}) c.vl(x, 13, 17, col);
            c.hl(4, 12, 8, rim); c.px(16, 7, rim); c.px(17, 6, rim); c.px(18, 3, rim);
        });
        b.add("cloudM", 38, 12, c -> cloud(c, new int[]{8, 15, 23, 31}, new int[]{8, 6, 7, 9}, new int[]{5, 6, 5, 4}, C(0x7C94D4), 0x28387A, 10));
        b.add("edgeT", 64, 6, c -> {
            c.wrap = true;
            for (int i = 0; i < 12; i++) {
                int x = (int) (rnd(i, 1, 61) * 64), y = (int) (rnd(i, 2, 61) * 5);
                double a = 0.4 + 0.6 * rnd(i, 3, 61);
                c.px(x, y, A(i % 3 == 0 ? 0xBFD4FF : 0xFFFFFF, a));
                if (i % 5 == 0) { c.px(x - 1, y, A(0xBFD4FF, a * 0.5)); c.px(x + 1, y, A(0xBFD4FF, a * 0.5)); c.px(x, y + 1, A(0xBFD4FF, a * 0.5)); }
            }
        });
        b.add("edgeB", 64, 6, c -> {
            c.wrap = true;
            for (int x = 0; x < 64; x++) {
                int top = 2 + (int) Math.round(wave(x, 64, 0, new double[]{1.1, 0.7}, new int[]{2, 5}, new double[]{0.4, 1.9}));
                for (int y = top; y < 6; y++) c.px(x, y, mix(C(0x2A4585), C(0x132048), (y - top) / 4.0));
                c.px(x, top, C(0xEAF2FF));
            }
        });
        b.corners("cm", 11, 11, c -> {
            c.hl(0, 9, 0, 0xFFFFFFFF); c.vl(0, 0, 9, 0xFFFFFFFF);
            int s = A(0xFFFFFF, 0.75);
            c.px(3, 3, 0xFFFFFFFF); c.px(2, 3, s); c.px(4, 3, s); c.px(3, 2, s); c.px(3, 4, s);
            c.px(2, 2, A(0xFFFFFF, 0.45)); c.px(4, 4, A(0xFFFFFF, 0.45)); c.px(2, 4, A(0xFFFFFF, 0.45)); c.px(4, 2, A(0xFFFFFF, 0.45));
        });
    }

    // ------------------------------------------------------------------ cyberpunk

    private static void skyline(Cv c, int[] ws, int[] hs, int base, int body, int edge, int trim, double glowA, int frame, int seed, boolean windows, int winA, int winB) {
        c.wrap = true;
        int x = 0;
        for (int i = 0; i < ws.length; i++) {
            int w = ws[i], h = hs[i], top = base - h;
            c.rect(x, top, w, h, mix(body, shade(body, 0.7), i % 2 * 0.6));
            c.vl(x, top, base - 1, edge);
            c.vl(x + w - 1, top, base - 1, shade(body, 0.6));
            int tc = (i % 2 == 0) ? 0x00F0FF : 0xFF2BD6;
            c.hl(x, x + w - 1, top, A(tc, 0.95));
            for (int g = 1; g <= 3; g++) c.hl(x, x + w - 1, top + g, A(tc, glowA / g));
            if (i % 3 == 0) { c.vl(x + w / 2, top - 5, top - 1, shade(edge, 1.3)); c.px(x + w / 2, top - 6, C(0xFF3050)); }
            if (i % 3 == 1) { c.rect(x + 1, top - 2, 3, 2, shade(body, 1.4)); }
            if (windows)
                for (int wy = top + 4; wy < base - 2; wy += 3)
                    for (int wx = x + 2; wx < x + w - 2; wx += 3) {
                        double r = rnd(wx + i * 7, wy, seed);
                        double flick = rnd(wx + i * 7, wy, seed + 99 + frame * 13);
                        boolean on = r < 0.30 || (r < 0.38 && flick < 0.5);
                        if (on) c.rect(wx, wy, 2, 1 + ((wx + wy) & 1), ((wx + wy) & 3) == 0 ? winB : winA);
                    }
            if (i == 2 && h > 30) { // billboard
                c.rect(x + 1, top + 8, w - 2, 7, C(0x1A0A30)); c.rect(x + 1, top + 8, w - 2, 1, C(0xFF2BD6)); c.rect(x + 1, top + 14, w - 2, 1, C(0xFF2BD6));
                c.rect(x + 3, top + 10, w - 6, 3, frame == 0 ? C(0x00F0FF) : C(0x7FFBFF));
            }
            x += w + 1;
        }
    }

    static void cyber(Builder b) {
        final int[] fw = {12, 9, 10, 14, 7, 6}, fh = {30, 40, 26, 44, 34, 28};
        b.add("cityF", 64, 50, c -> {
            skyline(c, fw, fh, 50, C(0x1B0F46), C(0x2E1A66), 0, 0.25, 0, 7, true, C(0x6A3AA8), C(0x3A8AA8));
        });
        final int[] nw = {9, 7, 12, 8, 11, 6, 4}, nh = {34, 22, 48, 28, 40, 26, 36};
        b.frames("cityN", 2, 64, 58, (c, f) -> skyline(c, nw, nh, 58, C(0x0F0824), C(0x2A1450), 0, 0.5, f, 3, true, C(0xFFF27A), C(0x7FFBFF)));
        b.frames("signA", 3, 32, 14, (c, f) -> {
            int m = f == 2 ? A(0xFF2BD6, 0.25) : C(0xFF2BD6);
            int t = f == 1 ? A(0x00F0FF, 0.25) : C(0x00F0FF);
            c.rect(0, 0, 32, 14, A(0x14061E, 0.9));
            c.hl(0, 31, 0, m); c.hl(0, 31, 13, m); c.vl(0, 0, 13, m); c.vl(31, 0, 13, m);
            c.text("BAR", 10, 4, t);
            c.px(2, 2, t); c.px(29, 11, t);
        });
        b.frames("signB", 3, 24, 13, (c, f) -> {
            int m = f == 2 ? A(0x00F0FF, 0.25) : C(0x00F0FF);
            int t = f == 1 ? A(0xFFF27A, 0.25) : C(0xFFF27A);
            c.rect(0, 0, 24, 13, A(0x14061E, 0.9));
            c.hl(0, 23, 0, m); c.hl(0, 23, 12, m); c.vl(0, 0, 12, m); c.vl(23, 0, 12, m);
            c.text("OPEN", 4, 4, t);
        });
        b.frames("drone", 2, 17, 10, (c, f) -> {
            int d = C(0x1B1236), e = C(0x3A2A70);
            c.rect(4, 4, 9, 4, d); c.hl(4, 12, 4, e); c.rect(2, 5, 2, 2, d); c.rect(13, 5, 2, 2, d);
            c.rect(7, 5, 3, 2, C(0xFF2BD6)); c.px(8, 5, C(0xFFFFFF));
            c.vl(3, 3, 4, e); c.vl(13, 3, 4, e);
            if (f == 0) { c.hl(0, 6, 2, C(0x7FFBFF)); c.hl(10, 16, 2, C(0x7FFBFF)); } else { c.hl(1, 5, 2, A(0x7FFBFF, 0.7)); c.hl(11, 15, 2, A(0x7FFBFF, 0.7)); }
            c.vl(5, 8, 9, e); c.vl(11, 8, 9, e);
            c.px(8, 9, A(0xFF2BD6, 0.8));
        });
        b.pair("car", 22, 9, c -> {
            int body = C(0x201040), hi = C(0x5A38A0);
            c.tri(2, 7, 8, 2, 18, 2, body); c.rect(2, 4, 18, 3, body); c.tri(18, 2, 21, 5, 18, 7, body);
            c.hl(3, 19, 4, hi);
            c.rect(9, 3, 5, 2, C(0x00F0FF)); c.px(10, 3, C(0xFFFFFF));
            c.hl(2, 19, 8, A(0xFF2BD6, 0.9)); c.hl(4, 17, 9, A(0xFF2BD6, 0.35));
            c.px(21, 5, C(0xFFF27A)); c.px(20, 5, C(0xFFF27A)); c.px(0, 5, C(0xFF3050));
        });
        b.add("edgeT", 64, 6, c -> {
            c.wrap = true;
            for (int x = 0; x < 64; x++) if (x % 10 < 7) { c.px(x, 1, C(0x00F0FF)); c.px(x, 2, A(0x00F0FF, 0.3)); }
            for (int x : new int[]{5, 22, 39, 56}) { c.px(x, 4, C(0xFF2BD6)); c.px(x + 1, 4, A(0xFF2BD6, 0.5)); }
            c.px(14, 0, C(0xFFF27A)); c.px(47, 0, C(0xFFF27A));
        });
        b.add("edgeB", 64, 6, c -> {
            c.wrap = true;
            int[] ws = {7, 5, 9, 6, 8, 7, 10, 5, 7}, hs = {4, 6, 3, 5, 6, 4, 5, 3, 5};
            int x = 0;
            for (int i = 0; i < ws.length; i++) {
                int top = 6 - hs[i];
                c.rect(x, top, ws[i], hs[i], C(0x120A2C));
                c.hl(x, x + ws[i] - 1, top, i % 2 == 0 ? C(0x00F0FF) : C(0xFF2BD6));
                for (int wx = x + 1; wx < x + ws[i] - 1; wx += 2) if (rnd(wx, i, 5) < 0.4) c.px(wx, top + 2 + (wx & 1), C(0xFFF27A));
                x += ws[i];
            }
        });
        b.corners("ccy", 12, 12, c -> {
            c.hl(0, 10, 0, 0xFFFFFFFF); c.vl(0, 0, 10, 0xFFFFFFFF);
            c.rect(3, 3, 2, 2, A(0xFFFFFF, 0.9)); c.hl(6, 8, 2, A(0xFFFFFF, 0.5)); c.vl(2, 6, 8, A(0xFFFFFF, 0.5));
        });
    }
}
