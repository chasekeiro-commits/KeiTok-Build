package takeyourminestream.ijustseen.minigames;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.class_310;
import takeyourminestream.ijustseen.utils.Logger;

/**
 * Two chat-driven minigames:
 *  - Chat Mobs: any mob name said in chat is summoned right on the player.
 *  - Chunk Swap: every N seconds the ground of the player's chunk is replaced with the block chat said the most.
 */
public final class MgChatModes {
    private MgChatModes() {}

    static final Set<String> MOBS = new HashSet<>(Arrays.asList((
        "allay armadillo axolotl bat bee blaze bogged breeze camel camel_husk cat cave_spider chicken cod copper_golem cow creaking creeper "
        + "dolphin donkey drowned elder_guardian ender_dragon enderman endermite evoker fox frog ghast glow_squid goat guardian happy_ghast hoglin "
        + "horse husk illusioner iron_golem llama magma_cube mooshroom mule nautilus ocelot panda parched parrot phantom pig piglin piglin_brute pillager "
        + "polar_bear pufferfish rabbit ravager salmon sheep shulker silverfish skeleton skeleton_horse slime sniffer snow_golem spider squid stray strider "
        + "tadpole trader_llama tropical_fish turtle vex villager vindicator wandering_trader warden witch wither wither_skeleton wolf zoglin zombie "
        + "zombie_horse zombie_nautilus zombie_villager zombified_piglin").split(" ")));

    static final Map<String, String> MOB_ALIAS = new HashMap<>();
    static final Set<String> BLOCKS = new HashSet<>();
    static final Map<String, String> BLOCK_ALIAS = new HashMap<>();

    static {
        MOB_ALIAS.put("golem", "iron_golem");
        MOB_ALIAS.put("snowman", "snow_golem");
        MOB_ALIAS.put("pigman", "zombified_piglin");
        MOB_ALIAS.put("dragon", "ender_dragon");
        MOB_ALIAS.put("enderdragon", "ender_dragon");
        MOB_ALIAS.put("mooshroom", "mooshroom");
        MOB_ALIAS.put("kitten", "cat");
        MOB_ALIAS.put("bunny", "rabbit");
        MOB_ALIAS.put("bear", "polar_bear");
        MOB_ALIAS.put("trader", "wandering_trader");

        BLOCKS.addAll(Arrays.asList((
            "stone granite diorite andesite polished_granite polished_diorite polished_andesite deepslate cobbled_deepslate polished_deepslate deepslate_bricks "
            + "deepslate_tiles chiseled_deepslate calcite tuff polished_tuff tuff_bricks chiseled_tuff dripstone_block grass_block dirt coarse_dirt podzol rooted_dirt "
            + "mud packed_mud mud_bricks muddy_mangrove_roots clay cobblestone mossy_cobblestone smooth_stone stone_bricks mossy_stone_bricks cracked_stone_bricks "
            + "chiseled_stone_bricks sand red_sand sandstone chiseled_sandstone cut_sandstone smooth_sandstone red_sandstone chiseled_red_sandstone cut_red_sandstone "
            + "smooth_red_sandstone gravel coal_ore iron_ore copper_ore gold_ore redstone_ore emerald_ore lapis_ore diamond_ore deepslate_coal_ore deepslate_iron_ore "
            + "deepslate_copper_ore deepslate_gold_ore deepslate_redstone_ore deepslate_emerald_ore deepslate_lapis_ore deepslate_diamond_ore nether_gold_ore "
            + "nether_quartz_ore ancient_debris coal_block iron_block copper_block gold_block redstone_block emerald_block lapis_block diamond_block netherite_block "
            + "raw_iron_block raw_copper_block raw_gold_block amethyst_block quartz_block smooth_quartz quartz_bricks chiseled_quartz_block quartz_pillar prismarine "
            + "prismarine_bricks dark_prismarine sea_lantern obsidian crying_obsidian bedrock netherrack nether_bricks red_nether_bricks cracked_nether_bricks "
            + "chiseled_nether_bricks soul_sand soul_soil basalt polished_basalt smooth_basalt blackstone polished_blackstone polished_blackstone_bricks "
            + "gilded_blackstone chiseled_polished_blackstone glowstone magma_block crimson_nylium warped_nylium nether_wart_block warped_wart_block shroomlight "
            + "bone_block end_stone end_stone_bricks purpur_block purpur_pillar snow_block ice packed_ice blue_ice sponge wet_sponge glass tinted_glass bookshelf tnt "
            + "hay_block slime_block honey_block honeycomb_block pumpkin carved_pumpkin jack_o_lantern melon moss_block pale_moss_block sculk target lodestone "
            + "crafting_table redstone_lamp note_block jukebox terracotta bricks copper_block exposed_copper weathered_copper oxidized_copper cut_copper resin_block "
            + "resin_bricks bamboo_planks bamboo_block mangrove_roots netherite_block respawn_anchor beacon").split(" ")));
        String[] colors = {"white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray", "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black"};
        for (String c : colors) {
            for (String f : new String[] {"wool", "concrete", "concrete_powder", "terracotta", "glazed_terracotta", "stained_glass"}) BLOCKS.add(c + "_" + f);
        }
        for (String w : new String[] {"oak", "spruce", "birch", "jungle", "acacia", "dark_oak", "mangrove", "cherry", "pale_oak"}) {
            BLOCKS.add(w + "_planks");
            BLOCKS.add(w + "_log");
            BLOCKS.add(w + "_wood");
            BLOCKS.add("stripped_" + w + "_log");
            BLOCKS.add("stripped_" + w + "_wood");
            BLOCKS.add(w + "_leaves");
        }
        for (String w : new String[] {"crimson", "warped"}) {
            BLOCKS.add(w + "_planks");
            BLOCKS.add(w + "_stem");
            BLOCKS.add(w + "_hyphae");
            BLOCKS.add("stripped_" + w + "_stem");
            BLOCKS.add("stripped_" + w + "_hyphae");
        }
        String[][] al = {
            {"diamond", "diamond_block"}, {"gold", "gold_block"}, {"iron", "iron_block"}, {"emerald", "emerald_block"}, {"lapis", "lapis_block"},
            {"redstone", "redstone_block"}, {"coal", "coal_block"}, {"copper", "copper_block"}, {"netherite", "netherite_block"}, {"grass", "grass_block"},
            {"wood", "oak_planks"}, {"planks", "oak_planks"}, {"log", "oak_log"}, {"leaves", "oak_leaves"}, {"wool", "white_wool"}, {"concrete", "white_concrete"},
            {"quartz", "quartz_block"}, {"brick", "bricks"}, {"amethyst", "amethyst_block"}, {"sandstone", "sandstone"}, {"hay", "hay_block"}, {"bone", "bone_block"},
            {"slime", "slime_block"}, {"honey", "honey_block"}, {"snow", "snow_block"}, {"purpur", "purpur_block"}, {"tuff", "tuff"}, {"mud", "mud"},
            {"bedrock", "bedrock"}, {"debris", "ancient_debris"}, {"lamp", "redstone_lamp"}
        };
        for (String[] a : al) BLOCK_ALIAS.put(a[0], a[1]);
        // every block id (full list shipped inside the mod)
        try (java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(
            MgChatModes.class.getResourceAsStream("/keitok_blocks.txt"), java.nio.charset.StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) BLOCKS.add(line);
            }
        } catch (Throwable t) {
            // fall back to the built-in list above
        }
    }

    private static final ScheduledThreadPoolExecutor EXEC = new ScheduledThreadPoolExecutor(1, r -> {
        Thread t = new Thread(r, "KeiTok-ChatModes");
        t.setDaemon(true);
        return t;
    });
    private static final AtomicInteger QUEUED = new AtomicInteger();
    private static final Map<String, Integer> TALLY = new ConcurrentHashMap<>();
    private static final Map<String, Integer> DEL_TALLY = new ConcurrentHashMap<>();
    private static volatile long nextDeleteAt = System.currentTimeMillis() + 10000L;
    private static volatile String lastDeleted = "";
    private static volatile long nextSwapAt = System.currentTimeMillis() + 10000L;
    private static volatile String lastWinner = "";
    private static volatile long lastWarnMs;

    static {
        EXEC.setRemoveOnCancelPolicy(true);
        EXEC.scheduleWithFixedDelay(() -> {
            try {
                tick();
            } catch (Throwable t) {
                Logger.warning("[Minigames] chunk swap tick failed: " + t);
            }
        }, 1000, 500, TimeUnit.MILLISECONDS);
    }

    /** Make sure the timer thread is running (touching the class starts it). */
    public static void init() {}

    // ------------------------------------------------------------------ chat input

    public static void onChat(String text) {
        MgConfig cfg = MgConfig.get();
        if (text == null || text.isEmpty() || (!cfg.chatMobs && !cfg.chunkSwap && !cfg.chunkDelete)) return;
        String[] tok = text.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", " ").trim().split(" ");
        if (cfg.chatMobs) spawnMobs(cfg, tok);
        if (cfg.chunkSwap) tallyBlocks(tok, TALLY, cfg.chunkBlocked);
        if (cfg.chunkDelete) tallyBlocks(tok, DEL_TALLY, cfg.deleteBlocked);
    }

    private static String find(String[] tok, int i, int[] len, Set<String> ids, Map<String, String> alias) {
        int maxN = ids == BLOCKS ? 6 : 3;
        for (int n = Math.min(maxN, tok.length - i); n >= 1; n--) {
            StringBuilder b = new StringBuilder();
            for (int k = 0; k < n; k++) {
                if (k > 0) b.append('_');
                b.append(tok[i + k]);
            }
            String key = b.toString();
            String hit = lookup(key, ids, alias);
            if (hit == null && key.length() > 3 && key.endsWith("s")) hit = lookup(key.substring(0, key.length() - 1), ids, alias);
            if (hit == null && key.endsWith("es") && key.length() > 4) hit = lookup(key.substring(0, key.length() - 2), ids, alias);
            if (hit != null) {
                len[0] = n;
                return hit;
            }
        }
        return null;
    }

    private static String lookup(String key, Set<String> ids, Map<String, String> alias) {
        if (ids.contains(key)) return key;
        return alias.get(key);
    }

    private static Set<String> blockedMobs(MgConfig cfg) {
        Set<String> b = listSet(cfg.chatMobBlocked);
        for (String k : new HashSet<>(b)) if (MOB_ALIAS.containsKey(k)) b.add(MOB_ALIAS.get(k));
        return b;
    }

    /** "minecraft:tnt, Iron Golem" -> {tnt, iron_golem} */
    static Set<String> listSet(String list) {
        Set<String> s = new HashSet<>();
        if (list != null) {
            for (String p : list.toLowerCase(Locale.ROOT).split(",")) {
                String t = p.trim().replace("minecraft:", "").replaceAll("[^a-z0-9]+", "_").replaceAll("^_+|_+$", "");
                if (!t.isEmpty()) s.add(t);
            }
        }
        return s;
    }

    private static void spawnMobs(MgConfig cfg, String[] tok) {
        Set<String> blocked = blockedMobs(cfg);
        Set<String> found = new java.util.LinkedHashSet<>();
        int[] len = new int[1];
        int max = Math.max(1, Math.min(cfg.chatMobMax, 10));
        for (int i = 0; i < tok.length && found.size() < max; ) {
            String hit = find(tok, i, len, MOBS, MOB_ALIAS);
            if (hit == null) {
                i++;
                continue;
            }
            i += len[0];
            if (!blocked.contains(hit)) found.add(hit);
        }
        long delay = 0;
        for (String id : found) {
            if (QUEUED.get() > 60) return; // a flood of messages shouldn't lag the game
            QUEUED.incrementAndGet();
            final String cmd = "execute at @s run summon minecraft:" + id + " ~ ~ ~";
            EXEC.schedule(() -> MgBridge.runOnClient(() -> {
                QUEUED.decrementAndGet();
                if (!ready()) return;
                MgBridge.sendCommand(cmd);
            }), delay, TimeUnit.MILLISECONDS);
            delay += 80;
        }
    }

    private static void tallyBlocks(String[] tok, Map<String, Integer> tally, String blockedList) {
        Set<String> blocked = listSet(blockedList);
        for (String k : new HashSet<>(blocked)) if (BLOCK_ALIAS.containsKey(k)) blocked.add(BLOCK_ALIAS.get(k));
        Set<String> seen = new HashSet<>();
        int[] len = new int[1];
        for (int i = 0; i < tok.length; ) {
            String hit = find(tok, i, len, BLOCKS, BLOCK_ALIAS);
            if (hit == null) {
                i++;
                continue;
            }
            i += len[0];
            if (!blocked.contains(hit) && seen.add(hit)) tally.merge(hit, 1, Integer::sum);
        }
    }

    // ------------------------------------------------------------------ chunk swap

    private static boolean ready() {
        String st = MgBridge.status();
        if (MgBridge.READY.equals(st)) return true;
        long now = System.currentTimeMillis();
        if (now - lastWarnMs > 20000L) {
            lastWarnMs = now;
            final String text = MgBridge.statusText(st);
            MgBridge.runOnClient(() -> MgBridge.chat("§c[Play] §f" + text));
        }
        return false;
    }

    /** Most-said block right now, or "" if nobody has said one. */
    public static String topBlock() {
        String best = "";
        int bc = 0;
        for (Map.Entry<String, Integer> e : TALLY.entrySet()) {
            if (e.getValue() > bc) {
                bc = e.getValue();
                best = e.getKey();
            }
        }
        return best;
    }

    public static int topCount() {
        String t = topBlock();
        return t.isEmpty() ? 0 : TALLY.get(t);
    }

    public static int secondsToSwap() {
        return (int) Math.max(0, (nextSwapAt - System.currentTimeMillis() + 999) / 1000);
    }

    /** Fraction of the current round still left (1 = just swapped, 0 = swapping now). */
    public static float fractionLeft() {
        long total = Math.max(3, MgConfig.get().chunkSeconds) * 1000L;
        long left = nextSwapAt - System.currentTimeMillis();
        return Math.max(0f, Math.min(1f, left / (float) total));
    }

    public static void clearTally() {
        TALLY.clear();
    }

    // ------------------------------------------------------------------ chunk delete

    private static String topOf(Map<String, Integer> tally) {
        String best = "";
        int bc = 0;
        for (Map.Entry<String, Integer> e : tally.entrySet()) {
            if (e.getValue() > bc) {
                bc = e.getValue();
                best = e.getKey();
            }
        }
        return best;
    }

    public static String topDelete() { return topOf(DEL_TALLY); }

    public static int topDeleteCount() {
        String t = topDelete();
        Integer c = t.isEmpty() ? null : DEL_TALLY.get(t);
        return c == null ? 0 : c;
    }

    public static int secondsToDelete() {
        return (int) Math.max(0, (nextDeleteAt - System.currentTimeMillis() + 999) / 1000);
    }

    public static float fractionLeftDelete() {
        long total = Math.max(3, MgConfig.get().deleteSeconds) * 1000L;
        long left = nextDeleteAt - System.currentTimeMillis();
        return Math.max(0f, Math.min(1f, left / (float) total));
    }

    public static void clearDeleteTally() { DEL_TALLY.clear(); }

    private static void tickDelete(MgConfig cfg) {
        long secs = Math.max(3, cfg.deleteSeconds) * 1000L;
        if (!cfg.chunkDelete) {
            nextDeleteAt = System.currentTimeMillis() + secs;
            return;
        }
        if (System.currentTimeMillis() < nextDeleteAt) return;
        nextDeleteAt = System.currentTimeMillis() + secs;
        String block;
        int count;
        synchronized (DEL_TALLY) {
            block = topOf(DEL_TALLY);
            Integer c = block.isEmpty() ? null : DEL_TALLY.get(block);
            count = c == null ? 0 : c;
            DEL_TALLY.clear(); // every round starts from 0 votes
        }
        if (block.isEmpty()) return;
        deleteNow(block, count);
    }

    /** Deletes every block of that type in the player's chunk (same area rules as Chunk Swap). */
    public static void deleteNow(final String block, final int said) {
        if (block == null || block.isEmpty() || block.endsWith("air")) return;
        final MgConfig cfg = MgConfig.get();
        MgBridge.runOnClient(() -> {
            if (!ready()) return;
            lastDeleted = block;
            int depth = cfg.deleteDepth <= 0 ? 100000 : cfg.deleteDepth;
            List<String> cmds = new ArrayList<>();
            boolean aligned = false;
            try {
                class_310 mc = class_310.method_1551();
                int bx = mc.field_1724.method_31477();
                int by = mc.field_1724.method_31478();
                int bz = mc.field_1724.method_31479();
                int x0 = Math.floorDiv(bx, 16) * 16;
                int z0 = Math.floorDiv(bz, 16) * 16;
                deleteSlices(cmds, "execute if dimension minecraft:overworld run ", x0, z0, 319, depth >= 100000 ? -64 : Math.max(-64, by - depth), block);
                deleteSlices(cmds, "execute unless dimension minecraft:overworld run ", x0, z0, 255, depth >= 100000 ? 0 : Math.max(0, by - depth), block);
                aligned = true;
            } catch (Throwable t) {
                cmds.clear();
            }
            if (!aligned) {
                int below = Math.min(depth, 384);
                for (int off = 0; off < below + 128; off += 128) {
                    cmds.add("execute at @s run fill ~-8 ~" + (off - below) + " ~-8 ~7 ~" + (off - below + 127) + " ~7 minecraft:air replace minecraft:" + block);
                }
            }
            for (String c : cmds) MgBridge.sendCommand(c);
            MgBridge.actionBar("§cChunk deleted: §f" + pretty(block) + (said > 0 ? " §7(said " + said + "x)" : ""));
        });
    }

    private static void deleteSlices(List<String> out, String prefix, int x0, int z0, int top, int bottom, String block) {
        for (int y2 = top; y2 >= bottom; y2 -= 128) {
            int y1 = Math.max(bottom, y2 - 127);
            out.add(prefix + "fill " + x0 + " " + y1 + " " + z0 + " " + (x0 + 15) + " " + y2 + " " + (z0 + 15) + " minecraft:air replace minecraft:" + block);
        }
    }

    private static void tick() {
        MgConfig cfg = MgConfig.get();
        tickDelete(cfg);
        if (!cfg.chunkSwap) {
            nextSwapAt = System.currentTimeMillis() + Math.max(3, cfg.chunkSeconds) * 1000L;
            return;
        }
        if (System.currentTimeMillis() < nextSwapAt) return;
        nextSwapAt = System.currentTimeMillis() + Math.max(3, cfg.chunkSeconds) * 1000L;
        // The round always ends with a clean slate: the vote is read, then wiped, so a block said
        // 10 times last round starts again from 0 and has to be said again to win.
        String block;
        int count;
        synchronized (TALLY) {
            block = topBlock();
            count = topCount();
            TALLY.clear();
        }
        if (block.isEmpty()) {
            // nobody voted: reset the chunk again with the last winner
            if (lastWinner.isEmpty()) return;
            block = lastWinner;
            count = 0;
        }
        swapNow(block, count);
    }

    /** Replaces the ground of the player's chunk (from just under their feet downwards) with one block. */
    public static void swapNow(final String block, final int said) {
        final MgConfig cfg = MgConfig.get();
        MgBridge.runOnClient(() -> {
            if (!ready()) return;
            lastWinner = block;
            int depth = cfg.chunkDepth <= 0 ? 100000 : Math.min(cfg.chunkDepth, 100000); // 0 = all the way to bedrock
            List<String> cmds = new ArrayList<>();
            boolean aligned = false;
            try {
                class_310 mc = class_310.method_1551();
                int bx = mc.field_1724.method_31477();
                int by = mc.field_1724.method_31478();
                int bz = mc.field_1724.method_31479();
                int x0 = Math.floorDiv(bx, 16) * 16;
                int z0 = Math.floorDiv(bz, 16) * 16;
                int top = by - 1;
                // overworld bedrock floor is y=-64, nether/end y=0: fill stops just above it
                slices(cmds, "execute if dimension minecraft:overworld run ", x0, z0, top, Math.max(-63, top - depth + 1), block);
                slices(cmds, "execute unless dimension minecraft:overworld run ", x0, z0, top, Math.max(1, top - depth + 1), block);
                // everything standing on the chunk (trees, buildings, plants...) becomes the winning block too
                for (String tag : ABOVE_TAGS) {
                    for (int y1 = Math.max(by, -64); y1 <= 255; y1 += 128) {
                        cmds.add("fill " + x0 + " " + y1 + " " + z0 + " " + (x0 + 15) + " " + Math.min(255, y1 + 127) + " " + (z0 + 15)
                            + " minecraft:" + block + " replace #minecraft:" + tag);
                    }
                }
                aligned = true;
            } catch (Throwable t) {
                cmds.clear();
            }
            if (!aligned) {
                // fallback: a 16x16 area around the player
                int remaining = Math.min(depth, 384);
                int off = 1;
                while (remaining > 0) {
                    int h = Math.min(128, remaining);
                    cmds.add("execute at @s run fill ~-8 ~-" + off + " ~-8 ~7 ~-" + (off + h - 1) + " ~7 minecraft:" + block + " replace");
                    off += h;
                    remaining -= h;
                }
            }
            if (!aligned) {
                for (String tag : ABOVE_TAGS) {
                    cmds.add("execute at @s run fill ~-8 ~ ~-8 ~7 ~127 ~7 minecraft:" + block + " replace #minecraft:" + tag);
                }
            }
            for (String c : cmds) MgBridge.sendCommand(c);
            MgBridge.actionBar("§eChunk swapped to §f" + pretty(block) + (said > 0 ? " §7(said " + said + "x)" : ""));
        });
    }

    /** Block tags that together cover nearly everything that can stand above the ground (trees, plants, buildings). */
    private static final String[] ABOVE_TAGS = {
        "mineable/pickaxe", "mineable/axe", "mineable/shovel", "mineable/hoe", "logs", "leaves", "planks", "wool", "wool_carpets",
        "flowers", "replaceable", "saplings", "crops", "impermeable", "ice", "banners", "beds", "candles", "climbable", "snow"
    };

    private static void slices(List<String> out, String prefix, int x0, int z0, int top, int bottom, String block) {
        for (int y2 = top; y2 >= bottom; y2 -= 128) {
            int y1 = Math.max(bottom, y2 - 127);
            out.add(prefix + "fill " + x0 + " " + y1 + " " + z0 + " " + (x0 + 15) + " " + y2 + " " + (z0 + 15) + " minecraft:" + block + " replace");
        }
    }

    public static void testMob(String id) {
        MgBridge.runOnClient(() -> {
            if (ready()) MgBridge.sendCommand("execute at @s run summon minecraft:" + id + " ~ ~ ~");
        });
    }

    static String pretty(String id) {
        StringBuilder b = new StringBuilder();
        for (String w : id.split("_")) {
            if (w.isEmpty()) continue;
            if (b.length() > 0) b.append(' ');
            b.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return b.toString();
    }

    /** Extra HUD lines for the two modes. */
    public static List<String> hudLines() {
        List<String> l = new ArrayList<>();
        MgConfig cfg = MgConfig.get();
        if (cfg.chatMobs) l.add("CHAT MOBS: SAY A MOB NAME");
        if (cfg.chunkSwap) {
            String top = topBlock();
            l.add("CHUNK SWAP - SAY A BLOCK");
            l.add("TOP: " + (top.isEmpty() ? (lastWinner.isEmpty() ? "-" : pretty(lastWinner) + " (last)") : pretty(top) + " x" + topCount()));
        }
        if (cfg.chunkDelete) {
            String top = topDelete();
            l.add("CHUNK DELETE - SAY A BLOCK");
            l.add("TOP: " + (top.isEmpty() ? (lastDeleted.isEmpty() ? "-" : pretty(lastDeleted) + " (last)") : pretty(top) + " x" + topDeleteCount()));
        }
        return l;
    }
}
