package takeyourminestream.ijustseen.minigames;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.concurrent.CopyOnWriteArrayList;
import takeyourminestream.ijustseen.core.storage.StoragePaths;
import takeyourminestream.ijustseen.utils.Logger;

/** Persistent settings + rules for Interactive Minigames. Stored as interactive_minigames.json. */
public final class MgConfig {
    private static MgConfig instance;

    public boolean enabled = false;
    public int maxPerAction = 100;
    public int commandDelayMs = 60;
    public boolean announce = true;
    /** Right-side overlay listing the active gifts and what they do. */
    public boolean hudEnabled = true;
    public boolean hudRight = true;
    public int hudOffsetY = 28;
    public int hudMaxLines = 22;
    public int hudScale = 100;
    /** Size of the chunk / mob HUD (separate from the gifts HUD). */
    public int modeScale = 100;
    /** 26 Aura settings (see the aura package). */
    public boolean auraEnabled = true;
    public int auraDesign = 1;
    public int auraScalePct = 100;
    public int auraSpeedPct = 100;
    public int auraIntensityPct = 100;
    /** 0 = auto, 1 = low .. 4 = ultra. */
    public int auraQuality = 0;
    public int auraRange = 48;
    public boolean auraUseTheme = true;
    public int auraColor = 0xFF2D7DFF;
    public boolean auraLogo = true;
    /** Show other KeiTok players. Needs KeiTok on the server too: without it nobody else is shown. */
    public boolean auraNetwork = true;
    public int hudSlideSec = 5;
    public boolean hudCustom = false;
    public int hudX = 0;
    public int hudY = 0;
    public boolean modeCustom = false;
    public int modeX = 0;
    public int modeY = 0;
    public boolean winCounter = false;
    public boolean chatMobs = false;
    public int chatMobMax = 1;
    public String chatMobBlocked = "";
    public String chunkBlocked = "";
    public boolean themeComments = false;
    public boolean chunkSwap = false;
    public int chunkSeconds = 10;
    public int chunkDepth = 0;
    public boolean chunkDelete = false;
    public int deleteSeconds = 10;
    public int deleteDepth = 0;
    public String deleteBlocked = "";
    public int wins = 0;
    public final List<MgRule> rules = new CopyOnWriteArrayList<>();
    /** Every gift name ever seen live (plus the built-in catalog), so all of them can be picked in the editor. */
    public final TreeSet<String> knownGifts = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);

    private MgConfig() {}

    public static synchronized MgConfig get() {
        if (instance == null) {
            instance = new MgConfig();
            instance.load();
        }
        return instance;
    }

    private static Path file() {
        return StoragePaths.getModRootDir().resolve("interactive_minigames.json");
    }

    @SuppressWarnings("unchecked")
    public synchronized void load() {
        rules.clear();
        knownGifts.clear();
        knownGifts.addAll(MgGifts.CATALOG);
        boolean loaded = false;
        try {
            Path f = file();
            if (Files.exists(f)) {
                Object root = MgJson.parse(new String(Files.readAllBytes(f), StandardCharsets.UTF_8));
                if (root instanceof Map) {
                    Map<String, Object> m = (Map<String, Object>) root;
                    enabled = MgRule.bool(m.get("enabled"), false);
                    maxPerAction = clamp(MgRule.num(m.get("maxPerAction"), 100), 1, 1000);
                    commandDelayMs = clamp(MgRule.num(m.get("commandDelayMs"), 60), 0, 5000);
                    announce = MgRule.bool(m.get("announce"), true);
                    hudEnabled = MgRule.bool(m.get("hudEnabled"), true);
                    hudRight = MgRule.bool(m.get("hudRight"), true);
                    hudOffsetY = clamp(MgRule.num(m.get("hudOffsetY"), 28), 0, 600);
                    hudMaxLines = clamp(MgRule.num(m.get("hudMaxLines"), 22), 3, 80);
                    hudScale = clamp(MgRule.num(m.get("hudScale"), 100), 40, 300);
                    modeScale = clamp(MgRule.num(m.get("modeScale"), 100), 40, 300);
                    auraEnabled = MgRule.bool(m.get("auraEnabled"), true);
                    auraDesign = clamp(MgRule.num(m.get("auraDesign"), 1), 1, 26);
                    auraScalePct = clamp(MgRule.num(m.get("auraScalePct"), 100), 25, 300);
                    auraSpeedPct = clamp(MgRule.num(m.get("auraSpeedPct"), 100), 25, 300);
                    auraIntensityPct = clamp(MgRule.num(m.get("auraIntensityPct"), 100), 10, 200);
                    auraQuality = clamp(MgRule.num(m.get("auraQuality"), 0), 0, 4);
                    auraRange = clamp(MgRule.num(m.get("auraRange"), 48), 16, 128);
                    auraUseTheme = MgRule.bool(m.get("auraUseTheme"), true);
                    Object ac = m.get("auraColor");
                    if (ac instanceof Number) auraColor = ((Number) ac).intValue();
                    auraLogo = MgRule.bool(m.get("auraLogo"), true);
                    auraNetwork = MgRule.bool(m.get("auraNetwork"), true);
                    hudSlideSec = clamp(MgRule.num(m.get("hudSlideSec"), 5), 1, 60);
                    hudCustom = MgRule.bool(m.get("hudCustom"), false);
                    hudX = clamp(MgRule.num(m.get("hudX"), 0), 0, 20000);
                    hudY = clamp(MgRule.num(m.get("hudY"), 0), 0, 20000);
                    modeCustom = MgRule.bool(m.get("modeCustom"), false);
                    modeX = clamp(MgRule.num(m.get("modeX"), 0), 0, 20000);
                    modeY = clamp(MgRule.num(m.get("modeY"), 0), 0, 20000);
                    winCounter = MgRule.bool(m.get("winCounter"), false);
                    chatMobs = MgRule.bool(m.get("chatMobs"), false);
                    chatMobMax = clamp(MgRule.num(m.get("chatMobMax"), 1), 1, 10);
                    Object cmb = m.get("chatMobBlocked");
                    chatMobBlocked = cmb instanceof String ? (String) cmb : "";
                    if ("ender_dragon,wither".equals(chatMobBlocked)) chatMobBlocked = ""; // old default: nothing is blocked now
                    Object cbb = m.get("chunkBlocked");
                    chunkBlocked = cbb instanceof String ? (String) cbb : "";
                    themeComments = MgRule.bool(m.get("themeComments"), false);
                    chunkSwap = MgRule.bool(m.get("chunkSwap"), false);
                    chunkSeconds = clamp(MgRule.num(m.get("chunkSeconds"), 10), 3, 600);
                    chunkDepth = clamp(MgRule.num(m.get("chunkDepth"), 0), 0, 384);
                    if (chunkDepth == 128) chunkDepth = 0; // old default -> now "to bedrock"
                    chunkDelete = MgRule.bool(m.get("chunkDelete"), false);
                    deleteSeconds = clamp(MgRule.num(m.get("deleteSeconds"), 10), 3, 600);
                    deleteDepth = clamp(MgRule.num(m.get("deleteDepth"), 0), 0, 384);
                    Object dbb = m.get("deleteBlocked");
                    deleteBlocked = dbb instanceof String ? (String) dbb : "";
                    wins = Math.max(0, MgRule.num(m.get("wins"), 0));
                    Object kg = m.get("knownGifts");
                    if (kg instanceof List) {
                        for (Object o : (List<Object>) kg) if (o instanceof String) knownGifts.add((String) o);
                    }
                    Object rl = m.get("rules");
                    if (rl instanceof List) {
                        for (Object o : (List<Object>) rl) {
                            if (o instanceof Map) rules.add(MgRule.fromMap((Map<String, Object>) o));
                        }
                    }
                    loaded = true;
                }
            }
        } catch (Throwable t) {
            Logger.warning("[Minigames] Could not read config, using defaults: " + t);
        }
        if (!loaded) {
            resetDefaults();
        }
    }

    public synchronized void save() {
        try {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("version", 1L);
            m.put("enabled", enabled);
            m.put("maxPerAction", (long) maxPerAction);
            m.put("commandDelayMs", (long) commandDelayMs);
            m.put("announce", announce);
            m.put("hudEnabled", hudEnabled);
            m.put("hudRight", hudRight);
            m.put("hudOffsetY", (long) hudOffsetY);
            m.put("hudMaxLines", (long) hudMaxLines);
            m.put("hudScale", (long) hudScale);
            m.put("modeScale", (long) modeScale);
            m.put("auraEnabled", auraEnabled);
            m.put("auraDesign", (long) auraDesign);
            m.put("auraScalePct", (long) auraScalePct);
            m.put("auraSpeedPct", (long) auraSpeedPct);
            m.put("auraIntensityPct", (long) auraIntensityPct);
            m.put("auraQuality", (long) auraQuality);
            m.put("auraRange", (long) auraRange);
            m.put("auraUseTheme", auraUseTheme);
            m.put("auraColor", (long) auraColor);
            m.put("auraLogo", auraLogo);
            m.put("auraNetwork", auraNetwork);
            m.put("hudSlideSec", (long) hudSlideSec);
            m.put("hudCustom", hudCustom);
            m.put("hudX", (long) hudX);
            m.put("hudY", (long) hudY);
            m.put("modeCustom", modeCustom);
            m.put("modeX", (long) modeX);
            m.put("modeY", (long) modeY);
            m.put("winCounter", winCounter);
            m.put("chatMobs", chatMobs);
            m.put("chatMobMax", (long) chatMobMax);
            m.put("chatMobBlocked", chatMobBlocked == null ? "" : chatMobBlocked);
            m.put("chunkBlocked", chunkBlocked == null ? "" : chunkBlocked);
            m.put("themeComments", themeComments);
            m.put("chunkSwap", chunkSwap);
            m.put("chunkSeconds", (long) chunkSeconds);
            m.put("chunkDepth", (long) chunkDepth);
            m.put("chunkDelete", chunkDelete);
            m.put("deleteSeconds", (long) deleteSeconds);
            m.put("deleteDepth", (long) deleteDepth);
            m.put("deleteBlocked", deleteBlocked == null ? "" : deleteBlocked);
            m.put("wins", (long) wins);
            m.put("knownGifts", new ArrayList<Object>(knownGifts));
            List<Object> rl = new ArrayList<>();
            for (MgRule r : rules) rl.add(r.toMap());
            m.put("rules", rl);
            Path f = file();
            Files.createDirectories(f.getParent());
            Files.write(f, MgJson.write(m).getBytes(StandardCharsets.UTF_8));
        } catch (Throwable t) {
            Logger.warning("[Minigames] Could not save config: " + t);
        }
    }

    private static Path presetDir() {
        return StoragePaths.getModRootDir().resolve("minigame_presets");
    }

    /** Saves the current rules as a preset file and returns its name. */
    public synchronized String savePreset() {
        save();
        try {
            Path dir = presetDir();
            Files.createDirectories(dir);
            int n = 1;
            while (Files.exists(dir.resolve("preset-" + n + ".json"))) n++;
            Map<String, Object> m = new LinkedHashMap<>();
            List<Object> rl = new ArrayList<>();
            for (MgRule r : rules) rl.add(r.toMap());
            m.put("rules", rl);
            Files.write(dir.resolve("preset-" + n + ".json"), MgJson.write(m).getBytes(StandardCharsets.UTF_8));
            return "preset-" + n;
        } catch (Throwable t) {
            Logger.warning("[Minigames] Could not save preset: " + t);
            return null;
        }
    }

    public synchronized List<String> listPresets() {
        List<String> out = new ArrayList<>();
        try {
            Path dir = presetDir();
            if (Files.isDirectory(dir)) {
                try (java.util.stream.Stream<Path> s = Files.list(dir)) {
                    s.map(p -> p.getFileName().toString()).filter(n -> n.endsWith(".json")).sorted()
                        .forEach(n -> out.add(n.substring(0, n.length() - 5)));
                }
            }
        } catch (Throwable ignored) { }
        return out;
    }

    @SuppressWarnings("unchecked")
    public synchronized boolean loadPreset(String name) {
        try {
            Path f = presetDir().resolve(name + ".json");
            Object root = MgJson.parse(new String(Files.readAllBytes(f), StandardCharsets.UTF_8));
            if (!(root instanceof Map)) return false;
            Object rl = ((Map<String, Object>) root).get("rules");
            if (!(rl instanceof List)) return false;
            List<MgRule> nr = new ArrayList<>();
            for (Object o : (List<Object>) rl) if (o instanceof Map) nr.add(MgRule.fromMap((Map<String, Object>) o));
            rules.clear();
            rules.addAll(nr);
            save();
            return true;
        } catch (Throwable t) {
            Logger.warning("[Minigames] Could not load preset: " + t);
            return false;
        }
    }

    public synchronized void resetDefaults() {
        rules.clear();
        rules.addAll(defaultRules());
        save();
    }

    public synchronized void rememberGift(String name) {
        if (name == null || name.trim().isEmpty()) return;
        if (knownGifts.add(name.trim())) save();
    }

    /** The starter setup, matching the layout from the stream overlay. Everything is editable. */
    static List<MgRule> defaultRules() {
        List<MgRule> l = new ArrayList<>();
        l.add(rule(MgTrigger.FOLLOW, "", MgAction.TNT, "", 1, 4, "{user} followed - TNT!"));
        MgRule likes = rule(MgTrigger.LIKES, "10000", MgAction.CLEAR_INVENTORY, "", 1, 0, "10000 likes! Inventory gone");
        l.add(likes);
        l.add(rule(MgTrigger.GIFT, "Rose", MgAction.FREEZE, "", 1, 3, "{user} froze you"));
        l.add(rule(MgTrigger.GIFT, "Heart Me", MgAction.CLEAR_INVENTORY, "", 1, 0, "{user} wiped your inventory"));
        l.add(rule(MgTrigger.GIFT, "Fire", MgAction.SPAWN, "zombie", 3, 0, "{user} sent zombies"));
        l.add(rule(MgTrigger.GIFT, "GG", MgAction.GIVE, "golden_apple", 1, 0, "{user} gave you a golden apple"));
        l.add(rule(MgTrigger.GIFT, "Finger Heart", MgAction.GIVE, "enchanted_golden_apple", 1, 0, "{user} gave you a notch apple"));
        l.add(rule(MgTrigger.GIFT, "Perfume", MgAction.TNT, "", 2, 4, "{user} sent TNT"));
        l.add(rule(MgTrigger.GIFT, "Doughnut", MgAction.RANDOM_TP, "1000", 1, 0, "{user} teleported you"));
        l.add(rule(MgTrigger.GIFT, "Rosa", MgAction.GIVE, "diamond", 5, 0, "{user} gave you diamonds"));
        l.add(rule(MgTrigger.GIFT, "Ice Cream Cone", MgAction.GIVE, "totem_of_undying", 1, 0, "{user} gave you a totem"));
        l.add(rule(MgTrigger.GIFT, "Corgi", MgAction.SPAWN, "warden", 1, 0, "{user} summoned a Warden"));
        l.add(rule(MgTrigger.GIFT, "Paper Crane", MgAction.SPAWN, "skeleton", 15, 0, "{user} sent skeletons"));
        l.add(rule(MgTrigger.GIFT, "Confetti", MgAction.SPAWN, "creeper", 15, 0, "{user} sent creepers"));
        l.add(rule(MgTrigger.GIFT, "Galaxy", MgAction.SPAWN, "warden", 7, 0, "{user} unleashed 7 Wardens"));
        // a few extra example alerts so people see what else is possible (all editable / deletable)
        MgRule share = rule(MgTrigger.SHARE, "", MgAction.GIVE, "cooked_beef", 8, 0, "{user} shared the stream - snacks!");
        l.add(share);
        MgRule sub = rule(MgTrigger.SUBSCRIBE, "", MgAction.GIVE, "diamond", 10, 0, "{user} subscribed!");
        l.add(sub);
        MgRule chat = rule(MgTrigger.CHAT, "!lightning", MgAction.LIGHTNING, "", 1, 0, "{user} called lightning");
        chat.cooldown = 30;
        l.add(chat);
        return l;
    }

    static MgRule rule(MgTrigger t, String match, MgAction a, String arg, int amount, int duration, String msg) {
        MgRule r = new MgRule(t, match, a, arg, amount, duration);
        r.message = msg;
        return r;
    }

    static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
}
