package takeyourminestream.ijustseen.minigames;

/** Info about the live event that triggered a rule (used for placeholders and combo counts). */
public final class MgCtx {
    public String login = "viewer";
    public String user = "viewer";
    public String gift = "";
    public int count = 1;
    public long likes = 0L;
    public String text = "";

    public MgCtx() {}

    public static MgCtx of(String login, String display) {
        MgCtx c = new MgCtx();
        c.login = clean(login, "viewer");
        c.user = clean(display != null && !display.trim().isEmpty() ? display : login, "viewer");
        return c;
    }

    /** Viewer-controlled text must never be able to inject extra commands, so keep it harmless. */
    static String clean(String s, String fallback) {
        if (s == null) return fallback;
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length() && b.length() < 32; i++) {
            char c = s.charAt(i);
            if (Character.isLetterOrDigit(c) || c == ' ' || c == '_' || c == '-' || c == '.') b.append(c);
            else b.append('_');
        }
        String r = b.toString().trim();
        return r.isEmpty() ? fallback : r;
    }
}
