package takeyourminestream.ijustseen.minigames;

/** What happens in the world when a rule fires. */
public enum MgAction {
    GIVE("Give item", "Item id, e.g. diamond", "diamond", "Amount = item count."),
    SPAWN("Spawn mob", "Mob id, e.g. zombie (add NBT after |  e.g. creeper|{ignited:1b})", "zombie", "Amount = how many mobs."),
    TNT("Spawn TNT", "Not used", "", "Amount = number of TNT. It explodes by itself after Duration seconds (0 = right away)."),
    FREEZE("Freeze player", "Not used", "", "Duration = seconds frozen in place."),
    CLEAR_INVENTORY("Remove inventory", "Optional item id (empty = everything)", "", "Wipes the player's inventory."),
    EFFECT("Potion effect", "Effect id, e.g. blindness, speed, nausea", "blindness", "Duration = seconds, Amount = effect level."),
    RANDOM_TP("Random teleport", "Max distance in blocks (default 1000)", "1000", "Teleports the player to a random safe spot."),
    LIGHTNING("Lightning", "Not used", "", "Amount = number of strikes around the player."),
    LAUNCH("Launch into the sky", "Not used", "", "Duration = seconds of levitation, Amount = power."),
    HEAL("Heal + feed", "Not used", "", "Full health and food."),
    HURT("Hurt player", "Not used", "", "Amount = damage points (2 = 1 heart)."),
    KILL("Kill player", "Not used", "", "Careful!"),
    TIME("Set time", "day, noon, night, midnight or ticks", "day", "Changes the world time."),
    WEATHER("Set weather", "clear, rain or thunder", "thunder", "Changes the weather."),
    XP("Give XP", "levels or points", "levels", "Amount = levels (or points)."),
    TITLE("Show title", "Text shown on screen", "{user} sent {gift}!", "Big title in the middle of the screen."),
    SOUND("Play sound", "Sound id, e.g. entity.creeper.primed", "entity.creeper.primed", "Plays a sound for the player."),
    COMMAND("Run command(s)", "Any command, no slash. Chain with  ;;  (e.g. say hi ;; give @s dirt)", "say {user} says hi", "Placeholders: {user} {gift} {count} {likes}. Amount = repeats."),
    WIN("Add win", "Not used", "", "Adds to the WINS counter shown on the HUD (Amount = wins added)."),
    ALERT("Alert only", "Not used", "", "Only shows the message, changes nothing in the world.");

    public final String label;
    public final String argHint;
    public final String defaultArg;
    public final String help;

    MgAction(String label, String argHint, String defaultArg, String help) {
        this.label = label;
        this.argHint = argHint;
        this.defaultArg = defaultArg;
        this.help = help;
    }

    public MgAction next() {
        MgAction[] v = values();
        return v[(ordinal() + 1) % v.length];
    }

    public MgAction prev() {
        MgAction[] v = values();
        return v[(ordinal() + v.length - 1) % v.length];
    }

    public static MgAction parse(String s) {
        if (s != null) {
            for (MgAction a : values()) {
                if (a.name().equalsIgnoreCase(s.trim())) return a;
            }
        }
        return ALERT;
    }
}
