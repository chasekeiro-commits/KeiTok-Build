package takeyourminestream.ijustseen.minigames;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_2960;

/**
 * Cached pixel-art sprites for the animated themes.
 * Every scene is painted once (on the CPU, tiny) into a small texture atlas, uploaded once, and from then on a theme
 * only draws a handful of textured quads per frame instead of hundreds of rectangles.
 */
public final class MgSprites {
    private MgSprites() {}

    // ------------------------------------------------------------------ atlas model

    public static final class Reg {
        public final int u, v, w, h;
        Reg(int u, int v, int w, int h) { this.u = u; this.v = v; this.w = w; this.h = h; }
    }

    public static final class Atlas {
        public final String key;
        public final int size;
        int[] px;
        final HashMap<String, Reg> regs = new HashMap<>();
        public class_2960 id;
        public Reg solid;
        Atlas(String key, int size) { this.key = key; this.size = size; this.px = new int[size * size]; }
        public Reg reg(String n) { return regs.get(n); }
        public boolean has(String n) { return regs.containsKey(n); }
    }

    /** How a finished atlas reaches the GPU. Replaced by the preview tool. */
    public interface Uploader { void upload(class_2960 id, int[] px, int size) throws Throwable; }

    public static Uploader uploader = new Uploader() {
        @Override public void upload(class_2960 id, int[] px, int size) {
            takeyourminestream.ijustseen.core.render.PanelTextureUpload.upload(id, px, size);
        }
    };

    public interface Freer { void free(class_2960 id); }

    public static Freer freer = new Freer() {
        @Override public void free(class_2960 id) {
            takeyourminestream.ijustseen.core.render.PanelTextureUpload.free(id);
        }
    };

    private static final LinkedHashMap<String, Atlas> CACHE = new LinkedHashMap<>();
    private static final HashSet<String> FAILED = new HashSet<>();

    /** Returns the atlas of a theme, building and uploading it on first use (null if that is impossible). */
    public static Atlas get(String key) {
        Atlas a = CACHE.get(key);
        if (a != null) return a;
        if (key == null || FAILED.contains(key)) return null;
        try {
            Builder b = new Builder();
            common(b);
            MgArt.theme(key, b);
            a = b.build(key);
            a.id = class_2960.method_60655("keitok", "fx_" + key);
            uploader.upload(a.id, a.px, a.size);
            a.px = null;
            CACHE.put(key, a);
            while (CACHE.size() > 3) {
                Map.Entry<String, Atlas> old = CACHE.entrySet().iterator().next();
                CACHE.remove(old.getKey());
                try { freer.free(old.getValue().id); } catch (Throwable t) { /* ignore */ }
            }
            return a;
        } catch (Throwable t) {
            FAILED.add(key);
            return null;
        }
    }

    // ------------------------------------------------------------------ painting

    public interface Painter { void paint(Cv c); }
    public interface FramePainter { void paint(Cv c, int frame); }

    private static final int[] BAYER = {0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5};

    public static int hash(int x, int y, int s) {
        int h = x * 374761393 + y * 668265263 + s * 1442695041;
        h = (h ^ (h >>> 13)) * 1274126177;
        return h ^ (h >>> 16);
    }

    /** Deterministic random in [0,1). */
    public static double rnd(int x, int y, int s) { return (hash(x, y, s) & 0xFFFFFF) / 16777216.0; }

    /** Smooth periodic 1D value noise in [0,1). x is in pixels, period in pixels (integer). */
    public static double vnoise(double x, int period, int seed) {
        double fx = Math.floor(x);
        int i0 = Math.floorMod((int) fx, period);
        int i1 = (i0 + 1) % period;
        double t = x - fx;
        t = t * t * (3 - 2 * t);
        return rnd(i0, 0, seed) * (1 - t) + rnd(i1, 0, seed) * t;
    }

    public static int C(int rgb) { return 0xFF000000 | rgb; }

    public static int A(int rgb, double a) {
        return ((int) Math.max(0, Math.min(255, Math.round(a * 255))) << 24) | (rgb & 0xFFFFFF);
    }

    public static int mix(int a, int b, double t) {
        t = Math.max(0, Math.min(1, t));
        int ar = a >> 16 & 255, ag = a >> 8 & 255, ab = a & 255, aa = a >>> 24;
        int br = b >> 16 & 255, bg = b >> 8 & 255, bb = b & 255, ba = b >>> 24;
        return ((int) (aa + (ba - aa) * t) << 24) | ((int) (ar + (br - ar) * t) << 16) | ((int) (ag + (bg - ag) * t) << 8) | (int) (ab + (bb - ab) * t);
    }

    public static int shade(int c, double f) {
        int r = Math.max(0, Math.min(255, (int) ((c >> 16 & 255) * f)));
        int g = Math.max(0, Math.min(255, (int) ((c >> 8 & 255) * f)));
        int b = Math.max(0, Math.min(255, (int) ((c & 255) * f)));
        return (c & 0xFF000000) | (r << 16) | (g << 8) | b;
    }

    /** A drawing surface over one rectangle of the atlas. Coordinates are local to that rectangle. */
    public static final class Cv {
        final int[] p;
        final int S, ox, oy;
        public final int w, h;
        boolean fx, fy, wrap;

        Cv(int[] p, int S, int ox, int oy, int w, int h) { this.p = p; this.S = S; this.ox = ox; this.oy = oy; this.w = w; this.h = h; }

        static int over(int dst, int src) {
            int sa = src >>> 24;
            if (sa == 255) return src;
            if (sa == 0) return dst;
            int da = dst >>> 24;
            if (da == 0) return src;
            int oa = sa + da * (255 - sa) / 255;
            if (oa == 0) return 0;
            int r = ((src >> 16 & 255) * sa + (dst >> 16 & 255) * da * (255 - sa) / 255) / oa;
            int g = ((src >> 8 & 255) * sa + (dst >> 8 & 255) * da * (255 - sa) / 255) / oa;
            int b = ((src & 255) * sa + (dst & 255) * da * (255 - sa) / 255) / oa;
            return (oa << 24) | (r << 16) | (g << 8) | b;
        }

        private int idx(int x, int y) {
            if (wrap) x = Math.floorMod(x, w);
            if (x < 0 || y < 0 || x >= w || y >= h) return -1;
            if (fx) x = w - 1 - x;
            if (fy) y = h - 1 - y;
            return (oy + y) * S + ox + x;
        }

        public void px(int x, int y, int c) {
            int i = idx(x, y);
            if (i >= 0) p[i] = over(p[i], c);
        }

        /** Replaces the pixel (also used to erase). */
        public void set(int x, int y, int c) {
            int i = idx(x, y);
            if (i >= 0) p[i] = c;
        }

        public int get(int x, int y) {
            int i = idx(x, y);
            return i >= 0 ? p[i] : 0;
        }

        public void rect(int x, int y, int rw, int rh, int c) {
            for (int j = 0; j < rh; j++) for (int i = 0; i < rw; i++) px(x + i, y + j, c);
        }

        public void hl(int x0, int x1, int y, int c) { for (int x = x0; x <= x1; x++) px(x, y, c); }
        public void vl(int x, int y0, int y1, int c) { for (int y = y0; y <= y1; y++) px(x, y, c); }

        public void disc(int cx, int cy, int r, int c) { ell(cx, cy, r, r, c); }

        public void ell(int cx, int cy, int rx, int ry, int c) {
            for (int dy = -ry; dy <= ry; dy++)
                for (int dx = -rx; dx <= rx; dx++) {
                    double nx = rx == 0 ? 0 : dx / (rx + 0.35), ny = ry == 0 ? 0 : dy / (ry + 0.35);
                    if (nx * nx + ny * ny <= 1.0) px(cx + dx, cy + dy, c);
                }
        }

        public void ring(int cx, int cy, int r, int c) {
            for (int dy = -r - 1; dy <= r + 1; dy++)
                for (int dx = -r - 1; dx <= r + 1; dx++) {
                    double d = Math.sqrt(dx * dx + dy * dy);
                    if (d <= r + 0.5 && d > r - 0.7) px(cx + dx, cy + dy, c);
                }
        }

        public void line(int x0, int y0, int x1, int y1, int c) {
            int dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0);
            int sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1;
            int err = dx + dy;
            for (int guard = 0; guard < 4000; guard++) {
                px(x0, y0, c);
                if (x0 == x1 && y0 == y1) break;
                int e2 = 2 * err;
                if (e2 >= dy) { err += dy; x0 += sx; }
                if (e2 <= dx) { err += dx; y0 += sy; }
            }
        }

        /** Line made of small discs (thickness r). */
        public void thick(double x0, double y0, double x1, double y1, double r, int c) {
            double len = Math.max(1, Math.hypot(x1 - x0, y1 - y0));
            int n = (int) Math.ceil(len * 1.5);
            for (int i = 0; i <= n; i++) {
                double t = i / (double) n;
                double x = x0 + (x1 - x0) * t, y = y0 + (y1 - y0) * t;
                double rr = r;
                int ir = (int) Math.floor(rr);
                if (ir <= 0) px((int) Math.round(x), (int) Math.round(y), c);
                else disc((int) Math.round(x), (int) Math.round(y), ir, c);
            }
        }

        public void tri(double x0, double y0, double x1, double y1, double x2, double y2, int c) {
            int minX = (int) Math.floor(Math.min(x0, Math.min(x1, x2))), maxX = (int) Math.ceil(Math.max(x0, Math.max(x1, x2)));
            int minY = (int) Math.floor(Math.min(y0, Math.min(y1, y2))), maxY = (int) Math.ceil(Math.max(y0, Math.max(y1, y2)));
            double den = (y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2);
            if (Math.abs(den) < 1e-9) return;
            for (int y = minY; y <= maxY; y++)
                for (int x = minX; x <= maxX; x++) {
                    double px = x + 0.5, py = y + 0.5;
                    double a = ((y1 - y2) * (px - x2) + (x2 - x1) * (py - y2)) / den;
                    double b = ((y2 - y0) * (px - x2) + (x0 - x2) * (py - y2)) / den;
                    double g = 1 - a - b;
                    if (a >= -0.02 && b >= -0.02 && g >= -0.02) px(x, y, c);
                }
        }

        public void grad(int x, int y, int gw, int gh, int top, int bottom) {
            for (int j = 0; j < gh; j++) {
                int col = mix(top, bottom, gh <= 1 ? 0 : j / (double) (gh - 1));
                for (int i = 0; i < gw; i++) px(x + i, y + j, col);
            }
        }

        /** Ordered-dither between two colours (t = 0..1). */
        public boolean dith(int x, int y, double t) { return BAYER[(y & 3) * 4 + (x & 3)] < t * 16; }

        public void speckle(int x, int y, int sw, int sh, double density, int seed, int c) {
            for (int j = 0; j < sh; j++) for (int i = 0; i < sw; i++) if (rnd(x + i, y + j, seed) < density) px(x + i, y + j, c);
        }

        /** Adds a 1px outline around opaque pixels. */
        public void outline(int c) {
            ArrayList<int[]> todo = new ArrayList<>();
            for (int y = -1; y <= h; y++)
                for (int x = -1; x <= w; x++) {
                    if ((get(x, y) >>> 24) >= 100) continue;
                    if ((get(x - 1, y) >>> 24) >= 140 || (get(x + 1, y) >>> 24) >= 140 || (get(x, y - 1) >>> 24) >= 140 || (get(x, y + 1) >>> 24) >= 140)
                        todo.add(new int[]{x, y});
                }
            for (int[] q : todo) px(q[0], q[1], c);
        }

        /** A shaded ball of leaves (pal = dark..light, light comes from the upper left). */
        public void blob(int cx, int cy, int r, int[] pal, int seed) {
            for (int dy = -r - 2; dy <= r + 2; dy++)
                for (int dx = -r - 2; dx <= r + 2; dx++) {
                    double d = Math.sqrt(dx * dx + dy * dy * 1.05);
                    double edge = r + (rnd(dx, dy, seed) - 0.5) * 1.8;
                    if (d > edge) continue;
                    double lit = (-dx * 0.55 - dy * 0.85) / Math.max(1, r);
                    double n = (rnd(dx * 3 + 1, dy * 3 + 7, seed + 5) - 0.5) * 0.8;
                    double v = 0.5 + lit * 0.5 + n * 0.5;
                    int i = (int) Math.floor(v * pal.length);
                    i = Math.max(0, Math.min(pal.length - 1, i));
                    px(cx + dx, cy + dy, pal[i]);
                }
        }

        /** Tiny 3x5 pixel font (letters, digits and a few signs). */
        public void text(String s, int x, int y, int c) {
            for (int k = 0; k < s.length(); k++) {
                String g = glyph(s.charAt(k));
                if (g != null)
                    for (int row = 0; row < 5; row++) {
                        int bits = g.charAt(row) - '0';
                        for (int col = 0; col < 3; col++) if ((bits & (4 >> col)) != 0) px(x + k * 4 + col, y + row, c);
                    }
            }
        }
    }

    private static final String FONT_KEYS = "0123456789.:-_>/! ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String[] FONT = {
        "75557", "26227", "71747", "71717", "55711", "74717", "74757", "71222", "75757", "75717", "00002", "02020", "00700", "00007", "42124", "11244", "22202", "00000",
        "25755", "65656", "74447", "65556", "74647", "74644", "74557", "55755", "72227", "11157", "55655", "44447", "57755", "75555", "75557", "75744", "75571", "65655",
        "74717", "72222", "55557", "55552", "55775", "55255", "55222", "71247"
    };

    static String glyph(char ch) {
        int i = FONT_KEYS.indexOf(Character.toUpperCase(ch));
        return i < 0 ? null : FONT[i];
    }

    // ------------------------------------------------------------------ atlas builder

    public static final class Builder {
        static final class Spec {
            final String n; final int w, h; final Painter p; final boolean fx, fy;
            int x, y;
            Spec(String n, int w, int h, Painter p, boolean fx, boolean fy) { this.n = n; this.w = w; this.h = h; this.p = p; this.fx = fx; this.fy = fy; }
        }

        final ArrayList<Spec> specs = new ArrayList<>();
        final HashSet<String> names = new HashSet<>();

        public Builder add(String n, int w, int h, Painter p) { return addF(n, w, h, p, false, false); }

        Builder addF(String n, int w, int h, Painter p, boolean fx, boolean fy) {
            if (!names.add(n)) throw new IllegalStateException("duplicate sprite " + n);
            specs.add(new Spec(n, w, h, p, fx, fy));
            return this;
        }

        /** Same picture facing right (name+"R") and left (name+"L"). */
        public Builder pair(String n, int w, int h, Painter p) {
            addF(n + "R", w, h, p, false, false);
            return addF(n + "L", w, h, p, true, false);
        }

        public Builder frames(String n, int cnt, int w, int h, FramePainter p) {
            for (int i = 0; i < cnt; i++) {
                final int f = i;
                add(n + i, w, h, c -> p.paint(c, f));
            }
            return this;
        }

        public Builder framesPair(String n, int cnt, int w, int h, FramePainter p) {
            for (int i = 0; i < cnt; i++) {
                final int f = i;
                addF(n + "R" + i, w, h, c -> p.paint(c, f), false, false);
                addF(n + "L" + i, w, h, c -> p.paint(c, f), true, false);
            }
            return this;
        }

        /** Four mirrored corner pieces: n+"TL", "TR", "BL", "BR" (paint the top-left one). */
        public Builder corners(String n, int w, int h, Painter tl) {
            addF(n + "TL", w, h, tl, false, false);
            addF(n + "TR", w, h, tl, true, false);
            addF(n + "BL", w, h, tl, false, true);
            return addF(n + "BR", w, h, tl, true, true);
        }

        Atlas build(String key) {
            ArrayList<Spec> order = new ArrayList<>(specs);
            Collections.sort(order, (a, b) -> b.h != a.h ? b.h - a.h : b.w - a.w);
            for (int size : new int[]{128, 256, 512}) {
                if (!layout(order, size)) continue;
                Atlas a = new Atlas(key, size);
                for (Spec s : order) {
                    Cv c = new Cv(a.px, size, s.x, s.y, s.w, s.h);
                    c.fx = s.fx;
                    c.fy = s.fy;
                    s.p.paint(c);
                    a.regs.put(s.n, new Reg(s.x, s.y, s.w, s.h));
                }
                a.solid = a.regs.get("solid");
                return a;
            }
            throw new IllegalStateException("sprites do not fit");
        }

        private static boolean layout(ArrayList<Spec> order, int size) {
            int x = 1, y = 1, rowH = 0;
            for (Spec s : order) {
                if (x + s.w + 1 > size) { x = 1; y += rowH + 1; rowH = 0; }
                if (y + s.h + 1 > size || s.w + 2 > size) return false;
                s.x = x;
                s.y = y;
                x += s.w + 1;
                rowH = Math.max(rowH, s.h);
            }
            return true;
        }
    }

    // ------------------------------------------------------------------ pictures every theme shares (white, tinted when drawn)

    static void common(Builder b) {
        b.add("solid", 2, 2, c -> c.rect(0, 0, 2, 2, 0xFFFFFFFF));
        b.add("rampR", 64, 1, c -> { for (int i = 0; i < 64; i++) c.px(i, 0, A(0xFFFFFF, Math.pow((i + 1) / 64.0, 1.8))); });
        b.add("rampL", 64, 1, c -> { for (int i = 0; i < 64; i++) c.px(63 - i, 0, A(0xFFFFFF, Math.pow((i + 1) / 64.0, 1.8))); });
        b.add("rampD", 1, 64, c -> { for (int i = 0; i < 64; i++) c.px(0, i, A(0xFFFFFF, Math.pow((i + 1) / 64.0, 1.8))); });
        b.add("rampU", 1, 64, c -> { for (int i = 0; i < 64; i++) c.px(0, 63 - i, A(0xFFFFFF, Math.pow((i + 1) / 64.0, 1.8))); });
        b.add("glow", 33, 33, c -> {
            for (int y = 0; y < 33; y++) for (int x = 0; x < 33; x++) {
                double d = Math.hypot(x - 16, y - 16) / 16.5;
                if (d < 1) c.px(x, y, A(0xFFFFFF, Math.pow(1 - d, 2.0)));
            }
        });
        b.add("puff", 9, 9, c -> {
            for (int y = 0; y < 9; y++) for (int x = 0; x < 9; x++) {
                double d = Math.hypot(x - 4, y - 4) / 4.6;
                if (d < 1) c.px(x, y, A(0xFFFFFF, Math.pow(1 - d, 1.1)));
            }
        });
        b.add("dot", 3, 3, c -> {
            c.px(1, 1, 0xFFFFFFFF);
            c.px(0, 1, A(0xFFFFFF, 0.55)); c.px(2, 1, A(0xFFFFFF, 0.55)); c.px(1, 0, A(0xFFFFFF, 0.55)); c.px(1, 2, A(0xFFFFFF, 0.55));
            c.px(0, 0, A(0xFFFFFF, 0.2)); c.px(2, 0, A(0xFFFFFF, 0.2)); c.px(0, 2, A(0xFFFFFF, 0.2)); c.px(2, 2, A(0xFFFFFF, 0.2));
        });
        b.add("spark5", 5, 5, c -> {
            c.px(2, 2, 0xFFFFFFFF);
            c.px(1, 2, A(0xFFFFFF, 0.8)); c.px(3, 2, A(0xFFFFFF, 0.8)); c.px(2, 1, A(0xFFFFFF, 0.8)); c.px(2, 3, A(0xFFFFFF, 0.8));
            c.px(0, 2, A(0xFFFFFF, 0.35)); c.px(4, 2, A(0xFFFFFF, 0.35)); c.px(2, 0, A(0xFFFFFF, 0.35)); c.px(2, 4, A(0xFFFFFF, 0.35));
        });
        b.add("spark9", 9, 9, c -> {
            c.px(4, 4, 0xFFFFFFFF);
            for (int i = 1; i <= 4; i++) {
                int a = (int) (255 * Math.pow(1 - (i - 1) / 4.5, 1.4));
                c.px(4 - i, 4, (a << 24) | 0xFFFFFF); c.px(4 + i, 4, (a << 24) | 0xFFFFFF);
                c.px(4, 4 - i, (a << 24) | 0xFFFFFF); c.px(4, 4 + i, (a << 24) | 0xFFFFFF);
            }
            c.px(3, 3, A(0xFFFFFF, 0.5)); c.px(5, 3, A(0xFFFFFF, 0.5)); c.px(3, 5, A(0xFFFFFF, 0.5)); c.px(5, 5, A(0xFFFFFF, 0.5));
        });
        // a soft slanted beam of light (white, tinted when drawn)
        b.add("beam", 26, 64, c -> {
            for (int y = 0; y < 64; y++) {
                double cx = 7 + y * 0.18, half = 3.2 + y * 0.12;
                double fall = Math.pow(1 - y / 64.0, 0.8);
                for (int x = 0; x < 26; x++) {
                    double d = Math.abs(x - cx) / half;
                    if (d < 1) c.px(x, y, A(0xFFFFFF, (1 - d * d) * fall));
                }
            }
        });
        b.corners("br", 9, 9, c -> {
            c.hl(0, 7, 0, 0xFFFFFFFF); c.vl(0, 0, 7, 0xFFFFFFFF);
            c.px(2, 2, A(0xFFFFFF, 0.8)); c.px(3, 2, A(0xFFFFFF, 0.35)); c.px(2, 3, A(0xFFFFFF, 0.35));
        });
    }
}
