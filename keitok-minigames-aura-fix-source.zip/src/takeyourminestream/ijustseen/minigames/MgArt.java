package takeyourminestream.ijustseen.minigames;

import static takeyourminestream.ijustseen.minigames.MgSprites.A;
import static takeyourminestream.ijustseen.minigames.MgSprites.C;
import static takeyourminestream.ijustseen.minigames.MgSprites.mix;
import static takeyourminestream.ijustseen.minigames.MgSprites.rnd;
import static takeyourminestream.ijustseen.minigames.MgSprites.shade;
import static takeyourminestream.ijustseen.minigames.MgSprites.vnoise;

import takeyourminestream.ijustseen.minigames.MgSprites.Builder;
import takeyourminestream.ijustseen.minigames.MgSprites.Cv;

/** Pixel art for the themes: purple moon, lokalhost and ocean (the others are in MgArt2 and MgArt3). */
final class MgArt {
    private MgArt() {}

    static void theme(String key, Builder b) {
        switch (key) {
            case "purple_moon": purple(b); break;
            case "lokalhost": lokal(b); break;
            case "ocean_depths": ocean(b); break;
            case "sakura_bloom": MgArt2.sakura(b); break;
            case "emerald_grove": MgArt2.grove(b); break;
            case "solar_flare": MgArt2.solar(b); break;
            case "midnight_blue": MgArt3.midnight(b); break;
            case "cyberpunk": MgArt3.cyber(b); break;
            default: break; // the default theme only uses the shared pictures
        }
    }

    // ------------------------------------------------------------------ helpers shared by all art files

    static final double TAU = Math.PI * 2;

    /** Periodic height line for tileable hills: sum of sines with whole numbers of cycles. */
    static double wave(int x, int period, double base, double[] amp, int[] cyc, double[] ph) {
        double v = base;
        for (int i = 0; i < amp.length; i++) v += amp[i] * Math.sin(TAU * cyc[i] * x / period + ph[i]);
        return v;
    }

    static void pine(Cv c, int cx, int base, int h, int col, int snow, int hi) {
        int tiers = Math.max(2, h / 4);
        for (int t = 0; t < tiers; t++) {
            double top = base - h + t * (h - 2.0) / tiers;
            double bot = top + (h / (double) tiers) * 1.9;
            double half = 1.2 + (t + 1) * (h / 2.6) / tiers;
            c.tri(cx, top, cx - half, bot, cx + half, bot, col);
            if (snow != 0) c.tri(cx, top, cx - half * 0.6, top + (bot - top) * 0.45, cx + half * 0.6, top + (bot - top) * 0.45, snow);
        }
        c.rect(cx, base - 1, 1, 2, shade(col, 0.7));
        if (hi != 0) for (int t = 0; t < tiers; t++) c.px(cx - 1 - t / 2, base - h + 3 + t * (h / tiers), hi);
    }

    static void cloud(Cv c, int[] cx, int[] cy, int[] r, int top, int bottom, int baseY) {
        for (int i = 0; i < cx.length; i++) c.disc(cx[i], cy[i], r[i], top);
        for (int y = 0; y < c.h; y++)
            for (int x = 0; x < c.w; x++) {
                int p = c.get(x, y);
                if ((p >>> 24) == 0) continue;
                if (y > baseY) c.set(x, y, 0);
                else if (y > baseY - 3) c.set(x, y, mix(p, bottom | 0xFF000000, 0.65));
            }
    }

    // ------------------------------------------------------------------ purple moon

    static void purple(Builder b) {
        b.add("moon", 28, 28, c -> {
            c.disc(13, 14, 11, C(0xF4ECFF));
            for (int y = 0; y < 28; y++)
                for (int x = 0; x < 28; x++) {
                    double d = Math.hypot(x - 19.5, y - 11.5);
                    if (d < 9.8) { c.set(x, y, 0); continue; }
                    int p = c.get(x, y);
                    if ((p >>> 24) == 0) continue;
                    double t = Math.min(1, (d - 9.8) / 4.0);
                    c.set(x, y, mix(C(0xB9A2E6), C(0xFFFAFF), t));
                }
            c.disc(6, 16, 1, C(0xCDB8F0)); c.disc(8, 21, 1, C(0xCDB8F0)); c.px(5, 12, C(0xCDB8F0)); c.px(7, 8, C(0xD9C8F6));
            c.px(4, 19, C(0xCDB8F0)); c.px(10, 23, C(0xD0BCF2));
        });
        b.add("cloud0", 38, 12, c -> cloud(c, new int[]{8, 15, 23, 31}, new int[]{8, 6, 7, 9}, new int[]{5, 6, 5, 4}, C(0xF0E8FF), 0xA08CD8, 10));
        b.add("cloud1", 26, 9, c -> cloud(c, new int[]{6, 12, 19}, new int[]{6, 4, 6}, new int[]{4, 4, 3}, C(0xF0E8FF), 0xA08CD8, 7));
        b.add("hillF", 64, 26, c -> {
            c.wrap = true;
            for (int x = 0; x < 64; x++) {
                double hgt = wave(x, 64, 13, new double[]{5, 3, 1.6}, new int[]{1, 3, 7}, new double[]{0, 1.3, 0.4});
                int top = 26 - (int) Math.round(hgt);
                for (int y = top; y < 26; y++) c.px(x, y, mix(C(0x4C388C), C(0x251A48), (y - top) / (double) Math.max(1, 26 - top)));
                c.px(x, top, C(0x7660BE));
                if (c.dith(x, top + 1, 0.5)) c.px(x, top + 1, C(0x5E4AA4));
            }
        });
        b.add("hillN", 64, 18, c -> {
            c.wrap = true;
            int[] ridge = new int[64];
            for (int x = 0; x < 64; x++) {
                double hgt = wave(x, 64, 7, new double[]{3, 2, 1}, new int[]{2, 5, 9}, new double[]{0.7, 2.1, 0.3});
                ridge[x] = 18 - (int) Math.round(hgt);
                for (int y = ridge[x]; y < 18; y++) c.px(x, y, mix(C(0x1F1544), C(0x0D0820), (y - ridge[x]) / (double) Math.max(1, 18 - ridge[x])));
                c.px(x, ridge[x], C(0x3D2D76));
            }
            int[] tx = {5, 21, 30, 46, 58};
            for (int i = 0; i < tx.length; i++) pine(c, tx[i], ridge[tx[i]] + 1, 8 + (i * 3) % 4, C(0x120A2C), 0, C(0x2A1E58));
            // a little cottage with a lit window
            int hx = 38, hy = ridge[40];
            c.rect(hx, hy - 4, 7, 5, C(0x160D32));
            c.tri(hx - 1, hy - 4, hx + 3.5, hy - 8, hx + 8, hy - 4, C(0x1D1240));
            c.rect(hx + 2, hy - 3, 2, 2, C(0xFFD98A));
            c.px(hx + 5, hy - 8, C(0x160D32)); c.px(hx + 5, hy - 7, C(0x160D32));
        });
        b.add("tower", 14, 38, c -> {
            for (int y = 12; y < 38; y++)
                for (int x = 3; x < 11; x++) {
                    int col = C(0x30265A);
                    double n = rnd(x, y, 4);
                    if (n < 0.18) col = C(0x241B48); else if (n > 0.86) col = C(0x3D3070);
                    if (y % 4 == 0) col = shade(col, 0.82);
                    if (x == 3) col = C(0x4B3C84);
                    if (x == 10) col = C(0x1C1438);
                    c.px(x, y, col);
                }
            c.tri(6.5, 0, 0.5, 13, 12.5, 13, C(0x57308F));
            c.tri(6.5, 0, 0.5, 13, 5, 13, C(0x7144B0));
            c.rect(2, 12, 10, 1, C(0x20183E));
            c.rect(5, 20, 3, 4, C(0x12092A)); c.rect(5, 20, 3, 3, C(0xFFD98A)); c.px(6, 21, C(0xFFF2C8));
            c.rect(6, 29, 1, 3, C(0x12092A));
            c.px(6, 0, C(0xFFFFFF)); c.line(7, 1, 10, 2, C(0xFF6AB8)); c.px(10, 3, C(0xFF6AB8));
        });
        b.add("deadtree", 22, 32, c -> {
            int tr = C(0x160D30), hi = C(0x2C1F58);
            c.thick(11, 31, 11, 17, 1.4, tr);
            c.thick(11, 20, 4, 9, 1.0, tr); c.thick(4, 9, 2, 3, 0.6, tr); c.thick(5, 8, 8, 4, 0.6, tr);
            c.thick(11, 17, 17, 8, 1.0, tr); c.thick(17, 8, 20, 4, 0.6, tr); c.thick(16, 9, 13, 3, 0.6, tr);
            c.thick(10, 24, 17, 20, 0.7, tr); c.thick(11, 27, 5, 22, 0.6, tr);
            c.vl(10, 18, 30, hi);
            c.rect(8, 30, 7, 2, tr);
        });
        b.frames("bat", 2, 11, 7, (c, f) -> {
            int col = C(0x0C0618), hi = C(0x3A2670);
            int ty = f == 0 ? 0 : 6;
            c.tri(4.5, 3, 0, ty, 3.5, 5.5, col);
            c.tri(5.5, 3, 10, ty, 6.5, 5.5, col);
            c.rect(4, 1, 3, 4, col);
            c.px(4, 0, col); c.px(6, 0, col);
            c.px(4, 2, C(0xFF6AB8)); c.px(6, 2, C(0xFF6AB8));
            c.px(1, f == 0 ? 1 : 5, hi); c.px(9, f == 0 ? 1 : 5, hi);
            c.set(2, f == 0 ? 4 : 2, 0); c.set(8, f == 0 ? 4 : 2, 0);
        });
        b.add("fog", 64, 9, c -> {
            c.wrap = true;
            for (int y = 0; y < 9; y++)
                for (int x = 0; x < 64; x++) {
                    double n = 0.55 * vnoise(x / 8.0 + y * 0.02, 8, 1) + 0.45 * vnoise(x / 4.0 + 3, 16, 2);
                    double prof = Math.sin(Math.PI * (y + 0.5) / 9.0);
                    double a = Math.max(0, (n - 0.38) * 2.0) * prof;
                    if (a > 0.02) c.px(x, y, A(0xDCCBFF, Math.min(0.85, a * 1.0)));
                }
        });
        b.add("edgeT", 64, 6, c -> {
            c.wrap = true;
            for (int i = 0; i < 11; i++) {
                int x = (int) (rnd(i, 1, 41) * 64), y = (int) (rnd(i, 2, 41) * 5);
                double a = 0.45 + 0.55 * rnd(i, 3, 41);
                c.px(x, y, A(0xE9DAFF, a));
                if (i % 4 == 0) { c.px(x - 1, y, A(0xE9DAFF, a * 0.5)); c.px(x + 1, y, A(0xE9DAFF, a * 0.5)); c.px(x, y - 1, A(0xE9DAFF, a * 0.5)); c.px(x, y + 1, A(0xE9DAFF, a * 0.5)); }
            }
        });
        b.add("edgeB", 64, 6, c -> {
            c.wrap = true;
            int[] ridge = new int[64];
            for (int x = 0; x < 64; x++) {
                ridge[x] = 6 - (int) Math.round(wave(x, 64, 2.4, new double[]{1.4, 0.9}, new int[]{2, 5}, new double[]{0.7, 2.1}));
                for (int y = ridge[x]; y < 6; y++) c.px(x, y, mix(C(0x1F1544), C(0x0D0820), (y - ridge[x]) / 3.0));
                c.px(x, ridge[x], C(0x3D2D76));
            }
            for (int x : new int[]{8, 27, 45, 58}) pine(c, x, ridge[x] + 1, 5, C(0x120A2C), 0, 0);
        });
        b.corners("cp", 11, 11, c -> {
            c.hl(0, 9, 0, 0xFFFFFFFF); c.vl(0, 0, 9, 0xFFFFFFFF);
            c.px(3, 3, 0xFFFFFFFF);
            int s = A(0xFFFFFF, 0.55);
            c.px(2, 3, s); c.px(4, 3, s); c.px(3, 2, s); c.px(3, 4, s);
            c.px(1, 1, A(0xFFFFFF, 0.5));
        });
    }

    // ------------------------------------------------------------------ lokalhost (only red and black)

    static void lokal(Builder b) {
        final int R1 = C(0xFF2A2A), R2 = C(0xC01818), R3 = C(0x7A0A0A), R4 = C(0x3A0505);
        b.add("radar", 34, 34, c -> {
            c.disc(17, 17, 16, A(0x0A0000, 0.88));
            c.ring(17, 17, 16, R2); c.ring(17, 17, 11, R3); c.ring(17, 17, 6, R3);
            c.hl(1, 32, 17, R4); c.vl(17, 1, 32, R4);
            for (int k = 0; k < 12; k++) {
                double a = k * Math.PI / 6;
                c.px(17 + (int) Math.round(Math.cos(a) * 14.5), 17 + (int) Math.round(Math.sin(a) * 14.5), R2);
            }
            c.px(17, 17, R1);
        });
        b.frames("sweep", 12, 34, 34, (c, f) -> {
            double ang = f * Math.PI / 6;
            for (int y = 0; y < 34; y++)
                for (int x = 0; x < 34; x++) {
                    double dx = x - 16.5, dy = y - 16.5;
                    if (Math.hypot(dx, dy) > 15.8) continue;
                    double th = Math.atan2(dy, dx);
                    double rel = ang - th;
                    rel = rel - Math.floor(rel / TAU) * TAU;
                    if (rel < 1.6) c.px(x, y, A(0xFF2A2A, Math.pow(1 - rel / 1.6, 1.7) * 0.7));
                    if (rel < 0.11) c.px(x, y, C(0xFF5A5A));
                }
        });
        b.frames("rack", 2, 64, 24, (c, f) -> {
            c.wrap = true;
            for (int r = 0; r < 4; r++) {
                int x0 = r * 16 + 1, hgt = 15 + (r * 5) % 8, top = 24 - hgt;
                c.rect(x0, top, 14, hgt, C(0x0E0000));
                c.hl(x0, x0 + 13, top, C(0x4A0808));
                c.vl(x0, top, 23, C(0x2A0505)); c.vl(x0 + 13, top, 23, C(0x1A0303));
                for (int y = top + 2; y < 22; y += 3) {
                    c.hl(x0 + 2, x0 + 8, y, C(0x2A0606));
                    boolean on = rnd(r, y, 3 + f * 17) < 0.45;
                    c.px(x0 + 10, y, on ? R1 : C(0x3A0808));
                    if (rnd(r, y, 9) < 0.35) c.px(x0 + 11, y, rnd(r, y, 5 + f * 9) < 0.5 ? R2 : C(0x2A0505));
                }
            }
        });
        b.add("ecg", 64, 14, c -> {
            c.wrap = true;
            int base = 8;
            int[] dy = new int[64];
            for (int x = 14; x <= 16; x++) dy[x] = -1;
            dy[20] = 1; dy[21] = -6; dy[22] = 3;
            for (int x = 27; x <= 31; x++) dy[x] = -2;
            int prev = base;
            for (int x = 0; x < 64; x++) {
                int y = base + dy[x];
                int lo = Math.min(prev, y), hi = Math.max(prev, y);
                for (int yy = lo; yy <= hi; yy++) c.px(x, yy, R1);
                c.px(x, lo - 1, A(0xFF2A2A, 0.28)); c.px(x, hi + 1, A(0xFF2A2A, 0.28));
                prev = y;
            }
        });
        for (int v = 0; v < 3; v++) {
            final int seed = v * 11 + 1;
            b.add("col" + v, 5, 36, c -> {
                for (int gy = 0; gy + 5 <= 36; gy += 6) {
                    double t = Math.pow((gy + 5) / 36.0, 1.6);
                    int ch = (int) (rnd(gy, 1, seed) * 10);
                    c.text(String.valueOf(ch), 1, gy, gy + 6 > 36 - 1 ? R1 : A(0xFF2A2A, 0.12 + 0.75 * t));
                }
            });
        }
        b.add("edgeT", 64, 6, c -> {
            c.wrap = true;
            c.text("01101001", 0, 0, A(0xC01818, 0.6));
            c.text("10010110", 32, 1, A(0x7A0A0A, 0.95));
        });
        b.add("edgeB", 64, 6, c -> {
            c.wrap = true;
            int[] dy = new int[64];
            dy[18] = -1; dy[19] = -1; dy[28] = 1; dy[29] = -3; dy[30] = 2; for (int x = 42; x <= 44; x++) dy[x] = -1;
            int prev = 3;
            for (int x = 0; x < 64; x++) {
                int y = 3 + dy[x];
                for (int yy = Math.min(prev, y); yy <= Math.max(prev, y); yy++) c.px(x, yy, R1);
                c.px(x, Math.min(prev, y) - 1, A(0xFF2A2A, 0.25)); c.px(x, Math.max(prev, y) + 1, A(0xFF2A2A, 0.25));
                prev = y;
            }
        });
        b.corners("circ", 18, 18, c -> {
            c.hl(6, 17, 2, R2); c.line(6, 2, 2, 6, R2); c.vl(2, 6, 17, R2);
            c.hl(9, 17, 5, R3); c.line(9, 5, 5, 9, R3); c.vl(5, 9, 17, R3);
            c.rect(6, 1, 3, 3, R1); c.rect(1, 17, 3, 1, R1);
            c.px(17, 2, R1); c.px(17, 5, R2);
            c.rect(8, 8, 2, 2, R3); c.px(8, 8, R2);
        });
        b.corners("cl", 9, 9, c -> {
            c.hl(0, 7, 0, 0xFFFFFFFF); c.vl(0, 0, 7, 0xFFFFFFFF); c.px(2, 2, A(0xFFFFFF, 0.8));
        });
        b.add("txt", 62, 5, c -> c.text("127.0.0.1:25565", 0, 0, R2));
    }

    // ------------------------------------------------------------------ ocean depths

    private static void branch(Cv c, double x, double y, double ang, double len, double th, int depth, int maxDepth, int col1, int col2, int seed) {
        if (depth == 0 || len < 1.6) return;
        double x2 = x + Math.cos(ang) * len, y2 = y + Math.sin(ang) * len;
        c.thick(x, y, x2, y2, th, mix(col2, col1, depth / (double) maxDepth));
        double j = (rnd(depth, seed, 3) - 0.5) * 0.5;
        branch(c, x2, y2, ang - 0.55 + j, len * 0.74, Math.max(0.5, th * 0.8), depth - 1, maxDepth, col1, col2, seed + 1);
        branch(c, x2, y2, ang + 0.5 + j, len * 0.7, Math.max(0.5, th * 0.8), depth - 1, maxDepth, col1, col2, seed + 2);
        if (depth == 1) c.px((int) Math.round(x2), (int) Math.round(y2), C(0xFFE0D0));
    }

    static void ocean(Builder b) {
        b.add("wave", 64, 6, c -> {
            c.wrap = true;
            for (int x = 0; x < 64; x++) {
                double y = 1.5 + Math.sin(TAU * 2 * x / 64.0) * 1.1 + Math.sin(TAU * 5 * x / 64.0 + 1) * 0.6;
                int yy = (int) Math.round(y);
                c.px(x, yy, C(0xC8F6FF)); c.px(x, yy + 1, A(0x7FE9FF, 0.7)); c.px(x, yy + 2, A(0x4FB6FF, 0.4)); c.px(x, yy + 3, A(0x4FB6FF, 0.18));
            }
            c.px(9, 0, C(0xFFFFFF)); c.px(28, 1, C(0xFFFFFF)); c.px(47, 0, C(0xFFFFFF)); c.px(58, 1, A(0xFFFFFF, 0.7));
        });
        b.add("seabed", 64, 16, c -> {
            c.wrap = true;
            for (int x = 0; x < 64; x++) {
                int top = 5 + (int) Math.round(wave(x, 64, 0, new double[]{1.8, 1.1, 0.7}, new int[]{1, 3, 9}, new double[]{0, 2, 0.5}));
                for (int y = top; y < 16; y++) {
                    int col = mix(C(0xE6D49A), C(0xA8905A), (y - top) / (double) Math.max(1, 16 - top));
                    if (rnd(x, y, 6) < 0.12) col = shade(col, 0.88);
                    c.px(x, y, col);
                }
                c.px(x, top, C(0xF6EAC0));
            }
            c.rect(9, 9, 3, 2, C(0x8C8F99)); c.px(9, 9, C(0xB4B8C2)); c.rect(40, 8, 2, 2, C(0x777B88));
            c.rect(22, 10, 3, 2, C(0xF2D6C4)); c.px(23, 10, C(0xFFFFFF)); c.px(24, 11, C(0xD2A890));
            c.px(52, 11, C(0xF2D6C4)); c.px(53, 11, C(0xD2A890));
        });
        b.add("coralA", 26, 30, c -> branch(c, 13, 29, -Math.PI / 2, 8.5, 1.5, 5, 5, C(0xFFB09C), C(0xE0507A), 4));
        b.add("coralB", 24, 22, c -> {
            for (int k = 0; k < 15; k++) {
                double a = -Math.PI + 0.35 + k * (Math.PI - 0.7) / 14.0;
                for (int r = 2; r < 11 + (k % 2); r++) c.px(12 + (int) Math.round(Math.cos(a) * r * 1.05), 21 + (int) Math.round(Math.sin(a) * r), mix(C(0xA050E8), C(0xE6B4FF), r / 12.0));
            }
            for (int r = 4; r < 11; r += 3) for (int k = 0; k < 16; k++) {
                double a = -Math.PI + 0.35 + k * (Math.PI - 0.7) / 15.0;
                c.px(12 + (int) Math.round(Math.cos(a) * r * 1.05), 21 + (int) Math.round(Math.sin(a) * r), C(0x7A34B8));
            }
            c.rect(11, 18, 3, 4, C(0x7A34B8));
        });
        b.add("coralC", 20, 16, c -> {
            int[] tx = {2, 7, 12, 16}, th = {9, 13, 10, 7};
            for (int i = 0; i < 4; i++) {
                c.rect(tx[i], 15 - th[i], 3, th[i], C(0xFFC94A));
                c.vl(tx[i], 15 - th[i], 15, C(0xFFE58A)); c.vl(tx[i] + 2, 15 - th[i], 15, C(0xC98A1A));
                c.rect(tx[i] + 1, 15 - th[i], 1, 1, C(0x5A3A08));
            }
        });
        b.frames("kelp", 4, 9, 46, (c, f) -> {
            double ph = f * Math.PI / 2;
            for (int j = 0; j < 46; j++) {
                double off = Math.sin(ph + j * 0.21) * Math.min(3.4, j * 0.09);
                int x = 4 + (int) Math.round(off), y = 45 - j;
                c.px(x, y, C(0x39D58A)); c.px(x + 1, y, C(0x1F9F6A));
                if (j % 8 == 5) { c.px(x - 1, y, C(0x39D58A)); c.px(x - 2, y - 1, C(0x39D58A)); }
                if (j % 8 == 1 && j > 3) { c.px(x + 2, y, C(0x1F9F6A)); c.px(x + 3, y - 1, C(0x39D58A)); }
            }
        });
        b.framesPair("clown", 2, 14, 9, (c, f) -> {
            int o = C(0xFF8A2A), w = C(0xFFFFFF), k = C(0x2A1208);
            c.ell(8, 4, 5, 3, o);
            c.tri(0, 4 - 2 - f, 3.5, 4, 0, 4 + 2 + f, o);
            c.tri(6, 0.5, 11, 1.5, 9, 2.5, C(0xE06A18));
            c.vl(6, 2, 6, k); c.vl(7, 1, 7, w); c.vl(8, 1, 7, w); c.vl(9, 1, 7, k);
            c.vl(11, 3, 5, w);
            c.px(12, 3, k); c.px(10, 8, o);
            c.hl(5, 11, 7, mix(o, C(0xFFC48A), 0.5));
        });
        b.framesPair("tang", 2, 13, 9, (c, f) -> {
            int bl = C(0x3FA0FF), y = C(0xFFD23F), k = C(0x10223F);
            c.ell(7, 4, 5, 3, bl);
            c.tri(0, 4 - 3 - f, 3, 4, 0, 4 + 3 + f, y);
            c.line(3, 3, 10, 3, k); c.line(4, 4, 9, 6, shade(bl, 0.7));
            c.px(10, 3, C(0xFFFFFF)); c.px(11, 3, k);
            c.hl(6, 10, 7, C(0x8FD0FF));
        });
        b.framesPair("minnow", 2, 10, 6, (c, f) -> {
            int s = C(0xC6D8E6), k = C(0x203040);
            c.ell(6, 3, 3, 2, s);
            c.tri(0, 3 - 2 - f, 3, 3, 0, 3 + 2 + f, shade(s, 0.85));
            c.hl(4, 8, 4, C(0xEEF6FF));
            c.px(8, 2, k);
        });
        b.frames("jelly", 3, 15, 20, (c, f) -> {
            int ry = f == 1 ? 3 : 5, rx = f == 1 ? 6 : 5;
            int dome = A(0xE08FFF, 0.78), rim = A(0xFFD6FF, 0.95);
            for (int y = -ry; y <= 0; y++)
                for (int x = -rx; x <= rx; x++) {
                    double nx = x / (rx + 0.3), ny = y / (ry + 0.3);
                    if (nx * nx + ny * ny <= 1) c.px(7 + x, 6 + y, (y == -ry || nx * nx + ny * ny > 0.72) ? rim : dome);
                }
            c.px(5, 3 + (5 - ry), A(0xFFFFFF, 0.9)); c.px(6, 2 + (5 - ry), A(0xFFFFFF, 0.7));
            for (int i = 0; i < 5; i++) {
                int tx = 7 - 4 + i * 2;
                for (int j = 0; j < 9 + (i % 2) * 3; j++) {
                    int xx = tx + (int) Math.round(Math.sin(f * 2.1 + j * 0.7 + i) * 1.1);
                    c.px(xx, 7 + j, A(0xEBB6FF, 0.75 - j * 0.045));
                }
            }
        });
        b.pair("whale", 74, 30, c -> {
            int body = C(0x2A6A94), belly = C(0x6FA9C6), dark = C(0x1B4A6C);
            c.ell(40, 15, 31, 9, body);
            c.tri(70, 12, 44, 6, 44, 24, body);
            c.tri(70, 14, 62, 8, 62, 20, body);
            c.tri(2, 4, 12, 13, 12, 18, body); c.tri(4, 27, 12, 14, 12, 19, body);
            for (int x = 14; x < 56; x++) { int yy = 18 + (int) Math.round(Math.sin(x * 0.2) * 0.6); c.hl(x, x, yy, belly); c.hl(x, x, yy + 1, belly); }
            for (int x = 14; x < 52; x += 3) c.px(x, 20, shade(belly, 0.8));
            c.tri(30, 22, 38, 22, 28, 28, dark);
            c.px(63, 13, C(0x07202F)); c.px(63, 12, A(0xFFFFFF, 0.6));
            c.hl(54, 70, 17, dark);
            for (int y = 0; y < 30; y++) for (int x = 0; x < 74; x++) { int p = c.get(x, y); if ((p >>> 24) == 255) c.set(x, y, (p & 0xFFFFFF) | 0xCC000000); }
        });
        b.add("bubble", 5, 5, c -> {
            c.px(1, 0, A(0xFFFFFF, 0.8)); c.px(2, 0, A(0xFFFFFF, 0.8)); c.px(3, 0, A(0xFFFFFF, 0.8));
            c.px(0, 1, A(0xFFFFFF, 0.8)); c.px(4, 1, A(0xFFFFFF, 0.45)); c.px(0, 2, A(0xFFFFFF, 0.8)); c.px(4, 2, A(0xFFFFFF, 0.45));
            c.px(0, 3, A(0xFFFFFF, 0.5)); c.px(4, 3, A(0xFFFFFF, 0.3)); c.px(1, 4, A(0xFFFFFF, 0.45)); c.px(2, 4, A(0xFFFFFF, 0.45)); c.px(3, 4, A(0xFFFFFF, 0.3));
            c.px(1, 1, C(0xFFFFFF));
        });
        b.add("star", 11, 11, c -> {
            int o = C(0xFF8F5A), l = C(0xFFC49A);
            c.tri(5.5, 0, 3.6, 4.4, 7.4, 4.4, o); c.tri(10.5, 4, 7.2, 3.6, 7.2, 6.4, o); c.tri(8.6, 10.5, 6.6, 6.4, 8.4, 5, o);
            c.tri(2.4, 10.5, 4.4, 6.4, 2.6, 5, o); c.tri(0.5, 4, 3.8, 3.6, 3.8, 6.4, o);
            c.disc(5, 5, 2, o); c.px(5, 4, l); c.px(4, 5, l); c.px(5, 2, l); c.px(5, 6, shade(o, 0.8));
        });
        b.add("urchin", 11, 11, c -> {
            int p = C(0x6B2D9E), l = C(0xB86BFF);
            for (int k = 0; k < 12; k++) {
                double a = k * TAU / 12;
                c.line(5, 5, 5 + (int) Math.round(Math.cos(a) * 5), 5 + (int) Math.round(Math.sin(a) * 5), (k % 2 == 0) ? p : shade(p, 0.8));
            }
            c.disc(5, 5, 2, shade(p, 0.7)); c.px(4, 4, l);
        });
        b.add("edgeB", 64, 6, c -> {
            c.wrap = true;
            for (int x = 0; x < 64; x++) {
                int top = 3 + (int) Math.round(wave(x, 64, 0, new double[]{0.8, 0.6}, new int[]{2, 6}, new double[]{0, 1}));
                for (int y = top; y < 6; y++) c.px(x, y, mix(C(0xE6D49A), C(0xB59C5E), (y - top) / 3.0));
                c.px(x, top, C(0xF6EAC0));
            }
            for (int x : new int[]{7, 21, 38, 53}) { c.vl(x, 0, 3, C(0x39D58A)); c.vl(x + 1, 1, 3, C(0x1F9F6A)); c.px(x - 1, 2, C(0x39D58A)); }
        });
        b.corners("co", 11, 11, c -> {
            c.hl(0, 9, 0, 0xFFFFFFFF); c.vl(0, 0, 9, 0xFFFFFFFF);
            c.px(3, 3, A(0xFFFFFF, 0.9)); c.px(4, 3, A(0xFFFFFF, 0.5)); c.px(3, 4, A(0xFFFFFF, 0.5)); c.px(5, 5, A(0xFFFFFF, 0.35));
        });
    }
}
