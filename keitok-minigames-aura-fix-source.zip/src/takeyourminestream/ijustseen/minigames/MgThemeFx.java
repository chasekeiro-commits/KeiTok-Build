package takeyourminestream.ijustseen.minigames;

import net.minecraft.class_10799;
import net.minecraft.class_332;
import net.minecraft.class_437;
import takeyourminestream.ijustseen.minigames.MgSprites.Atlas;
import takeyourminestream.ijustseen.minigames.MgSprites.Reg;
import takeyourminestream.ijustseen.ui.gui.ModUiTheme;

/**
 * Animated theme scenery for menus and chat comment popups (GUI and in-world) plus the
 * "apply theme to comment popups?" question.
 *
 * Every picture is a cached sprite (see MgSprites), so a whole scene costs a few dozen textured quads per frame
 * instead of hundreds of rectangles. Small panels (rows, buttons, thin cards) get far less than big menu panels.
 */
public final class MgThemeFx {
    private MgThemeFx() {}

    private static volatile class_437 themesScreen;

    // ------------------------------------------------------------------ hooks called from patched game classes

    /** Remembers the themes screen so we can come back to it after the question. */
    public static void rememberThemes(class_437 s) {
        themesScreen = s;
    }

    /** Called right after a theme was picked. */
    public static void askAboutComments() {
        try {
            String th = ModUiTheme.getActiveTheme();
            if (th == null || th.equals("default")) {
                return;
            }
            class_437 parent = themesScreen;
            if (parent == null) return;
            takeyourminestream.ijustseen.ui.screen.MgThemeAskScreen.show(parent);
        } catch (Throwable t) {
            // never break the themes screen
        }
    }

    public static boolean commentsThemed() {
        try {
            String th = ModUiTheme.getActiveTheme();
            return MgConfig.get().themeComments && th != null && !th.equals("default");
        } catch (Throwable t) {
            return false;
        }
    }

    /** Panel tint for comment popups (rgb, no alpha). */
    public static int baseFilter(int v) {
        return commentsThemed() ? (ModUiTheme.PANEL_BG & 0xFFFFFF) : v;
    }

    /** Border tint for comment popups. */
    public static int borderFilter(int v) {
        return commentsThemed() ? (ModUiTheme.ACCENT & 0xFFFFFF) : v;
    }

    /** Animated border on the menu panels (all themes). */
    public static void menuBorder(class_332 g, int x, int y, int w, int h) {
        try {
            if (w < 90 || h < 30) return; // buttons and rows stay still: only the big panels get scenery
            animate(g, x, y, w, h, 1f, 1f, ModUiTheme.getActiveTheme());
        } catch (Throwable t) {
            // ignore
        }
    }

    /** Animated border on the chat comment popups when the player chose to theme them. */
    public static void commentBorder(class_332 g, int x, int y, int w, int h, float alpha) {
        try {
            if (!commentsThemed() || alpha < 0.05f) return;
            animate(g, x, y, w, h, alpha, 0.7f, ModUiTheme.getActiveTheme());
        } catch (Throwable t) {
            // ignore
        }
    }

    // ------------------------------------------------------------------ drawing back-ends (menus use the GUI, chat in the world uses quads)

    public interface Sink {
        void fill(double x0, double y0, double x1, double y1, int rgb, double a);
        void blit(Atlas at, int u, int v, int w, int h, double dx, double dy, double dw, double dh, int rgb, double a);
        /** Depth layer (only matters in the world; 0 = back .. 3 = front). */
        void layer(int n);
    }

    private static final class GuiSink implements Sink {
        class_332 g;
        private static int al(double a) { return (int) Math.max(0, Math.min(255, Math.round(a * 255))); }
        @Override public void fill(double x0, double y0, double x1, double y1, int rgb, double a) {
            int c = al(a);
            if (c <= 2) return;
            g.method_25294((int) Math.round(x0), (int) Math.round(y0), (int) Math.round(x1), (int) Math.round(y1), (c << 24) | (rgb & 0xFFFFFF));
        }
        @Override public void blit(Atlas at, int u, int v, int w, int h, double dx, double dy, double dw, double dh, int rgb, double a) {
            int c = al(a);
            if (c <= 2 || at == null || at.id == null || dw < 1 || dh < 1) return;
            g.method_25293(class_10799.field_56883, at.id, (int) Math.round(dx), (int) Math.round(dy), (float) u, (float) v,
                    (int) Math.round(dw), (int) Math.round(dh), w, h, at.size, at.size, (c << 24) | (rgb & 0xFFFFFF));
        }
        @Override public void layer(int n) { }
    }

    private static final GuiSink GUI = new GuiSink();

    // ------------------------------------------------------------------ scene state (render thread only)

    /** Preview tool: when >= 0 the animation time is frozen to this value. */
    public static double timeOverride = -1;

    private static Sink SK;
    private static Atlas AT;
    private static int PX, PY, PW, PH, K, LW, LH, TIER;
    private static double T, AA;
    private static boolean redOnly;

    private static final int WHITE = 0xFFFFFF;

    private static double frac(double v) { return v - Math.floor(v); }
    private static double clamp01(double v) { return v < 0 ? 0 : Math.min(v, 1); }

    private static Reg R(String n) { return AT.reg(n); }

    private static String frame(String base, double fps, int n) { return base + ((int) Math.floor(T * fps) % n); }
    private static String frameBounce(String base, double fps, int n) {
        int k = (int) Math.floor(T * fps) % (n * 2 - 2);
        return base + (k < n ? k : 2 * n - 2 - k);
    }

    // ------------------------------------------------------------------ primitives

    /** Draws part of a sprite (texel rectangle su,sv,sw,sh of region r) with its top-left at pixel dx,dy; crops to the panel. */
    private static void blitPx(Reg r, int su, int sv, int sw, int sh, int dx, int dy, double a, int tint) {
        if (r == null || a <= 0.012) return;
        int ix0 = PX + 1, iy0 = PY + 1, ix1 = PX + PW - 1, iy1 = PY + PH - 1;
        int c0 = 0, c1 = sw, r0 = 0, r1 = sh;
        if (dx < ix0) c0 = (ix0 - dx + K - 1) / K;
        if (dx + sw * K > ix1) c1 = Math.floorDiv(ix1 - dx, K);
        if (dy < iy0) r0 = (iy0 - dy + K - 1) / K;
        if (dy + sh * K > iy1) r1 = Math.floorDiv(iy1 - dy, K);
        if (c1 <= c0 || r1 <= r0) return;
        SK.blit(AT, r.u + su + c0, r.v + sv + r0, c1 - c0, r1 - r0, dx + c0 * K, dy + r0 * K, (c1 - c0) * K, (r1 - r0) * K, tint, a);
    }

    private static boolean fits(Reg r, double fh, double fw) { return r.h <= LH * fh && r.w <= LW * fw; }

    /** Sprite with its top-left at logical (lx, ly). Skipped when it is too big for this panel. */
    private static void put(String n, double lx, double ly, double a, int tint) { put(n, lx, ly, a, tint, 0.62); }

    private static void put(String n, double lx, double ly, double a, int tint, double maxFrac) {
        Reg r = R(n);
        if (r == null || !fits(r, maxFrac, 0.72)) return;
        blitPx(r, 0, 0, r.w, r.h, PX + (int) Math.round(lx * K), PY + (int) Math.round(ly * K), a, tint);
    }

    /** Sprite anchored to the right edge (rm = gap to the right edge) at top ly. */
    private static void putR(String n, double rm, double ly, double a, int tint) {
        Reg r = R(n);
        if (r == null) return;
        put(n, LW - rm - r.w, ly, a, tint);
    }

    /** Sprite anchored to the bottom edge (bm = gap to the bottom edge) at left lx. */
    private static void putB(String n, double lx, double bm, double a, int tint) { putB(n, lx, bm, a, tint, 0.62); }

    private static void putB(String n, double lx, double bm, double a, int tint, double maxFrac) {
        Reg r = R(n);
        if (r == null) return;
        put(n, lx, LH - bm - r.h, a, tint, maxFrac);
    }

    private static void putRB(String n, double rm, double bm, double a, int tint, double maxFrac) {
        Reg r = R(n);
        if (r == null) return;
        put(n, LW - rm - r.w, LH - bm - r.h, a, tint, maxFrac);
    }

    /** A horizontally repeating strip of rows [srcRow, srcRow+rows) of a tile, scrolled by 'scroll' texels. */
    private static void tileRows(Reg r, int srcRow, int rows, int dy, double scroll, double a, int tint) {
        if (r == null || rows <= 0 || a <= 0.012) return;
        int period = r.w;
        int col = (int) Math.floorMod((long) Math.floor(scroll), (long) period);
        int x = PX + 1, xEnd = PX + PW - 1;
        for (int guard = 0; x < xEnd && guard < 64; guard++) {
            int take = Math.min(period - col, (xEnd - x + K - 1) / K);
            blitPx(r, col, srcRow, take, rows, x, dy, a, tint);
            x += take * K;
            col = 0;
        }
    }

    /** Strip along the bottom edge showing the lowest rows of the tile (at most 'frac' of the panel height). */
    private static void tileB(String n, double scroll, double a, int tint, double frac) {
        Reg r = R(n);
        if (r == null) return;
        int rows = Math.max(3, Math.min(r.h, (int) (LH * frac)));
        tileRows(r, r.h - rows, rows, PY + PH - 1 - rows * K, scroll, a, tint);
    }

    /** Strip along the top edge showing the highest rows of the tile. */
    private static void tileT(String n, double scroll, double a, int tint, double frac) {
        Reg r = R(n);
        if (r == null) return;
        int rows = Math.max(3, Math.min(r.h, (int) (LH * frac)));
        tileRows(r, 0, rows, PY + 1, scroll, a, tint);
    }

    /** Whole tile with its top at logical ly. */
    private static void tileAt(String n, double ly, double scroll, double a, int tint) {
        Reg r = R(n);
        if (r == null) return;
        tileRows(r, 0, r.h, PY + (int) Math.round(ly * K), scroll, a, tint);
    }

    /** Filled rectangle in logical pixels, cropped to the panel. */
    private static void fl(double lx, double ly, double w, double h, int rgb, double a) {
        if (a <= 0.012) return;
        double x0 = PX + lx * K, y0 = PY + ly * K, x1 = x0 + w * K, y1 = y0 + h * K;
        x0 = Math.max(x0, PX + 1); y0 = Math.max(y0, PY + 1); x1 = Math.min(x1, PX + PW - 1); y1 = Math.min(y1, PY + PH - 1);
        if (x1 <= x0 || y1 <= y0) return;
        SK.fill(x0, y0, x1, y1, rgb, a);
    }

    /** Soft round glow centred at logical (cx, cy). */
    private static void halo(double cx, double cy, double rad, int rgb, double a) {
        Reg g = R("glow");
        if (g == null || a <= 0.012) return;
        double d = rad * 2 * K;
        double dx = PX + cx * K - d / 2, dy = PY + cy * K - d / 2;
        double x0 = Math.max(dx, PX + 1), y0 = Math.max(dy, PY + 1), x1 = Math.min(dx + d, PX + PW - 1), y1 = Math.min(dy + d, PY + PH - 1);
        if (x1 <= x0 + 1 || y1 <= y0 + 1) return;
        int u0 = (int) Math.floor((x0 - dx) / d * g.w), u1 = (int) Math.ceil((x1 - dx) / d * g.w);
        int v0 = (int) Math.floor((y0 - dy) / d * g.h), v1 = (int) Math.ceil((y1 - dy) / d * g.h);
        u1 = Math.min(g.w, Math.max(u1, u0 + 1)); v1 = Math.min(g.h, Math.max(v1, v0 + 1));
        SK.blit(AT, g.u + u0, g.v + v0, u1 - u0, v1 - v0, x0, y0, x1 - x0, y1 - y0, rgb, a);
    }

    private static void spark(double lx, double ly, int rgb, double a, boolean big) {
        Reg r = R(big ? "spark9" : "spark5");
        if (r == null) return;
        blitPx(r, 0, 0, r.w, r.h, PX + (int) Math.round(lx * K) - r.w * K / 2, PY + (int) Math.round(ly * K) - r.h * K / 2, a, rgb);
    }

    /** Twinkling star at a fraction of the panel size. */
    private static void twinkleF(double fx, double fy, int rgb, double a, double speed, double phase) {
        double k = 0.5 + 0.5 * Math.sin(T * speed + phase);
        k *= k;
        if (k < 0.12) return;
        spark(fx * LW, fy * LH, rgb, a * k, k > 0.7);
    }

    private static void shoot(double period, double off, int rgb, double a) {
        double u = frac((T + off) / period);
        if (u > 0.16) return;
        double k = u / 0.16, fade = Math.sin(Math.PI * k) * a;
        double sx = LW * (0.10 + 0.80 * k), sy = 3 + (LH - 10) * 0.5 * k;
        for (int i = 0; i < 6; i++) fl(sx - i * 2.2, sy - i * 1.1, 2, 1, rgb, fade * (1 - i / 6.0));
    }

    // ------------------------------------------------------------------ border effects: glow, comets, corners

    private static void glowEdge(int rgb, double a) {
        Reg ru = R("rampU"), rd = R("rampD"), rl = R("rampL"), rr = R("rampR");
        if (ru == null || a <= 0.012) return;
        double p = 0.55 + 0.45 * Math.sin(T * 1.6);
        double al = a * p * 0.30;
        int g = Math.max(3, Math.min(3 * K + 1, Math.min(PW, PH) / 4));
        SK.blit(AT, ru.u, ru.v, 1, 64, PX + 1, PY + 1, PW - 2, g, rgb, al);
        SK.blit(AT, rd.u, rd.v, 1, 64, PX + 1, PY + PH - 1 - g, PW - 2, g, rgb, al);
        SK.blit(AT, rl.u, rl.v, 64, 1, PX + 1, PY + 1, g, PH - 2, rgb, al);
        SK.blit(AT, rr.u, rr.v, 64, 1, PX + PW - 1 - g, PY + 1, g, PH - 2, rgb, al);
    }

    private static int lighten(int rgb) {
        return redOnly ? 0xFF6A6A : MgSprites.mix(0xFF000000 | rgb, 0xFFFFFFFF, 0.55) & 0xFFFFFF;
    }

    /** Fading comet running along the panel border. dir = 1 clockwise, -1 counter-clockwise. */
    private static void comet(double head, double len, int rgb, double a, int dir) {
        Reg rr = R("rampR");
        if (rr == null || a <= 0.012) return;
        double per = 2.0 * (PW + PH);
        head = head - Math.floor(head / per) * per;
        double s0 = dir > 0 ? head - len : head, s1 = dir > 0 ? head : head + len;
        int t = K + 1;
        double[] starts = {0, PW, PW + PH, 2.0 * PW + PH}, ends = {PW, PW + PH, 2.0 * PW + PH, per};
        for (int shift = -1; shift <= 1; shift++) {
            for (int e = 0; e < 4; e++) {
                double lo = Math.max(s0, starts[e] + shift * per), hi = Math.min(s1, ends[e] + shift * per);
                if (hi - lo < 0.5) continue;
                double pLo = dir > 0 ? (lo - s0) / len : (s1 - lo) / len;
                double pHi = dir > 0 ? (hi - s0) / len : (s1 - hi) / len;
                double l = lo - shift * per, h = hi - shift * per;
                boolean horiz = e == 0 || e == 2;
                double first, second; // phase at the left/top end and at the right/bottom end of the piece
                double x0, y0, x1, y1;
                if (e == 0) { x0 = PX + l; x1 = PX + h; y0 = PY; y1 = PY + t; first = pLo; second = pHi; }
                else if (e == 1) { y0 = PY + (l - PW); y1 = PY + (h - PW); x0 = PX + PW - t; x1 = PX + PW; first = pLo; second = pHi; }
                else if (e == 2) { x0 = PX + PW - (h - PW - PH); x1 = PX + PW - (l - PW - PH); y0 = PY + PH - t; y1 = PY + PH; first = pHi; second = pLo; }
                else { y0 = PY + PH - (h - 2.0 * PW - PH); y1 = PY + PH - (l - 2.0 * PW - PH); x0 = PX; x1 = PX + t; first = pHi; second = pLo; }
                Reg ramp;
                int s0t, s1t;
                if (first <= second) {
                    ramp = horiz ? R("rampR") : R("rampD");
                    s0t = (int) Math.floor(first * 64); s1t = (int) Math.ceil(second * 64);
                } else {
                    ramp = horiz ? R("rampL") : R("rampU");
                    s0t = (int) Math.floor((1 - first) * 64); s1t = (int) Math.ceil((1 - second) * 64);
                }
                s0t = Math.max(0, Math.min(63, s0t));
                s1t = Math.max(s0t + 1, Math.min(64, s1t));
                if (horiz) SK.blit(AT, ramp.u + s0t, ramp.v, s1t - s0t, 1, x0, y0, x1 - x0, y1 - y0, rgb, a);
                else SK.blit(AT, ramp.u, ramp.v + s0t, 1, s1t - s0t, x0, y0, x1 - x0, y1 - y0, rgb, a);
            }
        }
        // bright head
        double s = head;
        double hx, hy;
        if (s < PW) { hx = PX + s; hy = PY; }
        else if (s < PW + PH) { hx = PX + PW - t; hy = PY + (s - PW); }
        else if (s < 2.0 * PW + PH) { hx = PX + PW - (s - PW - PH) - t; hy = PY + PH - t; }
        else { hx = PX; hy = PY + PH - (s - 2.0 * PW - PH) - t; }
        SK.fill(hx, hy, hx + t, hy + t, lighten(rgb), Math.min(1, a * 1.1));
    }

    private static void corners(String prefix, int rgb, double a) {
        Reg tl = R(prefix + "TL"), tr = R(prefix + "TR"), bl = R(prefix + "BL"), br = R(prefix + "BR");
        if (tl == null || a <= 0.012) return;
        int w = tl.w * K, h = tl.h * K;
        if (PW < w * 3 || PH < h * 2) return;
        SK.blit(AT, tl.u, tl.v, tl.w, tl.h, PX + 1, PY + 1, w, h, rgb, a);
        SK.blit(AT, tr.u, tr.v, tr.w, tr.h, PX + PW - 1 - w, PY + 1, w, h, rgb, a);
        SK.blit(AT, bl.u, bl.v, bl.w, bl.h, PX + 1, PY + PH - 1 - h, w, h, rgb, a);
        SK.blit(AT, br.u, br.v, br.w, br.h, PX + PW - 1 - w, PY + PH - 1 - h, w, h, rgb, a);
    }

    /** Glow, one or two comets and corner pieces: the frame every theme shares. */
    private static void frameFx(int glowRgb, int c1, double sp1, double len1, int c2, double sp2, double len2, String corner, int cornerRgb) {
        SK.layer(3);
        double per = 2.0 * (PW + PH);
        double len = Math.max(10, per * 0.12 * Math.min(1.0, AA + 0.3) + 8);
        if (TIER >= 2) glowEdge(glowRgb, AA);
        double s1 = Math.max(per / 14, Math.min(per / 4, sp1));
        comet(T * s1, len * len1, c1, 0.95 * AA, 1);
        if (TIER >= 3 && c2 != 0) {
            double s2 = Math.max(per / 14, Math.min(per / 4, sp2));
            comet(-T * s2 + per / 2, len * len2, c2, 0.85 * AA, -1);
        }
        if (TIER >= 2 && corner != null) corners(corner, cornerRgb, 0.9 * AA);
    }

    // ------------------------------------------------------------------ entry points

    private static void animate(class_332 g, int x, int y, int w, int h, float alpha, float intensity, String theme) {
        if (w < 12 || h < 12) return;
        GUI.g = g;
        try {
            paint(GUI, theme, x, y, w, h, alpha, intensity, (w >= 260 && h >= 120) ? 2 : 1);
        } finally {
            GUI.g = null;
        }
    }

    /** Paints the scenery of a theme around a panel. k = size of one sprite pixel in panel pixels. */
    public static void paint(Sink sink, String theme, int x, int y, int w, int h, float alpha, float intensity, int k) {
        if (theme == null) theme = "default";
        if (w < 12 || h < 12) return;
        SK = sink; PX = x; PY = y; PW = w; PH = h; K = Math.max(1, k); LW = w / K; LH = h / K;
        T = timeOverride >= 0 ? timeOverride : System.nanoTime() / 1.0e9;
        AA = alpha * intensity;
        TIER = (LW < 36 || LH < 14) ? 0 : (LH < 22 || LW < 60) ? 1 : LH < 40 ? 2 : LH < 80 ? 3 : 4;
        if (TIER == 0) return;
        AT = MgSprites.get(theme);
        if (AT == null) return;
        redOnly = false;
        try {
            switch (theme) {
                case "purple_moon": purple(); break;
                case "lokalhost": redOnly = true; lokal(); break;
                case "ocean_depths": ocean(); break;
                case "sakura_bloom": sakura(); break;
                case "emerald_grove": grove(); break;
                case "solar_flare": solar(); break;
                case "midnight_blue": midnight(); break;
                case "cyberpunk": cyber(); break;
                default: plain(); break;
            }
        } finally {
            SK = null; AT = null;
        }
    }

    // ------------------------------------------------------------------ default (kept minimal on purpose)

    private static void plain() {
        int ac = ModUiTheme.ACCENT & 0xFFFFFF;
        frameFx(ac, ac, 40, 1.0, 0, 0, 0, null, 0);
        if (TIER >= 2) {
            twinkleF(0.2, 0.0, 0xFFFFFF, 0.5 * AA, 1.5, 0);
            twinkleF(0.7, 1.0, 0xFFFFFF, 0.5 * AA, 1.7, 2);
        }
    }

    // ------------------------------------------------------------------ purple moon

    private static void purple() {
        double pulse = 0.5 + 0.5 * Math.sin(T * 1.1);
        SK.layer(0);
        if (TIER >= 3) {
            halo(LW - 20, 18, 17, 0xB07CFF, AA * (0.30 + 0.12 * pulse));
            twinkleF(0.10, 0.14, 0xE9DAFF, 0.9 * AA, 1.3, 0.3); twinkleF(0.30, 0.08, 0xFFFFFF, 0.9 * AA, 1.7, 1.9);
            twinkleF(0.46, 0.20, 0xE9DAFF, 0.8 * AA, 1.1, 3.1); twinkleF(0.62, 0.07, 0xFFFFFF, 0.9 * AA, 1.9, 4.4);
            if (TIER >= 4) { twinkleF(0.22, 0.30, 0xE9DAFF, 0.8 * AA, 1.5, 5.2); twinkleF(0.55, 0.32, 0xFFFFFF, 0.7 * AA, 1.2, 0.9); shoot(8, 0, 0xFFFFFF, 0.9 * AA); }
            SK.layer(1);
            putR("moon", 6, 4, 0.95 * AA, WHITE);
            put("cloud0", frac(T / 30.0) * (LW + 50) - 40, 5, 0.30 * AA, WHITE);
            put("cloud1", frac(T / 44.0 + 0.5) * (LW + 40) - 30, 18, 0.20 * AA, WHITE);
        }
        if (TIER >= 4) {
            SK.layer(0);
            tileB("hillF", T * 0.6, 0.85 * AA, WHITE, 0.30);
            SK.layer(1);
            putB("tower", LW * 0.16, 6, 0.95 * AA, WHITE);
            putRB("deadtree", LW * 0.20, 5, 0.9 * AA, WHITE, 0.4);
            double wp = 0.7 + 0.3 * Math.sin(T * 3);
            halo(LW * 0.16 + 6.5, LH - 6 - 38 + 21.5, 7, 0xFFC870, 0.5 * AA * wp);
        }
        SK.layer(1);
        if (TIER >= 3) tileB("hillN", T * 1.6, 0.97 * AA, WHITE, 0.40); else if (TIER == 2) tileB("edgeB", T * 2, 0.95 * AA, WHITE, 1.0);
        SK.layer(2);
        if (TIER >= 2) tileT("edgeT", T * 1.5, 0.8 * AA, WHITE, 0.3);
        if (TIER >= 4) {
            tileAt("fog", LH - 20, -T * 2.5, 0.55 * AA, WHITE);
            put("bat" + ((int) (T * 7) % 2), frac(T / 10.0) * (LW + 30) - 15, 10 + 8 * Math.sin(T * 1.3), 0.95 * AA, WHITE);
            put("bat" + ((int) (T * 6 + 1) % 2), LW + 15 - frac(T / 13.0 + 0.4) * (LW + 30), 24 + 6 * Math.sin(T * 1.1 + 2), 0.85 * AA, WHITE);
        } else if (TIER == 3) {
            put("bat" + ((int) (T * 7) % 2), frac(T / 11.0) * (LW + 30) - 15, 9 + 6 * Math.sin(T * 1.3), 0.9 * AA, WHITE);
        }
        frameFx(0xB07CFF, 0xC9A7FF, 36, 1.0, 0xFFB3F0, 36, 0.8, "cp", 0xC9A7FF);
    }

    // ------------------------------------------------------------------ lokalhost (red and black only)

    private static void lokal() {
        int red = 0xFF2A2A;
        SK.layer(0);
        if (TIER >= 2) tileT("edgeT", T * 8, 0.85 * AA, WHITE, 0.3);
        if (TIER == 2) tileB("edgeB", T * 22, 0.9 * AA, WHITE, 1.0);
        if (TIER >= 3) {
            SK.layer(0);
            tileB(frame("rack", 1.6, 2), 0, 0.92 * AA, WHITE, 0.42);
            SK.layer(1);
            tileB("ecg", T * 36, 0.9 * AA, WHITE, 0.2);
            fl(frac(T / 5.0) * LW, 1, 2, LH - 2, red, 0.10 * AA);
        }
        if (TIER >= 4) {
            SK.layer(1);
            putR("radar", 8, 7, 0.95 * AA, WHITE);
            putR(frame("sweep", 9, 12), 8, 7, 0.95 * AA, WHITE);
            double bl = 0.4 + 0.6 * Math.abs(Math.sin(T * 1.3));
            fl(LW - 8 - 34 + 12, 7 + 9, 2, 2, red, bl * AA); fl(LW - 8 - 34 + 22, 7 + 20, 2, 2, red, (1.2 - bl) * AA); fl(LW - 8 - 34 + 9, 7 + 23, 2, 2, red, bl * 0.8 * AA);
            SK.layer(2);
            for (int i = 0; i < 4; i++) {
                double sp = 0.35 + i * 0.07;
                put("col" + (i % 3), 6 + i * 7, frac(T * sp + i * 0.27) * (LH + 40) - 38, 0.9 * AA, WHITE, 0.7);
            }
            put("txt", 8, LH - 24 - 10, 0.85 * AA, WHITE);
            fl(8 + 61, LH - 24 - 10, 2, 5, red, (((int) (T * 2)) % 2 == 0 ? 0.9 : 0.1) * AA);
            long b = (long) (T * 5);
            if (b % 6 == 0) for (int i = 0; i < 3; i++) fl(6 + ((b * 7919 + i * 104729) & 0xFFFF) / 65535.0 * (LW - 20), 8 + ((b * 31337 + i * 7727) & 0xFFFF) / 65535.0 * (LH - 40), 8, 1, 0xFF3A3A, 0.8 * AA);
        }
        frameFx(0xFF1F1F, 0xFF1F1F, 70, 1.0, 0x8A0000, 55, 0.5, TIER >= 3 ? "circ" : "cl", 0xFF2A2A);
    }

    // ------------------------------------------------------------------ ocean depths

    private static void ocean() {
        SK.layer(0);
        if (TIER >= 4) {
            for (int i = 0; i < 3; i++) put("beam", LW * (0.16 + 0.3 * i) + 4 * Math.sin(T * 0.4 + i), 6, (0.10 + 0.07 * Math.sin(T * 0.9 + i * 1.7)) * AA, 0x9FF0FF, 0.95);
            put("whale" + (frac(T / 120.0) < 0.5 ? "R" : "L"), (frac(T / 60.0) * (LW + 160)) - 90, LH * 0.18, 0.40 * AA, WHITE);
        }
        SK.layer(1);
        if (TIER >= 3) {
            tileB("seabed", 0, AA, WHITE, 0.40);
            putB("coralA", LW * 0.52, 7, 0.95 * AA, WHITE, 0.5);
            putB("coralB", LW * 0.30, 7, 0.95 * AA, WHITE, 0.4);
            putB("coralC", LW * 0.76, 7, 0.95 * AA, WHITE, 0.4);
            String kelp = frame("kelp", 3, 4);
            putB(kelp, 10, 6, 0.95 * AA, WHITE, 0.62);
            putB(frame("kelp", 3, 4), LW * 0.64, 6, 0.9 * AA, WHITE, 0.62);
            if (TIER >= 4) {
                putB("star", LW * 0.42, 6, AA, WHITE); putB("urchin", LW * 0.88, 6, AA, WHITE);
                putB(frame("kelp", 2.6, 4), LW - 14, 6, 0.9 * AA, WHITE);
            }
        } else if (TIER == 2) {
            tileB("edgeB", 0, AA, WHITE, 1.0);
        }
        SK.layer(2);
        if (TIER >= 2) {
            tileT("wave", T * 9, 0.75 * AA, WHITE, 0.3);
            if (TIER >= 3) tileT("wave", -T * 5 + 17, 0.35 * AA, WHITE, 0.3);
        }
        int f = (int) (T * 6) % 2;
        put("clownR" + f, frac(T / 14.0) * (LW + 30) - 16, LH * 0.50 + 4 * Math.sin(T * 2), AA, WHITE);
        if (TIER >= 3) {
            put("tangL" + f, LW + 14 - frac(T / 19.0 + 0.3) * (LW + 30), LH * 0.36 + 3 * Math.sin(T * 1.7 + 1), AA, WHITE);
            put("jelly" + new int[]{0, 1, 2, 1}[(int) (T * 2.6) % 4], LW * 0.72 + 6 * Math.sin(T * 0.5), LH * 0.22 + 8 * Math.sin(T * 0.7), 0.9 * AA, WHITE);
        }
        if (TIER >= 4) {
            for (int i = 0; i < 4; i++) put("minnowL" + ((int) (T * 7 + i) % 2), LW + 10 - frac(T / 11.0 + 0.62) * (LW + 40) + i * 9, LH * 0.70 + (i % 2) * 6 + 2 * Math.sin(T * 2 + i), 0.9 * AA, WHITE);
            put("clownL" + f, LW + 14 - frac(T / 17.0 + 0.7) * (LW + 30), LH * 0.58 + 3 * Math.sin(T * 1.9), AA, WHITE);
        }
        for (int i = 0; i < (TIER >= 4 ? 6 : TIER >= 3 ? 4 : 2); i++) {
            double u = frac(T * (0.10 + 0.03 * (i % 3)) + i * 0.37);
            put("bubble", (i * 0.2 + 0.1 + 0.03 * Math.sin(T + i)) * LW + (i % 2) * 8, LH - u * (LH + 6), Math.sin(Math.PI * u) * 0.9 * AA, 0xE8FBFF);
        }
        frameFx(0x4FB6FF, 0x7FE9FF, 28, 1.0, 0x4FB6FF, 22, 0.7, "co", 0x9FF0FF);
    }

    // ------------------------------------------------------------------ sakura bloom

    private static void sakura() {
        SK.layer(0);
        if (TIER >= 3) {
            halo(LW * 0.60 + 13, 22, 20, 0xFFB7D5, 0.30 * AA);
            put("sun", LW * 0.60, 9, 0.85 * AA, WHITE);
            put("cloudP", frac(T / 36.0) * (LW + 50) - 40, 6, 0.55 * AA, WHITE);
            if (TIER >= 4) {
                put("cloudP", frac(T / 50.0 + 0.45) * (LW + 50) - 40, 26, 0.35 * AA, WHITE);
                putB("fuji", LW * 0.16, 12, 0.55 * AA, WHITE, 0.4);
            }
        }
        SK.layer(1);
        if (TIER >= 3) tileB("ground", 0, AA, WHITE, 0.30); else if (TIER == 2) tileB("edgeB", 0, AA, WHITE, 1.0);
        if (TIER >= 4) {
            putB("torii", LW * 0.08, 9, 0.95 * AA, WHITE, 0.4);
            putB("lantern", LW * 0.08 + 38, 9, 0.95 * AA, WHITE, 0.4);
            double fl = 0.6 + 0.4 * Math.sin(T * 3.1);
            halo(LW * 0.08 + 38 + 6, LH - 9 - 22 + 9, 7, 0xFFC870, 0.35 * AA * fl);
            putRB("tree", 2, 8, 0.97 * AA, WHITE, 0.82);
        } else if (TIER == 3) {
            putRB("treeS", 4, 8, 0.97 * AA, WHITE, 0.82);
        }
        SK.layer(2);
        if (TIER >= 3) tileT("branchT", 0, 0.95 * AA, WHITE, 0.45); else if (TIER == 2) tileT("edgeT", 0, 0.95 * AA, WHITE, 0.3);
        int n = TIER >= 4 ? 9 : TIER >= 3 ? 6 : 3;
        for (int i = 0; i < n; i++) {
            double u = frac(T * (0.06 + 0.03 * (i % 3)) + i * 0.317);
            double px = ((i * 0.618) % 1.0) * LW + Math.sin(T * 1.3 + i * 1.9) * 7;
            put("petal" + ((int) (T * 3 + i) % 4), px, -3 + u * (LH + 4), Math.sin(Math.PI * u) * AA, WHITE);
        }
        frameFx(0xFFB7D5, 0xFFB7D5, 30, 1.0, TIER >= 4 ? 0xFFE6F1 : 0, 24, 0.6, "cs", WHITE);
    }

    // ------------------------------------------------------------------ emerald grove

    private static void grove() {
        SK.layer(0);
        if (TIER >= 4) {
            for (int i = 0; i < 2; i++) put("beam", LW * (0.30 + 0.28 * i), 4, (0.08 + 0.06 * Math.sin(T * 0.8 + i * 2)) * AA, 0xF2FF9A, 0.99);
        }
        SK.layer(1);
        if (TIER >= 3) {
            tileB("ground", 0, AA, WHITE, 0.34);
            double gp = 0.6 + 0.4 * Math.sin(T * 1.7);
            for (int i = 0; i * 64 + 47 < LW + 8; i++) halo(i * 64 + 47, LH - 12, 7, 0x4FE0D0, 0.40 * AA * gp);
        } else if (TIER == 2) {
            tileB("edgeB", 0, AA, WHITE, 1.0);
        }
        if (TIER >= 4) {
            putRB("oak", 2, 10, 0.97 * AA, WHITE, 0.82);
            putB("fern", LW * 0.10, 9, AA, WHITE, 0.3);
            putB("log", LW * 0.28, 9, AA, WHITE, 0.3);
        } else if (TIER == 3) {
            putRB("oakS", 4, 10, 0.97 * AA, WHITE, 0.82);
        }
        SK.layer(2);
        if (TIER >= 3) tileT(frame("vines", 1.6, 3), 0, 0.97 * AA, WHITE, 0.45); else if (TIER == 2) tileT("edgeT", 0, AA, WHITE, 0.3);
        if (TIER >= 3) {
            for (int i = 0; i < (TIER >= 4 ? 6 : 4); i++) {
                double k = 0.5 + 0.5 * Math.sin(T * 2 + i * 1.9);
                double fx = LW * frac(0.13 + i * 0.19 + 0.02 * Math.sin(T * 0.4 + i)), fy = LH * (0.3 + 0.35 * (0.5 + 0.5 * Math.sin(T * 0.8 + i * 2.3)));
                halo(fx, fy, 3.5, 0xF2FF8A, 0.55 * AA * k);
            }
            put("bird" + (((int) (T * 8)) % 3 == 0 ? "R" : "R") + ((int) (T * 8) % 3), frac(T / 16.0) * (LW + 30) - 14, LH * 0.25 + 5 * Math.sin(T * 1.1), 0.95 * AA, WHITE);
        }
        for (int i = 0; i < (TIER >= 4 ? 4 : 2); i++) {
            double u = frac(T * (0.05 + 0.02 * i) + i * 0.41);
            put("leaf" + ((int) (T * 3 + i) % 4), frac(i * 0.73 + 0.1) * LW + Math.sin(T + i) * 6, u * (LH + 4) - 2, Math.sin(Math.PI * u) * AA, WHITE);
        }
        frameFx(0x4CFF8F, 0x4CFF8F, 26, 1.1, 0xB6FF6A, 22, 0.6, "cg", 0x7CFFA0);
    }

    // ------------------------------------------------------------------ solar flare

    private static void solar() {
        double pulse = 0.5 + 0.5 * Math.sin(T * 1.5);
        SK.layer(0);
        if (TIER >= 3) {
            double cx = LW - 26, cy = 24;
            halo(cx, cy, 30, 0xFF8A1A, (0.20 + 0.10 * pulse) * AA);
            put(frame("rays", 3.2, 3), cx - 32, cy - 32, 0.95 * AA, WHITE, 0.75);
            put("sun", cx - 18, cy - 18, AA, WHITE);
            put("ash", frac(T / 34.0) * (LW + 50) - 40, 6, 0.55 * AA, WHITE);
        }
        SK.layer(1);
        if (TIER >= 4) {
            tileB("rock", 0, AA, WHITE, 0.16);
            putB("volcano", LW * 0.08, 9, AA, WHITE, 0.62);
            halo(LW * 0.08 + 36, LH - 9 - 48 + 9, 12, 0xFFB02E, (0.45 + 0.2 * pulse) * AA);
            for (int i = 0; i < 3; i++) {
                double u = frac(T * 0.12 + i * 0.33);
                halo(LW * 0.08 + 36 + 10 * u + 3 * Math.sin(T + i), LH - 9 - 48 - u * 34, 5 + u * 7, 0x8A5A48, (1 - u) * 0.45 * AA);
            }
        }
        if (TIER >= 3) tileB(frame("flame", 8, 4), 0, 0.95 * AA, WHITE, 0.30); else if (TIER == 2) tileB(frame("edgeB", 6, 2), 0, AA, WHITE, 1.0);
        SK.layer(2);
        if (TIER >= 2) tileT("edgeT", 0, 0.9 * AA, WHITE, 0.3);
        if (TIER >= 3) {
            double u = frac(T / 18.0);
            if (u < 0.55) put("phoenix" + ((int) (T * 7) % 3), u / 0.55 * (LW + 60) - 36, LH * 0.22 + 7 * Math.sin(T * 1.6), 0.95 * AA, WHITE);
        }
        for (int i = 0; i < (TIER >= 4 ? 8 : TIER >= 3 ? 5 : 2); i++) {
            double u = frac(T * (0.10 + 0.03 * (i % 3)) + i * 0.29);
            fl(frac(i * 0.618) * (LW - 6) + 3 + Math.sin(T * 2 + i) * 3, LH - 4 - u * (LH - 8), 1.2, 1.2, i % 2 == 0 ? 0xFFD060 : 0xFF7A1A, Math.sin(Math.PI * u) * AA);
        }
        frameFx(0xFF7A1A, 0xFFC247, 55, 1.0, 0xFF5A14, 45, 0.6, "cf", 0xFFB02E);
    }

    // ------------------------------------------------------------------ midnight blue

    private static void midnight() {
        double pulse = 0.5 + 0.5 * Math.sin(T * 0.9);
        SK.layer(0);
        if (TIER >= 3) {
            tileT("stars", 0, 0.9 * AA, WHITE, 0.6);
            tileT("aurora", T * 2.2, (0.55 + 0.25 * pulse) * AA, WHITE, 0.62);
            halo(LW - 24, 21, 18, 0x8FB4FF, 0.30 * AA);
            twinkleF(0.12, 0.12, 0xBFD4FF, 0.9 * AA, 1.4, 0.6); twinkleF(0.38, 0.06, 0xFFFFFF, 0.9 * AA, 1.8, 2.2);
            twinkleF(0.52, 0.18, 0xBFD4FF, 0.8 * AA, 1.1, 3.4); twinkleF(0.25, 0.26, 0xFFFFFF, 0.8 * AA, 1.6, 5.0);
            if (TIER >= 4) shoot(6.5, 2, 0xBFD4FF, 0.9 * AA);
        }
        SK.layer(1);
        if (TIER >= 3) {
            putR("moonF", 8, 5, 0.97 * AA, WHITE);
            put("cloudM", frac(T / 40.0) * (LW + 60) - 45, 22, 0.28 * AA, WHITE);
            tileB("mtn", T * 0.5, 0.95 * AA, WHITE, 0.46);
        }
        if (TIER >= 4) {
            putB("cabin", LW * 0.52, 8, AA, WHITE, 0.4);
            double wp = 0.75 + 0.25 * Math.sin(T * 2.3);
            halo(LW * 0.52 + 9.5, LH - 8 - 24 + 16.5, 6, 0xFFC870, 0.45 * AA * wp);
            for (int i = 0; i < 3; i++) {
                double u = frac(T * 0.16 + i * 0.33);
                halo(LW * 0.52 + 20.5 + u * 8, LH - 8 - 24 + 2 - u * 18, 3 + u * 3, 0xC8D8F8, (1 - u) * 0.35 * AA);
            }
        }
        SK.layer(2);
        if (TIER >= 3) tileB("pines", T * 1.0, AA, WHITE, 0.30); else if (TIER == 2) tileB("edgeB", 0, AA, WHITE, 1.0);
        if (TIER == 2) tileT("edgeT", 0, 0.9 * AA, WHITE, 0.3);
        if (TIER >= 4) {
            putB("wolf", LW * 0.80, 5, 0.95 * AA, WHITE, 0.3);
            putB(frame("fire", 9, 4), LW * 0.30, 5, AA, WHITE, 0.3);
            halo(LW * 0.30 + 5, LH - 5 - 6, 14, 0xFF9A3A, (0.30 + 0.12 * Math.sin(T * 11)) * AA);
        }
        for (int i = 0; i < (TIER >= 4 ? 8 : TIER >= 3 ? 5 : 2); i++) {
            double u = frac(T * (0.07 + 0.025 * (i % 3)) + i * 0.31);
            fl(frac(i * 0.618) * (LW - 4) + 2 + Math.sin(T * 1.3 + i) * 3, u * (LH - 4), 1.2, 1.2, 0xF4F8FF, 0.8 * AA);
        }
        frameFx(0x5A86FF, 0x5A86FF, 22, 1.2, 0x9FB8FF, 18, 0.6, "cm", 0xBFD4FF);
    }

    // ------------------------------------------------------------------ cyberpunk

    private static void cyber() {
        SK.layer(0);
        if (TIER >= 3) {
            tileB("cityF", T * 1.2, 0.80 * AA, WHITE, 0.52);
        }
        SK.layer(1);
        if (TIER >= 3) tileB(frame("cityN", 1.7, 2), -T * 2.5, AA, WHITE, 0.52); else if (TIER == 2) tileB("edgeB", T * 3, AA, WHITE, 1.0);
        SK.layer(2);
        if (TIER >= 2) tileT("edgeT", T * 4, 0.9 * AA, WHITE, 0.3);
        if (TIER >= 4) {
            int sf = ((long) (T * 4) % 11 == 0) ? 1 : (((long) (T * 4) % 17 == 0) ? 2 : 0);
            halo(LW * 0.14 + 16, LH * 0.30 + 7, 14, 0xFF2BD6, (sf == 0 ? 0.25 : 0.08) * AA);
            put("signA" + sf, LW * 0.14, LH * 0.30, 0.95 * AA, WHITE, 0.3);
            int sg = ((long) (T * 3) % 13 == 0) ? 1 : 0;
            put("signB" + sg, LW * 0.50, LH * 0.20, 0.95 * AA, WHITE, 0.3);
            put("drone" + ((int) (T * 12) % 2), frac(T / 12.0) * (LW + 40) - 20, LH * 0.14 + 5 * Math.sin(T * 1.5), AA, WHITE);
            double cu = frac(T / 9.0 + 0.3);
            put("carL", LW + 24 - cu * (LW + 50), LH * 0.40, AA, WHITE);
            put("carR", frac(T / 15.0 + 0.6) * (LW + 50) - 26, LH * 0.50, 0.9 * AA, WHITE);
        } else if (TIER >= 3) {
            put("drone" + ((int) (T * 12) % 2), frac(T / 12.0) * (LW + 40) - 20, LH * 0.12 + 3 * Math.sin(T * 1.5), AA, WHITE);
        }
        if (TIER >= 3) {
            for (int d = 0; d < (TIER >= 4 ? 12 : 7); d++) {
                double u = frac(T * (0.9 + 0.25 * (d % 3)) + d * 0.37);
                fl(3 + frac(d * 0.618) * (LW - 6) - u * 6, 2 + u * (LH - 6), 1, 3, 0x9FE8FF, 0.30 * AA);
            }
            fl(1, 1 + frac(T / 3.0) * (LH - 2), LW - 2, 1, 0x00F0FF, 0.12 * AA);
            long bk = (long) (T * 6);
            if (bk % 7 == 0) for (int i = 0; i < 3; i++) fl(((bk * 2654435761L + i * 40503L) & 0xFFFF) / 65535.0 * (LW - 14), ((bk * 40503L + i * 7727L) & 0xFFFF) / 65535.0 * (LH - 4), 9, 1, i == 1 ? 0xFF2BD6 : 0x00F0FF, 0.8 * AA);
        }
        frameFx(0xFF2BD6, 0x00F0FF, 95, 1.0, 0xFF2BD6, 80, 1.0, "ccy", 0x00F0FF);
    }
}
