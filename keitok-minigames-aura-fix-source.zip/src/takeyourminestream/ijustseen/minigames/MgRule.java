package takeyourminestream.ijustseen.minigames;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** One "when X happens, do Y" rule. Fully editable from the Interactive Minigames menu. */
public final class MgRule {
    public String id = UUID.randomUUID().toString().substring(0, 8);
    public boolean enabled = true;
    public MgTrigger trigger = MgTrigger.GIFT;
    /** Gift name / chat keyword / likes interval, depending on trigger. */
    public String match = "*";
    /** Minimum gift count (combo) needed to fire. */
    public int minCount = 1;
    public MgAction action = MgAction.ALERT;
    public String arg = "";
    public int amount = 1;
    /** Seconds (freeze / effect / fuse / levitation). */
    public int duration = 3;
    public int cooldown = 0;
    /** Milliseconds between repeated commands (Streamtoearn "Interval"). */
    public int interval = 100;
    /** Milliseconds before the first command (Streamtoearn "Delay"). */
    public int delay = 0;
    /** Optional sound id played when the rule fires (Streamtoearn "Add Audio"). */
    public String audio = "";
    /** When true, amount is multiplied by the gift count (combo of 5 roses = 5x). */
    public boolean perGiftCount = false;
    /** Optional text shown to the streamer when it fires. Placeholders: {user} {gift} {count}. */
    public String message = "";

    // runtime only
    public transient long lastFireMs = 0L;
    public transient long progress = 0L;

    public MgRule() {}

    public MgRule(MgTrigger trigger, String match, MgAction action, String arg, int amount, int duration) {
        this.trigger = trigger;
        this.match = match;
        this.action = action;
        this.arg = arg;
        this.amount = amount;
        this.duration = duration;
    }

    public MgRule copy() {
        MgRule r = new MgRule();
        r.id = id;
        r.enabled = enabled;
        r.trigger = trigger;
        r.match = match;
        r.minCount = minCount;
        r.action = action;
        r.arg = arg;
        r.amount = amount;
        r.duration = duration;
        r.cooldown = cooldown;
        r.interval = interval;
        r.delay = delay;
        r.audio = audio;
        r.perGiftCount = perGiftCount;
        r.message = message;
        r.lastFireMs = lastFireMs;
        r.progress = progress;
        return r;
    }

    public void copyFrom(MgRule o) {
        enabled = o.enabled;
        trigger = o.trigger;
        match = o.match;
        minCount = o.minCount;
        action = o.action;
        arg = o.arg;
        amount = o.amount;
        duration = o.duration;
        cooldown = o.cooldown;
        interval = o.interval;
        delay = o.delay;
        audio = o.audio;
        perGiftCount = o.perGiftCount;
        message = o.message;
    }

    /** Short one-line description for the list screen. */
    public String summary() {
        StringBuilder b = new StringBuilder();
        switch (trigger) {
            case GIFT:
                b.append("Gift ").append(blank(match) || "*".equals(match.trim()) ? "(any)" : match);
                if (minCount > 1) b.append(" x").append(minCount).append("+");
                break;
            case LIKES:
                b.append("Every ").append(match).append(" likes");
                break;
            case CHAT:
                b.append("Chat ").append(match);
                break;
            default:
                b.append(trigger.label);
        }
        b.append("  ->  ").append(action.label);
        switch (action) {
            case GIVE:
            case SPAWN:
                b.append(' ').append(arg).append(" x").append(amount);
                break;
            case TNT:
            case LIGHTNING:
                b.append(" x").append(amount);
                break;
            case FREEZE:
                b.append(' ').append(duration).append("s");
                break;
            case EFFECT:
                b.append(' ').append(arg).append(' ').append(duration).append("s");
                break;
            case CLEAR_INVENTORY:
                if (!blank(arg)) b.append(' ').append(arg);
                break;
            case COMMAND:
            case TITLE:
            case TIME:
            case WEATHER:
            case SOUND:
            case RANDOM_TP:
                if (!blank(arg)) b.append(": ").append(arg);
                break;
            default:
                break;
        }
        if (perGiftCount) b.append("  (x gift count)");
        return b.toString();
    }

    private static boolean blank(String s) { return s == null || s.trim().isEmpty(); }

    Map<String, Object> toMap() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id);
        m.put("enabled", enabled);
        m.put("trigger", trigger.name());
        m.put("match", match);
        m.put("minCount", (long) minCount);
        m.put("action", action.name());
        m.put("arg", arg);
        m.put("amount", (long) amount);
        m.put("duration", (long) duration);
        m.put("cooldown", (long) cooldown);
        m.put("interval", (long) interval);
        m.put("delay", (long) delay);
        m.put("audio", audio);
        m.put("perGiftCount", perGiftCount);
        m.put("message", message);
        return m;
    }

    @SuppressWarnings("unchecked")
    static MgRule fromMap(Map<String, Object> m) {
        MgRule r = new MgRule();
        r.id = str(m.get("id"), r.id);
        r.enabled = bool(m.get("enabled"), true);
        r.trigger = MgTrigger.parse(str(m.get("trigger"), "GIFT"));
        r.match = str(m.get("match"), "");
        r.minCount = num(m.get("minCount"), 1);
        r.action = MgAction.parse(str(m.get("action"), "ALERT"));
        r.arg = str(m.get("arg"), "");
        r.amount = num(m.get("amount"), 1);
        r.duration = num(m.get("duration"), 3);
        r.cooldown = num(m.get("cooldown"), 0);
        r.interval = num(m.get("interval"), 100);
        r.delay = num(m.get("delay"), 0);
        r.audio = str(m.get("audio"), "");
        r.perGiftCount = bool(m.get("perGiftCount"), false);
        r.message = str(m.get("message"), "");
        return r;
    }

    static String str(Object o, String d) { return o instanceof String ? (String) o : d; }

    static boolean bool(Object o, boolean d) { return o instanceof Boolean ? (Boolean) o : d; }

    static int num(Object o, int d) { return o instanceof Number ? ((Number) o).intValue() : d; }
}
