package takeyourminestream.ijustseen.minigames;

import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import org.joml.Matrix4f;
import takeyourminestream.ijustseen.minigames.MgSprites.Atlas;
import takeyourminestream.ijustseen.minigames.MgSprites.Reg;
import takeyourminestream.ijustseen.ui.gui.ModUiTheme;
import takeyourminestream.ijustseen.utils.RenderLayerCompat;

/**
 * Theme scenery for the chat comment panels drawn in the world ("around the player" / floating modes).
 * Uses the same cached sprites as the menus: each piece is one textured quad on top of the panel.
 */
public final class MgWorldFx {
    private MgWorldFx() {}

    private static class_4588 vc;
    private static Matrix4f mat;
    private static Atlas atlas;

    /** Sink that turns sprite pieces into textured world quads. */
    private static final class Sink implements MgThemeFx.Sink {
        @Override public void fill(double x0, double y0, double x1, double y1, int rgb, double a) {
            Reg s = atlas.reg("solid");
            if (s == null) return;
            double u = (s.u + 1) / (double) atlas.size, v = (s.v + 1) / (double) atlas.size;
            quad(x0, y0, x1, y1, u, v, u, v, rgb, a);
        }

        @Override public void blit(Atlas at, int u, int v, int w, int h, double dx, double dy, double dw, double dh, int rgb, double a) {
            double s = at.size;
            quad(dx, dy, dx + dw, dy + dh, u / s, v / s, (u + w) / s, (v + h) / s, rgb, a);
        }

        @Override public void layer(int n) { }
    }

    private static final Sink SINK = new Sink();

    /** Called from the patched MessagePanelWorldRenderer.drawPanelWithBorder before it returns. */
    public static void border(class_4587 ms, class_4597 consumers, int x, int y, int w, int h, float alpha) {
        try {
            if (!MgThemeFx.commentsThemed() || alpha < 0.05f || w < 12 || h < 12) return;
            String th = ModUiTheme.getActiveTheme();
            if (th == null) th = "default";
            Atlas at = MgSprites.get(th);
            if (at == null || at.id == null) return;
            vc = RenderLayerCompat.getEntityBuffer(consumers, at.id);
            atlas = at;
            ms.method_22903();
            try {
                ms.method_46416(0f, 0f, 0.04f);
                mat = ms.method_23760().method_23761();
                int k = Math.max(1, Math.min(3, Math.round(Math.min(w, h) / 40f)));
                MgThemeFx.paint(SINK, th, x, y, w, h, alpha, 0.7f, k);
            } finally {
                ms.method_22909();
                vc = null;
                atlas = null;
            }
        } catch (Throwable t) {
            // never break chat rendering
        }
    }

    private static void quad(double x0, double y0, double x1, double y1, double u0, double v0, double u1, double v1, int rgb, double a) {
        float al = (float) Math.max(0, Math.min(1, a));
        if (al <= 0.01f || vc == null) return;
        float r = ((rgb >> 16) & 255) / 255f, g = ((rgb >> 8) & 255) / 255f, b = (rgb & 255) / 255f;
        int ov = class_4608.field_21444;
        vc.method_22918(mat, (float) x0, (float) y0, 0f).method_22915(r, g, b, al).method_22913((float) u0, (float) v0).method_22922(ov).method_60803(15728880).method_22914(0f, 0f, -1f);
        vc.method_22918(mat, (float) x0, (float) y1, 0f).method_22915(r, g, b, al).method_22913((float) u0, (float) v1).method_22922(ov).method_60803(15728880).method_22914(0f, 0f, -1f);
        vc.method_22918(mat, (float) x1, (float) y1, 0f).method_22915(r, g, b, al).method_22913((float) u1, (float) v1).method_22922(ov).method_60803(15728880).method_22914(0f, 0f, -1f);
        vc.method_22918(mat, (float) x1, (float) y0, 0f).method_22915(r, g, b, al).method_22913((float) u1, (float) v0).method_22922(ov).method_60803(15728880).method_22914(0f, 0f, -1f);
    }
}
