package takeyourminestream.ijustseen.aura;

import net.minecraft.class_2561;
import net.minecraft.class_364;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import takeyourminestream.ijustseen.ui.screen.AuraScreen;
import takeyourminestream.ijustseen.utils.Logger;

/**
 * The "Aura" button, placed right after "Themes" on the settings screen. ModConfigScreen.createBottomButtons
 * calls this at its end (Patcher inserts the call). The screen rebuilds its buttons on every init, so each call
 * adds exactly one button.
 */
public final class AuraUi {
    private AuraUi() {}

    static final String LABEL = "Aura";
    private static final int GAP = 6;
    private static boolean warned;
    private static java.lang.reflect.Method addChildMethod;

    /**
     * Screen.addDrawableChild is protected, and this class is not a subclass of the screen, so it is called by
     * reflection (the runtime names are intermediary, like the rest of the mod).
     */
    private static void addChild(class_437 screen, class_4185 button) throws Exception {
        if (addChildMethod == null) {
            java.lang.reflect.Method m = class_437.class.getDeclaredMethod("method_37063", class_364.class);
            m.setAccessible(true);
            addChildMethod = m;
        }
        addChildMethod.invoke(screen, button);
    }

    public static void afterBottomButtons(class_437 screen, class_4185 themes) {
        try {
            if (screen == null || themes == null) return;
            class_310 mc = class_310.method_1551();
            class_327 font = mc == null ? null : mc.field_1772;
            int w = font == null ? 48 : font.method_1727(LABEL) + 24;
            int x = themes.method_46426() + themes.method_25368() + GAP;
            int y = themes.method_46427();
            if (x + w > screen.field_22789 - 8) {
                // a narrow window: put it on the row above Themes so it never covers the footer buttons
                x = themes.method_46426();
                y = y - 24;
            }
            class_4185 button = class_4185.method_46430(class_2561.method_43470(LABEL), b -> {
                class_310 m = class_310.method_1551();
                if (m != null) m.method_1507(new AuraScreen(screen));
            }).method_46434(x, y, w, 20).method_46431();
            addChild(screen, button);
        } catch (Throwable t) {
            if (!warned) {
                warned = true;
                Logger.warning("[KeiTok] the Aura button could not be added: " + t);
            }
        }
    }
}
