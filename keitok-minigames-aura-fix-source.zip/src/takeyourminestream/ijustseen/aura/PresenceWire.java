package takeyourminestream.ijustseen.aura;

import io.netty.buffer.ByteBuf;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Proxy;
import java.util.UUID;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.minecraft.class_2960;

/**
 * The only code that touches Minecraft's networking types. The rest of the presence code is plain Java.
 *
 * Why it looks like this: the mod is built against intermediary names, and this build has no mapping files to
 * check them against. So the names of CustomPayload, PacketCodec, ServerPlayerEntity and their methods are NOT
 * assumed. Each one is found at run time by its shape, for example "the static method that takes an encoder and a
 * decoder and returns the codec type". Fabric's own class and method names are not remapped, so they are used by
 * name. Anything that cannot be found throws Missing with the name of the thing, the caller logs it and presence
 * is turned off. The rest of KeiTok keeps running.
 *
 * Verified in the original jar: net.minecraft.class_2960 (Identifier) and its method_60655(String, String).
 * Not verified, found by shape: net.minecraft.class_8710 (CustomPayload), net.minecraft.class_9139 (PacketCodec).
 * Payloads are Proxy objects that implement CustomPayload, so their getId() does not need its name.
 */
final class PresenceWire {
    private PresenceWire() {}

    static final String NS = "keitok";

    private static final String CLIENT_NET = "net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking";
    private static final String SERVER_NET = "net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking";
    private static final String GAME_PROFILE = "com.mojang.authlib.GameProfile";
    private static final ClassLoader LOADER = PresenceWire.class.getClassLoader();

    /** Something this build could not find at run time. */
    static final class Missing extends IllegalStateException {
        private static final long serialVersionUID = 1L;

        Missing(String what) {
            super("KeiTok presence: cannot find " + what + " (intermediary name or Fabric API mismatch)");
        }
    }

    private static Class<?> payloadType;
    private static Class<?> identType;
    private static Class<?> idType;
    private static Object helloId;
    private static Object rosterId;
    private static boolean typesRegistered;

    static synchronized Object helloId() {
        return helloId;
    }

    static synchronized Object rosterId() {
        return rosterId;
    }

    /** Creates the two channel ids and registers both payload types. Call on the client and on the server. Once per JVM. */
    static synchronized void registerTypes() {
        if (typesRegistered) return;
        payloadType = type("net.minecraft.class_8710");
        identType = type("net.minecraft.class_2960");
        Class<?> codecType = type("net.minecraft.class_9139");
        idType = findIdType();
        helloId = newId("hello");
        rosterId = newId("roster");
        Method factory = findCodecFactory(codecType);
        Object c2s = PayloadTypeRegistry.playC2S();
        Object s2c = PayloadTypeRegistry.playS2C();
        Method reg = findAccepting(PayloadTypeRegistry.class, "register", 2, idType);
        call(reg, c2s, helloId, codecFor(factory, helloId));
        call(reg, s2c, rosterId, codecFor(factory, rosterId));
        typesRegistered = true;
    }

    // ---- client

    static boolean clientCanSend(Object id) {
        return (Boolean) call(findAccepting(type(CLIENT_NET), "canSend", 1, idType), null, id);
    }

    static void clientSend(Object id, byte[] data) {
        call(findAccepting(type(CLIENT_NET), "send", 1, payloadType), null, makePayload(id, data));
    }

    static void clientOnReceive(Object id, Consumer<byte[]> fn) {
        Method reg = findAccepting(type(CLIENT_NET), "registerGlobalReceiver", 2, idType);
        Object handler = receiverProxy(reg.getParameterTypes()[1], (payload, context) -> fn.accept(dataOf(payload)));
        call(reg, null, id, handler);
    }

    // ---- server

    /** The player object (ServerPlayerEntity) is passed through as an Object. */
    static void serverOnReceive(Object id, BiConsumer<Object, byte[]> fn) {
        Method reg = findAccepting(type(SERVER_NET), "registerGlobalReceiver", 2, idType);
        Class<?> handlerType = reg.getParameterTypes()[1];
        Class<?> contextType = singleMethod(handlerType).getParameterTypes()[1];
        Method playerOf = named(contextType, "player");
        Object handler = receiverProxy(handlerType, (payload, context) -> fn.accept(call(playerOf, context), dataOf(payload)));
        call(reg, null, id, handler);
    }

    static void serverOnLeave(Consumer<Object> fn) {
        try {
            Field field = type("net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents").getField("LEAVE");
            Class<?> listenerType = (Class<?>) ((ParameterizedType) field.getGenericType()).getActualTypeArguments()[0];
            Object listener = Proxy.newProxyInstance(LOADER, new Class<?>[] {listenerType}, (proxy, m, a) -> {
                if (m.getDeclaringClass() == Object.class) return objectMethod(proxy, m, a);
                fn.accept(a[0]);
                return null;
            });
            Method register = findAccepting(type("net.fabricmc.fabric.api.event.Event"), "register", 1, Object.class);
            call(register, field.get(null), listener);
        } catch (NoSuchFieldException | IllegalAccessException e) {
            throw new Missing("ServerPlayerEvents.LEAVE (" + e + ")");
        }
    }

    static boolean serverCanSend(Object player, Object id) {
        return (Boolean) call(findServer("canSend", player, id), null, player, id);
    }

    static void serverSend(Object player, Object id, byte[] data) {
        Object payload = makePayload(id, data);
        call(findServer("send", player, payload), null, player, payload);
    }

    static UUID uuidOf(Object player) {
        return (UUID) call(named(type(GAME_PROFILE), "getId"), gameProfileOf(player));
    }

    static String nameOf(Object player) {
        return (String) call(named(type(GAME_PROFILE), "getName"), gameProfileOf(player));
    }

    // ---- payloads and codecs

    /** The handler behind every payload we make. The only method of CustomPayload is getId(). */
    private static final class Payload implements InvocationHandler {
        final Object id;
        final byte[] data;

        Payload(Object id, byte[] data) {
            this.id = id;
            this.data = data;
        }

        @Override
        public Object invoke(Object proxy, Method m, Object[] a) {
            if (m.getDeclaringClass() == Object.class) return objectMethod(proxy, m, a);
            return id;
        }
    }

    static Object makePayload(Object id, byte[] data) {
        return Proxy.newProxyInstance(LOADER, new Class<?>[] {payloadType}, new Payload(id, data));
    }

    static byte[] dataOf(Object payload) {
        if (payload != null && Proxy.isProxyClass(payload.getClass())) {
            InvocationHandler h = Proxy.getInvocationHandler(payload);
            if (h instanceof Payload) return ((Payload) h).data;
        }
        throw new IllegalArgumentException("not a KeiTok payload");
    }

    private static Object codecFor(Method factory, Object id) {
        Class<?> encoderType = factory.getParameterTypes()[0];
        Class<?> decoderType = factory.getParameterTypes()[1];
        Object encoder = Proxy.newProxyInstance(LOADER, new Class<?>[] {encoderType}, (proxy, m, a) -> {
            if (m.getDeclaringClass() == Object.class) return objectMethod(proxy, m, a);
            ((ByteBuf) a[0]).writeBytes(dataOf(a[1]));
            return null;
        });
        Object decoder = Proxy.newProxyInstance(LOADER, new Class<?>[] {decoderType}, (proxy, m, a) -> {
            if (m.getDeclaringClass() == Object.class) return objectMethod(proxy, m, a);
            return makePayload(id, readAll((ByteBuf) a[0]));
        });
        return call(factory, null, encoder, decoder);
    }

    private static byte[] readAll(ByteBuf buf) {
        byte[] out = new byte[buf.readableBytes()];
        buf.readBytes(out);
        return out;
    }

    private static Object receiverProxy(Class<?> iface, BiConsumer<Object, Object> fn) {
        return Proxy.newProxyInstance(LOADER, new Class<?>[] {iface}, (proxy, m, a) -> {
            if (m.getDeclaringClass() == Object.class) return objectMethod(proxy, m, a);
            fn.accept(a[0], a[1]);
            return null;
        });
    }

    // ---- lookups by shape

    private static Object objectMethod(Object proxy, Method m, Object[] a) {
        switch (m.getName()) {
            case "equals":
                return proxy == a[0];
            case "hashCode":
                return System.identityHashCode(proxy);
            default:
                return "KeiTok presence (" + m.getDeclaringClass().getSimpleName() + ")";
        }
    }

    private static Class<?> type(String name) {
        try {
            return Class.forName(name, false, LOADER);
        } catch (ClassNotFoundException e) {
            throw new Missing("class " + name);
        }
    }

    private static Class<?> findIdType() {
        for (Class<?> c : payloadType.getDeclaredClasses()) {
            for (Constructor<?> k : c.getDeclaredConstructors()) {
                if (k.getParameterCount() == 1 && k.getParameterTypes()[0] == identType) return c;
            }
        }
        throw new Missing("the channel id class nested in " + payloadType.getName());
    }

    private static Object newId(String path) {
        try {
            Constructor<?> k = idType.getDeclaredConstructor(identType);
            k.setAccessible(true);
            return k.newInstance(class_2960.method_60655(NS, path));
        } catch (ReflectiveOperationException e) {
            throw new IllegalStateException("KeiTok presence: cannot create the channel id " + path, e);
        }
    }

    private static Method findCodecFactory(Class<?> codecType) {
        for (Method m : codecType.getMethods()) {
            if (Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 2 && m.getReturnType() == codecType) {
                return m;
            }
        }
        throw new Missing("the static codec factory that takes an encoder and a decoder");
    }

    /** The public method with this name and arity whose first parameter accepts firstArg. */
    private static Method findAccepting(Class<?> owner, String name, int arity, Class<?> firstArg) {
        for (Method m : owner.getMethods()) {
            if (m.getName().equals(name) && m.getParameterCount() == arity
                    && m.getParameterTypes()[0].isAssignableFrom(firstArg)) {
                return m;
            }
        }
        throw new Missing(owner.getName() + "." + name + " (" + arity + " arguments)");
    }

    /** ServerPlayNetworking.name(first, second) where the parameters accept these two objects. */
    private static Method findServer(String name, Object first, Object second) {
        for (Method m : type(SERVER_NET).getMethods()) {
            if (m.getName().equals(name) && m.getParameterCount() == 2
                    && m.getParameterTypes()[0].isInstance(first) && m.getParameterTypes()[1].isInstance(second)) {
                return m;
            }
        }
        throw new Missing("ServerPlayNetworking." + name + " for this player and payload");
    }

    private static Method singleMethod(Class<?> iface) {
        for (Method m : iface.getMethods()) {
            if (!Modifier.isStatic(m.getModifiers()) && m.getParameterCount() == 2) return m;
        }
        throw new Missing("the single handler method of " + iface.getName());
    }

    private static Method named(Class<?> owner, String name) {
        try {
            return owner.getMethod(name);
        } catch (NoSuchMethodException e) {
            throw new Missing(owner.getName() + "." + name + "()");
        }
    }

    /** The player's GameProfile: the one zero-argument method of the player that returns it. */
    private static Object gameProfileOf(Object player) {
        Class<?> profileType = type(GAME_PROFILE);
        for (Method m : player.getClass().getMethods()) {
            if (m.getParameterCount() == 0 && m.getReturnType() == profileType) return call(m, player);
        }
        throw new Missing("the player's GameProfile getter");
    }

    private static Object call(Method m, Object target, Object... args) {
        try {
            return m.invoke(target, args);
        } catch (ReflectiveOperationException e) {
            Throwable cause = e.getCause() != null ? e.getCause() : e;
            throw new IllegalStateException("KeiTok presence: " + m.getName() + " failed: " + cause, cause);
        }
    }
}
