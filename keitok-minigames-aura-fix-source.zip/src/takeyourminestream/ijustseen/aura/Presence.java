package takeyourminestream.ijustseen.aura;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Which players on the current server have KeiTok, as told to us by the server.
 * A player is only listed if the server received their KeiTok hello, so nobody is identified by guessing.
 * Thread-safe: the network thread writes it and the render thread reads it.
 */
public final class Presence {
    public static final int MAX = 1024;

    public static final class Entry {
        public final UUID id;
        public final String name;
        public final String version;
        /** True for the entry that belongs to the player running this client. */
        public final boolean self;

        public Entry(UUID id, String name, String version, boolean self) {
            this.id = id;
            this.name = name == null ? "" : name;
            this.version = version == null ? "" : version;
            this.self = self;
        }
    }

    private final Map<UUID, Entry> byId = new HashMap<>();
    private Entry self;

    /** Replaces the whole list with the server's latest snapshot. */
    public synchronized void replace(List<Entry> list) {
        byId.clear();
        self = null;
        if (list == null) return;
        for (Entry e : list) {
            if (byId.size() >= MAX) break;
            if (e == null || e.id == null) continue;
            byId.put(e.id, e);
            if (e.self) self = e;
        }
    }

    public synchronized void clear() {
        byId.clear();
        self = null;
    }

    public synchronized boolean isKeiTok(UUID id) {
        return id != null && byId.containsKey(id);
    }

    public synchronized Entry get(UUID id) {
        return id == null ? null : byId.get(id);
    }

    public synchronized Entry self() {
        return self;
    }

    public synchronized int size() {
        return byId.size();
    }

    public synchronized List<Entry> snapshot() {
        return new ArrayList<>(byId.values());
    }
}
