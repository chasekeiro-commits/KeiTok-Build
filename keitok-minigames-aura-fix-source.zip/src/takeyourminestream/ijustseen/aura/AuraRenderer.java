package takeyourminestream.ijustseen.aura;

/**
 * Builds the aura as billboarded quads. Pure maths: it only talks to a QuadSink, so it runs (and is tested)
 * without Minecraft. Nothing is allocated per frame: every buffer is a field that is reused.
 *
 * Coordinates passed to the sink are relative to the camera, so the caller only needs to multiply by the
 * world view matrix.
 */
public final class AuraRenderer {
    public static final int TEX_GLOW = 0;
    public static final int TEX_FEATHER = 1;
    public static final int TEX_LOGO = 2;

    /** Receives one quad: four corners of the sprite counter-clockwise as seen from the camera, a texture slot, and an RGBA colour. */
    public interface QuadSink {
        void quad(int tex,
                  double ax, double ay, double az,
                  double bx, double by, double bz,
                  double cx, double cy, double cz,
                  double dx, double dy, double dz,
                  float r, float g, float b, float a);
    }

    // colour roles
    private static final int R_RING = 0, R_ORBIT = 1, R_TRAIL = 2, R_WAVE = 3, R_SPARK = 4,
        R_WING = 5, R_SHELL = 6, R_CORE = 7;
    private static final double[] RING_HEIGHT = {0.05, 0.5, 1.0, 0.25, 0.75, 1.2};
    private static final double FEET_TO_NAME = 0.5;
    /** World size of the name-tag font: 1 pixel = 0.025 blocks. Used to size the logo beside a name. */
    public static final double NAME_PIXEL = 0.025;
    public static final double LOGO_PIXELS = 9;

    private final float[] pal = new float[9];
    private final double[] tmp = new double[4];
    private final double[] basis = new double[6];
    private QuadSink sink;
    private int budget;
    private double time;
    private double camX, camY, camZ;
    private double intensity;
    private double scale;
    private double factor;
    private int mode;
    private float cr, cg, cb;
    private int lastQuads;

    /** Sets the three palette colours used by the designs (accent, light, dark), as ARGB ints. */
    public void setPalette(int accent, int light, int dark) {
        put(0, accent);
        put(1, light);
        put(2, dark);
    }

    private void put(int slot, int argb) {
        pal[slot * 3] = ((argb >> 16) & 255) / 255f;
        pal[slot * 3 + 1] = ((argb >> 8) & 255) / 255f;
        pal[slot * 3 + 2] = (argb & 255) / 255f;
    }

    public int lastQuadCount() {
        return lastQuads;
    }

    /**
     * Draws the auras of all targets.
     *
     * @param t        targets for this tick (already filled and sorted nearest first)
     * @param look     settings
     * @param quality  governor level 0..3
     * @param timeSec  real time in seconds (drives all animation)
     * @param camX..Z  camera position in the world
     * @param alpha    how far between the last tick and this one (0..1)
     * @param sink     receives the quads
     * @param maxQuads hard limit for this frame
     */
    public int render(AuraTargets t, AuraLook look, int quality, double timeSec,
                      double camX, double camY, double camZ, double alpha, QuadSink sink, int maxQuads) {
        this.sink = sink;
        this.camX = camX;
        this.camY = camY;
        this.camZ = camZ;
        this.time = timeSec;
        this.budget = Math.min(maxQuads, AuraGovernor.QUAD_CAP[Math.max(0, Math.min(3, quality))]);
        this.factor = AuraGovernor.FACTOR[Math.max(0, Math.min(3, quality))];
        this.intensity = look.intensityPct / 100.0;
        this.scale = look.scalePct / 100.0;
        int before = budget;
        if (look.enabled) {
            for (int i = 0; i < t.count && budget > 0; i++) {
                renderAura(t, i, look, alpha);
            }
        }
        lastQuads = before - budget;
        return lastQuads;
    }

    /** Draws the name logos (one per KeiTok player). Separate pass, so it uses the logo texture. */
    public int renderLogos(AuraTargets t, AuraLook look, double camX, double camY, double camZ, double alpha, QuadSink sink) {
        this.sink = sink;
        this.camX = camX;
        this.camY = camY;
        this.camZ = camZ;
        this.budget = Math.min(Integer.MAX_VALUE, 4 * AuraTargets.MAX);
        int drawn = 0;
        for (int i = 0; i < t.count; i++) {
            if (!t.keitok[i]) continue;
            t.interpolate(i, alpha, tmp);
            double rx = tmp[0] - camX, ry = tmp[1] - camY, rz = tmp[2] - camZ;
            double dist = Math.sqrt(rx * rx + ry * ry + rz * rz);
            if (dist > look.rangeBlocks) continue;
            double body = t.bodyH[i] > 0 ? t.bodyH[i] : 1.8;
            // the name tag sits above the head, centred on the player
            double ax = rx, ay = ry + body + FEET_TO_NAME, az = rz;
            String nm = t.name[i];
            if (nm != null && !nm.isEmpty() && t.widthPx[i] > 0) {
                basis(ax, ay, az);
                // copy the camera-facing vectors first, because quadAt() reuses the basis buffer
                double rightX = basis[0], rightZ = basis[2];
                double upX = basis[3], upY = basis[4], upZ = basis[5];
                double k = NAME_PIXEL;
                double half = LOGO_PIXELS * k / 2;
                double side = t.widthPx[i] * k / 2 + 0.04 + half;
                double cx = ax + rightX * side + upX * (4 * k);
                double cy = ay + upY * (4 * k);
                double cz = az + rightZ * side + upZ * (4 * k);
                quadAt(TEX_LOGO, cx, cy, cz, half, 1f, 1f, 1f, 1f);
            } else {
                // no name known: the logo goes just above the name tag, centred
                quadAt(TEX_LOGO, ax, ay + 0.28, az, 0.16, 1f, 1f, 1f, 1f);
            }
            drawn++;
        }
        return drawn;
    }

    // ------------------------------------------------------------------ one player

    private void renderAura(AuraTargets t, int i, AuraLook look, double alpha) {
        t.interpolate(i, alpha, tmp);
        double rx = tmp[0] - camX, ry = tmp[1] - camY, rz = tmp[2] - camZ;
        double dist = Math.sqrt(rx * rx + ry * ry + rz * rz);
        double range = look.rangeBlocks;
        if (dist > range) return;
        // far players get a lighter version so distant auras cost less
        double lod = dist > range * 0.6 ? 0.5 : 1.0;
        double f = factor * lod;
        int d = look.design;
        double body = t.bodyH[i] > 0 ? t.bodyH[i] : 1.8;
        double bodyScale = body / 1.8;
        double s = scale * bodyScale;
        double speed = AuraDesigns.param(d, 9) / 10.0 * (look.speedPct / 100.0);
        double phase = time * speed;
        double yaw = tmp[3] * Math.PI / 180.0;
        mode = AuraDesigns.param(d, 8);

        // shell
        if (AuraDesigns.param(d, 6) != 0) {
            int n = Math.max(4, (int) Math.round(8 * f));
            for (int j = 0; j < n; j++) {
                double lon = Math.PI * 2 * j / n + phase * 0.15;
                double lat = AuraMath.sin(phase * 0.5 + j) * 0.35;
                double cxw = rx + 0.8 * s * AuraMath.cos(lon) * AuraMath.cos(lat);
                double cyw = ry + body * 0.5 + 0.8 * s * AuraMath.sin(lat) * 1.1;
                double czw = rz + 0.8 * s * AuraMath.sin(lon) * AuraMath.cos(lat);
                spr(TEX_GLOW, cxw, cyw, czw, 0.6 * s, R_SHELL, j, 0.12);
            }
        }
        // core
        if (AuraDesigns.param(d, 7) != 0) {
            spr(TEX_GLOW, rx, ry + body * 0.6, rz, 0.9 * s, R_CORE, 0, 0.22 + 0.08 * AuraMath.sin(phase * 2));
        }
        // rings
        int rings = AuraDesigns.param(d, 0);
        for (int k = 0; k < rings && budget > 0; k++) {
            double h = RING_HEIGHT[k % RING_HEIGHT.length] * body;
            double rad = (0.55 + 0.05 * k) * s * (1 + 0.08 * AuraMath.sin(phase * 2 + k));
            int n = Math.max(6, (int) Math.round(14 * f));
            double start = phase * (0.6 + 0.2 * k) * ((k & 1) == 0 ? 1 : -1);
            for (int j = 0; j < n; j++) {
                double a = start + Math.PI * 2 * j / n;
                spr(TEX_GLOW, rx + rad * AuraMath.cos(a), ry + h, rz + rad * AuraMath.sin(a), 0.12 * s, R_RING, k, 0.55);
            }
        }
        // waves
        int waves = AuraDesigns.param(d, 3);
        for (int w = 0; w < waves && budget > 0; w++) {
            double p = AuraMath.fract(phase * 0.35 + w * 0.5);
            double rad = (0.3 + 1.1 * p) * s;
            double alphaW = (1 - p) * (1 - p) * 0.6;
            int n = Math.max(8, (int) Math.round(18 * f));
            for (int j = 0; j < n; j++) {
                double a = Math.PI * 2 * j / n;
                spr(TEX_GLOW, rx + rad * AuraMath.cos(a), ry + body * 0.5, rz + rad * AuraMath.sin(a),
                    0.10 * s * (1 + p), R_WAVE, w, alphaW);
            }
        }
        // orbiting sparks with trails
        int orbit = AuraDesigns.param(d, 1);
        int n = orbit > 0 ? Math.max(2, (int) Math.round(orbit * f)) : 0;
        int trail = AuraDesigns.param(d, 2);
        for (int k = 0; k < n && budget > 0; k++) {
            double a = phase * 0.9 + Math.PI * 2 * k / n;
            double rad = (0.62 + 0.08 * AuraMath.sin(phase * 1.7 + k)) * s;
            double y = body * (0.15 + 0.7 * AuraMath.fract(k / (double) n + phase * 0.07));
            spr(TEX_GLOW, rx + rad * AuraMath.cos(a), ry + y, rz + rad * AuraMath.sin(a), 0.16 * s, R_ORBIT, k, 0.85);
            for (int j = 1; j <= trail && budget > 0; j++) {
                double ta = a - j * 0.16;
                double ty = y - j * 0.05 * body;
                spr(TEX_GLOW, rx + rad * AuraMath.cos(ta), ry + ty, rz + rad * AuraMath.sin(ta),
                    0.12 * s * (1 - j / (trail + 1.0)), R_TRAIL, k, 0.45 / j);
            }
        }
        // floating sparks
        int sparks = Math.max(0, (int) Math.round(AuraDesigns.param(d, 4) * f));
        for (int k = 0; k < sparks && budget > 0; k++) {
            double h1 = AuraMath.hash01(k * 73 + 11), h2 = AuraMath.hash01(k * 131 + 7);
            double a = Math.PI * 2 * h1 + phase * 0.2 * ((k & 1) == 0 ? 1 : -1);
            double rad = (0.5 + 0.6 * h2) * s;
            double y = body * (0.05 + 0.9 * AuraMath.fract(h2 * 3.7 + phase * 0.05));
            double twinkle = 0.55 + 0.45 * AuraMath.sin(phase * 6 + k * 1.3);
            spr(TEX_GLOW, rx + rad * AuraMath.cos(a), ry + y, rz + rad * AuraMath.sin(a), 0.07 * s, R_SPARK, k, 0.85 * twinkle);
        }
        // wings
        int style = AuraDesigns.param(d, 5);
        if (style > 0) renderWings(style, rx, ry, rz, yaw, body, s, f, phase);
    }

    private void renderWings(int style, double rx, double ry, double rz, double yaw, double body, double s, double f, double phase) {
        double sinY = AuraMath.sin(yaw), cosY = AuraMath.cos(yaw);
        // right = (cosY, 0, sinY); back = -forward = (sinY, 0, -cosY)
        double span, flap, size;
        switch (style) {
            case 1: span = 1.0; flap = 0.22; size = 0.22; break;
            case 2: span = 1.2; flap = 0.28; size = 0.26; break;
            case 3: span = 1.1; flap = 0.42; size = 0.24; break;
            case 4: span = 0.9; flap = 0.10; size = 0.16; break;
            case 5: span = 1.25; flap = 0.55; size = 0.28; break;
            case 6: span = 1.1; flap = 0.35; size = 0.20; break;
            default: span = 1.05; flap = 0.20; size = 0.20; break;
        }
        span *= s;
        size *= s;
        boolean glow = style == 4 || style == 5;
        int tex = glow ? TEX_GLOW : TEX_FEATHER;
        int n = style == 5 ? Math.max(3, (int) Math.round(5 * f)) : Math.max(3, (int) Math.round(9 * f));
        double baseX = rx + sinY * 0.15 * s;
        double baseY = ry + body * 0.72;
        double baseZ = rz - cosY * 0.15 * s;
        double flapPh = phase * (style == 5 ? 3.2 : 2.2);
        for (int sd = -1; sd <= 1; sd += 2) {
            for (int i = 0; i < n && budget > 0; i++) {
                double t = i / (n - 1.0);
                double a = (0.12 + 0.8 * t) * Math.PI;
                double bend = flap * span * AuraMath.sin(flapPh + sd * 0.6) * (0.3 + 0.7 * t);
                double extra = 0;
                if (style == 6) extra = 0.08 * span * AuraMath.sin(4 * a);
                if (style == 7) extra = 0.07 * span * AuraMath.sin(5 * a + phase);
                double out = span * 0.95 * AuraMath.sin(a) * sd;
                double x = baseX + cosY * out + sinY * span * 0.45 * t;
                double z = baseZ + sinY * out - cosY * span * 0.45 * t;
                double y = baseY + span * 0.55 * AuraMath.cos(a) * (1 - 0.35 * t) + bend + extra;
                double fs = size * (1.0 - 0.45 * t);
                spr(tex, x, y, z, fs, R_WING, i + (sd > 0 ? 1 : 0), 0.85);
            }
        }
    }

    // ------------------------------------------------------------------ primitives

    /** A camera-facing sprite coloured by role and palette. alpha is multiplied by the intensity. */
    private void spr(int tex, double x, double y, double z, double s, int role, int k, double alpha) {
        if (budget <= 0) return;
        int slot = slotFor(mode, role, k);
        cr = pal[slot * 3];
        cg = pal[slot * 3 + 1];
        cb = pal[slot * 3 + 2];
        double a = Math.max(0, Math.min(1, alpha * intensity));
        if (a <= 0.004) return;
        quadAt(tex, x, y, z, s, cr, cg, cb, (float) a);
    }

    private void quadAt(int tex, double x, double y, double z, double s, float r, float g, float b, float a) {
        if (budget <= 0) return;
        basis(x, y, z);
        double rx = basis[0] * s, rz = basis[2] * s;
        double ux = basis[3] * s, uy = basis[4] * s, uz = basis[5] * s;
        // counter-clockwise as seen from the camera: bottom-left, bottom-right, top-right, top-left
        sink.quad(tex,
            x - rx - ux, y - uy, z - rz - uz,
            x + rx - ux, y - uy, z + rz - uz,
            x + rx + ux, y + uy, z + rz + uz,
            x - rx + ux, y + uy, z - rz + uz,
            r, g, b, a);
        budget--;
    }

    /** Sets basis[0..5] to the camera-facing right and up vectors for a point at (x, y, z) relative to the camera. */
    private void basis(double x, double y, double z) {
        double tx = -x, ty = -y, tz = -z;
        double len = Math.sqrt(tx * tx + ty * ty + tz * tz);
        if (len < 1e-6) {
            tx = 0;
            ty = 0;
            tz = 1;
        } else {
            tx /= len;
            ty /= len;
            tz /= len;
        }
        double rx = tz, rz = -tx;
        double rl = Math.sqrt(rx * rx + rz * rz);
        if (rl < 1e-6) {
            rx = 1;
            rz = 0;
        } else {
            rx /= rl;
            rz /= rl;
        }
        basis[0] = rx;
        basis[1] = 0;
        basis[2] = rz;
        basis[3] = ty * rz;
        basis[4] = tz * rx - tx * rz;
        basis[5] = -ty * rx;
    }

    /** Palette slot for a colour role. Mode 0 = classic, 1 = bright, 2 = two-tone. */
    private static int slotFor(int mode, int role, int k) {
        switch (mode) {
            case 0:
                switch (role) {
                    case R_RING: return 2;
                    case R_SPARK: case R_CORE: return 1;
                    case R_WING: return (k & 1) == 0 ? 0 : 1;
                    default: return 0;
                }
            case 1:
                return role == R_ORBIT || role == R_SHELL || role == R_WAVE ? 0 : 1;
            default:
                switch (role) {
                    case R_ORBIT: return (k & 1) == 0 ? 0 : 2;
                    case R_SPARK: return (k & 1) == 0 ? 1 : 0;
                    case R_WING: return (k & 1) == 0 ? 0 : 2;
                    case R_CORE: return 0;
                    default: return 2;
                }
        }
    }
}
