package takeyourminestream.ijustseen.aura;

/**
 * The players that get an aura this tick, stored in fixed-size arrays so nothing is allocated per frame.
 * Positions are filled once per tick; the renderer interpolates between the previous and the current tick.
 */
public final class AuraTargets {
    public static final int MAX = 48;

    public int count;
    // current tick
    public final double[] cx = new double[MAX], cy = new double[MAX], cz = new double[MAX], cyaw = new double[MAX];
    // previous tick (matched by player id, so a player keeps its interpolation)
    public final double[] px = new double[MAX], py = new double[MAX], pz = new double[MAX], pyaw = new double[MAX];
    public final double[] bodyH = new double[MAX];
    public final int[] widthPx = new int[MAX];
    public final boolean[] self = new boolean[MAX];
    /** True when this player is known to have KeiTok (always true for the local player). */
    public final boolean[] keitok = new boolean[MAX];
    public final long[] idHi = new long[MAX], idLo = new long[MAX];
    public final String[] name = new String[MAX];

    // snapshot of last tick, used only to find where each player was before this tick
    private int prevCount;
    private final long[] prevHi = new long[MAX], prevLo = new long[MAX];
    private final double[] ox = new double[MAX], oy = new double[MAX], oz = new double[MAX], oyaw = new double[MAX];

    /** Call once at the start of each tick, before adding targets. */
    public void beginTick() {
        System.arraycopy(cx, 0, ox, 0, count);
        System.arraycopy(cy, 0, oy, 0, count);
        System.arraycopy(cz, 0, oz, 0, count);
        System.arraycopy(cyaw, 0, oyaw, 0, count);
        System.arraycopy(idHi, 0, prevHi, 0, count);
        System.arraycopy(idLo, 0, prevLo, 0, count);
        prevCount = count;
        count = 0;
    }

    /** @return false if the list is full. */
    public boolean add(long hi, long lo, boolean isSelf, boolean isKeitok, String playerName, double x, double y, double z, double yaw, double height, int widthPixels) {
        if (count >= MAX) return false;
        int i = count++;
        idHi[i] = hi;
        idLo[i] = lo;
        self[i] = isSelf;
        keitok[i] = isKeitok;
        name[i] = playerName;
        cx[i] = x;
        cy[i] = y;
        cz[i] = z;
        cyaw[i] = yaw;
        bodyH[i] = height;
        widthPx[i] = widthPixels;
        // Start from where this player was last tick, so movement is smooth; new players start in place.
        int j = findPrev(hi, lo);
        if (j >= 0) {
            px[i] = ox[j];
            py[i] = oy[j];
            pz[i] = oz[j];
            pyaw[i] = oyaw[j];
        } else {
            px[i] = x;
            py[i] = y;
            pz[i] = z;
            pyaw[i] = yaw;
        }
        return true;
    }

    private int findPrev(long hi, long lo) {
        for (int j = 0; j < prevCount; j++) {
            if (prevHi[j] == hi && prevLo[j] == lo) return j;
        }
        return -1;
    }

    /** Writes the interpolated feet position and yaw of target i into out[0..3]. */
    public void interpolate(int i, double alpha, double[] out) {
        out[0] = px[i] + (cx[i] - px[i]) * alpha;
        out[1] = py[i] + (cy[i] - py[i]) * alpha;
        out[2] = pz[i] + (cz[i] - pz[i]) * alpha;
        double dy = cyaw[i] - pyaw[i];
        while (dy > 180) dy -= 360;
        while (dy < -180) dy += 360;
        out[3] = pyaw[i] + dy * alpha;
    }

    /** Sorts targets nearest-first so the quad budget is spent on the players that matter most. */
    public void sortByDistance(double camX, double camY, double camZ) {
        for (int i = 1; i < count; i++) {
            int k = i;
            while (k > 0 && dist2(k, camX, camY, camZ) < dist2(k - 1, camX, camY, camZ)) {
                swap(k, k - 1);
                k--;
            }
        }
    }

    private double dist2(int i, double x, double y, double z) {
        double dx = cx[i] - x, dy = cy[i] - y, dz = cz[i] - z;
        return dx * dx + dy * dy + dz * dz;
    }

    private void swap(int a, int b) {
        double t;
        t = cx[a]; cx[a] = cx[b]; cx[b] = t;
        t = cy[a]; cy[a] = cy[b]; cy[b] = t;
        t = cz[a]; cz[a] = cz[b]; cz[b] = t;
        t = cyaw[a]; cyaw[a] = cyaw[b]; cyaw[b] = t;
        t = px[a]; px[a] = px[b]; px[b] = t;
        t = py[a]; py[a] = py[b]; py[b] = t;
        t = pz[a]; pz[a] = pz[b]; pz[b] = t;
        t = pyaw[a]; pyaw[a] = pyaw[b]; pyaw[b] = t;
        t = bodyH[a]; bodyH[a] = bodyH[b]; bodyH[b] = t;
        int w = widthPx[a]; widthPx[a] = widthPx[b]; widthPx[b] = w;
        boolean s = self[a]; self[a] = self[b]; self[b] = s;
        boolean k = keitok[a]; keitok[a] = keitok[b]; keitok[b] = k;
        long h = idHi[a]; idHi[a] = idHi[b]; idHi[b] = h;
        long l = idLo[a]; idLo[a] = idLo[b]; idLo[b] = l;
        String n = name[a]; name[a] = name[b]; name[b] = n;
    }
}
