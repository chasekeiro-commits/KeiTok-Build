package takeyourminestream.ijustseen.aura;

import net.fabricmc.api.DedicatedServerModInitializer;

/**
 * Dedicated-server entrypoint of the KeiTok jar. It only relays the presence hellos (PresenceServerImpl), so KeiTok
 * players on this server can see each other. Vanilla clients never send a hello, so nothing happens for them.
 * This class never throws: if the relay cannot start, the server runs normally without it.
 */
public final class PresenceServer implements DedicatedServerModInitializer {
    @Override
    public void onInitializeServer() {
        try {
            PresenceServerImpl.init();
        } catch (Throwable t) {
            java.util.logging.Logger.getLogger("KeiTok").warning("KeiTok presence relay is off: " + t);
        }
    }
}
