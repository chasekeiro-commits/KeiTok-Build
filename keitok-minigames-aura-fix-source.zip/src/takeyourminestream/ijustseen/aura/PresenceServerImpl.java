package takeyourminestream.ijustseen.aura;

import java.io.IOException;
import java.util.logging.Logger;

/**
 * Server side of the presence: listens for KeiTok hellos and sends each KeiTok player the list. Runs only on a
 * dedicated server, through PresenceServer. It uses java.util.logging and no client classes.
 */
final class PresenceServerImpl {
    private static final Logger LOG = Logger.getLogger("KeiTok");
    private static volatile PresenceHub<Object> hub;

    private PresenceServerImpl() {}

    static synchronized void init() {
        if (hub != null) return;
        PresenceWire.registerTypes();
        hub = new PresenceHub<>(new PresenceHub.Port<Object>() {
            @Override
            public boolean canSend(Object player) {
                return PresenceWire.serverCanSend(player, PresenceWire.rosterId());
            }

            @Override
            public void send(Object player, byte[] roster) {
                PresenceWire.serverSend(player, PresenceWire.rosterId(), roster);
            }
        }, Presence.MAX);
        PresenceWire.serverOnReceive(PresenceWire.helloId(), PresenceServerImpl::onHello);
        PresenceWire.serverOnLeave(PresenceServerImpl::onLeave);
        LOG.info("KeiTok presence relay is on");
    }

    private static void onHello(Object player, byte[] data) {
        String version;
        try {
            version = PresenceCodec.decodeHello(data);
        } catch (IOException e) {
            return; // malformed: the player is simply not listed
        }
        PresenceHub<Object> h = hub;
        if (h != null) h.onHello(player, PresenceWire.uuidOf(player), PresenceWire.nameOf(player), version);
    }

    private static void onLeave(Object player) {
        PresenceHub<Object> h = hub;
        if (h != null) h.onLeave(player, PresenceWire.uuidOf(player));
    }
}
