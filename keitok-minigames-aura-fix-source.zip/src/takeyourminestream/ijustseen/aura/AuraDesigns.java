package takeyourminestream.ijustseen.aura;

/**
 * The 26 aura designs. Pure data: no Minecraft types, so it can be tested without the game.
 *
 * Columns of each row (see PARAMS):
 *   0 rings   - horizontal glow rings (0..3)
 *   1 orbit   - orbiting sparks that circle the body (0..12)
 *   2 trail   - trailing glow behind each orbiting spark (0..3)
 *   3 waves   - expanding energy waves (0..2)
 *   4 sparks  - twinkling particles floating around the body (0..30)
 *   5 wings   - wing style index into WING_STYLES (0 = no wings)
 *   6 shell   - translucent glow shell around the body (0/1)
 *   7 core    - soft glow at the chest (0/1)
 *   8 colors  - colour role layout (0..2), see AuraRenderer
 *   9 speed   - animation speed x10 (10 = normal)
 */
public final class AuraDesigns {
    private AuraDesigns() {}

    public static final int COUNT = 26;

    public static final String[] WING_STYLES = {
        "None", "Angel", "Golden", "Phoenix", "Crystal", "Butterfly", "Bat", "Dragon"
    };

    private static final String[] NAMES = {
        "Halo", "Nebula Veil", "Ember Crown", "Frost Angel", "Solar Wings",
        "Void Rift", "Starfall", "Aurora Ribbon", "Prism Lattice", "Comet Tail",
        "Spirit Flame", "Neon Pulse", "Lunar Ring", "Rune Circle", "Phoenix",
        "Ice Crystal", "Glitch Shell", "Cosmic Dust", "Pixel Storm", "Heart Aura",
        "Crystal Spire", "Tidal Wave", "Thunder Halo", "Shadow Wings", "Golden Sigil",
        "Dragon Scales"
    };

    private static final int[][] PARAMS = {
        {1, 6, 0, 0, 6, 0, 0, 1, 0, 10},   // 1 Halo
        {0, 10, 2, 1, 12, 0, 1, 0, 2, 10}, // 2 Nebula Veil
        {2, 8, 3, 0, 16, 0, 0, 1, 0, 20},  // 3 Ember Crown
        {1, 6, 0, 1, 8, 1, 0, 1, 1, 10},   // 4 Frost Angel
        {1, 10, 2, 0, 8, 2, 0, 1, 0, 10},  // 5 Solar Wings
        {2, 4, 0, 2, 6, 0, 1, 0, 2, 20},   // 6 Void Rift
        {0, 4, 3, 0, 30, 0, 0, 0, 1, 10},  // 7 Starfall
        {1, 8, 2, 1, 10, 0, 1, 0, 2, 10},  // 8 Aurora Ribbon
        {3, 6, 0, 0, 6, 0, 0, 1, 2, 10},   // 9 Prism Lattice
        {0, 3, 3, 0, 4, 0, 0, 0, 0, 30},   // 10 Comet Tail
        {0, 12, 3, 0, 8, 0, 0, 1, 0, 20},  // 11 Spirit Flame
        {2, 0, 0, 2, 0, 0, 1, 0, 1, 20},   // 12 Neon Pulse
        {3, 2, 0, 0, 6, 0, 0, 0, 1, 10},   // 13 Lunar Ring
        {3, 12, 0, 0, 0, 0, 0, 0, 0, 10},  // 14 Rune Circle
        {1, 10, 3, 1, 14, 3, 0, 1, 0, 20}, // 15 Phoenix
        {1, 4, 0, 1, 10, 4, 0, 1, 1, 10},  // 16 Ice Crystal
        {0, 6, 0, 2, 12, 0, 1, 0, 2, 30},  // 17 Glitch Shell
        {0, 6, 1, 0, 24, 0, 0, 0, 2, 10},  // 18 Cosmic Dust
        {1, 10, 0, 2, 16, 0, 0, 0, 0, 30}, // 19 Pixel Storm
        {1, 8, 1, 1, 8, 5, 0, 1, 0, 10},   // 20 Heart Aura
        {2, 6, 0, 0, 8, 0, 1, 1, 1, 10},   // 21 Crystal Spire
        {2, 8, 0, 2, 8, 0, 1, 0, 2, 10},   // 22 Tidal Wave
        {2, 4, 2, 2, 6, 0, 0, 1, 1, 30},   // 23 Thunder Halo
        {0, 4, 0, 1, 8, 6, 1, 0, 2, 10},   // 24 Shadow Wings
        {2, 8, 0, 1, 10, 2, 0, 1, 1, 10},  // 25 Golden Sigil
        {1, 6, 0, 0, 6, 7, 1, 1, 0, 10},   // 26 Dragon Scales
    };

    /** Clamps a 1-based design number from the config into 0..COUNT-1. */
    public static int index(int design) {
        return Math.max(0, Math.min(COUNT - 1, design - 1));
    }

    public static String name(int design) {
        return NAMES[index(design)];
    }

    public static int param(int design, int column) {
        return PARAMS[index(design)][column];
    }

    public static String wingName(int style) {
        return WING_STYLES[Math.max(0, Math.min(WING_STYLES.length - 1, style))];
    }
}
