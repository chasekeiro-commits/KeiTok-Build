package takeyourminestream.ijustseen.aura;

/** The aura settings as the renderer sees them. One mutable instance is reused, so nothing is allocated per frame. */
public final class AuraLook {
    public boolean enabled = true;
    /** 1..26, see AuraDesigns. */
    public int design = 1;
    public int scalePct = 100;
    public int speedPct = 100;
    public int intensityPct = 100;
    /** 0 = auto (adjusts itself to keep FPS), 1 = low, 2 = medium, 3 = high, 4 = ultra. */
    public int quality = 0;
    /** Blocks. Players farther than this get no aura. */
    public int rangeBlocks = 48;
    public boolean useTheme = true;
    /** ARGB colour used when useTheme is false. */
    public int customArgb = 0xFF2D7DFF;
    public boolean logo = true;
}
