package takeyourminestream.ijustseen.aura;

/**
 * Keeps the aura cheap. In auto mode it lowers the quality when the aura takes too long or FPS drops,
 * and raises it again after a calm period. Pure logic, so it is tested without the game.
 */
public final class AuraGovernor {
    /** Share of the full design's sprites used at each quality level (low .. ultra). */
    public static final double[] FACTOR = {0.3, 0.55, 0.8, 1.0};
    /** Hard cap on quads per frame at each quality level. */
    public static final int[] QUAD_CAP = {700, 1600, 3200, 6000};
    public static final String[] NAMES = {"Low", "Medium", "High", "Ultra"};

    private static final double AURA_HEAVY_MS = 1.5;
    private static final double AURA_CALM_MS = 0.5;
    private static final double FRAME_HEAVY_MS = 22.0;
    private static final double FRAME_CALM_MS = 14.0;
    private static final long DROP_HOLD_MS = 1500;
    private static final long RAISE_CALM_MS = 5000;

    private boolean auto = true;
    private int level = 2;
    private double emaAuraMs = 0;
    private double emaFrameMs = 0;
    private long lastChangeMs = 0;
    private long calmSinceMs = -1;

    /** @param manualLevel 0..3, used when auto is false; in auto mode it is only the starting point. */
    public void configure(boolean autoMode, int manualLevel) {
        this.auto = autoMode;
        this.level = Math.max(0, Math.min(3, manualLevel));
        if (!autoMode) calmSinceMs = -1;
    }

    /**
     * Feed one frame's measurements.
     * @param nowMs     current time in milliseconds
     * @param auraMs    how long the aura took this frame
     * @param frameMs   time between this frame and the previous one
     * @return the quality level to use for the next frame (0..3)
     */
    public int update(long nowMs, double auraMs, double frameMs) {
        emaAuraMs = emaAuraMs == 0 ? auraMs : emaAuraMs * 0.9 + auraMs * 0.1;
        emaFrameMs = emaFrameMs == 0 ? frameMs : emaFrameMs * 0.9 + frameMs * 0.1;
        if (!auto) return level;

        boolean heavy = emaAuraMs > AURA_HEAVY_MS || emaFrameMs > FRAME_HEAVY_MS;
        boolean calm = emaAuraMs < AURA_CALM_MS && emaFrameMs < FRAME_CALM_MS;
        if (heavy) {
            calmSinceMs = -1;
            if (level > 0 && nowMs - lastChangeMs >= DROP_HOLD_MS) {
                level--;
                lastChangeMs = nowMs;
            }
        } else if (calm) {
            if (calmSinceMs < 0) calmSinceMs = nowMs;
            if (level < 3 && nowMs - calmSinceMs >= RAISE_CALM_MS && nowMs - lastChangeMs >= RAISE_CALM_MS) {
                level++;
                lastChangeMs = nowMs;
                calmSinceMs = nowMs;
            }
        } else {
            calmSinceMs = -1;
        }
        return level;
    }

    public int level() { return level; }

    public double emaAuraMs() { return emaAuraMs; }

    public double emaFrameMs() { return emaFrameMs; }
}
