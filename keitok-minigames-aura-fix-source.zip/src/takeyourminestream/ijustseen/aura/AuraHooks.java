package takeyourminestream.ijustseen.aura;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_310;
import takeyourminestream.ijustseen.minigames.MgConfig;
import takeyourminestream.ijustseen.utils.Logger;

/**
 * Client entry point for the 26 Aura.
 *
 * Fabric's Event API is accessed reflectively so this class does not link against
 * a particular binary shape of net.fabricmc.fabric.api.event.Event at class-load
 * time. This avoids IncompatibleClassChangeError when the runtime Fabric API's
 * Event type differs from the one used to compile this class.
 */
public final class AuraHooks implements net.fabricmc.api.ClientModInitializer {
    private static boolean started;

    private interface ListenerCall {
        void invoke(Object[] args) throws Throwable;
    }

    @Override
    public void onInitializeClient() {
        init();
    }

    public static synchronized void init() {
        if (started) return;
        // Set only after successful event registration; allow a later retry if the API is unavailable.
        try {
            registerEvent(
                "net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents",
                "AFTER_ENTITIES",
                args -> AuraMc.onFrame((WorldRenderContext) args[0])
            );
            registerEvent(
                "net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents",
                "END_CLIENT_TICK",
                args -> {
                    class_310 client = (class_310) args[0];
                    try {
                        AuraMc.onTick(client);
                    } catch (Throwable ignored) {
                        // AuraMc reports its own errors.
                    }
                    try {
                        PresenceNet.onTick();
                    } catch (Throwable ignored) {
                        // Other-player presence is optional.
                    }
                }
            );
            registerEvent(
                "net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents",
                "JOIN",
                args -> PresenceNet.onJoin()
            );
            registerEvent(
                "net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents",
                "DISCONNECT",
                args -> PresenceNet.onDisconnect()
            );
            started = true;
            Logger.info("[KeiTok] 26 Aura ready");
        } catch (Throwable t) {
            Logger.warning("[KeiTok] 26 Aura could not start: " + rootCause(t));
        }

        try {
            if (MgConfig.get().auraNetwork) PresenceNet.register();
        } catch (Throwable t) {
            Logger.warning("[KeiTok] other-player presence could not start: " + rootCause(t));
        }
    }

    /**
     * Reads the static event field and invokes its register(listener) method
     * without statically linking to Fabric's Event class or its interface/class shape.
     */
    private static void registerEvent(String ownerName, String fieldName, ListenerCall callback) throws Exception {
        ClassLoader loader = AuraHooks.class.getClassLoader();
        Class<?> owner = Class.forName(ownerName, true, loader);
        Field field = owner.getField(fieldName);
        Object event = field.get(null);
        if (event == null) throw new IllegalStateException(ownerName + "." + fieldName + " is null");

        Method register = null;
        for (Method method : event.getClass().getMethods()) {
            if (!"register".equals(method.getName()) || method.getParameterTypes().length != 1) continue;
            Class<?> candidate = method.getParameterTypes()[0];
            if (candidate.isInterface()) {
                register = method;
                break;
            }
        }
        if (register == null) {
            // Some Fabric versions expose register on a public interface/superclass.
            for (Class<?> type = event.getClass(); type != null && register == null; type = type.getSuperclass()) {
                for (Class<?> iface : type.getInterfaces()) {
                    for (Method method : iface.getMethods()) {
                        if ("register".equals(method.getName()) && method.getParameterTypes().length == 1
                            && method.getParameterTypes()[0].isInterface()) {
                            register = method;
                            break;
                        }
                    }
                    if (register != null) break;
                }
            }
        }
        if (register == null) throw new NoSuchMethodException("register(listener) on " + event.getClass().getName());

        Class<?> listenerType = register.getParameterTypes()[0];
        Object listener = Proxy.newProxyInstance(loader, new Class<?>[] { listenerType }, new InvocationHandler() {
            @Override
            public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
                if (method.getDeclaringClass() == Object.class) {
                    if ("toString".equals(method.getName())) return "KeiTok Aura listener";
                    if ("hashCode".equals(method.getName())) return System.identityHashCode(proxy);
                    if ("equals".equals(method.getName())) return proxy == (args == null ? null : args[0]);
                }
                callback.invoke(args == null ? new Object[0] : args);
                return null;
            }
        });
        register.invoke(event, listener);
    }

    private static Throwable rootCause(Throwable t) {
        Throwable current = t;
        while (current.getCause() != null && current.getCause() != current) current = current.getCause();
        return current;
    }
}
