package takeyourminestream.ijustseen.aura;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Server side of the KeiTok presence: the players who sent a valid hello, and the roster each of them is sent.
 *
 * A player is only listed after their hello. The hello carries no identity: the id and the name come from the
 * server's own connection, so a client cannot list someone else. Pure Java with no Minecraft types, so it is
 * tested without the game. PresenceServerImpl connects it to the real connections.
 *
 * @param <L> whatever the server uses to reach a player (the player object on a real server)
 */
public final class PresenceHub<L> {

    /** What the hub needs from the server: who can receive a roster, and how to send one. */
    public interface Port<L> {
        boolean canSend(L link);

        void send(L link, byte[] roster);
    }

    private static final class Member<L> {
        final UUID id;
        final String name;
        final String version;
        final L link;

        Member(UUID id, String name, String version, L link) {
            this.id = id;
            this.name = name;
            this.version = version;
            this.link = link;
        }
    }

    private final Port<L> port;
    private final int maxMembers;
    private final Map<UUID, Member<L>> members = new LinkedHashMap<>();

    public PresenceHub(Port<L> port, int maxMembers) {
        this.port = port;
        this.maxMembers = Math.max(1, Math.min(maxMembers, Presence.MAX));
    }

    /**
     * A player sent a valid hello. Returns true if the list changed and was sent out again.
     * A repeated hello from the same connection with the same name and version changes nothing and sends nothing.
     */
    public synchronized boolean onHello(L link, UUID id, String name, String version) {
        if (link == null || id == null) return false;
        String n = PresenceCodec.clip(name);
        String v = PresenceCodec.clip(version);
        Member<L> old = members.get(id);
        if (old != null) {
            if (old.link == link && old.name.equals(n) && old.version.equals(v)) return false;
        } else if (members.size() >= maxMembers) {
            return false;
        }
        members.put(id, new Member<>(id, n, v, link));
        broadcast();
        return true;
    }

    /**
     * A player left. Only their own connection can remove them, so a late event from an older session is ignored.
     * Returns true if they were listed and the list was sent out again.
     */
    public synchronized boolean onLeave(L link, UUID id) {
        Member<L> m = id == null ? null : members.get(id);
        if (m == null || m.link != link) return false;
        members.remove(id);
        broadcast();
        return true;
    }

    public synchronized void clear() {
        members.clear();
    }

    public synchronized int size() {
        return members.size();
    }

    /** Sends each listed player who can receive it the whole list, with only that player's own entry marked self. */
    private void broadcast() {
        List<Presence.Entry> all = new ArrayList<>(members.size());
        for (Member<L> m : members.values()) {
            all.add(new Presence.Entry(m.id, m.name, m.version, false));
        }
        for (Member<L> to : members.values()) {
            if (!port.canSend(to.link)) continue;
            List<Presence.Entry> mine = new ArrayList<>(all.size());
            for (Presence.Entry e : all) {
                mine.add(new Presence.Entry(e.id, e.name, e.version, e.id.equals(to.id)));
            }
            byte[] data;
            try {
                data = PresenceCodec.encodePresence(mine);
            } catch (IOException e) {
                continue;
            }
            try {
                port.send(to.link, data);
            } catch (RuntimeException e) {
                // one broken connection must not stop the others from getting the list
            }
        }
    }
}
