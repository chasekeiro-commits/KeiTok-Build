package takeyourminestream.ijustseen.aura;

/** Fast maths for the aura: a sine table, a cheap hash, and clamping. Pure Java. */
public final class AuraMath {
    private AuraMath() {}

    private static final int TABLE = 4096;
    private static final float[] SIN = new float[TABLE];
    private static final double TWO_PI = Math.PI * 2;

    static {
        for (int i = 0; i < TABLE; i++) {
            SIN[i] = (float) Math.sin(i * TWO_PI / TABLE);
        }
    }

    /** Table lookup sine. Accurate to about 0.0015, which is plenty for particles. */
    public static double sin(double radians) {
        int i = (int) (radians * (TABLE / TWO_PI)) & (TABLE - 1);
        return SIN[i];
    }

    public static double cos(double radians) {
        return sin(radians + Math.PI / 2);
    }

    /** Deterministic pseudo-random value in [0, 1) from an integer seed. No allocation. */
    public static double hash01(int seed) {
        int h = seed;
        h ^= h >>> 16;
        h *= 0x7feb352d;
        h ^= h >>> 15;
        h *= 0x846ca68b;
        h ^= h >>> 16;
        return (h & 0x7fffffff) / (double) 0x80000000L;
    }

    public static double fract(double x) {
        return x - Math.floor(x);
    }

    public static double clamp(double v, double lo, double hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
