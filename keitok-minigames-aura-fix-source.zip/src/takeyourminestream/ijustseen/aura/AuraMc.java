package takeyourminestream.ijustseen.aura;

import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.UUID;
import javax.imageio.ImageIO;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_4050;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_746;
import org.joml.Matrix4f;
import takeyourminestream.ijustseen.core.render.PanelTextureUpload;
import takeyourminestream.ijustseen.minigames.MgConfig;
import takeyourminestream.ijustseen.ui.gui.ModUiTheme;
import takeyourminestream.ijustseen.utils.CameraPositionCompat;
import takeyourminestream.ijustseen.utils.Logger;
import takeyourminestream.ijustseen.utils.RenderLayerCompat;

/**
 * Connects the pure aura code to the game. Reads the players once per tick, draws the quads once per frame.
 *
 * Minecraft names (intermediary) used here, and their status:
 *   checked against the original jar's bytecode: class_310 fields field_1724/field_1687/field_1772 and method_1551,
 *     class_746.method_33571, method_18376, method_18381, method_36454, class_638.method_20812, class_327.method_1727,
 *     CameraPositionCompat, RenderLayerCompat, PanelTextureUpload.
 *   NOT checked: class_1297.method_5667 (Entity.getUuid). Only reached when "Other players" is on.
 */
public final class AuraMc {
    private AuraMc() {}

    private static final String NS = "keitok";
    private static final String LOGO_RESOURCE = "/assets/take-your-stream-chat/icon.png";
    private static final int MAX_ERRORS = 50;
    private static final int OTHER_RANGE_MAX = 96;

    private static final Presence PRESENCE = new Presence();
    private static final AuraLook LOOK = new AuraLook();
    private static final AuraTargets TARGETS = new AuraTargets();
    private static final AuraRenderer RENDERER = new AuraRenderer();
    private static final AuraGovernor GOVERNOR = new AuraGovernor();
    private static final McSink SINK = new McSink();
    private static final class_2960[] TEX = new class_2960[3];

    private static volatile long lastTickNs;
    private static long lastFrameNs;
    private static boolean texturesReady;
    private static boolean logoReady;
    private static boolean governorReady;
    private static boolean governorAuto;
    private static int governorManual;
    private static int errors;
    private static volatile boolean disabled;

    /** The KeiTok players the server told us about (empty unless "Other players" is on and a server answered). */
    public static Presence presence() {
        return PRESENCE;
    }

    /** The quality level the governor is using right now, 0..3 (Low..Ultra). */
    public static int governorLevel() {
        return GOVERNOR.level();
    }

    public static String qualityNow() {
        return AuraGovernor.NAMES[GOVERNOR.level()];
    }

    /** Once per client tick: remember where every aura player is. */
    public static void onTick(class_310 mc) {
        if (disabled) return;
        try {
            lastTickNs = System.nanoTime();
            refreshLook();
            TARGETS.beginTick();
            class_746 me = mc.field_1724;
            if (me == null || mc.field_1687 == null) return;
            if (!LOOK.enabled && !LOOK.logo) return;
            Presence.Entry self = PRESENCE.self();
            addTarget(mc, me, true, true, self == null ? null : self.id, self == null ? null : self.name);
            if (PRESENCE.size() > 0) addOtherPlayers(mc, me);
        } catch (Throwable t) {
            fail("tick", t);
        }
    }

    /** Once per frame, after the world's entities are drawn. */
    public static void onFrame(WorldRenderContext ctx) {
        if (disabled) return;
        try {
            long now = System.nanoTime();
            double frameMs = lastFrameNs == 0 ? 16.0 : (now - lastFrameNs) / 1e6;
            lastFrameNs = now;
            if (!LOOK.enabled && !LOOK.logo) return;
            class_310 mc = class_310.method_1551();
            if (mc == null || mc.field_1687 == null) return;
            ensureTextures();
            if (!texturesReady) return;

            class_243 cam = CameraPositionCompat.getCameraPos(mc);
            Matrix4f mat = ctx.matrices().method_23760().method_23761();
            double alpha = AuraMath.clamp((now - lastTickNs) / 50e6, 0, 1);
            TARGETS.sortByDistance(cam.field_1352, cam.field_1351, cam.field_1350);
            applyPalette();
            configureGovernor();
            int quality = GOVERNOR.level();

            SINK.bind(mat, ctx.consumers());
            long t0 = System.nanoTime();
            try {
                if (LOOK.enabled) {
                    RENDERER.render(TARGETS, LOOK, quality, now / 1e9,
                        cam.field_1352, cam.field_1351, cam.field_1350, alpha, SINK, Integer.MAX_VALUE);
                }
                if (LOOK.logo && logoReady) {
                    RENDERER.renderLogos(TARGETS, LOOK, cam.field_1352, cam.field_1351, cam.field_1350, alpha, SINK);
                }
            } finally {
                SINK.unbind();
            }
            long auraNs = System.nanoTime() - t0;
            GOVERNOR.update(System.currentTimeMillis(), auraNs / 1e6, frameMs);
        } catch (Throwable t) {
            fail("frame", t);
        }
    }

    // ------------------------------------------------------------------ players

    private static void addOtherPlayers(class_310 mc, class_746 me) {
        class_243 p = me.method_33571();
        double r = Math.min(LOOK.rangeBlocks, OTHER_RANGE_MAX);
        class_238 box = new class_238(p.field_1352 - r, p.field_1351 - r, p.field_1350 - r,
            p.field_1352 + r, p.field_1351 + r, p.field_1350 + r);
        Iterable<?> nearby = mc.field_1687.method_20812(me, box);
        if (nearby == null) return;
        for (Object o : nearby) {
            if (!(o instanceof class_1297)) continue;
            class_1297 e = (class_1297) o;
            UUID id = e.method_5667();
            if (id == null || !PRESENCE.isKeiTok(id)) continue;
            Presence.Entry entry = PRESENCE.get(id);
            addTarget(mc, e, false, true, id, entry == null ? null : entry.name);
            if (TARGETS.count >= AuraTargets.MAX) break;
        }
    }

    private static void addTarget(class_310 mc, class_1297 e, boolean self, boolean keitok, UUID id, String name) {
        class_243 eye = e.method_33571();
        class_4050 pose = e.method_18376();
        float eyeH = e.method_18381(pose);
        // the eyes sit near the top of the body, so the feet are one eye height below them
        double feetY = eye.field_1351 - eyeH;
        double body = eyeH > 0.5f ? eyeH / 0.9 : 1.8;
        int width = name == null || name.isEmpty() || mc.field_1772 == null ? 0 : mc.field_1772.method_1727(name);
        long hi = id == null ? 0L : id.getMostSignificantBits();
        long lo = id == null ? 0L : id.getLeastSignificantBits();
        TARGETS.add(hi, lo, self, keitok, name, eye.field_1352, feetY, eye.field_1350, e.method_36454(), body, width);
    }

    // ------------------------------------------------------------------ settings, governor, palette

    private static void refreshLook() {
        MgConfig c = MgConfig.get();
        LOOK.enabled = c.auraEnabled;
        LOOK.design = c.auraDesign;
        LOOK.scalePct = c.auraScalePct;
        LOOK.speedPct = c.auraSpeedPct;
        LOOK.intensityPct = c.auraIntensityPct;
        LOOK.quality = c.auraQuality;
        LOOK.rangeBlocks = c.auraRange;
        LOOK.useTheme = c.auraUseTheme;
        LOOK.customArgb = c.auraColor;
        LOOK.logo = c.auraLogo;
        // switching the setting off forgets the other players at once
        if (!c.auraNetwork && PRESENCE.size() > 0) PRESENCE.clear();
    }

    /** Only calls configure when the quality setting changes, so the governor keeps its own adjusted level. */
    private static void configureGovernor() {
        boolean auto = LOOK.quality == 0;
        int manual = Math.max(0, LOOK.quality - 1);
        if (!governorReady || auto != governorAuto || (!auto && manual != governorManual)) {
            GOVERNOR.configure(auto, auto ? 2 : manual);
            governorReady = true;
            governorAuto = auto;
            governorManual = manual;
        }
    }

    private static void applyPalette() {
        int accent;
        int light;
        int dark;
        if (LOOK.useTheme) {
            accent = ModUiTheme.ACCENT;
            light = ModUiTheme.TEXT_PRIMARY;
            dark = ModUiTheme.ACCENT_DARK;
        } else {
            accent = LOOK.customArgb | 0xFF000000;
            light = mix(accent, 0xFFFFFFFF, 0.6f);
            dark = mix(accent, 0xFF000000, 0.45f);
        }
        RENDERER.setPalette(accent, light, dark);
    }

    static int mix(int a, int b, float t) {
        int r = (int) (((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
        int g = (int) (((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
        int bl = (int) ((a & 255) * (1 - t) + (b & 255) * t);
        return 0xFF000000 | (r << 16) | (g << 8) | bl;
    }

    // ------------------------------------------------------------------ textures (uploaded once)

    private static void ensureTextures() {
        if (texturesReady) return;
        texturesReady = true;
        try {
            TEX[AuraRenderer.TEX_GLOW] = class_2960.method_60655(NS, "aura_glow");
            TEX[AuraRenderer.TEX_FEATHER] = class_2960.method_60655(NS, "aura_feather");
            TEX[AuraRenderer.TEX_LOGO] = class_2960.method_60655(NS, "aura_logo");
            PanelTextureUpload.upload(TEX[AuraRenderer.TEX_GLOW], glowPixels(64), 64);
            PanelTextureUpload.upload(TEX[AuraRenderer.TEX_FEATHER], featherPixels(32), 32);
            int[] logo = logoPixels(32);
            if (logo != null) {
                PanelTextureUpload.upload(TEX[AuraRenderer.TEX_LOGO], logo, 32);
                logoReady = true;
            } else {
                Logger.warning("[KeiTok] KeiTok logo not found; name logos are off");
            }
        } catch (Throwable t) {
            texturesReady = false;
            fail("textures", t);
        }
    }

    /** Soft round glow, ARGB. */
    static int[] glowPixels(int size) {
        int[] px = new int[size * size];
        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                double dx = (x + 0.5) / size * 2 - 1, dy = (y + 0.5) / size * 2 - 1;
                double a = AuraMath.clamp(1 - Math.sqrt(dx * dx + dy * dy), 0, 1);
                a = Math.pow(a, 1.8);
                px[y * size + x] = ((int) (a * 255) << 24) | 0xFFFFFF;
            }
        }
        return px;
    }

    /** A narrow feather shape that tapers toward its tip (top), ARGB. */
    static int[] featherPixels(int size) {
        int[] px = new int[size * size];
        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                double dx = (x + 0.5) / size * 2 - 1, dy = (y + 0.5) / size * 2 - 1;
                double half = 0.42 * (0.55 + 0.45 * (dy + 1) / 2);
                double a = AuraMath.clamp(1 - (dx * dx) / (half * half) - (dy * dy) / 0.95, 0, 1);
                a = Math.pow(a, 0.8);
                px[y * size + x] = ((int) (a * 255) << 24) | 0xFFFFFF;
            }
        }
        return px;
    }

    /** The KeiTok icon from the mod's own resources, averaged down to size x size (alpha-weighted). */
    static int[] logoPixels(int size) {
        try (InputStream in = AuraMc.class.getResourceAsStream(LOGO_RESOURCE)) {
            if (in == null) return null;
            BufferedImage img = ImageIO.read(in);
            if (img == null) return null;
            int w = img.getWidth();
            int h = img.getHeight();
            int[] px = new int[size * size];
            for (int y = 0; y < size; y++) {
                int y0 = y * h / size;
                int y1 = Math.max(y0 + 1, (y + 1) * h / size);
                for (int x = 0; x < size; x++) {
                    int x0 = x * w / size;
                    int x1 = Math.max(x0 + 1, (x + 1) * w / size);
                    long sr = 0, sg = 0, sb = 0, sa = 0;
                    long n = 0;
                    for (int sy = y0; sy < y1; sy++) {
                        for (int sx = x0; sx < x1; sx++) {
                            int argb = img.getRGB(sx, sy);
                            long a = argb >>> 24;
                            sa += a;
                            sr += ((argb >> 16) & 255) * a;
                            sg += ((argb >> 8) & 255) * a;
                            sb += (argb & 255) * a;
                            n++;
                        }
                    }
                    int alpha = n == 0 ? 0 : (int) (sa / n);
                    int r = sa == 0 ? 0 : (int) (sr / sa);
                    int g = sa == 0 ? 0 : (int) (sg / sa);
                    int b = sa == 0 ? 0 : (int) (sb / sa);
                    px[y * size + x] = (alpha << 24) | (r << 16) | (g << 8) | b;
                }
            }
            return px;
        } catch (Exception e) {
            return null;
        }
    }

    // ------------------------------------------------------------------ quads into the game's buffers

    /**
     * Turns the renderer's quads into vertices. The renderer sends corners counter-clockwise as seen from the
     * camera (bottom-left, bottom-right, top-right, top-left), so back-face culling never hides a sprite.
     */
    private static final class McSink implements AuraRenderer.QuadSink {
        private Matrix4f mat;
        private class_4597 consumers;
        private class_4588 vc;
        private int vcTex = -1;

        void bind(Matrix4f m, class_4597 c) {
            mat = m;
            consumers = c;
            vc = null;
            vcTex = -1;
        }

        void unbind() {
            mat = null;
            consumers = null;
            vc = null;
            vcTex = -1;
        }

        @Override
        public void quad(int tex,
                         double ax, double ay, double az,
                         double bx, double by, double bz,
                         double cx, double cy, double cz,
                         double dx, double dy, double dz,
                         float r, float g, float b, float a) {
            if (mat == null || consumers == null || tex < 0 || tex >= TEX.length) return;
            if (vc == null || tex != vcTex) {
                class_2960 id = TEX[tex];
                vc = id == null ? null : RenderLayerCompat.getEntityBuffer(consumers, id);
                vcTex = tex;
            }
            if (vc == null) return;
            int ov = class_4608.field_21444;
            vertex(vc, ax, ay, az, r, g, b, a, 0f, 1f, ov);
            vertex(vc, bx, by, bz, r, g, b, a, 1f, 1f, ov);
            vertex(vc, cx, cy, cz, r, g, b, a, 1f, 0f, ov);
            vertex(vc, dx, dy, dz, r, g, b, a, 0f, 0f, ov);
        }

        private void vertex(class_4588 v, double x, double y, double z, float r, float g, float b, float a,
                            float u, float w, int ov) {
            v.method_22918(mat, (float) x, (float) y, (float) z)
                .method_22915(r, g, b, a)
                .method_22913(u, w)
                .method_22922(ov)
                .method_60803(15728880)
                .method_22914(0f, 0f, -1f);
        }
    }

    // ------------------------------------------------------------------ errors

    private static void fail(String where, Throwable t) {
        errors++;
        if (errors <= 3) Logger.warning("[KeiTok aura] " + where + " failed: " + t);
        if (errors >= MAX_ERRORS && !disabled) {
            disabled = true;
            Logger.warning("[KeiTok aura] turned off after " + MAX_ERRORS + " errors; the rest of KeiTok keeps working");
        }
    }
}
