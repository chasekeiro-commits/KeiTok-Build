package takeyourminestream.ijustseen.aura;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Binary format for the KeiTok presence messages. Pure Java, so it is tested without the game.
 *
 * Hello (client -> server):  byte protocol (1), UTF version
 * Presence (server -> client): byte protocol (1), int count, then per entry:
 *     long id.msb, long id.lsb, UTF name, UTF version, boolean self
 */
public final class PresenceCodec {
    private PresenceCodec() {}

    public static final int PROTOCOL = 1;
    public static final int MAX_STRING = 64;

    public static byte[] encodeHello(String version) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(bytes)) {
            out.writeByte(PROTOCOL);
            out.writeUTF(clip(version));
        }
        return bytes.toByteArray();
    }

    public static byte[] encodePresence(List<Presence.Entry> entries) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(bytes)) {
            out.writeByte(PROTOCOL);
            int n = Math.min(entries.size(), Presence.MAX);
            out.writeInt(n);
            for (int i = 0; i < n; i++) {
                Presence.Entry e = entries.get(i);
                out.writeLong(e.id.getMostSignificantBits());
                out.writeLong(e.id.getLeastSignificantBits());
                out.writeUTF(clip(e.name));
                out.writeUTF(clip(e.version));
                out.writeBoolean(e.self);
            }
        }
        return bytes.toByteArray();
    }

    /** Decodes a presence message. Throws IOException for anything malformed, so bad input is ignored. */
    public static List<Presence.Entry> decodePresence(byte[] data) throws IOException {
        try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(data))) {
            int protocol = in.readUnsignedByte();
            if (protocol != PROTOCOL) throw new IOException("unknown protocol " + protocol);
            int n = in.readInt();
            if (n < 0 || n > Presence.MAX) throw new IOException("bad count " + n);
            List<Presence.Entry> out = new ArrayList<>(n);
            for (int i = 0; i < n; i++) {
                UUID id = new UUID(in.readLong(), in.readLong());
                String name = readBounded(in);
                String version = readBounded(in);
                boolean self = in.readBoolean();
                out.add(new Presence.Entry(id, name, version, self));
            }
            return out;
        }
    }

    /** Decodes a hello: the protocol byte and the version, and nothing after them. Throws IOException if malformed. */
    public static String decodeHello(byte[] data) throws IOException {
        try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(data))) {
            int protocol = in.readUnsignedByte();
            if (protocol != PROTOCOL) throw new IOException("unknown protocol " + protocol);
            String version = readBounded(in);
            if (in.available() != 0) throw new IOException("trailing bytes");
            return version;
        }
    }

    private static String readBounded(DataInputStream in) throws IOException {
        String s = in.readUTF();
        if (s.length() > MAX_STRING) throw new IOException("string too long");
        return s;
    }

    static String clip(String s) {
        if (s == null) return "";
        return s.length() > MAX_STRING ? s.substring(0, MAX_STRING) : s;
    }
}
