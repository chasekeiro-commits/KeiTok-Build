package takeyourminestream.ijustseen.aura;

import takeyourminestream.ijustseen.minigames.MgConfig;
import takeyourminestream.ijustseen.utils.Logger;

/**
 * Other KeiTok players, from the server, over Fabric networking (PresenceWire builds the channels).
 *
 * On join we say hello on "keitok:hello", if the server accepts that channel. A server running this same KeiTok jar
 * (PresenceServer) answers on "keitok:roster" with every KeiTok player on it. A vanilla server never answers, so
 * nobody else is shown there. Your own name always gets the logo (AuraMc), with or without a server.
 * "Other players" in the Aura screen turns the hello off.
 */
public final class PresenceNet {
    private PresenceNet() {}

    public static final String VERSION = "8.0.0";

    /** About ten seconds of ticks to keep retrying the hello after joining, since the server may accept the channel late. */
    private static final int HELLO_TICKS = 200;

    private static boolean registered;
    private static boolean helloSent;
    private static int helloTicksLeft;
    private static Object helloId;

    /** Registers the channels on this client. Safe to call more than once. */
    public static synchronized void register() {
        if (registered) return;
        try {
            PresenceWire.registerTypes();
            helloId = PresenceWire.helloId();
            PresenceWire.clientOnReceive(PresenceWire.rosterId(), PresenceNet::onRoster);
            registered = true;
            Logger.info("[KeiTok] other-player presence is on");
        } catch (Throwable t) {
            Logger.warning("[KeiTok] other-player presence is unavailable: " + t);
        }
    }

    static void onRoster(byte[] data) {
        try {
            AuraMc.presence().replace(PresenceCodec.decodePresence(data));
        } catch (Throwable t) {
            Logger.warning("[KeiTok] ignored a malformed presence list from the server");
        }
    }

    /** We joined a server: forget the old list and start saying hello. */
    public static synchronized void onJoin() {
        try {
            AuraMc.presence().clear();
        } catch (Throwable ignored) {
            // nothing to forget
        }
        helloSent = false;
        helloTicksLeft = HELLO_TICKS;
        trySayHello();
    }

    /** Every client tick: keeps retrying the hello for a while after joining. */
    public static synchronized void onTick() {
        if (helloSent || helloTicksLeft <= 0) return;
        helloTicksLeft--;
        trySayHello();
    }

    public static synchronized void onDisconnect() {
        helloSent = false;
        helloTicksLeft = 0;
        try {
            AuraMc.presence().clear();
        } catch (Throwable ignored) {
            // nothing to forget
        }
    }

    private static void trySayHello() {
        if (!registered || helloSent || !MgConfig.get().auraNetwork) return;
        boolean ready;
        try {
            ready = PresenceWire.clientCanSend(helloId);
        } catch (Throwable t) {
            ready = false; // not connected yet: try again on a later tick
        }
        if (!ready) return;
        try {
            PresenceWire.clientSend(helloId, PresenceCodec.encodeHello(VERSION));
            helloSent = true;
        } catch (Throwable t) {
            helloTicksLeft = 0;
            Logger.warning("[KeiTok] could not say hello to the server: " + t);
        }
    }
}
