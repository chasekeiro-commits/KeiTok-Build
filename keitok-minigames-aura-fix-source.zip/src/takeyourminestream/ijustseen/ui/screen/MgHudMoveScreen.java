package takeyourminestream.ijustseen.ui.screen;

import net.minecraft.class_332;
import net.minecraft.class_11909;
import net.minecraft.class_437;
import takeyourminestream.ijustseen.minigames.MgConfig;
import takeyourminestream.ijustseen.minigames.MgHud;
import takeyourminestream.ijustseen.ui.gui.ModUiTheme;

/**
 * Move and resize the two minigame HUDs. Press on a HUD and drag it anywhere; release to keep the spot.
 * Each HUD has its own size buttons.
 */
public class MgHudMoveScreen extends MgScreenBase {
    private int drag = -1;
    private int grabX;
    private int grabY;

    public MgHudMoveScreen(class_437 parent) {
        super("Move & size HUDs", parent);
    }

    private void again() {
        open(new MgHudMoveScreen(parent));
    }

    private int sizeRowY(int panel) { return this.field_22790 - (panel == 0 ? 84 : 60); }

    @Override
    protected void method_25426() {
        fields.clear();
        final MgConfig cfg = MgConfig.get();
        int w = this.field_22789;
        int h = this.field_22790;
        for (int p = 0; p < 2; p++) {
            final int panel = p;
            int y = sizeRowY(p);
            int bx = w - 150;
            addBtn("-", bx, y, 22, 18, b -> {
                if (panel == 0) cfg.hudScale = Math.max(40, cfg.hudScale - 10);
                else cfg.modeScale = Math.max(40, cfg.modeScale - 10);
                cfg.save();
            });
            addBtn("+", bx + 26, y, 22, 18, b -> {
                if (panel == 0) cfg.hudScale = Math.min(300, cfg.hudScale + 10);
                else cfg.modeScale = Math.min(300, cfg.modeScale + 10);
                cfg.save();
            });
            addBtn("100%", bx + 52, y, 56, 18, b -> {
                if (panel == 0) cfg.hudScale = 100; else cfg.modeScale = 100;
                cfg.save();
            });
        }
        addBtn("Reset spots", w / 2 - 105, h - 26, 100, 20, b -> {
            cfg.hudCustom = false;
            cfg.modeCustom = false;
            cfg.save();
            again();
        });
        addBtn("Done", w / 2 + 5, h - 26, 100, 20, b -> method_25419());
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubled) {
        if (super.method_25402(event, doubled)) return true;
        if (event.method_74245() != 0) return false;
        double mx = event.comp_4798();
        double my = event.comp_4799();
        for (int p = 0; p < 2; p++) {
            int[] s = MgHud.spot(p);
            int pw = MgHud.lastWidth(p);
            int ph = MgHud.lastHeight(p);
            if (mx >= s[0] && mx < s[0] + pw && my >= s[1] && my < s[1] + ph) {
                drag = p;
                grabX = (int) mx - s[0];
                grabY = (int) my - s[1];
                return true;
            }
        }
        return false;
    }

    public boolean method_25403(class_11909 event, double dx, double dy) {
        if (drag < 0) return false;
        MgConfig cfg = MgConfig.get();
        int pw = MgHud.lastWidth(drag);
        int ph = MgHud.lastHeight(drag);
        int nx = clamp((int) event.comp_4798() - grabX, 0, Math.max(0, this.field_22789 - pw));
        int ny = clamp((int) event.comp_4799() - grabY, 0, Math.max(0, this.field_22790 - ph));
        if (drag == 0) {
            cfg.hudX = nx;
            cfg.hudY = ny;
            cfg.hudCustom = true;
        } else {
            cfg.modeX = nx;
            cfg.modeY = ny;
            cfg.modeCustom = true;
        }
        return true;
    }

    public boolean method_25406(class_11909 event) {
        if (drag < 0) return false;
        drag = -1;
        MgConfig.get().save();
        return true;
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float delta) {
        renderThemed(g, mx, my, delta, () -> {
            MgConfig cfg = MgConfig.get();
            for (int p = 0; p < 2; p++) {
                int[] s = MgHud.spot(p);
                MgHud.renderPreview(g, s[0], s[1], p);
            }
            int w = this.field_22789;
            txt(g, fit("Press on a HUD and drag it anywhere. Release to keep the spot.", w - 24), 12, 24, ModUiTheme.TEXT_MUTED);
            txt(g, "Gifts HUD size: " + cfg.hudScale + "%", 12, sizeRowY(0) + 5, ModUiTheme.TEXT_SECONDARY);
            txt(g, "Chunk / mob HUD size: " + cfg.modeScale + "%", 12, sizeRowY(1) + 5, ModUiTheme.TEXT_SECONDARY);
        });
    }
}
