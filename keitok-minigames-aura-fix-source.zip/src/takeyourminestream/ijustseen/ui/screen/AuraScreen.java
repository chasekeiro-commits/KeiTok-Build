package takeyourminestream.ijustseen.ui.screen;

import net.minecraft.class_332;
import net.minecraft.class_437;
import takeyourminestream.ijustseen.aura.AuraDesigns;
import takeyourminestream.ijustseen.aura.AuraMc;
import takeyourminestream.ijustseen.aura.PresenceNet;
import takeyourminestream.ijustseen.minigames.MgConfig;
import takeyourminestream.ijustseen.ui.gui.ModUiTheme;

/** The 26 Aura settings, opened from the Aura button next to Themes. Every change is saved at once. */
public class AuraScreen extends MgScreenBase {
    static final int[] PRESETS = {0xFF2D7DFF, 0xFFB56CFF, 0xFF3DDC84, 0xFFFF9F1A, 0xFFFF4D4D, 0xFFFFFFFF, 0xFF00E5FF, 0xFFFF59C8};
    static final String[] PRESET_NAMES = {"Blue", "Purple", "Green", "Orange", "Red", "White", "Cyan", "Pink"};
    static final String[] QUALITY = {"Auto", "Low", "Medium", "High", "Ultra"};

    public AuraScreen(class_437 parent) {
        super("26 Aura", parent);
    }

    private static int rowY(int row) {
        return 36 + row * 24;
    }

    private int leftX() {
        return this.field_22789 / 2 - 210;
    }

    private int rightX() {
        return this.field_22789 / 2 + 10;
    }

    static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    static int stepDesign(int design, int step) {
        int n = AuraDesigns.COUNT;
        return ((design - 1 + step) % n + n) % n + 1;
    }

    static int presetIndex(int argb) {
        for (int i = 0; i < PRESETS.length; i++) {
            if (PRESETS[i] == argb) return i;
        }
        return 0;
    }

    private void change(Runnable action) {
        action.run();
        try {
            MgConfig c = MgConfig.get();
            c.save();
            if (c.auraNetwork) PresenceNet.register();
        } catch (Throwable ignored) {
            // the change still applies for this session
        }
        open(new AuraScreen(parent));
    }

    @Override
    protected void method_25426() {
        fields.clear();
        final MgConfig c = MgConfig.get();
        final int lx = leftX();
        final int rx = rightX();
        addBtn(c.auraEnabled ? "Aura: ON" : "Aura: OFF", lx, rowY(0), 200, 20,
            b -> change(() -> c.auraEnabled = !c.auraEnabled));
        addBtn("<", lx, rowY(1), 24, 20, b -> change(() -> c.auraDesign = stepDesign(c.auraDesign, -1)));
        addBtn(">", lx + 176, rowY(1), 24, 20, b -> change(() -> c.auraDesign = stepDesign(c.auraDesign, 1)));
        addBtn("-", lx + 96, rowY(3), 24, 20, b -> change(() -> c.auraScalePct = clamp(c.auraScalePct - 25, 25, 300)));
        addBtn("+", lx + 176, rowY(3), 24, 20, b -> change(() -> c.auraScalePct = clamp(c.auraScalePct + 25, 25, 300)));
        addBtn("-", lx + 96, rowY(4), 24, 20, b -> change(() -> c.auraSpeedPct = clamp(c.auraSpeedPct - 25, 25, 300)));
        addBtn("+", lx + 176, rowY(4), 24, 20, b -> change(() -> c.auraSpeedPct = clamp(c.auraSpeedPct + 25, 25, 300)));
        addBtn("-", lx + 96, rowY(5), 24, 20, b -> change(() -> c.auraIntensityPct = clamp(c.auraIntensityPct - 10, 10, 200)));
        addBtn("+", lx + 176, rowY(5), 24, 20, b -> change(() -> c.auraIntensityPct = clamp(c.auraIntensityPct + 10, 10, 200)));
        addBtn("-", lx + 96, rowY(6), 24, 20, b -> change(() -> c.auraRange = clamp(c.auraRange - 8, 16, 128)));
        addBtn("+", lx + 176, rowY(6), 24, 20, b -> change(() -> c.auraRange = clamp(c.auraRange + 8, 16, 128)));
        addBtn("Quality: " + QUALITY[clamp(c.auraQuality, 0, 4)], lx, rowY(7), 200, 20,
            b -> change(() -> c.auraQuality = (c.auraQuality + 1) % 5));

        addBtn(c.auraUseTheme ? "Colours: my theme" : "Colours: custom", rx, rowY(0), 200, 20,
            b -> change(() -> c.auraUseTheme = !c.auraUseTheme));
        addBtn("Colour: " + PRESET_NAMES[presetIndex(c.auraColor)], rx, rowY(1), 200, 20,
            b -> change(() -> c.auraColor = PRESETS[(presetIndex(c.auraColor) + 1) % PRESETS.length]));
        addBtn(c.auraLogo ? "Name logo: ON" : "Name logo: OFF", rx, rowY(2), 200, 20,
            b -> change(() -> c.auraLogo = !c.auraLogo));
        addBtn(c.auraNetwork ? "Other players: ON" : "Other players: OFF", rx, rowY(3), 200, 20,
            b -> change(() -> c.auraNetwork = !c.auraNetwork));
        addBtn("Done", (this.field_22789 - 100) / 2, this.field_22790 - 26, 100, 20, b -> method_25419());
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float delta) {
        renderThemed(g, mx, my, delta, () -> {
            MgConfig c = MgConfig.get();
            int lx = leftX();
            int rx = rightX();
            txt(g, c.auraDesign + " / " + AuraDesigns.COUNT, lx + 84, rowY(1) + 6, ModUiTheme.TEXT_PRIMARY);
            txt(g, fit(AuraDesigns.name(c.auraDesign), 200), lx, rowY(2) + 6, ModUiTheme.TEXT_PRIMARY);
            valueRow(g, lx, rowY(3), "Size", c.auraScalePct + "%");
            valueRow(g, lx, rowY(4), "Speed", c.auraSpeedPct + "%");
            valueRow(g, lx, rowY(5), "Intensity", c.auraIntensityPct + "%");
            valueRow(g, lx, rowY(6), "Range", c.auraRange + " blocks");
            if (c.auraQuality == 0) {
                note(g, lx, rowY(8), "Auto is using: " + AuraMc.qualityNow());
            }
            note(g, rx, rowY(4), "Other KeiTok players show up when the");
            note(g, rx, rowY(4) + 12, "server runs KeiTok too (same jar).");
            note(g, rx, rowY(4) + 24, "Nothing else is shown.");
            note(g, rx, rowY(5) + 12, "Experimental: if a server kicks you");
            note(g, rx, rowY(5) + 24, "after joining, turn this off.");
        });
    }

    private void valueRow(class_332 g, int x, int y, String label, String value) {
        txt(g, label, x, y + 6, ModUiTheme.TEXT_PRIMARY);
        txt(g, value, x + 148 - this.field_22793.method_1727(value) / 2, y + 6, ModUiTheme.TEXT_PRIMARY);
    }

    private void note(class_332 g, int x, int y, String s) {
        txt(g, fit(s, 200), x, y, ModUiTheme.TEXT_MUTED);
    }
}
