package takeyourminestream.ijustseen.ui.screen;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_11909;
import net.minecraft.class_437;
import takeyourminestream.ijustseen.ui.gui.ModUiTheme;
import takeyourminestream.ijustseen.ui.gui.ScreenUiHelper;

/** Shared helpers for the Interactive Minigames screens (same look as the other KeiTok menus). */
abstract class MgScreenBase extends DimScreen {
    protected final class_437 parent;
    protected final List<class_342> fields = new ArrayList<>();

    protected MgScreenBase(String title, class_437 parent) {
        super(class_2561.method_43470(title));
        this.parent = parent;
    }

    protected class_4185 addBtn(String label, int x, int y, int w, int h, class_4185.class_4241 action) {
        class_4185 b = class_4185.method_46430(class_2561.method_43470(label), action).method_46434(x, y, w, h).method_46431();
        this.method_37063(b);
        return b;
    }

    protected class_342 addField(int x, int y, int w, int h, String text, int maxLen, String label) {
        class_342 f = new class_342(this.field_22793, x, y, w, h, class_2561.method_43470(label));
        f.method_1880(maxLen);
        f.method_1852(text == null ? "" : text);
        this.method_37063(f);
        this.fields.add(f);
        return f;
    }

    protected void txt(class_332 g, String s, int x, int y, int color) {
        g.method_27535(this.field_22793, class_2561.method_43470(s), x, y, color);
    }

    protected String fit(String s, int maxWidth) {
        return ModUiTheme.fit(this.field_22793, s, maxWidth);
    }

    protected void renderThemed(class_332 g, int mx, int my, float delta, Runnable body) {
        Set<class_4185> hidden = ScreenUiHelper.hideButtons(this);
        super.method_25394(g, mx, my, delta);
        ScreenUiHelper.restoreButtons(hidden);
        ModUiTheme.drawTitle(g, this.field_22793, this.field_22785, this.field_22789);
        body.run();
        for (class_342 f : fields) {
            ModUiTheme.drawInputFrame(g, f.method_46426(), f.method_46427(), f.method_25368(), f.method_25364(), f.method_25370());
        }
        ScreenUiHelper.renderAllButtons(g, mx, my, this);
    }

    // ---- immediate-mode custom buttons (used for the Streamtoearn look)
    private static final class Hit {
        final int x, y, w, h;
        final Runnable action;
        Hit(int x, int y, int w, int h, Runnable action) { this.x = x; this.y = y; this.w = w; this.h = h; this.action = action; }
    }

    private final List<Hit> hits = new ArrayList<>();

    protected void clearHits() { hits.clear(); }

    /** Draws a flat colored button and registers its click area. */
    protected void cbtn(class_332 g, int mx, int my, int x, int y, int w, int h, String label, int color, Runnable action) {
        boolean hov = mx >= x && mx < x + w && my >= y && my < y + h;
        g.method_25294(x, y, x + w, y + h, hov ? lighten(color) : color);
        int tw = this.field_22793.method_1727(label);
        txt(g, label, x + (w - tw) / 2, y + (h - 8) / 2, 0xFFFFFFFF);
        if (action != null) hits.add(new Hit(x, y, w, h, action));
    }

    protected void cregion(int x, int y, int w, int h, Runnable action) {
        hits.add(new Hit(x, y, w, h, action));
    }

    protected static int lighten(int c) {
        int r = Math.min(255, ((c >> 16) & 255) + 28);
        int gg = Math.min(255, ((c >> 8) & 255) + 28);
        int b = Math.min(255, (c & 255) + 28);
        return 0xFF000000 | (r << 16) | (gg << 8) | b;
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubled) {
        if (event.method_74245() == 0) {
            double mx = event.comp_4798();
            double my = event.comp_4799();
            for (int i = hits.size() - 1; i >= 0; i--) {
                Hit h = hits.get(i);
                if (mx >= h.x && mx < h.x + h.w && my >= h.y && my < h.y + h.h) {
                    h.action.run();
                    return true;
                }
            }
        }
        return super.method_25402(event, doubled);
    }

    /** Grid cell for item i of n: {x, y, width}. Adapts the column count to the window height. */
    protected int[] cell(int i, int n, int top, int bottomReserve, int itemH, int maxColW) {
        int w = this.field_22789;
        int h = this.field_22790;
        int avail = Math.max(itemH, h - top - bottomReserve);
        int rowsFit = Math.max(1, avail / itemH);
        int cols = Math.max(2, Math.min(4, (n + rowsFit - 1) / rowsFit));
        int rows = (n + cols - 1) / cols;
        int colW = Math.min(maxColW, (w - 20 - (cols - 1) * 8) / cols);
        int total = cols * colW + (cols - 1) * 8;
        int x0 = (w - total) / 2;
        int col = i / rows;
        int row = i % rows;
        return new int[] {x0 + col * (colW + 8), top + row * itemH, colW};
    }

    protected void open(class_437 screen) {
        if (this.field_22787 != null) this.field_22787.method_1507(screen);
    }

    @Override
    public void method_25419() {
        open(parent);
    }

    protected static int parseInt(String s, int fallback) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return fallback;
        }
    }
}
