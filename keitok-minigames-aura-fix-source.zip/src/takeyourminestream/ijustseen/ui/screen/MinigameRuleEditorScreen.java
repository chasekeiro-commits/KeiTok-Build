package takeyourminestream.ijustseen.ui.screen;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import takeyourminestream.ijustseen.minigames.MgAction;
import takeyourminestream.ijustseen.minigames.MgConfig;
import takeyourminestream.ijustseen.minigames.MgEngine;
import takeyourminestream.ijustseen.minigames.MgRule;
import takeyourminestream.ijustseen.minigames.MgTrigger;
import takeyourminestream.ijustseen.ui.gui.ModUiTheme;

/**
 * Add or edit one Interactive Minigames rule in three simple steps:
 * 1) WHEN does it happen  2) WHAT should happen  3) HOW MUCH. Advanced options are on their own page.
 * A plain sentence at the bottom always says what the rule will do.
 */
public class MinigameRuleEditorScreen extends MgScreenBase {
    private static final int LAST_PAGE = 3;
    private static final String[] TITLES = {
        "Step 1 of 3 - WHEN does it happen?",
        "Step 2 of 3 - WHAT should happen?",
        "Step 3 of 3 - HOW MUCH?",
        "Advanced options (optional)"
    };
    private static final int GREEN = 0xFF55FF66;
    private static final int RED = 0xFFFF5555;

    private final MgRule target;
    private final boolean isNew;
    private final MgRule work;
    private final int page;
    private String error = "";

    public MinigameRuleEditorScreen(class_437 parent, MgRule target, boolean isNew, MgRule workingCopy) {
        this(parent, target, isNew, workingCopy, 0);
    }

    private MinigameRuleEditorScreen(class_437 parent, MgRule target, boolean isNew, MgRule workingCopy, int page) {
        super(isNew ? "New Minigame Rule" : "Edit Minigame Rule", parent);
        this.target = target;
        this.isNew = isNew;
        this.work = workingCopy != null ? workingCopy : target.copy();
        this.page = Math.max(0, Math.min(LAST_PAGE, page));
    }

    private void goTo(int p) {
        open(new MinigameRuleEditorScreen(parent, target, isNew, work, p));
    }

    @Override
    protected void method_25426() {
        fields.clear();
        final MgConfig cfg = MgConfig.get();
        int w = this.field_22789;
        int h = this.field_22790;
        int top = 44;
        if (page == 0) {
            int fw = Math.min(330, w - 30);
            int x0 = (w - fw) / 2;
            MgTrigger[] ts = MgTrigger.values();
            int cols = 3;
            int bw = (fw - 8) / cols;
            for (int i = 0; i < ts.length; i++) {
                final MgTrigger t = ts[i];
                boolean sel = t == work.trigger;
                addBtn((sel ? "> " : "") + t.label + (sel ? " <" : ""), x0 + (i % cols) * (bw + 4), top + (i / cols) * 24, bw, 20,
                    b -> setTrigger(t));
            }
            int ry = top + 3 * 24 + 40;
            if (work.trigger == MgTrigger.GIFT) {
                class_342 f = addField(x0 + 26, ry, fw - 52, 18, work.match, 80, "gift");
                f.method_1863(s -> work.match = s);
                addBtn("<", x0, ry, 22, 18, b -> { work.match = stepGift(cfg, -1); goTo(0); });
                addBtn(">", x0 + fw - 22, ry, 22, 18, b -> { work.match = stepGift(cfg, 1); goTo(0); });
                class_342 m = addField(x0, ry + 46, 80, 18, Integer.toString(work.minCount), 6, "min");
                m.method_1863(s -> work.minCount = parseInt(s, work.minCount));
            } else if (work.trigger == MgTrigger.LIKES || work.trigger == MgTrigger.CHAT) {
                class_342 f = addField(x0, ry, fw, 18, work.match, 80, "match");
                f.method_1863(s -> work.match = s);
            }
        } else if (page == 1) {
            int fw = Math.min(380, w - 30);
            int x0 = (w - fw) / 2;
            MgAction[] as = MgAction.values();
            int cols = 4;
            int bw = (fw - 3 * 4) / cols;
            for (int i = 0; i < as.length; i++) {
                final MgAction a = as[i];
                boolean sel = a == work.action;
                addBtn((sel ? "> " : "") + a.label + (sel ? " <" : ""), x0 + (i % cols) * (bw + 4), top + (i / cols) * 22, bw, 18,
                    b -> setAction(a));
            }
            int ay = top + 5 * 22 + 24;
            class_342 f = addField(x0, ay, fw, 18, work.arg, 200, "argument");
            f.method_1863(s -> work.arg = s);
        } else if (page == 2) {
            int fw = Math.min(280, w - 40);
            int x0 = (w - fw) / 2;
            class_342 a = addField(x0, top + 14, fw, 18, Integer.toString(work.amount), 6, "amount");
            a.method_1863(s -> work.amount = parseInt(s, work.amount));
            class_342 d = addField(x0, top + 58, fw, 18, Integer.toString(work.duration), 6, "duration");
            d.method_1863(s -> work.duration = parseInt(s, work.duration));
            class_342 c = addField(x0, top + 102, fw, 18, Integer.toString(work.cooldown), 6, "cooldown");
            c.method_1863(s -> work.cooldown = parseInt(s, work.cooldown));
            class_342 m = addField(x0, top + 146, fw, 18, work.message, 120, "message");
            m.method_1863(s -> work.message = s);
            addBtn(work.enabled ? "Status: enabled (click to turn off)" : "Status: disabled (click to turn on)", x0, top + 180, fw / 2 - 4, 18,
                b -> { work.enabled = !work.enabled; goTo(2); });
            addBtn("Advanced options >", x0 + fw / 2 + 4, top + 180, fw - fw / 2 - 4, 18, b -> goTo(3));
        } else {
            int fw = Math.min(280, w - 40);
            int x0 = (w - fw) / 2;
            class_342 i1 = addField(x0, top + 14, fw, 18, Integer.toString(work.interval), 6, "interval");
            i1.method_1863(s -> work.interval = parseInt(s, work.interval));
            class_342 d = addField(x0, top + 58, fw, 18, Integer.toString(work.delay), 7, "delay");
            d.method_1863(s -> work.delay = parseInt(s, work.delay));
            class_342 au = addField(x0, top + 102, fw, 18, work.audio, 80, "audio");
            au.method_1863(s -> work.audio = s);
            addBtn(work.perGiftCount ? "Multiply by gift count: YES (combo x)" : "Multiply by gift count: no", x0, top + 146, fw, 18,
                b -> { work.perGiftCount = !work.perGiftCount; goTo(3); });
        }

        // bottom row: Back / Next / Save / Test / Cancel
        List<String> labels = new ArrayList<>();
        if (page > 0) labels.add("Back");
        if (page < 2) labels.add("Next");
        labels.add(isNew ? "Add rule" : "Save");
        if (page >= 2) labels.add("Test");
        labels.add("Cancel");
        int n = labels.size();
        int bw = Math.min(96, (w - 20 - 8 * (n - 1)) / n);
        int total = n * bw + 8 * (n - 1);
        int bx = (w - total) / 2;
        int by = h - 26;
        for (int i = 0; i < n; i++) {
            final String l = labels.get(i);
            addBtn(l, bx + i * (bw + 8), by, bw, 20, b -> onNav(l));
        }
    }

    private void onNav(String label) {
        switch (label) {
            case "Back": goTo(page - 1); break;
            case "Next": goTo(page + 1); break;
            case "Test": {
                MgRule t = work.copy();
                sanitize(t);
                MgEngine.test(t);
                break;
            }
            case "Cancel": method_25419(); break;
            default: save(); break;
        }
    }

    private void setTrigger(MgTrigger t) {
        String old = work.match;
        boolean wasDefault = old == null || old.trim().isEmpty();
        for (MgTrigger x : MgTrigger.values()) {
            if (x.defaultMatch.equals(old)) wasDefault = true;
        }
        work.trigger = t;
        if (wasDefault) work.match = t.defaultMatch;
        goTo(0);
    }

    private void setAction(MgAction a) {
        boolean wasDefault = work.arg == null || work.arg.isEmpty();
        for (MgAction x : MgAction.values()) {
            if (x.defaultArg.equals(work.arg)) wasDefault = true;
        }
        work.action = a;
        if (wasDefault) work.arg = a.defaultArg;
        if (a == MgAction.TNT) work.duration = 0; // TNT explodes right away unless you set a delay
        goTo(1);
    }

    private String stepGift(MgConfig cfg, int dir) {
        List<String> all = new ArrayList<>(cfg.knownGifts);
        if (all.isEmpty()) return work.match;
        String cur = work.match == null ? "" : work.match.split("[,|]")[0].trim();
        int idx = -1;
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).equalsIgnoreCase(cur)) { idx = i; break; }
        }
        int next = idx < 0 ? (dir > 0 ? 0 : all.size() - 1) : (idx + dir + all.size()) % all.size();
        return all.get(next);
    }

    private static void sanitize(MgRule r) {
        if (r.match == null) r.match = "";
        if (r.arg == null) r.arg = "";
        if (r.message == null) r.message = "";
        r.minCount = Math.max(1, Math.min(r.minCount, 100000));
        r.amount = Math.max(1, Math.min(r.amount, 1000));
        r.duration = Math.max(0, Math.min(r.duration, 3600));
        r.cooldown = Math.max(0, Math.min(r.cooldown, 86400));
        r.interval = Math.max(0, Math.min(r.interval, 60000));
        r.delay = Math.max(0, Math.min(r.delay, 600000));
        if (r.audio == null) r.audio = "";
        if (r.trigger == MgTrigger.LIKES) {
            long n;
            try {
                n = Long.parseLong(r.match.trim());
            } catch (Exception e) {
                n = 0;
            }
            if (n <= 0) r.match = "1000";
        }
        if (r.trigger == MgTrigger.GIFT && r.match.trim().isEmpty()) r.match = "*";
    }

    /** Plain-language summary of a rule, e.g. "When someone sends Rose -> spawn mob: creeper." */
    static String sentence(MgRule r) {
        String m = r.match == null ? "" : r.match.trim();
        String when;
        switch (r.trigger) {
            case GIFT:
                when = (m.isEmpty() || m.equals("*")) ? "someone sends any gift" : "someone sends " + m;
                if (r.minCount > 1) when += " (" + r.minCount + " or more)";
                break;
            case LIKES: when = "every " + m + " likes"; break;
            case CHAT:
                when = (m.isEmpty() || m.equals("*")) ? "anyone writes in chat" : "someone writes \"" + m + "\" in chat";
                break;
            default: when = r.trigger.label.toLowerCase(Locale.ROOT) + " happens";
        }
        String arg = r.arg == null ? "" : r.arg.trim();
        int bar = arg.indexOf('|');
        if (bar >= 0) arg = arg.substring(0, bar).trim();
        String what = r.action.label.toLowerCase(Locale.ROOT);
        if (!arg.isEmpty()) what += ": " + arg;
        if (r.amount > 1) what += " x" + r.amount;
        return "When " + when + " -> " + what + ".";
    }

    private void save() {
        MgConfig cfg = MgConfig.get();
        sanitize(work);
        if (work.trigger == MgTrigger.CHAT && work.match.trim().isEmpty()) {
            error = "Chat keyword can't be empty.";
            return;
        }
        if (isNew) {
            target.copyFrom(work);
            cfg.rules.add(target);
        } else {
            target.copyFrom(work);
        }
        cfg.save();
        open(parent);
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float delta) {
        renderThemed(g, mx, my, delta, () -> {
            int w = this.field_22789;
            int h = this.field_22790;
            int maxW = w - 24;
            int fw = Math.min(280, w - 40);
            int x0 = (w - fw) / 2;
            txt(g, fit(TITLES[page], maxW), 12, 24, ModUiTheme.TEXT_SECONDARY);
            if (page == 0) {
                int ry = 44 + 3 * 24 + 40;
                txt(g, fit(work.trigger.matchHint, maxW), 12, 44 + 3 * 24 + 6, ModUiTheme.TEXT_MUTED);
                if (work.trigger == MgTrigger.GIFT) {
                    txt(g, "Gift name (use < > to pick one you received):", x0, ry - 12, ModUiTheme.TEXT_SECONDARY);
                    txt(g, "Only count at least this many gifts (1 = any):", x0, ry + 34, ModUiTheme.TEXT_SECONDARY);
                } else if (work.trigger == MgTrigger.LIKES) {
                    txt(g, "Likes between each trigger (e.g. 1000):", x0, ry - 12, ModUiTheme.TEXT_SECONDARY);
                } else if (work.trigger == MgTrigger.CHAT) {
                    txt(g, "Word people type in chat (e.g. !tnt):", x0, ry - 12, ModUiTheme.TEXT_SECONDARY);
                } else {
                    txt(g, "Nothing to fill in for this trigger. Press Next.", x0, ry, ModUiTheme.TEXT_MUTED);
                }
            } else if (page == 1) {
                int ay = 44 + 5 * 22 + 24;
                txt(g, fit("Action: " + work.action.help, maxW), 12, 44 + 5 * 22 + 6, ModUiTheme.TEXT_MUTED);
                txt(g, fit("Argument: " + work.action.argHint, maxW), 12, ay - 12, ModUiTheme.TEXT_SECONDARY);
            } else if (page == 2) {
                txt(g, "Amount (how many):", (w - Math.min(280, w - 40)) / 2, 44, ModUiTheme.TEXT_SECONDARY);
                txt(g, "Duration in seconds (fuse, freeze, effect):", (w - Math.min(280, w - 40)) / 2, 88, ModUiTheme.TEXT_SECONDARY);
                txt(g, "Cooldown in seconds (0 = none):", (w - Math.min(280, w - 40)) / 2, 132, ModUiTheme.TEXT_SECONDARY);
                txt(g, "Message to you (optional, {user} {gift} {count}):", (w - Math.min(280, w - 40)) / 2, 176, ModUiTheme.TEXT_SECONDARY);
                txt(g, fit(work.action.help, maxW), 12, 44 + 210, ModUiTheme.TEXT_MUTED);
            } else {
                txt(g, "Delay between commands in ms (0 = fast):", (w - Math.min(280, w - 40)) / 2, 44, ModUiTheme.TEXT_SECONDARY);
                txt(g, "Wait before the first command in ms:", (w - Math.min(280, w - 40)) / 2, 88, ModUiTheme.TEXT_SECONDARY);
                txt(g, "Sound id to play (optional, e.g. entity.creeper.primed):", (w - Math.min(280, w - 40)) / 2, 132, ModUiTheme.TEXT_SECONDARY);
            }
            txt(g, fit(sentence(work), maxW), 12, h - 58, GREEN);
            if (!error.isEmpty()) txt(g, fit(error, maxW), 12, h - 74, RED);
        });
    }
}
