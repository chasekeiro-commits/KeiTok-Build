package takeyourminestream.ijustseen.ui.screen;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import takeyourminestream.ijustseen.minigames.MgAction;
import takeyourminestream.ijustseen.minigames.MgActions;
import takeyourminestream.ijustseen.minigames.MgBridge;
import takeyourminestream.ijustseen.minigames.MgConfig;
import takeyourminestream.ijustseen.minigames.MgCtx;
import takeyourminestream.ijustseen.minigames.MgEngine;
import takeyourminestream.ijustseen.minigames.MgIcons;
import takeyourminestream.ijustseen.minigames.MgRule;
import takeyourminestream.ijustseen.minigames.MgTrigger;

/**
 * Interactive Minigames rule list - styled after the Streamtoearn trigger list:
 * reorder arrows, trigger icon, action icon + stats, commands, audio, play / test / copy / delete.
 */
public class MinigamesScreen extends MgScreenBase {
    static final int ROW_H = 50;
    static final int GAP = 3;

    // palette
    static final int C_ROW = 0xFF15171B;
    static final int C_BORDER = 0xFF2B2E35;
    static final int C_SMALL = 0xFF1D2025;
    static final int C_GRAY = 0xFFB0B4BA;
    static final int C_WHITE = 0xFFFFFFFF;
    static final int C_PINK = 0xFFFF9DF2;
    static final int C_ORANGE = 0xFFF28C1B;
    static final int C_BLUE = 0xFF1E73D2;
    static final int C_RED = 0xFFE5484D;
    static final int C_NEW = 0xFF1F4FB5;
    static final int C_SAVE = 0xFF3C8D2F;
    static final int C_GOLD = 0xFFFFD84D;
    static final int C_GREEN = 0xFF55FF66;
    static final int C_BAD = 0xFFFF6B6B;

    private int page;
    private String filter;
    private final List<MgRule> view = new ArrayList<>();
    private final Map<MgRule, List<String>> preview = new IdentityHashMap<>();
    private class_342 searchField;
    private int pages = 1;
    private int perPage = 1;
    private int listTop = 38;
    private int listBottom;
    private String flash = "";
    private long flashUntil;

    public MinigamesScreen(class_437 parent) {
        this(parent, 0, "");
    }

    public MinigamesScreen(class_437 parent, int page, String filter) {
        super("Interactive Minigames  -  Streamtoearn", parent);
        this.page = page;
        this.filter = filter == null ? "" : filter;
    }

    @Override
    protected void method_25426() {
        fields.clear();
        MgConfig cfg = MgConfig.get();
        int h = this.field_22790;

        view.clear();
        String f = filter.trim().toLowerCase(Locale.ROOT);
        for (MgRule r : cfg.rules) {
            if (f.isEmpty() || (r.summary() + " " + r.message).toLowerCase(Locale.ROOT).contains(f)) view.add(r);
        }
        listBottom = h - 52;
        perPage = Math.max(1, (listBottom - listTop + GAP) / (ROW_H + GAP));
        pages = Math.max(1, (view.size() + perPage - 1) / perPage);
        if (page >= pages) page = pages - 1;
        if (page < 0) page = 0;

        preview.clear();
        int from = page * perPage;
        int to = Math.min(view.size(), from + perPage);
        for (int i = from; i < to; i++) {
            MgRule r = view.get(i);
            MgCtx c = MgCtx.of("nickname", "nickname");
            if (r.trigger == MgTrigger.GIFT) {
                String m = r.match == null ? "" : r.match.split("[,|]")[0].trim();
                c.gift = m.isEmpty() || m.equals("*") ? "Rose" : m;
                c.count = Math.max(1, r.minCount);
            }
            List<String> cmds = new ArrayList<>();
            try {
                cmds.addAll(MgActions.build(r, c, cfg));
            } catch (Throwable ignored) { }
            preview.put(r, cmds);
        }

        searchField = addField(10, h - 48, Math.max(80, Math.min(120, this.field_22789 / 4)), 18, filter, 40, "Search");
    }

    private void reopen() {
        open(new MinigamesScreen(parent, page, filter));
    }

    private void edit(MgRule r) {
        open(new MinigameRuleEditorScreen(this, r, false, null));
    }

    private void swap(MgRule r, int dir) {
        MgConfig cfg = MgConfig.get();
        int vi = view.indexOf(r);
        int vj = vi + dir;
        if (vi < 0 || vj < 0 || vj >= view.size()) return;
        MgRule other = view.get(vj);
        int a = cfg.rules.indexOf(r);
        int b = cfg.rules.indexOf(other);
        if (a < 0 || b < 0) return;
        cfg.rules.set(a, other);
        cfg.rules.set(b, r);
        cfg.save();
        // keep the moved row visible even if it crossed a page border
        page = Math.max(0, Math.min(pages - 1, vj / perPage));
        reopen();
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float delta) {
        renderThemed(g, mx, my, delta, () -> body(g, mx, my));
    }

    private void body(class_332 g, int mx, int my) {
        clearHits();
        MgConfig cfg = MgConfig.get();
        int w = this.field_22789;
        int h = this.field_22790;

        // status + collab banner
        String st = MgBridge.status();
        boolean ok = MgBridge.READY.equals(st);
        String banner = "COLLAB WITH STREAMTOEARN";
        int bw = this.field_22793.method_1727(banner);
        txt(g, (ok ? "[OK] " : "[!] ") + fit(MgBridge.statusText(st), w - bw - 40), 12, 24, ok ? C_GREEN : C_BAD);
        txt(g, "§l" + banner, w - 12 - bw, 24, C_GOLD);

        // rows
        int from = Math.min(page * perPage, view.size());
        int to = Math.min(view.size(), from + perPage);
        for (int i = from; i < to; i++) {
            row(g, mx, my, view.get(i), listTop + (i - from) * (ROW_H + GAP), cfg);
        }
        if (view.isEmpty()) {
            txt(g, cfg.rules.isEmpty() ? "No triggers yet - press New Trigger (or Settings > Reset to defaults)." : "No triggers match your search.",
                16, listTop + 10, C_GRAY);
        }

        // bottom line A: search / master / settings / paging
        int ay = h - 48;
        int sx = 10 + searchField.method_25368() + 4;
        cbtn(g, mx, my, sx, ay, 44, 18, "Search", C_SMALL, () -> {
            this.filter = searchField.method_1882();
            this.page = 0;
            reopen();
        });
        cbtn(g, mx, my, sx + 46, ay, 38, 18, "Clear", C_SMALL, () -> {
            this.filter = "";
            this.page = 0;
            reopen();
        });
        int settingsX = w - 10 - 60;
        cbtn(g, mx, my, settingsX, ay, 60, 18, "Settings", C_SMALL, () -> open(new MinigamesSettingsScreen(this)));
        int masterX = settingsX - 4 - 100;
        cbtn(g, mx, my, masterX, ay, 100, 18, cfg.enabled ? "Minigames: ON" : "Minigames: OFF", cfg.enabled ? C_SAVE : C_RED, () -> {
            cfg.enabled = !cfg.enabled;
            cfg.save();
            reopen();
        });
        int nextX = masterX - 4 - 18;
        cbtn(g, mx, my, nextX, ay, 18, 18, ">", page < pages - 1 ? C_SMALL : 0xFF101114, () -> {
            if (page < pages - 1) {
                page++;
                reopen();
            }
        });
        String pg = (page + 1) + "/" + pages;
        int pgW = this.field_22793.method_1727(pg);
        txt(g, pg, nextX - 4 - pgW, ay + 5, C_GRAY);
        int prevX = nextX - 4 - pgW - 4 - 18;
        cbtn(g, mx, my, prevX, ay, 18, 18, "<", page > 0 ? C_SMALL : 0xFF101114, () -> {
            if (page > 0) {
                page--;
                reopen();
            }
        });

        // bottom line B: New Trigger (left) / Save Preset (right) like the Streamtoearn window
        int by = h - 24;
        cbtn(g, mx, my, 10, by, 100, 18, "New Trigger", C_NEW, () -> {
            MgRule nr = new MgRule();
            nr.trigger = MgTrigger.GIFT;
            nr.match = "Rose";
            nr.action = MgAction.GIVE;
            nr.arg = "diamond";
            nr.amount = 1;
            open(new MinigameRuleEditorScreen(this, nr, true, null));
        });
        cbtn(g, mx, my, w - 10 - 100 - 108, by, 100, 18, "Tutorial", C_SMALL, () -> open(new MgTutorialScreen(this)));
        cbtn(g, mx, my, w - 10 - 100, by, 100, 18, "Save Preset", C_SAVE, () -> {
            String n = cfg.savePreset();
            flash = n == null ? "Could not save preset" : "Saved " + n;
            flashUntil = System.currentTimeMillis() + 3500L;
        });
        if (System.currentTimeMillis() < flashUntil) {
            int fw = this.field_22793.method_1727(flash);
            txt(g, flash, (w - fw) / 2, by + 5, C_GREEN);
        } else {
            String info = view.size() + " trigger" + (view.size() == 1 ? "" : "s") + "  |  HUD: " + (cfg.hudEnabled ? "on" : "off");
            int iw = this.field_22793.method_1727(info);
            txt(g, info, (w - iw) / 2, by + 5, C_GRAY);
        }
    }

    private void row(class_332 g, int mx, int my, MgRule r, int y, MgConfig cfg) {
        int w = this.field_22789;
        int rx = 10;
        int rw = w - 20;
        int dim = r.enabled ? 0 : 1;
        box(g, rx, y, rw, ROW_H, C_ROW, C_BORDER);
        // clicking anywhere on the row opens the editor (small controls are registered after, so they win)
        cregion(rx, y, rw, ROW_H, () -> edit(r));

        // column A: up / menu / down
        int ax = rx + 4;
        small(g, mx, my, ax, y + 3, 14, 14, 1, () -> swap(r, -1));
        small(g, mx, my, ax, y + 18, 14, 14, 2, () -> edit(r));
        small(g, mx, my, ax, y + 33, 14, 14, 3, () -> swap(r, 1));

        // column B: trigger
        int bx = rx + 22;
        MgIcons.drawTrigger(g, r, bx, y + 6, 3);
        int tx = bx + (MgIcons.hasGiftIcon(r) ? 36 : 28);
        txt(g, "Anyone", tx, y + 6, C_GRAY);
        g.method_25294(tx, y + 17, tx + 7, y + 24, 0xFF000000);
        g.method_25294(tx + 3, y + 18, tx + 4, y + 22, C_WHITE);
        g.method_25294(tx + 4, y + 18, tx + 6, y + 19, 0xFF25F4EE);
        String tl = triggerLabel(r);
        txt(g, tl, tx + 10, y + 16, r.trigger == MgTrigger.GIFT ? C_PINK : C_WHITE);
        txt(g, fit(triggerDetail(r), 66), tx, y + 26, C_WHITE);
        boolean on = r.enabled;
        cbtn(g, mx, my, tx, y + 36, 26, 11, on ? "ON" : "OFF", on ? C_SAVE : C_RED, () -> {
            r.enabled = !r.enabled;
            cfg.save();
            reopen();
        });

        // column C: action
        int cx = rx + 22 + 28 + 70 + 10;
        cg(g, cx - 5, y + 6, y + ROW_H - 6);
        MgIcons.drawAction(g, r, cx, y + 6, 3);
        int ctx = cx + 30;
        txt(g, "§l" + fit(MgIcons.actionTitle(r), 80), ctx, y + 6, C_WHITE);
        stat(g, ctx, y + 17, "Repetition: ", Integer.toString(r.amount));
        stat(g, ctx, y + 26, "Interval: ", Integer.toString(r.interval));
        stat(g, ctx, y + 35, "Delay: ", Integer.toString(r.delay));
        if (r.perGiftCount) stat(g, ctx, y + 44 - 1, "Multiplier: ", "true");

        // right group: orange play, blue play, copy, delete
        int by = y + (ROW_H - 20) / 2;
        int rEdge = rx + rw - 4;
        int bTrash = rEdge - 20;
        int bCopy = bTrash - 24;
        int bBlue = bCopy - 24;
        int bOrange = bBlue - 24;
        cbtnIcon(g, mx, my, bOrange, by, C_ORANGE, 0, () -> MgEngine.test(r));
        cbtnIcon(g, mx, my, bBlue, by, C_BLUE, 1, () -> MgEngine.testAudio(r));
        cbtnIcon(g, mx, my, bCopy, by, C_BLUE, 2, () -> {
            MgRule c = r.copy();
            c.id = java.util.UUID.randomUUID().toString().substring(0, 8);
            int idx = cfg.rules.indexOf(r);
            cfg.rules.add(idx < 0 ? cfg.rules.size() : idx + 1, c);
            cfg.save();
            reopen();
        });
        cbtnIcon(g, mx, my, bTrash, by, C_RED, 3, () -> {
            cfg.rules.remove(r);
            cfg.save();
            reopen();
        });
        cg(g, bOrange - 5, y + 6, y + ROW_H - 6);

        // audio + plus
        int audioW = 58;
        int audioX = bOrange - 10 - audioW;
        boolean hasAudio = r.audio != null && !r.audio.trim().isEmpty();
        String at = hasAudio ? fit(r.audio.trim(), audioW) : "Add Audio";
        int atw = this.field_22793.method_1727(at);
        txt(g, hasAudio ? at : "§lAdd Audio", audioX + (audioW - Math.min(audioW, hasAudio ? atw : atw - 6)) / 2, y + (ROW_H - 8) / 2,
            hasAudio ? C_GREEN : C_WHITE);
        cregion(audioX - 2, y + 6, audioW + 4, ROW_H - 12, () -> edit(r));
        cg(g, audioX - 5, y + 6, y + ROW_H - 6);
        int plusX = audioX - 10 - 16;
        cg(g, plusX - 5, y + 6, y + ROW_H - 6);
        txt(g, "+", plusX + 5, y + (ROW_H - 8) / 2, C_WHITE);
        cregion(plusX - 2, y + 6, 22, ROW_H - 12, () -> edit(r));

        // column D: commands
        int dx = ctx + 88 + 8;
        int dEnd = plusX - 10;
        cg(g, dx - 5, y + 6, y + ROW_H - 6);
        List<String> cmds = preview.get(r);
        int n = cmds == null ? 0 : cmds.size();
        int maxW = dEnd - dx;
        if (maxW > 20) {
            stat(g, dx, y + 6, "Commands: ", Integer.toString(n));
            if (n > 0) {
                txt(g, "§l" + fit("/" + cmds.get(0), maxW), dx, y + 17, C_WHITE);
                if (n > 1) txt(g, "§l" + fit(n > 2 ? "(+" + (n - 1) + " more)" : "/" + cmds.get(1), maxW), dx, y + 26, C_GRAY);
            } else if (r.action == MgAction.ALERT || r.action == MgAction.WIN) {
                txt(g, fit(r.action == MgAction.WIN ? "adds to wins counter" : "alert only", maxW), dx, y + 17, C_GRAY);
            }
        }
        if (dim == 1) {
            // dim the whole row when disabled (drawn last, translucent)
            g.method_25294(rx + 1, y + 1, rx + rw - 1, y + ROW_H - 1, 0x66101114);
        }
    }

    private static String triggerLabel(MgRule r) {
        switch (r.trigger) {
            case GIFT: return "Gift";
            case LIKES: return "Likes";
            case FOLLOW: return "Follow";
            case SHARE: return "Share";
            case SUBSCRIBE: return "Subscribe";
            case JOIN: return "Join";
            case CHAT: return "Chat";
            case BITS: return "Bits";
            default: return "Raid";
        }
    }

    private static String triggerDetail(MgRule r) {
        switch (r.trigger) {
            case GIFT: {
                String m = r.match == null ? "" : r.match.trim();
                String s = m.isEmpty() || m.equals("*") ? "Any gift" : m;
                return r.minCount > 1 ? s + " x" + r.minCount : s;
            }
            case LIKES: return r.match + " Likes";
            case CHAT: return r.match;
            default: return "";
        }
    }

    private void stat(class_332 g, int x, int y, String label, String value) {
        txt(g, label, x, y, C_GRAY);
        txt(g, "§l" + value, x + this.field_22793.method_1727(label), y, C_WHITE);
    }

    private static void box(class_332 g, int x, int y, int w, int h, int fill, int border) {
        g.method_25294(x, y, x + w, y + h, border);
        g.method_25294(x + 1, y + 1, x + w - 1, y + h - 1, fill);
    }

    /** Thin vertical column separator. */
    private static void cg(class_332 g, int x, int y1, int y2) {
        g.method_25294(x, y1, x + 1, y2, C_BORDER);
    }

    /** kind 1 = up chevron, 2 = menu lines, 3 = down chevron */
    private void small(class_332 g, int mx, int my, int x, int y, int w, int h, int kind, Runnable action) {
        boolean hov = mx >= x && mx < x + w && my >= y && my < y + h;
        box(g, x, y, w, h, hov ? 0xFF2A2E36 : C_SMALL, 0xFF3A3E46);
        int cx = x + w / 2;
        int cy = y + h / 2;
        if (kind == 2) {
            for (int i = -3; i <= 3; i += 3) g.method_25294(cx - 3, cy + i - 1 + 0, cx + 4, cy + i, C_WHITE);
        } else {
            for (int i = 0; i < 3; i++) {
                int half = kind == 1 ? i : 2 - i;
                g.method_25294(cx - half - 1, cy - 2 + i + (kind == 1 ? 0 : 0), cx + half + 1 + 0, cy - 1 + i, C_WHITE);
            }
        }
        cregion(x, y, w, h, action);
    }

    /** icon: 0 = play, 1 = play (audio), 2 = copy, 3 = trash */
    private void cbtnIcon(class_332 g, int mx, int my, int x, int y, int color, int icon, Runnable action) {
        boolean hov = mx >= x && mx < x + 20 && my >= y && my < y + 20;
        g.method_25294(x, y, x + 20, y + 20, hov ? lighten(color) : color);
        int cx = x + 10;
        int cy = y + 10;
        switch (icon) {
            case 0:
            case 1: {
                int[] widths = {2, 4, 6, 8, 6, 4, 2};
                for (int i = 0; i < widths.length; i++) {
                    g.method_25294(cx - 3, cy - 4 + i, cx - 3 + widths[i], cy - 3 + i, C_WHITE);
                }
                break;
            }
            case 2: {
                g.method_25294(cx - 5, cy - 6, cx + 2, cy + 3, C_WHITE);
                g.method_25294(cx - 4, cy - 5, cx + 1, cy + 2, color);
                g.method_25294(cx - 2, cy - 3, cx + 5, cy + 6, C_WHITE);
                g.method_25294(cx - 1, cy - 2, cx + 4, cy + 5, color);
                break;
            }
            default: {
                g.method_25294(cx - 5, cy - 5, cx + 5, cy - 4, C_WHITE);
                g.method_25294(cx - 2, cy - 7, cx + 2, cy - 5, C_WHITE);
                g.method_25294(cx - 4, cy - 3, cx + 4, cy + 7, C_WHITE);
                g.method_25294(cx - 2, cy - 2, cx - 1, cy + 6, color);
                g.method_25294(cx + 1, cy - 2, cx + 2, cy + 6, color);
            }
        }
        cregion(x, y, 20, 20, action);
    }
}
