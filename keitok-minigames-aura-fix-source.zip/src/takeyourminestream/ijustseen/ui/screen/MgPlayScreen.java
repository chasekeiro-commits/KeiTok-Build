package takeyourminestream.ijustseen.ui.screen;

import net.minecraft.class_332;
import net.minecraft.class_437;
import takeyourminestream.ijustseen.minigames.MgConfig;
import takeyourminestream.ijustseen.ui.gui.ModUiTheme;

/** "Play" hub: the four ways to play with your stream. */
public class MgPlayScreen extends MgScreenBase {
    private static final int GAP = 6;

    public MgPlayScreen(class_437 parent) {
        super("Play - COLLAB WITH STREAMTOEARN", parent);
    }

    private int cardH() { return Math.max(46, Math.min(62, (this.field_22790 - 96) / 4 - GAP)); }
    private int cardW() { return Math.min(380, this.field_22789 - 20); }
    private int cardX() { return (this.field_22789 - cardW()) / 2; }
    private int cardY(int i) { return 34 + i * (cardH() + GAP); }

    private void again() { open(new MgPlayScreen(parent)); }

    @Override
    protected void method_25426() {
        fields.clear();
        final MgConfig cfg = MgConfig.get();
        int cw = cardW();
        int cx = cardX();
        for (int i = 0; i < 4; i++) {
            int y = cardY(i);
            int bx = cx + cw - 128;
            final int idx = i;
            addBtn("Open", bx, y + cardH() - 24, 56, 18, b -> {
                if (idx == 0) open(new MinigamesScreen(this));
                else if (idx == 1) open(new MgChatMobsScreen(this));
                else if (idx == 2) open(new MgChunkSwapScreen(this));
                else open(new MgChunkDeleteScreen(this));
            });
            boolean on = i == 0 ? cfg.enabled : i == 1 ? cfg.chatMobs : i == 2 ? cfg.chunkSwap : cfg.chunkDelete;
            addBtn(on ? "ON" : "OFF", bx + 60, y + cardH() - 24, 60, 18, b -> {
                if (idx == 0) cfg.enabled = !cfg.enabled;
                else if (idx == 1) cfg.chatMobs = !cfg.chatMobs;
                else if (idx == 2) cfg.chunkSwap = !cfg.chunkSwap;
                else cfg.chunkDelete = !cfg.chunkDelete;
                cfg.save();
                again();
            });
        }
        addBtn("Tutorial", (this.field_22789 - 100) / 2 - 106, this.field_22790 - 26, 100, 20, b -> open(new MgTutorialScreen(this)));
        addBtn("Done", (this.field_22789 - 100) / 2, this.field_22790 - 26, 100, 20, b -> method_25419());
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float delta) {
        renderThemed(g, mx, my, delta, () -> {
            String[] titles = {"1. Interactive Minigames", "2. Chat Mobs", "3. Chunk Swap", "4. Chunk Delete"};
            String[][] desc = {
                {"Gifts, follows, likes, shares and chat trigger", "things you set up (the Streamtoearn-style list)."},
                {"Whatever mob chat says is summoned right", "on top of you. Say \"creeper\" -> creeper."},
                {"Every few seconds the ground of your chunk", "becomes the block chat said the most."},
                {"Whatever block chat says the most is deleted", "everywhere in your chunk every round."}
            };
            int cw = cardW();
            int cx = cardX();
            for (int i = 0; i < 4; i++) {
                int y = cardY(i);
                g.method_25294(cx, y, cx + cw, y + cardH(), 0xFF26262C);
                g.method_25294(cx, y, cx + 3, y + cardH(), i == 0 ? 0xFF2D7DFF : i == 1 ? 0xFF3DDC84 : i == 2 ? 0xFFFF9F1A : 0xFFFF4D4D);
                txt(g, "§l" + titles[i], cx + 10, y + 6, 0xFFFFFFFF);
                txt(g, fit(desc[i][0], cw - 20), cx + 10, y + 20, ModUiTheme.TEXT_MUTED);
                txt(g, fit(desc[i][1], cw - 20), cx + 10, y + 30, ModUiTheme.TEXT_MUTED);
            }
            txt(g, fit("Commands run as YOU in a singleplayer world with cheats on.", this.field_22789 - 24), 12, this.field_22790 - 40, ModUiTheme.TEXT_MUTED);
        });
    }
}
