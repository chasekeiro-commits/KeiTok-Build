package takeyourminestream.ijustseen.ui.screen;

import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/** Press action for the "Play" entry in the main KeiTok settings menu. */
public final class MinigamesOpen implements class_4185.class_4241 {
    private final class_437 parent;

    public MinigamesOpen(class_437 parent) {
        this.parent = parent;
    }

    @Override
    public void onPress(class_4185 button) {
        class_310 mc = class_310.method_1551();
        if (mc != null) mc.method_1507(new MgPlayScreen(parent));
    }
}
