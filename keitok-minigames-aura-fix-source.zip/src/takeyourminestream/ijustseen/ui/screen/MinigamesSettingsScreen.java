package takeyourminestream.ijustseen.ui.screen;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import takeyourminestream.ijustseen.minigames.MgAction;
import takeyourminestream.ijustseen.minigames.MgConfig;
import takeyourminestream.ijustseen.minigames.MgRule;
import takeyourminestream.ijustseen.minigames.MgTrigger;
import takeyourminestream.ijustseen.ui.gui.ModUiTheme;

/** Interactive Minigames settings: HUD overlay, win counter, safety cap, presets and bulk tools. */
public class MinigamesSettingsScreen extends MgScreenBase {
    private static final int ITEM_H = 30;
    private static final int ITEMS = 16;
    private static int presetCursor = 0;

    private class_4185 resetButton;
    private boolean resetArmed;
    private String note = "";

    private static final String[] LABELS = {
        "Alert messages", "Max amount per action (safety cap)", "HUD overlay (gifts + what they do)", "HUD side",
        "HUD vertical offset", "HUD max lines", "Gifts HUD size (%, 40-300)", "Win counter", "Wins", "Rules tool", "Rules tool", "Presets", "Presets", "Move & size HUDs", "Chunk / mob HUD size (%, 40-300)", "Slide time (sec each way)"
    };

    public MinigamesSettingsScreen(class_437 parent) {
        super("Minigames Settings", parent);
    }

    private void again() {
        open(new MinigamesSettingsScreen(parent));
    }

    @Override
    protected void method_25426() {
        fields.clear();
        final MgConfig cfg = MgConfig.get();
        int h = this.field_22790;
        for (int i = 0; i < ITEMS; i++) {
            int[] c = cell(i, ITEMS, 36, 54, ITEM_H, 230);
            int x = c[0];
            int y = c[1] + 10;
            int w = c[2];
            switch (i) {
                case 0:
                    addBtn(cfg.announce ? "Shown on action bar: ON" : "Shown on action bar: OFF", x, y, w, 18, b -> {
                        cfg.announce = !cfg.announce;
                        cfg.save();
                        again();
                    });
                    break;
                case 1: {
                    class_342 f = addField(x, y, w, 18, Integer.toString(cfg.maxPerAction), 5, "max");
                    f.method_1863(s -> cfg.maxPerAction = Math.max(1, Math.min(1000, parseInt(s, cfg.maxPerAction))));
                    break;
                }
                case 2:
                    addBtn(cfg.hudEnabled ? "HUD: ON (default)" : "HUD: OFF", x, y, w, 18, b -> {
                        cfg.hudEnabled = !cfg.hudEnabled;
                        cfg.save();
                        again();
                    });
                    break;
                case 3:
                    addBtn(cfg.hudRight ? "Right side" : "Left side", x, y, w, 18, b -> {
                        cfg.hudRight = !cfg.hudRight;
                        cfg.save();
                        again();
                    });
                    break;
                case 4: {
                    class_342 f = addField(x, y, w, 18, Integer.toString(cfg.hudOffsetY), 4, "offset");
                    f.method_1863(s -> cfg.hudOffsetY = Math.max(0, Math.min(600, parseInt(s, cfg.hudOffsetY))));
                    break;
                }
                case 5: {
                    class_342 f = addField(x, y, w, 18, Integer.toString(cfg.hudMaxLines), 3, "lines");
                    f.method_1863(s -> cfg.hudMaxLines = Math.max(3, Math.min(80, parseInt(s, cfg.hudMaxLines))));
                    break;
                }
                case 6: {
                    int bw = (w - 8) / 3;
                    addBtn("-", x, y, bw, 18, b -> { cfg.hudScale = Math.max(40, cfg.hudScale - 10); cfg.save(); again(); });
                    addBtn("+", x + bw + 4, y, bw, 18, b -> { cfg.hudScale = Math.min(300, cfg.hudScale + 10); cfg.save(); again(); });
                    addBtn("100%", x + (bw + 4) * 2, y, bw, 18, b -> { cfg.hudScale = 100; cfg.save(); again(); });
                    break;
                }
                case 7:
                    addBtn(cfg.winCounter ? "Win counter: ON" : "Win counter: OFF", x, y, w, 18, b -> {
                        cfg.winCounter = !cfg.winCounter;
                        cfg.save();
                        again();
                    });
                    break;
                case 8: {
                    int bw = (w - 8) / 3;
                    addBtn("-1", x, y, bw, 18, b -> {
                        cfg.wins = Math.max(0, cfg.wins - 1);
                        cfg.save();
                        again();
                    });
                    addBtn("+1", x + bw + 4, y, bw, 18, b -> {
                        cfg.wins++;
                        cfg.save();
                        again();
                    });
                    addBtn("Reset", x + (bw + 4) * 2, y, bw, 18, b -> {
                        cfg.wins = 0;
                        cfg.save();
                        again();
                    });
                    break;
                }
                case 9:
                    addBtn("Add all gifts (disabled)", x, y, w, 18, b -> {
                        int added = 0;
                        for (String g : new java.util.ArrayList<>(cfg.knownGifts)) {
                            if (hasGiftRule(cfg, g)) continue;
                            MgRule nr = new MgRule(MgTrigger.GIFT, g, MgAction.ALERT, "", 1, 3);
                            nr.enabled = false;
                            cfg.rules.add(nr);
                            added++;
                        }
                        if (added > 0) cfg.save();
                        note = "Added " + added + " gift trigger(s). Edit them in the list.";
                    });
                    break;
                case 10:
                    resetButton = addBtn(resetArmed ? "Click again to confirm" : "Reset to defaults", x, y, w, 18, b -> {
                        if (!resetArmed) {
                            resetArmed = true;
                            resetButton.method_25355(class_2561.method_43470("Click again to confirm"));
                            return;
                        }
                        cfg.resetDefaults();
                        resetArmed = false;
                        resetButton.method_25355(class_2561.method_43470("Reset to defaults"));
                        note = "Default triggers restored.";
                    });
                    break;
                case 11:
                    addBtn("Save preset", x, y, w, 18, b -> {
                        String n = cfg.savePreset();
                        note = n == null ? "Could not save preset." : "Saved " + n + " (minigame_presets folder).";
                    });
                    break;
                case 12:
                    addBtn("Load next preset", x, y, w, 18, b -> {
                        List<String> all = cfg.listPresets();
                        if (all.isEmpty()) {
                            note = "No presets yet - press Save preset first.";
                            return;
                        }
                        presetCursor = presetCursor % all.size();
                        String name = all.get(presetCursor);
                        presetCursor++;
                        note = cfg.loadPreset(name) ? "Loaded " + name + "." : "Could not load " + name + ".";
                    });
                    break;
                case 13:
                    addBtn("Move & size HUDs (drag)", x, y, w, 18, b -> open(new MgHudMoveScreen(this)));
                    break;
                case 14: {
                    int bw = (w - 8) / 3;
                    addBtn("-", x, y, bw, 18, b -> { cfg.modeScale = Math.max(40, cfg.modeScale - 10); cfg.save(); again(); });
                    addBtn("+", x + bw + 4, y, bw, 18, b -> { cfg.modeScale = Math.min(300, cfg.modeScale + 10); cfg.save(); again(); });
                    addBtn("100%", x + (bw + 4) * 2, y, bw, 18, b -> { cfg.modeScale = 100; cfg.save(); again(); });
                    break;
                }
                default: {
                    class_342 f = addField(x, y, w, 18, Integer.toString(cfg.hudSlideSec), 2, "slide");
                    f.method_1863(v -> cfg.hudSlideSec = Math.max(1, Math.min(60, parseInt(v, cfg.hudSlideSec))));
                }
            }
        }
        addBtn("Done", (this.field_22789 - 100) / 2, h - 26, 100, 20, b -> method_25419());
    }

    private static boolean hasGiftRule(MgConfig cfg, String gift) {
        String g = norm(gift);
        for (MgRule r : cfg.rules) {
            if (r.trigger != MgTrigger.GIFT || r.match == null) continue;
            for (String alt : r.match.split("[,|]")) {
                if (norm(alt).equals(g)) return true;
            }
        }
        return false;
    }

    private static String norm(String s) {
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = Character.toLowerCase(s.charAt(i));
            if (Character.isLetterOrDigit(c)) b.append(c);
        }
        return b.toString();
    }

    @Override
    public void method_25419() {
        MgConfig.get().save();
        super.method_25419();
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float delta) {
        renderThemed(g, mx, my, delta, () -> {
            MgConfig cfg = MgConfig.get();
            for (int i = 0; i < ITEMS; i++) {
                int[] c = cell(i, ITEMS, 36, 54, ITEM_H, 230);
                String label = LABELS[i];
                if (i == 6) label = "Gifts HUD size: " + cfg.hudScale + "%";
                if (i == 14) label = "Chunk / mob HUD size: " + cfg.modeScale + "%";
                if (i == 8) label = "Wins: " + cfg.wins;
                txt(g, fit(label, c[2]), c[0], c[1], ModUiTheme.TEXT_SECONDARY);
            }
            int w = this.field_22789;
            int h = this.field_22790;
            if (!note.isEmpty()) txt(g, fit(note, w - 24), 12, h - 40, 0xFF55FF66);
            txt(g, fit("Commands run as YOU in a singleplayer world with cheats on. Rules: interactive_minigames.json", w - 24),
                12, h - 50, ModUiTheme.TEXT_MUTED);
        });
    }
}
