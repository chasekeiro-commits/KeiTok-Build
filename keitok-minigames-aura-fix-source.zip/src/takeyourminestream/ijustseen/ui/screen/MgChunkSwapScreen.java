package takeyourminestream.ijustseen.ui.screen;

import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import takeyourminestream.ijustseen.minigames.MgChatModes;
import takeyourminestream.ijustseen.minigames.MgConfig;
import takeyourminestream.ijustseen.ui.gui.ModUiTheme;

/** Settings for the Chunk Swap minigame. */
public class MgChunkSwapScreen extends MgScreenBase {
    private static final int ITEM_H = 30;
    private static final int ITEMS = 6;
    private static final String[] LABELS = {"Chunk Swap", "Swap every (seconds)", "Depth (0 = down to bedrock)", "Swap now", "Chat tally", "Blocked blocks (comma list)"};
    private String note = "";

    public MgChunkSwapScreen(class_437 parent) {
        super("Chunk Swap", parent);
    }

    private void again() { open(new MgChunkSwapScreen(parent)); }

    @Override
    protected void method_25426() {
        fields.clear();
        final MgConfig cfg = MgConfig.get();
        for (int i = 0; i < ITEMS; i++) {
            int[] c = cell(i, ITEMS, 40, 80, ITEM_H, 260);
            int x = c[0], y = c[1] + 10, w = c[2];
            switch (i) {
                case 0:
                    addBtn(cfg.chunkSwap ? "ON" : "OFF", x, y, w, 18, b -> { cfg.chunkSwap = !cfg.chunkSwap; cfg.save(); again(); });
                    break;
                case 1: {
                    class_342 f = addField(x, y, w, 18, Integer.toString(cfg.chunkSeconds), 3, "seconds");
                    f.method_1863(s -> cfg.chunkSeconds = Math.max(3, Math.min(600, parseInt(s, cfg.chunkSeconds))));
                    break;
                }
                case 2: {
                    class_342 f = addField(x, y, w, 18, Integer.toString(cfg.chunkDepth), 3, "depth");
                    f.method_1863(s -> cfg.chunkDepth = Math.max(0, Math.min(384, parseInt(s, cfg.chunkDepth))));
                    break;
                }
                case 3:
                    addBtn("Swap now (top block or stone)", x, y, w, 18, b -> {
                        String t = MgChatModes.topBlock();
                        MgChatModes.swapNow(t.isEmpty() ? "stone" : t, MgChatModes.topCount());
                        MgChatModes.clearTally();
                        note = "Swapped.";
                    });
                    break;
                case 4:
                    addBtn("Clear tally", x, y, w, 18, b -> {
                        MgChatModes.clearTally();
                        note = "Tally cleared.";
                    });
                    break;
                default: {
                    class_342 f = addField(x, y, w, 18, cfg.chunkBlocked == null ? "" : cfg.chunkBlocked, 300, "blocked");
                    f.method_1863(v -> cfg.chunkBlocked = v);
                }
            }
        }
        addBtn("Done", (this.field_22789 - 100) / 2, this.field_22790 - 26, 100, 20, b -> method_25419());
    }

    @Override
    public void method_25419() {
        MgConfig.get().save();
        super.method_25419();
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float delta) {
        renderThemed(g, mx, my, delta, () -> {
            for (int i = 0; i < ITEMS; i++) {
                int[] c = cell(i, ITEMS, 40, 80, ITEM_H, 260);
                String label = LABELS[i];
                if (i == 4) {
                    String t = MgChatModes.topBlock();
                    label = "Top block: " + (t.isEmpty() ? "none yet" : t + " x" + MgChatModes.topCount());
                }
                txt(g, fit(label, c[2]), c[0], c[1], ModUiTheme.TEXT_SECONDARY);
            }
            int w = this.field_22789 - 24;
            if (!note.isEmpty()) txt(g, fit(note, w), 12, this.field_22790 - 68, 0xFF55FF66);
            txt(g, fit("WARNING: this permanently replaces the ground of your chunk. Back up your world!", w), 12, this.field_22790 - 56, 0xFFFF5555);
            txt(g, fit("Every block can be named. Nothing is blocked unless you list it above (e.g. lava, tnt).", w), 12, this.field_22790 - 45, ModUiTheme.TEXT_MUTED);
        });
    }
}
