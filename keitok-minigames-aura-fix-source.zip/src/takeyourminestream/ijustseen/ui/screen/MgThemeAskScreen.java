package takeyourminestream.ijustseen.ui.screen;

import net.minecraft.class_332;
import net.minecraft.class_310;
import net.minecraft.class_437;
import takeyourminestream.ijustseen.minigames.MgConfig;
import takeyourminestream.ijustseen.ui.gui.ModUiTheme;

/** "Do you want this theme to apply to the comment popups too?" - shown after a theme is picked. */
public class MgThemeAskScreen extends MgScreenBase {
    public MgThemeAskScreen(class_437 parent) {
        super("Theme changed", parent);
    }

    public static void show(class_437 themesScreen) {
        class_310 mc = class_310.method_1551();
        if (mc != null) mc.method_1507(new MgThemeAskScreen(themesScreen));
    }

    @Override
    protected void method_25426() {
        fields.clear();
        final MgConfig cfg = MgConfig.get();
        int cx = this.field_22789 / 2;
        int y = this.field_22790 / 2 + 8;
        addBtn("Yes, apply to comments", cx - 124, y, 120, 20, b -> {
            cfg.themeComments = true;
            cfg.save();
            method_25419();
        });
        addBtn("No, menus only", cx + 4, y, 120, 20, b -> {
            cfg.themeComments = false;
            cfg.save();
            method_25419();
        });
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float delta) {
        renderThemed(g, mx, my, delta, () -> {
            int w = this.field_22789;
            int cy = this.field_22790 / 2;
            String q = "Do you want this to apply to the comment popups?";
            txt(g, q, (w - this.field_22793.method_1727(q)) / 2, cy - 22, 0xFFFFFFFF);
            String s = "Colors and the animated border will match your theme.";
            txt(g, s, (w - this.field_22793.method_1727(s)) / 2, cy - 8, ModUiTheme.TEXT_MUTED);
        });
    }
}
