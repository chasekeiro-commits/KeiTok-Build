package takeyourminestream.ijustseen.ui.screen;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_332;
import net.minecraft.class_437;
import takeyourminestream.ijustseen.ui.gui.ModUiTheme;

/** Multi-page tutorial for every Interactive Minigames feature. Prev / Next / Done. */
public class MgTutorialScreen extends MgScreenBase {
    private static final class Page {
        final String title;
        final String[] lines;
        Page(String title, String... lines) { this.title = title; this.lines = lines; }
    }

    private static final Page[] PAGES = {
        new Page("Welcome",
            "This tutorial explains every minigame, one page at a time.",
            "Use Next and Back at the bottom to move between pages.",
            "Everything is controlled from the Play screen. Each card has",
            "an Open button and an ON / OFF switch."),
        new Page("How a rule works",
            "Interactive Minigames is a list of rules. Every rule has",
            "three parts, shown in the editor as three steps:",
            "1. WHEN: what happens on stream (a gift, a follow, likes, chat...)",
            "2. WHAT: what should happen in your world (spawn, TNT, effect...)",
            "3. HOW MUCH: amount, duration, cooldown and an optional message."),
        new Page("Triggers (WHEN)",
            "GIFT - someone sends a gift. Pick the gift name, or * for any.",
            "FOLLOW / SHARE / SUBSCRIBE / JOIN / RAID - a stream event.",
            "LIKES - every N likes (for example every 1000 likes).",
            "CHAT - someone writes a word in chat, for example !tnt.",
            "BITS - cheers on the stream."),
        new Page("Actions (WHAT)",
            "SPAWN and TNT - mobs and TNT appear near you.",
            "GIVE, XP, HEAL, HURT, EFFECT - items and status effects.",
            "FREEZE, LAUNCH, RANDOM_TP, LIGHTNING - fun things to your player.",
            "TIME, WEATHER, TITLE, SOUND, ALERT - change the world or show text.",
            "COMMAND - run any Minecraft command as you (advanced)."),
        new Page("Adding a rule",
            "1. Open Interactive Minigames and press Add rule.",
            "2. Step 1: pick the trigger. Gifts also need a gift name.",
            "3. Step 2: pick the action and type its argument (the hint",
            "   under the list explains what to write).",
            "4. Step 3: set the amount and duration, then press Add rule.",
            "Tip: Test runs the rule once so you can see what it does."),
        new Page("Example rule",
            "Trigger: GIFT, name Rose, count 1.",
            "Action: SPAWN, argument creeper, amount 1.",
            "Result: every time someone sends a Rose, a creeper appears",
            "next to you. The sentence at the bottom of the editor always",
            "tells you in plain words what your rule does."),
        new Page("TNT explodes by itself",
            "TNT rules now explode on their own. Duration is the fuse in",
            "seconds: set 0 to explode right away, or 3 to wait 3 seconds.",
            "Amount is how many TNT blocks are placed.",
            "The editor sets Duration to 0 when you pick TNT. Change it",
            "if you want a delay."),
        new Page("Move and size the HUDs",
            "The HUDs are the panels that show gift names and timers.",
            "Open Settings in the minigames screen, then choose",
            "\"Move & size HUDs (drag)\".",
            "Drag any panel with the mouse to put it anywhere on screen.",
            "Use -, + and 100% to change each panel's size on its own."),
        new Page("Chunk and mob HUD",
            "The chunk / mob panel has its own size control in Settings.",
            "Use -, + and 100% next to \"Chunk / mob HUD size\".",
            "Reset spots puts every panel back where it started.",
            "Done closes the move screen and saves your positions."),
        new Page("Chat Mobs",
            "Whatever mob name people type in chat is summoned on top of",
            "you. Type \"creeper\" and a creeper appears.",
            "Turn it on or off with the switch on the Play screen.",
            "Mob names that do not exist are ignored."),
        new Page("Chunk Swap",
            "Every few seconds the ground of your chunk changes to the",
            "block that chat asked for most. Turn it on in Play.",
            "Use the Open button to change the timing and the blocks."),
        new Page("Chunk Delete",
            "Every round, the block that chat named most is removed from",
            "your whole chunk. Use it carefully: it really deletes blocks.",
            "Turn it on or off with its switch on the Play screen."),
        new Page("Multiplayer",
            "Minigames work in singleplayer by default.",
            "On a server, type /keitok force once to turn them on here.",
            "Commands such as spawn and TNT need operator rights on the",
            "server. Without them, alerts, the win counter and the HUDs",
            "still work, but the spawns and explosions will not."),
        new Page("26 Aura",
            "Every player with KeiTok gets a 26 design aura.",
            "Open it with the Aura button next to Themes.",
            "Pick a design, size, speed, quality and colour.",
            "Your own name always gets the KeiTok logo.",
            "Other KeiTok players get the logo when their server runs KeiTok.",
            "Turn that off with Other players in the Aura screen."),
        new Page("Troubleshooting",
            "Nothing happens? Check that the switch is ON and the rule is",
            "enabled (Status in step 3). Check the gift name is spelled",
            "the same as on stream.",
            "The status line at the top tells you if the game is ready.",
            "If a rule says NO WORLD, join a world first.")
    };

    private final int page;

    public MgTutorialScreen(class_437 parent) {
        this(parent, 0);
    }

    private MgTutorialScreen(class_437 parent, int page) {
        super("Minigames Tutorial", parent);
        this.page = Math.max(0, Math.min(PAGES.length - 1, page));
    }

    private void goTo(int p) {
        open(new MgTutorialScreen(parent, p));
    }

    @Override
    protected void method_25426() {
        fields.clear();
        int w = this.field_22789;
        int h = this.field_22790;
        int by = h - 26;
        boolean last = page == PAGES.length - 1;
        if (page > 0) addBtn("< Back", w / 2 - 170, by, 90, 20, b -> goTo(page - 1));
        addBtn("Done", w / 2 - 45, by, 90, 20, b -> method_25419());
        if (!last) addBtn("Next >", w / 2 + 80, by, 90, 20, b -> goTo(page + 1));
        else addBtn("Start over", w / 2 + 80, by, 90, 20, b -> goTo(0));
    }

    /** Word-wraps a string into lines that fit maxWidth pixels. */
    private List<String> wrap(String s, int maxWidth) {
        List<String> out = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        for (String word : s.split(" ")) {
            String trial = cur.length() == 0 ? word : cur + " " + word;
            if (this.field_22793.method_1727(trial) <= maxWidth) {
                cur.setLength(0);
                cur.append(trial);
            } else {
                if (cur.length() > 0) out.add(cur.toString());
                cur.setLength(0);
                cur.append(word);
            }
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float delta) {
        renderThemed(g, mx, my, delta, () -> {
            int w = this.field_22789;
            int h = this.field_22790;
            int maxW = Math.min(420, w - 32);
            int x0 = (w - maxW) / 2;
            Page p = PAGES[page];
            txt(g, "Page " + (page + 1) + " of " + PAGES.length, x0, 34, ModUiTheme.TEXT_MUTED);
            txt(g, "§l" + p.title, x0, 48, 0xFFFFFFFF);
            int y = 66;
            for (String raw : p.lines) {
                for (String line : wrap(raw, maxW)) {
                    if (y > h - 50) break;
                    txt(g, line, x0, y, ModUiTheme.TEXT_SECONDARY);
                    y += 12;
                }
                y += 3;
            }
        });
    }
}
