package takeyourminestream.ijustseen.ui.screen;

import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_437;
import takeyourminestream.ijustseen.minigames.MgChatModes;
import takeyourminestream.ijustseen.minigames.MgConfig;
import takeyourminestream.ijustseen.ui.gui.ModUiTheme;

/** Settings for the Chat Mobs minigame. */
public class MgChatMobsScreen extends MgScreenBase {
    private static final int ITEM_H = 30;
    private static final int ITEMS = 4;
    private static final String[] LABELS = {"Chat Mobs", "Max mobs per chat message", "Blocked mobs (comma list)", "Test"};

    public MgChatMobsScreen(class_437 parent) {
        super("Chat Mobs", parent);
    }

    private void again() { open(new MgChatMobsScreen(parent)); }

    @Override
    protected void method_25426() {
        fields.clear();
        final MgConfig cfg = MgConfig.get();
        for (int i = 0; i < ITEMS; i++) {
            int[] c = cell(i, ITEMS, 40, 70, ITEM_H, 260);
            int x = c[0], y = c[1] + 10, w = c[2];
            switch (i) {
                case 0:
                    addBtn(cfg.chatMobs ? "ON" : "OFF", x, y, w, 18, b -> { cfg.chatMobs = !cfg.chatMobs; cfg.save(); again(); });
                    break;
                case 1: {
                    class_342 f = addField(x, y, w, 18, Integer.toString(cfg.chatMobMax), 2, "max");
                    f.method_1863(s -> cfg.chatMobMax = Math.max(1, Math.min(10, parseInt(s, cfg.chatMobMax))));
                    break;
                }
                case 2: {
                    class_342 f = addField(x, y, w, 18, cfg.chatMobBlocked == null ? "" : cfg.chatMobBlocked, 200, "blocked");
                    f.method_1863(s -> cfg.chatMobBlocked = s);
                    break;
                }
                default:
                    addBtn("Spawn a creeper on me", x, y, w, 18, b -> MgChatModes.testMob("creeper"));
            }
        }
        addBtn("Done", (this.field_22789 - 100) / 2, this.field_22790 - 26, 100, 20, b -> method_25419());
    }

    @Override
    public void method_25419() {
        MgConfig.get().save();
        super.method_25419();
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float delta) {
        renderThemed(g, mx, my, delta, () -> {
            for (int i = 0; i < ITEMS; i++) {
                int[] c = cell(i, ITEMS, 40, 70, ITEM_H, 260);
                txt(g, fit(LABELS[i], c[2]), c[0], c[1], ModUiTheme.TEXT_SECONDARY);
            }
            int w = this.field_22789 - 24;
            txt(g, fit("Any mob name in chat (zombie, creeper, iron golem...) is summoned on you.", w), 12, this.field_22790 - 56, ModUiTheme.TEXT_MUTED);
            txt(g, fit("Every mob is allowed. Type mob names above (e.g. wither, warden) to block them.", w), 12, this.field_22790 - 45, ModUiTheme.TEXT_MUTED);
        });
    }
}
