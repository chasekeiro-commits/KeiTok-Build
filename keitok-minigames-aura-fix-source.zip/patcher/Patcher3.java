import jdk.internal.org.objectweb.asm.*;
import java.nio.file.*;

/** Theme patches. Reads ORIGINAL classes (arg0 = extracted original jar) and writes patched ones into arg1. Idempotent. */
public class Patcher3 {
    static final String FX = "takeyourminestream/ijustseen/minigames/MgThemeFx";
    static int n = 0;

    interface Hook { void at(MethodVisitor mv, int op); }

    static void patch(Path src, Path dst, String method, String desc, int atOp, boolean entry, Hook h) throws Exception {
        byte[] in = Files.readAllBytes(src);
        ClassReader cr = new ClassReader(in);
        ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
        cr.accept(new ClassVisitor(Opcodes.ASM9, cw) {
            public MethodVisitor visitMethod(int acc, String name, String d, String sig, String[] ex) {
                MethodVisitor mv = super.visitMethod(acc, name, d, sig, ex);
                if (!name.equals(method) || !d.equals(desc)) return mv;
                return new MethodVisitor(Opcodes.ASM9, mv) {
                    public void visitCode() {
                        super.visitCode();
                        if (entry) { h.at(this, -1); n++; }
                    }
                    public void visitInsn(int op) {
                        if (!entry && op == atOp) { h.at(this, op); n++; }
                        super.visitInsn(op);
                    }
                };
            }
        }, 0);
        Files.write(dst, cw.toByteArray());
    }

    public static void main(String[] a) throws Exception {
        Path o = Paths.get(a[0]).resolve("takeyourminestream/ijustseen");
        Path d = Paths.get(a[1]).resolve("takeyourminestream/ijustseen");
        final String G = "net/minecraft/class_332";
        // 1. menu panels: animated border for every theme
        patch(o.resolve("ui/gui/ModUiTheme.class"), d.resolve("ui/gui/ModUiTheme.class"), "drawBorderedPanel", "(L" + G + ";IIII)V", Opcodes.RETURN, false, (mv, op) -> {
            mv.visitVarInsn(Opcodes.ALOAD, 0);
            for (int i = 1; i <= 4; i++) mv.visitVarInsn(Opcodes.ILOAD, i);
            mv.visitMethodInsn(Opcodes.INVOKESTATIC, FX, "menuBorder", "(L" + G + ";IIII)V", false);
        });
        // 2. comment popups: animated border
        patch(o.resolve("ui/gui/MessagePanelGuiRenderer.class"), d.resolve("ui/gui/MessagePanelGuiRenderer.class"), "drawPanel", "(L" + G + ";IIIIFI)V", Opcodes.RETURN, false, (mv, op) -> {
            mv.visitVarInsn(Opcodes.ALOAD, 0);
            for (int i = 1; i <= 4; i++) mv.visitVarInsn(Opcodes.ILOAD, i);
            mv.visitVarInsn(Opcodes.FLOAD, 5);
            mv.visitMethodInsn(Opcodes.INVOKESTATIC, FX, "commentBorder", "(L" + G + ";IIIIF)V", false);
        });
        // 3. comment popup colors
        String EV = "takeyourminestream/ijustseen/integration/chat/ChatEventType";
        Path mpc = o.resolve("core/MessagePanelColors.class");
        Path mpcOut = d.resolve("core/MessagePanelColors.class");
        patch(mpc, mpcOut, "baseRgb", "(L" + EV + ";)I", Opcodes.IRETURN, false, (mv, op) ->
            mv.visitMethodInsn(Opcodes.INVOKESTATIC, FX, "baseFilter", "(I)I", false));
        patch(mpcOut, mpcOut, "borderRgb", "(IL" + EV + ";)I", Opcodes.IRETURN, false, (mv, op) ->
            mv.visitMethodInsn(Opcodes.INVOKESTATIC, FX, "borderFilter", "(I)I", false));
        // 4. themes screen: remember it + ask after a theme is picked
        Path ts = o.resolve("ui/screen/ThemesScreen.class");
        Path tsOut = d.resolve("ui/screen/ThemesScreen.class");
        patch(ts, tsOut, "lambda$init$0", "(Ljava/lang/String;Lnet/minecraft/class_4185;)V", Opcodes.RETURN, false, (mv, op) ->
            mv.visitMethodInsn(Opcodes.INVOKESTATIC, FX, "askAboutComments", "()V", false));
        patch(tsOut, tsOut, "method_25426", "()V", 0, true, (mv, op) -> {
            mv.visitVarInsn(Opcodes.ALOAD, 0);
            mv.visitMethodInsn(Opcodes.INVOKESTATIC, FX, "rememberThemes", "(Lnet/minecraft/class_437;)V", false);
        });
        System.out.println("theme patch points applied: " + n + " (expected 6)");
        if (n != 6) System.exit(2);
    }
}
