import jdk.internal.org.objectweb.asm.*;
import java.nio.file.*;

/** Adds "/keitok force" (and /streamchat, /minestream force) to CommandManager.buildRootCommand. */
public class Patcher2 {
    public static void main(String[] a) throws Exception {
        Path p = Paths.get(a[0]).resolve("takeyourminestream/ijustseen/commands/CommandManager.class");
        byte[] in = Files.readAllBytes(p);
        ClassReader cr = new ClassReader(in);
        ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
        final int[] n = {0};
        cr.accept(new ClassVisitor(Opcodes.ASM9, cw) {
            public MethodVisitor visitMethod(int acc, String name, String desc, String sig, String[] ex) {
                MethodVisitor mv = super.visitMethod(acc, name, desc, sig, ex);
                if (!name.equals("buildRootCommand")) return mv;
                return new MethodVisitor(Opcodes.ASM9, mv) {
                    public void visitInsn(int op) {
                        if (op == Opcodes.ARETURN) {
                            String LAB = "com/mojang/brigadier/builder/LiteralArgumentBuilder";
                            String AB = "com/mojang/brigadier/builder/ArgumentBuilder";
                            super.visitLdcInsn("force");
                            super.visitMethodInsn(Opcodes.INVOKESTATIC, "net/fabricmc/fabric/api/client/command/v2/ClientCommandManager", "literal", "(Ljava/lang/String;)L" + LAB + ";", false);
                            super.visitTypeInsn(Opcodes.NEW, "takeyourminestream/ijustseen/minigames/MgForceCommand");
                            super.visitInsn(Opcodes.DUP);
                            super.visitMethodInsn(Opcodes.INVOKESPECIAL, "takeyourminestream/ijustseen/minigames/MgForceCommand", "<init>", "()V", false);
                            super.visitMethodInsn(Opcodes.INVOKEVIRTUAL, LAB, "executes", "(Lcom/mojang/brigadier/Command;)L" + AB + ";", false);
                            super.visitMethodInsn(Opcodes.INVOKEVIRTUAL, LAB, "then", "(L" + AB + ";)L" + AB + ";", false);
                            super.visitTypeInsn(Opcodes.CHECKCAST, LAB);
                            n[0]++;
                        }
                        super.visitInsn(op);
                    }
                };
            }
        }, 0);
        Files.write(p, cw.toByteArray());
        System.out.println("force patched returns: " + n[0]);
        if (n[0] != 1) System.exit(2);
    }
}
