import jdk.internal.org.objectweb.asm.*;
import java.nio.file.*;

/** Patches the compiled KeiTok classes in place (input dir -> same dir) to wire in Interactive Minigames. */
public class Patcher implements Opcodes {
    static final String HOOKS = "takeyourminestream/ijustseen/minigames/MgHooks";
    static final String SCREEN = "takeyourminestream/ijustseen/ui/screen/ModConfigScreen";
    static final String ENTRY = SCREEN + "$ConfigEntry";
    static final String ETYPE = SCREEN + "$ConfigEntryType";
    static final String ECAT = SCREEN + "$ConfigCategory";
    static final String OPEN = "takeyourminestream/ijustseen/ui/screen/MinigamesOpen";
    static int hits = 0;

    interface Entry { void emit(MethodVisitor mv); }

    static byte[] entryHook(byte[] in, String method, String desc, Entry e) {
        ClassReader cr = new ClassReader(in);
        ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
        cr.accept(new ClassVisitor(ASM9, cw) {
            @Override public MethodVisitor visitMethod(int acc, String name, String d, String sig, String[] ex) {
                MethodVisitor mv = super.visitMethod(acc, name, d, sig, ex);
                if (name.equals(method) && d.equals(desc)) {
                    hits++;
                    return new MethodVisitor(ASM9, mv) {
                        @Override public void visitCode() { super.visitCode(); e.emit(mv); }
                    };
                }
                return mv;
            }
        }, 0);
        return cw.toByteArray();
    }

    static byte[] patchConfigScreen(byte[] in) {
        ClassReader cr = new ClassReader(in);
        ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
        final boolean[] injected = {false};
        cr.accept(new ClassVisitor(ASM9, cw) {
            @Override public MethodVisitor visitMethod(int acc, String name, String d, String sig, String[] ex) {
                MethodVisitor mv = super.visitMethod(acc, name, d, sig, ex);
                if (name.equals("createConfigEntries") && d.equals("()V")) {
                    return new MethodVisitor(ASM9, mv) {
                        @Override public void visitLdcInsn(Object v) {
                            if (!injected[0] && "takeyourstreamchat.config.regexps_config".equals(v)) {
                                injected[0] = true;
                                super.visitVarInsn(ALOAD, 0);
                                super.visitMethodInsn(INVOKESPECIAL, SCREEN, "kt$addMinigamesEntry", "()V", false);
                            }
                            super.visitLdcInsn(v);
                        }
                    };
                }
                return mv;
            }
            @Override public void visitEnd() {
                MethodVisitor m = super.visitMethod(ACC_PRIVATE | ACC_SYNTHETIC, "kt$addMinigamesEntry", "()V", null, null);
                m.visitCode();
                m.visitLdcInsn("takeyourstreamchat.config.minigames.button");
                m.visitMethodInsn(INVOKESTATIC, "net/minecraft/class_2561", "method_43471", "(Ljava/lang/String;)Lnet/minecraft/class_5250;", true);
                m.visitTypeInsn(NEW, OPEN);
                m.visitInsn(DUP);
                m.visitVarInsn(ALOAD, 0);
                m.visitMethodInsn(INVOKESPECIAL, OPEN, "<init>", "(Lnet/minecraft/class_437;)V", false);
                m.visitMethodInsn(INVOKESTATIC, "net/minecraft/class_4185", "method_46430",
                    "(Lnet/minecraft/class_2561;Lnet/minecraft/class_4185$class_4241;)Lnet/minecraft/class_4185$class_7840;", false);
                m.visitInsn(ICONST_0);
                m.visitInsn(ICONST_0);
                m.visitIntInsn(SIPUSH, 170);
                m.visitIntInsn(BIPUSH, 20);
                m.visitMethodInsn(INVOKEVIRTUAL, "net/minecraft/class_4185$class_7840", "method_46434",
                    "(IIII)Lnet/minecraft/class_4185$class_7840;", false);
                m.visitMethodInsn(INVOKEVIRTUAL, "net/minecraft/class_4185$class_7840", "method_46431",
                    "()Lnet/minecraft/class_4185;", false);
                m.visitVarInsn(ASTORE, 1);
                m.visitVarInsn(ALOAD, 0);
                m.visitVarInsn(ALOAD, 1);
                m.visitMethodInsn(INVOKEVIRTUAL, SCREEN, "method_37063", "(Lnet/minecraft/class_364;)Lnet/minecraft/class_364;", false);
                m.visitInsn(POP);
                m.visitVarInsn(ALOAD, 0);
                m.visitFieldInsn(GETFIELD, SCREEN, "configEntries", "Ljava/util/List;");
                m.visitTypeInsn(NEW, ENTRY);
                m.visitInsn(DUP);
                m.visitLdcInsn("takeyourstreamchat.config.minigames");
                m.visitLdcInsn("takeyourstreamchat.config.minigames.desc");
                m.visitFieldInsn(GETSTATIC, ETYPE, "BUTTON", "L" + ETYPE + ";");
                m.visitVarInsn(ALOAD, 1);
                m.visitFieldInsn(GETSTATIC, ECAT, "GENERAL", "L" + ECAT + ";");
                m.visitMethodInsn(INVOKESPECIAL, ENTRY, "<init>",
                    "(Ljava/lang/String;Ljava/lang/String;L" + ETYPE + ";Ljava/lang/Object;L" + ECAT + ";)V", false);
                m.visitMethodInsn(INVOKEINTERFACE, "java/util/List", "add", "(Ljava/lang/Object;)Z", true);
                m.visitInsn(POP);
                m.visitInsn(RETURN);
                m.visitMaxs(0, 0);
                m.visitEnd();
                super.visitEnd();
            }
        }, 0);
        if (!injected[0]) throw new IllegalStateException("config screen anchor not found");
        hits++;
        return cw.toByteArray();
    }

    static final String AURA_UI = "takeyourminestream/ijustseen/aura/AuraUi";

    /** Calls AuraUi.afterBottomButtons(this, themesButton) at the end of createBottomButtons (the Themes button's row). */
    static byte[] patchAuraButton(byte[] in) {
        ClassReader cr = new ClassReader(in);
        ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
        final boolean[] injected = {false};
        cr.accept(new ClassVisitor(ASM9, cw) {
            @Override public MethodVisitor visitMethod(int acc, String name, String d, String sig, String[] ex) {
                MethodVisitor mv = super.visitMethod(acc, name, d, sig, ex);
                if (name.equals("createBottomButtons") && d.equals("()V")) {
                    return new MethodVisitor(ASM9, mv) {
                        @Override public void visitInsn(int op) {
                            if (op == RETURN) {
                                injected[0] = true;
                                super.visitVarInsn(ALOAD, 0);
                                super.visitVarInsn(ALOAD, 0);
                                super.visitFieldInsn(GETFIELD, SCREEN, "themesButton", "Lnet/minecraft/class_4185;");
                                super.visitMethodInsn(INVOKESTATIC, AURA_UI, "afterBottomButtons",
                                    "(Lnet/minecraft/class_437;Lnet/minecraft/class_4185;)V", false);
                            }
                            super.visitInsn(op);
                        }
                    };
                }
                return mv;
            }
        }, 0);
        if (!injected[0]) throw new IllegalStateException("bottom buttons anchor not found");
        hits++;
        return cw.toByteArray();
    }

    static void patch(Path root, String cls, java.util.function.Function<byte[], byte[]> f) throws Exception {
        Path p = root.resolve(cls + ".class");
        Files.write(p, f.apply(Files.readAllBytes(p)));
    }

    public static void main(String[] a) throws Exception {
        Path root = Paths.get(a[0]);
        String tk = "takeyourminestream/ijustseen/integration/";
        patch(root, tk + "tiktok/TikTokChatClient$1", b -> {
            b = entryHook(b, "onGift", "(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V", mv -> {
                mv.visitVarInsn(LLOAD, 1); mv.visitVarInsn(ALOAD, 3); mv.visitVarInsn(ALOAD, 4);
                mv.visitVarInsn(ALOAD, 5); mv.visitVarInsn(ILOAD, 6);
                mv.visitMethodInsn(INVOKESTATIC, HOOKS, "onTikTokGift", "(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V", false);
            });
            b = entryHook(b, "onFollow", "(JLjava/lang/String;Ljava/lang/String;)V", mv -> {
                mv.visitVarInsn(LLOAD, 1); mv.visitVarInsn(ALOAD, 3); mv.visitVarInsn(ALOAD, 4);
                mv.visitMethodInsn(INVOKESTATIC, HOOKS, "onTikTokFollow", "(JLjava/lang/String;Ljava/lang/String;)V", false);
            });
            b = entryHook(b, "onSubscribe", "(JLjava/lang/String;Ljava/lang/String;)V", mv -> {
                mv.visitVarInsn(LLOAD, 1); mv.visitVarInsn(ALOAD, 3); mv.visitVarInsn(ALOAD, 4);
                mv.visitMethodInsn(INVOKESTATIC, HOOKS, "onTikTokSubscribe", "(JLjava/lang/String;Ljava/lang/String;)V", false);
            });
            return b;
        });
        patch(root, tk + "tiktok/TikTokWebSocket", b -> entryHook(b, "dispatchMessage",
            "(L" + tk + "tiktok/proto/TikTokProto$ProtoMap;)V", mv -> {
                mv.visitVarInsn(ALOAD, 1);
                mv.visitMethodInsn(INVOKESTATIC, HOOKS, "onTikTokRaw", "(L" + tk + "tiktok/proto/TikTokProto$ProtoMap;)V", false);
            }));
        patch(root, tk + "chat/ChatMessagePipeline", b -> {
            b = entryHook(b, "process", "(L" + tk + "chat/IncomingChatMessage;)V", mv -> {
                mv.visitVarInsn(ALOAD, 1);
                mv.visitMethodInsn(INVOKESTATIC, HOOKS, "onMessage", "(L" + tk + "chat/IncomingChatMessage;)V", false);
            });
            b = entryHook(b, "processYouTubeBatch", "(Ljava/util/List;)V", mv -> {
                mv.visitVarInsn(ALOAD, 1);
                mv.visitMethodInsn(INVOKESTATIC, HOOKS, "onMessageBatch", "(Ljava/util/List;)V", false);
            });
            return b;
        });
        patch(root, "takeyourminestream/ijustseen/messages/MessageHudRenderer", b -> entryHook(b, "renderHudMessages",
            "(Lnet/minecraft/class_332;)V", mv -> {
                mv.visitVarInsn(ALOAD, 1);
                mv.visitMethodInsn(INVOKESTATIC, "takeyourminestream/ijustseen/minigames/MgHud", "render", "(Lnet/minecraft/class_332;)V", false);
            }));
        patch(root, SCREEN, b -> patchAuraButton(patchConfigScreen(b)));
        System.out.println("patch points applied: " + hits + " (expected 9)");
        if (hits != 9) System.exit(2);
    }
}
