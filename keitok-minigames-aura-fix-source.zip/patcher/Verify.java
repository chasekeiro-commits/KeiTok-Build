import jdk.internal.org.objectweb.asm.*;
import jdk.internal.org.objectweb.asm.tree.*;
import jdk.internal.org.objectweb.asm.tree.analysis.*;
import java.nio.file.*;
import java.util.*;

public class Verify {
    public static void main(String[] a) throws Exception {
        int bad = 0, methods = 0, classes = 0;
        List<Path> files = new ArrayList<>();
        try (var s = Files.walk(Paths.get(a[0]))) { s.filter(p -> p.toString().endsWith(".class")).forEach(files::add); }
        for (Path f : files) {
            String rel = Paths.get(a[0]).relativize(f).toString();
            boolean mine = rel.contains("minigames") || rel.contains("Mg") || rel.contains("Minigame")
                || rel.contains("/aura/") || rel.endsWith("AuraScreen.class");
            boolean patched = rel.contains("TikTokChatClient$1") || rel.endsWith("TikTokWebSocket.class") || rel.endsWith("ChatMessagePipeline.class")
                || rel.endsWith("ModConfigScreen.class") || rel.endsWith("MessageHudRenderer.class");
            if (!mine && !patched) continue;
            classes++;
            ClassNode cn = new ClassNode();
            new ClassReader(Files.readAllBytes(f)).accept(cn, 0);
            for (MethodNode mn : cn.methods) {
                if (mn.instructions.size() == 0) continue;
                methods++;
                try {
                    new Analyzer<>(new BasicVerifier()).analyze(cn.name, mn);
                } catch (Exception e) {
                    bad++;
                    System.out.println("FAIL " + cn.name + "." + mn.name + mn.desc + " : " + e.getMessage());
                }
            }
        }
        System.out.println("verified " + classes + " classes / " + methods + " methods, failures: " + bad);
    }
}
