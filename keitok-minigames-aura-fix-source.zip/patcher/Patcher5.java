import jdk.internal.org.objectweb.asm.*;
import java.nio.file.*;

/** Adds the theme animation to the in-world comment panels. Reads the ORIGINAL class (arg0) and writes into arg1. Idempotent. */
public class Patcher5 {
    static int n = 0;
    public static void main(String[] a) throws Exception {
        String rel = "takeyourminestream/ijustseen/core/render/MessagePanelWorldRenderer.class";
        Path src = Paths.get(a[0]).resolve(rel), dst = Paths.get(a[1]).resolve(rel);
        ClassReader cr = new ClassReader(Files.readAllBytes(src));
        ClassWriter cw = new ClassWriter(cr, ClassWriter.COMPUTE_MAXS);
        cr.accept(new ClassVisitor(Opcodes.ASM9, cw) {
            public MethodVisitor visitMethod(int acc, String name, String d, String sig, String[] ex) {
                MethodVisitor mv = super.visitMethod(acc, name, d, sig, ex);
                if (!name.equals("drawPanelWithBorder") || !d.equals("(Lnet/minecraft/class_4587;Lnet/minecraft/class_4597;IIIIFI)V")) return mv;
                return new MethodVisitor(Opcodes.ASM9, mv) {
                    public void visitInsn(int op) {
                        if (op == Opcodes.RETURN) {
                            super.visitVarInsn(Opcodes.ALOAD, 0);
                            super.visitVarInsn(Opcodes.ALOAD, 1);
                            for (int i = 2; i <= 5; i++) super.visitVarInsn(Opcodes.ILOAD, i);
                            super.visitVarInsn(Opcodes.FLOAD, 6);
                            super.visitMethodInsn(Opcodes.INVOKESTATIC, "takeyourminestream/ijustseen/minigames/MgWorldFx", "border",
                                "(Lnet/minecraft/class_4587;Lnet/minecraft/class_4597;IIIIF)V", false);
                            n++;
                        }
                        super.visitInsn(op);
                    }
                };
            }
        }, 0);
        Files.write(dst, cw.toByteArray());
        System.out.println("world panel hooks: " + n + " (expected >= 1)");
        if (n < 1) System.exit(2);
    }
}
