package takeyourminestream.ijustseen.aura;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_3222;

/**
 * Runs the real reflective wiring (PresenceWire, PresenceServerImpl) against the test doubles in test-fakes/.
 * It proves the mechanics: payload proxies, codecs, handlers, the hub and the leave event.
 * It does NOT prove the intermediary names, which only a run of the real game can show.
 */
public final class PresenceWireTest {
    static int passed = 0, failed = 0;

    static void check(boolean ok, String what) {
        if (ok) {
            passed++;
        } else {
            failed++;
            System.out.println("FAIL: " + what);
        }
    }

    /** The player says hello. The fake server treats the player's client as one that accepts the roster channel. */
    static void hello(class_3222 player, String version) throws Exception {
        ServerPlayNetworking.sender = player;
        ServerPlayNetworking.CAN_RECEIVE.add(player);
        PresenceWire.clientSend(PresenceWire.helloId(), PresenceCodec.encodeHello(version));
    }

    public static void main(String[] args) throws Exception {
        UUID annId = new UUID(1, 1);
        UUID bobId = new UUID(2, 2);
        class_3222 ann = new class_3222("Ann", annId);
        class_3222 bob = new class_3222("Bob", bobId);
        class_3222 cat = new class_3222("Cat", new UUID(3, 3));
        class_3222 dan = new class_3222("Dan", new UUID(4, 4));

        PresenceWire.registerTypes();
        List<byte[]> rosters = new ArrayList<>();
        PresenceWire.clientOnReceive(PresenceWire.rosterId(), rosters::add);
        PresenceServerImpl.init();
        check(PresenceWire.clientCanSend(PresenceWire.helloId()), "the client may send hello once the server listens");
        check(PresenceWire.uuidOf(ann).equals(annId) && PresenceWire.nameOf(ann).equals("Ann"),
            "uuid and name come from the player's profile");
        check(!PresenceWire.serverCanSend(ann, PresenceWire.rosterId()), "no roster until the client accepts the channel");

        // Ann says hello: she is the only one listed, and her list goes to her, marked self.
        hello(ann, "8.0.0");
        check(rosters.size() == 1, "Ann's hello sends one list");
        List<Presence.Entry> one = PresenceCodec.decodePresence(rosters.get(0));
        check(one.size() == 1 && one.get(0).id.equals(annId) && one.get(0).self
            && one.get(0).name.equals("Ann") && one.get(0).version.equals("8.0.0"),
            "Ann sees herself, marked self, with her name and version");

        // Bob says hello: both get the list, and each list marks only the reader as self.
        rosters.clear();
        hello(bob, "8.0.0");
        check(rosters.size() == 2, "Bob's hello sends the list to both players");
        List<Presence.Entry> toAnn = PresenceCodec.decodePresence(rosters.get(0));
        List<Presence.Entry> toBob = PresenceCodec.decodePresence(rosters.get(1));
        check(toAnn.size() == 2 && toAnn.get(0).self && !toAnn.get(1).self, "Ann's list marks only Ann");
        check(toBob.size() == 2 && !toBob.get(0).self && toBob.get(1).self && toBob.get(1).id.equals(bobId),
            "Bob's list marks only Bob");

        // A malformed hello is ignored: nothing is sent.
        rosters.clear();
        ServerPlayNetworking.sender = cat;
        ServerPlayNetworking.CAN_RECEIVE.add(cat);
        PresenceWire.clientSend(PresenceWire.helloId(), new byte[] {9});
        check(rosters.isEmpty(), "a malformed hello sends nothing");

        // Cat says a valid hello: three lists go out, and each has three players.
        hello(cat, "8.0.0");
        check(rosters.size() == 3, "Cat's hello sends a list to all three");
        check(PresenceCodec.decodePresence(rosters.get(2)).size() == 3, "the list has all three players");

        // Bob's client no longer accepts the channel: he is skipped, but the others still get the change.
        rosters.clear();
        ServerPlayNetworking.CAN_RECEIVE.remove(bob);
        hello(cat, "8.0.1");
        check(rosters.size() == 2, "a player who cannot receive the channel is skipped");
        check(PresenceCodec.decodePresence(rosters.get(0)).size() == 3, "Bob stays listed for the others");
        ServerPlayNetworking.CAN_RECEIVE.add(bob);

        // Ann leaves: the others get the list without her. A player who never said hello leaving changes nothing.
        rosters.clear();
        ServerPlayerEvents.fireLeave(ann);
        check(rosters.size() == 2, "the remaining players get the list after Ann leaves");
        boolean annGone = true;
        for (byte[] b : rosters) {
            List<Presence.Entry> l = PresenceCodec.decodePresence(b);
            for (Presence.Entry e : l) {
                if (e.id.equals(annId)) annGone = false;
            }
        }
        check(annGone, "Ann is gone from every list");
        rosters.clear();
        ServerPlayerEvents.fireLeave(dan);
        check(rosters.isEmpty(), "a player who never said hello leaving changes nothing");
        ServerPlayerEvents.fireLeave(ann);
        check(rosters.isEmpty(), "Ann leaving twice changes nothing");

        System.out.println("presence wiring: passed " + passed + ", failed " + failed);
        if (failed > 0) System.exit(1);
    }
}
