package takeyourminestream.ijustseen.aura;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** Headless tests for the server side of the presence (PresenceHub) and the hello codec. */
public final class PresenceHubTests {
    static int passed = 0, failed = 0;

    static void check(boolean ok, String what) {
        if (ok) passed++;
        else {
            failed++;
            System.out.println("FAIL: " + what);
        }
    }

    /** A fake server: a link is just a name. Every send is recorded, and some links can be made unable to receive. */
    static final class FakePort implements PresenceHub.Port<String> {
        final Set<String> cannotReceive = new HashSet<>();
        final List<String> sentTo = new ArrayList<>();
        final List<byte[]> sent = new ArrayList<>();

        @Override
        public boolean canSend(String link) {
            return !cannotReceive.contains(link);
        }

        @Override
        public void send(String link, byte[] roster) {
            sentTo.add(link);
            sent.add(roster);
        }

        void reset() {
            sentTo.clear();
            sent.clear();
        }
    }

    static final UUID A = new UUID(1, 1), B = new UUID(2, 2), C = new UUID(3, 3);

    static List<Presence.Entry> decode(byte[] data) throws IOException {
        return PresenceCodec.decodePresence(data);
    }

    static void helloAndRoster() throws IOException {
        FakePort port = new FakePort();
        PresenceHub<String> hub = new PresenceHub<>(port, 1024);
        check(hub.onHello("linkA", A, "Ann", "8.0.0"), "first hello changes the list");
        check(port.sentTo.equals(List.of("linkA")), "first hello sends the list to that player only");
        List<Presence.Entry> lone = decode(port.sent.get(0));
        check(lone.size() == 1 && lone.get(0).self, "a lone player sees only themself, marked self");
        port.reset();
        check(hub.onHello("linkB", B, "Bob", "8.0.0"), "second hello changes the list");
        check(port.sentTo.equals(List.of("linkA", "linkB")), "both players get the new list");
        List<Presence.Entry> toA = decode(port.sent.get(0));
        List<Presence.Entry> toB = decode(port.sent.get(1));
        check(toA.size() == 2 && toB.size() == 2, "each list has both players");
        check(toA.get(0).id.equals(A) && toA.get(0).self && !toA.get(1).self, "A's list marks only A as self");
        check(toB.get(0).id.equals(A) && !toB.get(0).self && toB.get(1).id.equals(B) && toB.get(1).self,
            "B's list marks only B as self");
        check(toA.get(1).name.equals("Bob") && toA.get(1).version.equals("8.0.0"), "names and versions are carried");
    }

    static void sameHelloTwiceSendsNothing() {
        FakePort port = new FakePort();
        PresenceHub<String> hub = new PresenceHub<>(port, 1024);
        hub.onHello("linkA", A, "Ann", "8.0.0");
        port.reset();
        check(!hub.onHello("linkA", A, "Ann", "8.0.0"), "the same hello again changes nothing");
        check(port.sent.isEmpty(), "the same hello again sends nothing");
        check(hub.onHello("linkA", A, "Ann", "8.0.1"), "a new version is an update");
        check(port.sent.size() == 1, "an update sends the list again");
    }

    static void leaveOnlyFromTheSameConnection() throws IOException {
        FakePort port = new FakePort();
        PresenceHub<String> hub = new PresenceHub<>(port, 1024);
        hub.onHello("linkA", A, "Ann", "8.0.0");
        hub.onHello("linkB", B, "Bob", "8.0.0");
        port.reset();
        check(!hub.onLeave("otherLink", A), "a leave from another connection is ignored");
        check(hub.size() == 2 && port.sent.isEmpty(), "an ignored leave changes nothing");
        check(hub.onLeave("linkA", A), "the real leave removes the player");
        check(hub.size() == 1, "one player is left");
        check(port.sentTo.equals(List.of("linkB")), "the remaining player gets the new list");
        check(decode(port.sent.get(0)).size() == 1, "the new list has only B");
        check(!hub.onLeave("linkA", A), "leaving twice does nothing");
    }

    static void unreachablePlayersAreSkipped() {
        FakePort port = new FakePort();
        PresenceHub<String> hub = new PresenceHub<>(port, 1024);
        port.cannotReceive.add("linkA");
        hub.onHello("linkA", A, "Ann", "8.0.0");
        hub.onHello("linkB", B, "Bob", "8.0.0");
        check(!port.sentTo.contains("linkA"), "a player who cannot receive the channel is not sent the list");
        check(port.sentTo.contains("linkB"), "the others still get the list");
        check(hub.size() == 2, "a player who cannot receive is still listed for the others");
    }

    static void capIsEnforced() {
        FakePort port = new FakePort();
        PresenceHub<String> hub = new PresenceHub<>(port, 2);
        hub.onHello("linkA", A, "Ann", "8.0.0");
        hub.onHello("linkB", B, "Bob", "8.0.0");
        check(!hub.onHello("linkC", C, "Cat", "8.0.0"), "a third player is not listed when the cap is 2");
        check(hub.size() == 2, "the list stays at the cap");
    }

    static void clearForgetsEveryone() {
        FakePort port = new FakePort();
        PresenceHub<String> hub = new PresenceHub<>(port, 1024);
        hub.onHello("linkA", A, "Ann", "8.0.0");
        hub.clear();
        check(hub.size() == 0, "clear forgets everyone");
    }

    static void badInputIsSafe() throws IOException {
        FakePort port = new FakePort();
        PresenceHub<String> hub = new PresenceHub<>(port, 1024);
        check(!hub.onHello(null, A, "Ann", "8.0.0"), "a null link is ignored");
        check(!hub.onHello("linkA", null, "Ann", "8.0.0"), "a null id is ignored");
        check(hub.onHello("linkA", A, "x".repeat(200), null), "a long name and a null version are accepted");
        List<Presence.Entry> e = decode(port.sent.get(0));
        check(e.get(0).name.length() == PresenceCodec.MAX_STRING && e.get(0).version.isEmpty(),
            "long names are clipped and a null version becomes empty");
    }

    static boolean rejectsHello(byte[] data) {
        try {
            PresenceCodec.decodeHello(data);
            return false;
        } catch (IOException e) {
            return true;
        }
    }

    static byte[] helloWithVersion(String version) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (DataOutputStream out = new DataOutputStream(bytes)) {
            out.writeByte(PresenceCodec.PROTOCOL);
            out.writeUTF(version);
        }
        return bytes.toByteArray();
    }

    static void helloCodec() throws IOException {
        check("8.0.0".equals(PresenceCodec.decodeHello(PresenceCodec.encodeHello("8.0.0"))), "hello round trip");
        check("".equals(PresenceCodec.decodeHello(PresenceCodec.encodeHello(null))), "a null version is sent as empty");
        check(rejectsHello(new byte[0]), "an empty hello is rejected");
        check(rejectsHello(new byte[] {9, 0, 1, 'x'}), "an unknown protocol is rejected");
        check(rejectsHello(helloWithVersion("x".repeat(65))), "a version over 64 characters is rejected");
        byte[] ok = PresenceCodec.encodeHello("8.0.0");
        check(rejectsHello(Arrays.copyOf(ok, ok.length + 1)), "trailing bytes are rejected");
        check(!rejectsHello(helloWithVersion("x".repeat(64))), "a 64-character version is accepted");
    }

    public static void main(String[] args) throws Exception {
        helloAndRoster();
        sameHelloTwiceSendsNothing();
        leaveOnlyFromTheSameConnection();
        unreachablePlayersAreSkipped();
        capIsEnforced();
        clearForgetsEveryone();
        badInputIsSafe();
        helloCodec();
        System.out.println("presence hub: passed " + passed + ", failed " + failed);
        if (failed > 0) System.exit(1);
    }
}
