package takeyourminestream.ijustseen.aura;

import com.sun.management.ThreadMXBean;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.lang.management.ManagementFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Headless tests for the aura: run with `java -cp build/pure:build/test ...AuraTests`. */
public final class AuraTests {
    static int passed = 0, failed = 0;

    static void check(boolean ok, String what) {
        if (ok) passed++;
        else {
            failed++;
            System.out.println("FAIL: " + what);
        }
    }

    /** Counts quads and checks every coordinate is finite. */
    static final class CountingSink implements AuraRenderer.QuadSink {
        int quads;
        int bad;
        int[] perTex = new int[3];
        double maxRadius;

        static int finiteFail(double d) {
            return (Double.isNaN(d) || Double.isInfinite(d)) ? 1 : 0;
        }

        @Override
        public void quad(int tex, double ax, double ay, double az, double bx, double by, double bz,
                         double cx, double cy, double cz, double dx, double dy, double dz,
                         float r, float g, float b, float a) {
            quads++;
            if (tex >= 0 && tex < 3) perTex[tex]++;
            bad += finiteFail(ax) + finiteFail(ay) + finiteFail(az) + finiteFail(bx) + finiteFail(by) + finiteFail(bz)
                + finiteFail(cx) + finiteFail(cy) + finiteFail(cz) + finiteFail(dx) + finiteFail(dy) + finiteFail(dz);
            maxRadius = Math.max(maxRadius, Math.abs(ax) + Math.abs(az));
        }
    }

    static AuraLook look(int design) {
        AuraLook l = new AuraLook();
        l.design = design;
        return l;
    }

    static AuraTargets oneTarget(double x, double y, double z) {
        AuraTargets t = new AuraTargets();
        t.beginTick();
        t.add(1, 1, true, true, "me", x, y, z, 0, 1.8, 40);
        return t;
    }

    public static void main(String[] args) throws Exception {
        testDesigns();
        testGovernor();
        testCodec();
        testPresence();
        testTargets();
        testRenderer();
        testWinding();
        testPerformanceAndMemory();
        System.out.println("passed " + passed + ", failed " + failed);
        if (failed > 0) System.exit(1);
    }

    static void testDesigns() {
        check(AuraDesigns.COUNT == 26, "26 designs");
        java.util.Set<String> names = new java.util.HashSet<>();
        for (int d = 1; d <= 26; d++) {
            String n = AuraDesigns.name(d);
            check(n != null && !n.isEmpty(), "design " + d + " has a name");
            names.add(n);
            check(AuraDesigns.param(d, 0) >= 0 && AuraDesigns.param(d, 0) <= 3, "rings range " + d);
            check(AuraDesigns.param(d, 1) >= 0 && AuraDesigns.param(d, 1) <= 12, "orbit range " + d);
            check(AuraDesigns.param(d, 4) >= 0 && AuraDesigns.param(d, 4) <= 30, "sparks range " + d);
            check(AuraDesigns.param(d, 5) >= 0 && AuraDesigns.param(d, 5) < AuraDesigns.WING_STYLES.length, "wing style " + d);
            check(AuraDesigns.param(d, 9) > 0, "speed " + d);
        }
        check(names.size() == 26, "26 distinct names");
        check(AuraDesigns.index(0) == 0 && AuraDesigns.index(99) == 25, "design index is clamped");
        check(AuraDesigns.param(26, 5) == 7, "dragon scales has dragon wings");
    }

    static void testGovernor() {
        AuraGovernor g = new AuraGovernor();
        g.configure(true, 3);
        long t = 0;
        for (int i = 0; i < 200; i++) {
            t += 100;
            g.update(t, 4.0, 40.0); // heavy frames: 40 ms, aura 4 ms
        }
        check(g.level() == 0, "heavy frames drop quality to the lowest level, got " + g.level());

        for (int i = 0; i < 2000; i++) {
            t += 100;
            g.update(t, 0.1, 8.0); // calm frames for 200 s
        }
        check(g.level() == 3, "calm frames raise quality back to ultra, got " + g.level());

        AuraGovernor manual = new AuraGovernor();
        manual.configure(false, 1);
        for (int i = 0; i < 200; i++) manual.update(i * 100L, 9.0, 60.0);
        check(manual.level() == 1, "manual quality never changes");
    }

    static byte[] encodeRaw(int protocol, int count, String name) throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(bytes);
        out.writeByte(protocol);
        out.writeInt(count);
        if (name != null) {
            out.writeLong(1L);
            out.writeLong(2L);
            out.writeUTF(name);
            out.writeUTF("1.0");
            out.writeBoolean(false);
        }
        out.flush();
        return bytes.toByteArray();
    }

    static void testCodec() throws Exception {
        List<Presence.Entry> in = new ArrayList<>();
        in.add(new Presence.Entry(new UUID(5, 6), "Alice", "8.0.0", true));
        in.add(new Presence.Entry(new UUID(7, 8), "Bob", "8.0.0", false));
        List<Presence.Entry> out = PresenceCodec.decodePresence(PresenceCodec.encodePresence(in));
        check(out.size() == 2, "round trip count");
        check(out.get(0).id.equals(new UUID(5, 6)) && out.get(0).self, "round trip first entry");
        check(out.get(1).name.equals("Bob") && !out.get(1).self, "round trip second entry");

        boolean threw = false;
        try { PresenceCodec.decodePresence(encodeRaw(9, 0, null)); } catch (java.io.IOException e) { threw = true; }
        check(threw, "unknown protocol is rejected");

        threw = false;
        try { PresenceCodec.decodePresence(encodeRaw(1, 5000, null)); } catch (java.io.IOException e) { threw = true; }
        check(threw, "huge count is rejected");

        threw = false;
        try {
            PresenceCodec.decodePresence(encodeRaw(1, 1, "x".repeat(200)));
        } catch (java.io.IOException e) { threw = true; }
        check(threw, "overlong name is rejected");

        threw = false;
        try {
            byte[] good = PresenceCodec.encodePresence(in);
            PresenceCodec.decodePresence(java.util.Arrays.copyOf(good, good.length - 5));
        } catch (java.io.IOException e) { threw = true; }
        check(threw, "truncated message is rejected");

        threw = false;
        try { PresenceCodec.decodePresence(new byte[0]); } catch (java.io.IOException e) { threw = true; }
        check(threw, "empty message is rejected");
    }

    static void testPresence() {
        Presence p = new Presence();
        check(!p.isKeiTok(new UUID(1, 1)), "nobody is KeiTok before the server says so");
        List<Presence.Entry> list = new ArrayList<>();
        list.add(new Presence.Entry(new UUID(1, 1), "A", "8", true));
        list.add(new Presence.Entry(new UUID(2, 2), "B", "8", false));
        p.replace(list);
        check(p.isKeiTok(new UUID(2, 2)), "listed player is KeiTok");
        check(!p.isKeiTok(new UUID(3, 3)), "unlisted player is not KeiTok");
        check(p.self() != null && p.self().name.equals("A"), "self entry found");
        p.replace(new ArrayList<>());
        check(!p.isKeiTok(new UUID(2, 2)), "player who left is removed on the next snapshot");
        for (int i = 0; i < Presence.MAX + 500; i++) {
            List<Presence.Entry> big = new ArrayList<>();
            big.add(new Presence.Entry(new UUID(i, i), "p" + i, "8", false));
            p.replace(big);
        }
        check(p.size() <= Presence.MAX, "presence size is capped");
        p.clear();
        check(p.size() == 0 && p.self() == null, "clear empties the cache");
    }

    static void testTargets() {
        AuraTargets t = new AuraTargets();
        t.beginTick();
        t.add(9, 9, false, true, "walker", 0, 64, 0, 0, 1.8, 0);
        t.beginTick();
        t.add(9, 9, false, true, "walker", 10, 64, 0, 0, 1.8, 0);
        double[] out = new double[4];
        t.interpolate(0, 0.0, out);
        check(out[0] == 0, "interpolation starts at the previous tick");
        t.interpolate(0, 1.0, out);
        check(out[0] == 10, "interpolation ends at the current tick");
        t.interpolate(0, 0.5, out);
        check(Math.abs(out[0] - 5) < 1e-9, "interpolation is halfway at alpha 0.5");

        t.beginTick();
        t.add(1, 1, false, true, "far", 100, 0, 0, 0, 1.8, 0);
        t.add(2, 2, false, true, "near", 3, 0, 0, 0, 1.8, 0);
        t.add(3, 3, false, true, "mid", 10, 0, 0, 0, 1.8, 0);
        t.sortByDistance(0, 0, 0);
        check(t.name[0].equals("near") && t.name[1].equals("mid") && t.name[2].equals("far"), "sorted nearest first");
        int capped = 0;
        for (int i = 0; i < AuraTargets.MAX + 10; i++) if (t.add(i, i, false, true, "x", 0, 0, 0, 0, 1.8, 0)) capped++;
        check(capped <= AuraTargets.MAX, "target list has a fixed size");
    }

    static void testRenderer() {
        AuraRenderer r = new AuraRenderer();
        r.setPalette(0xFF2D7DFF, 0xFFFFFFFF, 0xFF1A3FA0);
        for (int d = 1; d <= 26; d++) {
            CountingSink sink = new CountingSink();
            AuraLook l = look(d);
            AuraTargets t = oneTarget(0, 0, 0);
            r.render(t, l, 3, 1.25, 0, 0, 0, 1.0, sink, 100000);
            check(sink.quads > 0, "design " + d + " draws something");
            check(sink.bad == 0, "design " + d + " has finite coordinates");
            check(sink.maxRadius < 6, "design " + d + " stays near the body, radius " + sink.maxRadius);
        }
        // quality and budget
        CountingSink low = new CountingSink();
        CountingSink ultra = new CountingSink();
        AuraTargets t = oneTarget(0, 0, 0);
        r.render(t, look(2), 0, 1.0, 0, 0, 0, 1.0, low, 100000);
        r.render(t, look(2), 3, 1.0, 0, 0, 0, 1.0, ultra, 100000);
        check(low.quads < ultra.quads, "low quality draws fewer quads than ultra (" + low.quads + " < " + ultra.quads + ")");
        CountingSink capped = new CountingSink();
        r.render(t, look(12), 3, 1.0, 0, 0, 0, 1.0, capped, 50);
        check(capped.quads <= 50, "per-frame budget is honoured");

        // range culling
        AuraLook near = look(1);
        near.rangeBlocks = 10;
        CountingSink far = new CountingSink();
        AuraTargets distant = oneTarget(100, 0, 0);
        r.render(distant, near, 3, 1.0, 0, 0, 0, 1.0, far, 100000);
        check(far.quads == 0, "players beyond the range get no aura");

        // disabled
        AuraLook off = look(1);
        off.enabled = false;
        CountingSink none = new CountingSink();
        r.render(t, off, 3, 1.0, 0, 0, 0, 1.0, none, 100000);
        check(none.quads == 0, "disabled aura draws nothing");

        // logos: beside the name, and above the head when no name is known
        CountingSink logo = new CountingSink();
        AuraTargets named = new AuraTargets();
        named.beginTick();
        named.add(4, 4, false, true, "Bob", 0, 64, 0, 0, 1.8, 30);
        named.add(5, 5, false, false, "NotKeitok", 0, 64, 0, 0, 1.8, 30);
        named.add(6, 6, false, true, null, 2, 64, 0, 0, 1.8, 0);
        int drawn = r.renderLogos(named, look(1), 0, 64, 0, 1.0, logo);
        check(drawn == 2, "only KeiTok players get a logo (" + drawn + ")");
        check(logo.perTex[AuraRenderer.TEX_LOGO] == 2, "two logo quads");
    }

    /** Every sprite faces the camera: its corners run counter-clockwise as seen from the camera (back faces are culled). */
    static void testWinding() {
        final int[] bad = {0};
        final int[] total = {0};
        AuraRenderer.QuadSink sink = (tex, ax, ay, az, bx, by, bz, cx, cy, cz, dx, dy, dz, r, g, b, a) -> {
            total[0]++;
            double e1x = bx - ax, e1y = by - ay, e1z = bz - az;
            double e2x = cx - ax, e2y = cy - ay, e2z = cz - az;
            double nx = e1y * e2z - e1z * e2y, ny = e1z * e2x - e1x * e2z, nz = e1x * e2y - e1y * e2x;
            double mx = (ax + bx + cx + dx) / 4, my = (ay + by + cy + dy) / 4, mz = (az + bz + cz + dz) / 4;
            // the camera is at the origin, so the direction from the sprite to it is minus its centre
            if (!(-(nx * mx + ny * my + nz * mz) > 0)) bad[0]++;
        };
        AuraTargets t = new AuraTargets();
        t.beginTick();
        t.add(1, 1, true, true, "a", 3, 0, 0, 0, 1.8, 40);
        t.add(2, 2, false, true, "b", -4, 0, 5, 45, 1.8, 40);
        t.add(3, 3, false, true, "c", 0, 0, -6, 120, 1.8, 40);
        t.add(4, 4, false, true, "d", 7, 2, 7, 200, 1.8, 40);
        AuraRenderer renderer = new AuraRenderer();
        for (int d = 1; d <= AuraDesigns.COUNT; d++) {
            renderer.render(t, look(d), 3, 1.25, 0, 0, 0, 1.0, sink, Integer.MAX_VALUE);
        }
        check(total[0] > 1000, "winding test drew quads (" + total[0] + ")");
        check(bad[0] == 0, "every quad faces the camera counter-clockwise (bad " + bad[0] + ")");
    }

    static void testPerformanceAndMemory() throws Exception {
        AuraRenderer r = new AuraRenderer();
        r.setPalette(0xFF2D7DFF, 0xFFFFFFFF, 0xFF1A3FA0);
        AuraTargets t = new AuraTargets();
        t.beginTick();
        for (int i = 0; i < AuraTargets.MAX; i++) {
            // 48 KeiTok players in a ring 10..30 blocks away
            double ang = i * 0.7;
            t.add(i, i, i == 0, true, "p" + i, 10 + 20 * Math.cos(ang), 64, 10 + 20 * Math.sin(ang), i * 9, 1.8, 40);
        }
        t.sortByDistance(0, 64, 0);
        AuraLook l = look(20);
        CountingSink sink = new CountingSink();
        for (int warm = 0; warm < 300; warm++) {
            r.render(t, l, 3, warm / 20.0, 0, 64, 0, 0.5, sink, 6000);
        }
        ThreadMXBean mx = (ThreadMXBean) ManagementFactory.getThreadMXBean();
        long tid = Thread.currentThread().getId();
        int frames = 2000;
        long alloc0 = mx.getThreadAllocatedBytes(tid);
        long t0 = System.nanoTime();
        int quadTotal = 0;
        for (int f = 0; f < frames; f++) {
            sink.quads = 0;
            r.render(t, l, 3, 10 + f / 20.0, 0, 64, 0, (f % 20) / 20.0, sink, 6000);
            quadTotal += sink.quads;
        }
        long ns = System.nanoTime() - t0;
        long bytes = mx.getThreadAllocatedBytes(tid) - alloc0;
        double msPerFrame = ns / 1e6 / frames;
        System.out.printf("perf: 48 KeiTok players, design 20, ultra: %.3f ms/frame, %d quads/frame, %.1f KB allocated per frame%n",
            msPerFrame, quadTotal / frames, bytes / 1024.0 / frames);
        check(msPerFrame < 3.0, "aura costs under 3 ms per frame on this machine (" + msPerFrame + ")");
        check(bytes / (double) frames < 2048, "aura allocates under 2 KB per frame");

        // Leak check: presence cache under constant join/leave churn stays bounded.
        Presence p = new Presence();
        for (int i = 0; i < 20000; i++) {
            List<Presence.Entry> snap = new ArrayList<>();
            for (int k = 0; k < 40; k++) snap.add(new Presence.Entry(new UUID(i, k), "n", "8", false));
            p.replace(snap);
        }
        check(p.size() == 40, "presence churn does not grow the cache");
    }
}
