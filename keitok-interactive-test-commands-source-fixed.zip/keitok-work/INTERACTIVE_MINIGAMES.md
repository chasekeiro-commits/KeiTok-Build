# KeiTok — Interactive Minigames (1.21.11 source addition)

This source update adds an **Interactive Minigames** button to the main KeiTok settings footer.

## Safety and scope

- Actions are ignored unless the game is in a local singleplayer world.
- The local player must have permission level 2 (commands/cheats enabled).
- Commands are sent through the integrated server's normal command path; they are not sent to multiplayer servers or Realms.
- Turning the feature off clears pending HUD alerts.

## Event command placeholders

The settings screen has command fields for `FOLLOW`, `LIKE`, `SUBSCRIBE`, `GIFT`, `RAID`, and `BITS`.

Available placeholders:

- `{user}` — event sender's display name
- `{event}` — event type
- `{message}` — event text supplied by the chat integration
- `{count}` — event count (test gifts support a count from 1 to 64; live events default to 1)

Commands may be entered with or without a leading `/`. Example commands:

- Follow: `give @p minecraft:iron_ingot 3`
- Subscribe: `effect give @p minecraft:speed 10 1`
- Default gift: `give @p minecraft:diamond 1`
- Raid: `summon minecraft:zombie ~ ~ ~`
- Bits: `give @p minecraft:emerald 2`

## Per-gift overrides

In **Gift overrides**, enter `gift name=command` rules separated by semicolons:

`rose=give @p minecraft:rose_bush 1; doughnut=give @p minecraft:diamond 5`

Gift matching is case-insensitive and uses the longest matching configured gift-name fragment. If no override matches, the default GIFT command is used.

## HUD alerts

Gift/event alerts appear from the top-left, filling left-to-right and then continuing on the next row. The settings let you change alert duration and maximum visible alerts. Alerts currently use a compact dark Minecraft-style card with an event-colored accent.

## Configuration file

Settings are saved to `config/keitok-interactive-minigames.json`.

## Current event coverage

This implementation connects to the event types already emitted by the included integrations: follows, subscriptions, gifts, raids, and bits. Likes are currently supported by the local test command; real likes and donations still need their respective chat adapters.


## In-game test commands

With Interactive Minigames enabled in a singleplayer world with cheats enabled, use:

- `/keitok test gift rose`
- `/keitok test gift rose 5`
- `/keitok test follow`
- `/keitok test like`
- `/keitok test subscribe`
- `/keitok test raid`
- `/keitok test bits`

These simulate a `TestViewer` event, show the matching HUD alert, and run the configured event command (including a matching per-gift override). The `like` event is currently available for local testing; a live platform likes adapter is still required for real likes.
