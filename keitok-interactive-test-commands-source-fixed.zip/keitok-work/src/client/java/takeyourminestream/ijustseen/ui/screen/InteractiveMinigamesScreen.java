package takeyourminestream.ijustseen.ui.screen;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import takeyourminestream.ijustseen.minigames.InteractiveMinigames;

import java.util.LinkedHashMap;
import java.util.Map;

/** Settings for local singleplayer streamer-triggered minigames. */
public final class InteractiveMinigamesScreen extends Screen {
    private final Screen parent;
    private final Map<String, TextFieldWidget> fields = new LinkedHashMap<>();
    private final Map<String, Integer> fieldLabelY = new LinkedHashMap<>();
    private ButtonWidget enabledButton;
    private ButtonWidget durationButton;
    private ButtonWidget maxAlertsButton;
    private int duration;
    private int maxAlerts;

    public InteractiveMinigamesScreen(Screen parent) {
        super(Text.literal("Interactive Minigames"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        int center = width / 2;
        int fieldWidth = Math.min(340, width - 48);
        int left = center - fieldWidth / 2;
        int y = 42;
        enabledButton = addDrawableChild(ButtonWidget.builder(enabledLabel(), b -> {
            InteractiveMinigames.setEnabled(!InteractiveMinigames.isEnabled());
            b.setMessage(enabledLabel());
        }).dimensions(left, y, fieldWidth, 20).build());
        y += 27;
        duration = InteractiveMinigames.getAlertSeconds();
        durationButton = addDrawableChild(ButtonWidget.builder(durationLabel(), b -> {
            duration = duration >= 15 ? 3 : duration + 3;
            InteractiveMinigames.setAlertSeconds(duration);
            b.setMessage(durationLabel());
        }).dimensions(left, y, (fieldWidth - 6) / 2, 20).build());
        maxAlerts = InteractiveMinigames.getMaxAlerts();
        maxAlertsButton = addDrawableChild(ButtonWidget.builder(maxLabel(), b -> {
            maxAlerts = maxAlerts >= 16 ? 2 : maxAlerts + 2;
            InteractiveMinigames.setMaxAlerts(maxAlerts);
            b.setMessage(maxLabel());
        }).dimensions(left + (fieldWidth + 6) / 2, y, (fieldWidth - 6) / 2, 20).build());
        y += 34;
        addField("FOLLOW", "Follow command", left, y, fieldWidth); y += 43;
        addField("SUBSCRIBE", "Subscribe command", left, y, fieldWidth); y += 43;
        addField("GIFT", "Default gift command", left, y, fieldWidth); y += 43;
        addField("RAID", "Raid command", left, y, fieldWidth); y += 43;
        addField("BITS", "Bits command", left, y, fieldWidth); y += 43;
        addField("GIFT_RULES", "Gift overrides: name=command; name=command", left, y, fieldWidth);
        addDrawableChild(ButtonWidget.builder(Text.literal("Save"), b -> saveAndClose())
            .dimensions(center - 104, height - 30, 100, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("gui.cancel"), b -> close())
            .dimensions(center + 4, height - 30, 100, 20).build());
    }

    private void addField(String key, String hint, int x, int y, int width) {
        TextFieldWidget field = new TextFieldWidget(textRenderer, x, y + 13, width, 20, Text.literal(hint));
        field.setMaxLength(1000);
        if (key.equals("GIFT_RULES")) {
            field.setText(InteractiveMinigames.getGiftRules());
        } else field.setText(InteractiveMinigames.getCommand(key));
        fields.put(key, field);
        fieldLabelY.put(key, y);
        addDrawableChild(field);
    }

    private void saveAndClose() {
        for (Map.Entry<String, TextFieldWidget> entry : fields.entrySet()) {
            if (!entry.getKey().equals("GIFT_RULES")) InteractiveMinigames.setCommand(entry.getKey(), entry.getValue().getText());
        }
        String rules = fields.get("GIFT_RULES").getText();
        // Each rule is gift-name=command, separated by semicolons. Clear old overrides first.
        InteractiveMinigames.clearGiftCommands();
        for (String rule : rules.split(";")) {
            int separator = rule.indexOf('=');
            if (separator > 0 && separator < rule.length() - 1) {
                InteractiveMinigames.setCommand("GIFT:" + rule.substring(0, separator).trim().toLowerCase(), rule.substring(separator + 1).trim());
            }
        }
        InteractiveMinigames.save();
        close();
    }

    private Text enabledLabel() { return Text.literal("Interactive Minigames: " + (InteractiveMinigames.isEnabled() ? "ON" : "OFF")); }
    private Text durationLabel() { return Text.literal("Alert duration: " + duration + "s"); }
    private Text maxLabel() { return Text.literal("Max alerts: " + maxAlerts); }

    @Override
    public void close() { if (client != null) client.setScreen(parent); }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 14, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
            Text.literal("Singleplayer worlds only • Cheats / permission level 2 required"), width / 2, 28, 0xFFFFD36B);
        super.render(context, mouseX, mouseY, delta);
        for (Map.Entry<String, Integer> entry : fieldLabelY.entrySet()) {
            String label = switch (entry.getKey()) {
                case "FOLLOW" -> "Follow command";
                case "SUBSCRIBE" -> "Subscribe command";
                case "GIFT" -> "Default gift command";
                case "RAID" -> "Raid command";
                case "BITS" -> "Bits command";
                default -> "Gift overrides (name=command; name=command)";
            };
            context.drawText(textRenderer, Text.literal(label), width / 2 - Math.min(170, (width - 48) / 2), entry.getValue(), 0xFFE0E0E0, false);
        }
    }
}
