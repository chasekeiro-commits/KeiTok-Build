package takeyourminestream.ijustseen.commands;

import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import takeyourminestream.ijustseen.interfaces.IChatConnectionManager;
import takeyourminestream.ijustseen.interfaces.IBanwordManager;
import takeyourminestream.ijustseen.messages.MessageSpawner;
import takeyourminestream.ijustseen.minigames.InteractiveMinigames;
import takeyourminestream.ijustseen.filtering.BlockedUsernameManager;
import takeyourminestream.ijustseen.config.ModConfig;
import takeyourminestream.ijustseen.tts.TtsManager;
import takeyourminestream.ijustseen.utils.Logger;

import java.util.Set;

/**
 * Менеджер команд мода
 */
public class CommandManager {
    private final IChatConnectionManager chatConnectionManager;
    private final IBanwordManager banwordManager;
    private final BlockedUsernameManager blockedUsernameManager;
    private final MessageSpawner messageSpawner;

    public CommandManager(IChatConnectionManager chatConnectionManager, IBanwordManager banwordManager, BlockedUsernameManager blockedUsernameManager, MessageSpawner messageSpawner) {
        this.chatConnectionManager = chatConnectionManager;
        this.banwordManager = banwordManager;
        this.blockedUsernameManager = blockedUsernameManager;
        this.messageSpawner = messageSpawner;
    }

    public void registerCommands() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(buildRootCommand("streamchat"));
            dispatcher.register(buildRootCommand("minestream"));
            dispatcher.register(buildRootCommand("keitok"));
            dispatcher.register(buildRootCommand("KeiTok"));
        });
    }

    private com.mojang.brigadier.builder.LiteralArgumentBuilder<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource> buildRootCommand(String name) {
        return ClientCommandManager.literal(name)
                .then(ClientCommandManager.literal("test")
                    .then(ClientCommandManager.literal("gift")
                        .then(ClientCommandManager.argument("gift", StringArgumentType.word())
                            .executes(context -> executeInteractiveTest("GIFT", StringArgumentType.getString(context, "gift"), 1))
                            .then(ClientCommandManager.argument("count", IntegerArgumentType.integer(1, 64))
                                .executes(context -> executeInteractiveTest("GIFT", StringArgumentType.getString(context, "gift"), IntegerArgumentType.getInteger(context, "count"))))))
                    .then(ClientCommandManager.literal("follow").executes(context -> executeInteractiveTest("FOLLOW", "", 1)))
                    .then(ClientCommandManager.literal("like").executes(context -> executeInteractiveTest("LIKE", "", 1)))
                    .then(ClientCommandManager.literal("subscribe").executes(context -> executeInteractiveTest("SUBSCRIBE", "", 1)))
                    .then(ClientCommandManager.literal("raid").executes(context -> executeInteractiveTest("RAID", "", 1)))
                    .then(ClientCommandManager.literal("bits").executes(context -> executeInteractiveTest("BITS", "", 1)))
                    .then(ClientCommandManager.argument("message", StringArgumentType.greedyString())
                        .executes(context -> executeTestCommand(StringArgumentType.getString(context, "message")))))
                .then(ClientCommandManager.literal("stop")
                    .executes(context -> executeStopCommand()))
                .then(ClientCommandManager.literal("chat")
                    .then(ClientCommandManager.literal("start")
                        .executes(context -> executeChatStartCommand()))
                    .then(ClientCommandManager.literal("stop")
                        .executes(context -> executeChatStopCommand())))
                .then(ClientCommandManager.literal("twitch")
                    .then(ClientCommandManager.literal("start")
                        .executes(context -> executeChatStartCommand()))
                    .then(ClientCommandManager.literal("stop")
                        .executes(context -> executeChatStopCommand())))
                .then(ClientCommandManager.literal("banword")
                    .then(ClientCommandManager.literal("add")
                        .then(ClientCommandManager.argument("word", StringArgumentType.word())
                            .executes(context -> {
                                String word = StringArgumentType.getString(context, "word");
                                return executeBanwordAddCommand(word);
                            })))
                    .then(ClientCommandManager.literal("remove")
                        .then(ClientCommandManager.argument("word", StringArgumentType.word())
                            .executes(context -> {
                                String word = StringArgumentType.getString(context, "word");
                                return executeBanwordRemoveCommand(word);
                            })))
                    .then(ClientCommandManager.literal("list")
                        .executes(context -> executeBanwordListCommand())))
                .then(ClientCommandManager.literal("blockuser")
                    .then(ClientCommandManager.literal("add")
                        .then(ClientCommandManager.argument("username", StringArgumentType.word())
                            .executes(context -> {
                                String username = StringArgumentType.getString(context, "username");
                                return executeBlockuserAddCommand(username);
                            })))
                    .then(ClientCommandManager.literal("remove")
                        .then(ClientCommandManager.argument("username", StringArgumentType.word())
                            .executes(context -> {
                                String username = StringArgumentType.getString(context, "username");
                                return executeBlockuserRemoveCommand(username);
                            })))
                    .then(ClientCommandManager.literal("list")
                        .executes(context -> executeBlockuserListCommand())))
                .then(ClientCommandManager.literal("tts")
                    .executes(context -> executeTtsStatusCommand())
                    .then(ClientCommandManager.literal("on")
                        .executes(context -> executeTtsEnabledCommand(true)))
                    .then(ClientCommandManager.literal("off")
                        .executes(context -> executeTtsEnabledCommand(false)))
                    .then(ClientCommandManager.literal("status")
                        .executes(context -> executeTtsStatusCommand()))
                    .then(ClientCommandManager.literal("skip")
                        .executes(context -> {
                            TtsManager.skip();
                            return 1;
                        }))
                    .then(ClientCommandManager.literal("clear")
                        .executes(context -> {
                            TtsManager.clear();
                            Logger.sendInfoToPlayer("TTS queue cleared");
                            return 1;
                        }))
                    .then(ClientCommandManager.literal("test")
                        .then(ClientCommandManager.argument("text", StringArgumentType.greedyString())
                            .executes(context -> {
                                TtsManager.speakRaw(StringArgumentType.getString(context, "text"));
                                return 1;
                            })))
                    .then(ClientCommandManager.literal("voices")
                        .executes(context -> executeTtsVoicesCommand()))
                    .then(ClientCommandManager.literal("voice")
                        .then(ClientCommandManager.literal("default")
                            .executes(context -> executeTtsVoiceCommand("")))
                        .then(ClientCommandManager.argument("name", StringArgumentType.greedyString())
                            .executes(context -> executeTtsVoiceCommand(StringArgumentType.getString(context, "name")))))
                    .then(ClientCommandManager.literal("rate")
                        .then(ClientCommandManager.argument("value", IntegerArgumentType.integer(-10, 10))
                            .executes(context -> {
                                int value = IntegerArgumentType.getInteger(context, "value");
                                takeyourminestream.ijustseen.config.ConfigManager.getInstance().setConfigValue("ttsRate", value);
                                Logger.sendInfoToPlayer("TTS rate: " + value + " (-10 slow .. 10 fast)");
                                return 1;
                            })))
                    .then(ClientCommandManager.literal("volume")
                        .then(ClientCommandManager.argument("value", IntegerArgumentType.integer(0, 100))
                            .executes(context -> {
                                int value = IntegerArgumentType.getInteger(context, "value");
                                takeyourminestream.ijustseen.config.ConfigManager.getInstance().setConfigValue("ttsVolume", value);
                                Logger.sendInfoToPlayer("TTS volume: " + value);
                                return 1;
                            }))))
                .then(ClientCommandManager.literal("help")
                    .executes(context -> executeHelpCommand()));
    }

    private int executeInteractiveTest(String event, String gift, int count) {
        if (!InteractiveMinigames.simulateTest(event, gift, count)) {
            Logger.sendInfoToPlayer("Interactive Minigames test requires it to be enabled in a singleplayer world with cheats enabled.");
            return 0;
        }
        Logger.sendInfoToPlayer("Simulated " + event.toLowerCase() + (event.equals("GIFT") ? " gift: " + gift + " x" + count : " event") + ".");
        return 1;
    }

    private int executeTestCommand(String message) {
        messageSpawner.setCurrentMessage(message);
        Logger.sendInfoToPlayer("Тестовое сообщение установлено: " + message);
        return 1;
    }

    private int executeStopCommand() {
        messageSpawner.setCurrentMessage("");
        TtsManager.clear();
        chatConnectionManager.disconnect();
        Logger.sendInfoToPlayer("Мод остановлен");
        return 1;
    }

    private int executeChatStartCommand() {
        chatConnectionManager.connect(messageSpawner);
        return 1;
    }

    private int executeChatStopCommand() {
        chatConnectionManager.disconnect();
        return 1;
    }

    private int executeBanwordAddCommand(String word) {
        banwordManager.addBanword(word);
        Logger.sendInfoToPlayer("Банворд добавлен: " + word);
        return 1;
    }

    private int executeBanwordRemoveCommand(String word) {
        banwordManager.removeBanword(word);
        Logger.sendInfoToPlayer("Банворд удален: " + word);
        return 1;
    }

    private int executeBanwordListCommand() {
        Set<String> banwords = banwordManager.getBanwords();
        if (banwords.isEmpty()) {
            Logger.sendInfoToPlayer("Список банвордов пуст");
        } else {
            Logger.sendInfoToPlayer("Список банвордов (" + banwords.size() + "):");
            for (String banword : banwords) {
                Logger.sendToPlayer("  - " + banword);
            }
        }
        return 1;
    }

    private int executeBlockuserAddCommand(String username) {
        blockedUsernameManager.addBlockedUsername(username);
        Logger.sendInfoToPlayer("Ник добавлен в чёрный список: " + username);
        return 1;
    }

    private int executeBlockuserRemoveCommand(String username) {
        blockedUsernameManager.removeBlockedUsername(username);
        Logger.sendInfoToPlayer("Ник удалён из чёрного списка: " + username);
        return 1;
    }

    private int executeBlockuserListCommand() {
        Set<String> blocked = blockedUsernameManager.getBlockedUsernames();
        if (blocked.isEmpty()) {
            Logger.sendInfoToPlayer("Чёрный список ников пуст");
        } else {
            Logger.sendInfoToPlayer("Чёрный список ников (" + blocked.size() + "):");
            for (String username : blocked) {
                Logger.sendToPlayer("  - " + username);
            }
        }
        return 1;
    }

    private int executeTtsEnabledCommand(boolean enabled) {
        ModConfig.setENABLE_TTS(enabled);
        if (!enabled) {
            TtsManager.clear();
        }
        Logger.sendInfoToPlayer("TTS " + (enabled ? "enabled" : "disabled"));
        return 1;
    }

    private int executeTtsStatusCommand() {
        var config = ModConfig.getCurrentConfig();
        Logger.sendInfoToPlayer("TTS " + (config.isEnableTts() ? "ON" : "OFF")
            + " | voice: " + (config.getTtsVoice().isBlank() ? "default" : config.getTtsVoice())
            + " | rate " + config.getTtsRate() + " | volume " + config.getTtsVolume());
        if (config.isEnableTts()) {
            Logger.sendToPlayer("  " + TtsManager.describe());
        }
        return 1;
    }

    private int executeTtsVoiceCommand(String name) {
        takeyourminestream.ijustseen.config.ConfigManager.getInstance().setConfigValue("ttsVoice", name.strip());
        Logger.sendInfoToPlayer("TTS voice: " + (name.isBlank() ? "system default" : name.strip()));
        TtsManager.speakRaw("This is the new voice.");
        return 1;
    }

    private int executeTtsVoicesCommand() {
        Logger.sendInfoToPlayer("Looking up installed voices...");
        Thread lookup = new Thread(() -> {
            java.util.List<String> voices = TtsManager.listVoices();
            net.minecraft.client.MinecraftClient.getInstance().execute(() -> {
                if (voices.isEmpty()) {
                    Logger.sendErrorToPlayer("No TTS voices found");
                    return;
                }
                java.util.List<String> shown = voices.size() > 40 ? voices.subList(0, 40) : voices;
                Logger.sendInfoToPlayer("TTS voices (" + voices.size() + "): " + String.join(", ", shown)
                    + (voices.size() > shown.size() ? ", ..." : ""));
                Logger.sendToPlayer("  -> /streamchat tts voice <name>");
            });
        }, "TYSC-TTS-Voices");
        lookup.setDaemon(true);
        lookup.start();
        return 1;
    }

    private int executeHelpCommand() {
        Logger.sendInfoToPlayer("=== KeiTok — команды ===");
        Logger.sendInfoToPlayer("/streamchat test <сообщение> — тестовое сообщение");
        Logger.sendInfoToPlayer("/streamchat stop — очистить сообщения и отключить чаты");
        Logger.sendInfoToPlayer("/streamchat chat start — подключиться ко всем включённым платформам");
        Logger.sendInfoToPlayer("/streamchat chat stop — отключиться от чатов");
        Logger.sendInfoToPlayer("/streamchat banword add|remove|list — банворды");
        Logger.sendInfoToPlayer("/streamchat blockuser add|remove|list — чёрный список ников");
        Logger.sendInfoToPlayer("/streamchat tts on|off|status|skip|clear — озвучка чата (TTS)");
        Logger.sendInfoToPlayer("/streamchat tts test <text> | voices | voice <name|default> | rate <-10..10> | volume <0..100>");
        Logger.sendInfoToPlayer("/streamchat help — эта справка");
        Logger.sendInfoToPlayer("Алиасы: /keitok …, /minestream … (то же самое)");
        return 1;
    }
}
