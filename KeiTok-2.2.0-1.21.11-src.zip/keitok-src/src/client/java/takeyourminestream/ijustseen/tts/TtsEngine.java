package takeyourminestream.ijustseen.tts;

import takeyourminestream.ijustseen.config.ModConfig;
import takeyourminestream.ijustseen.config.ModConfigData;
import takeyourminestream.ijustseen.utils.Logger;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Озвучка очереди текста средствами ОС, без нативных библиотек:
 * Windows — SAPI через PowerShell, macOS — {@code say}, Linux — espeak-ng / espeak / spd-say.
 * Читает голос, скорость и громкость из {@link ModConfigData} при каждой фразе.
 * Намеренно не использует классы Minecraft (общий исходник для всех версий).
 */
public final class TtsEngine {
    private static final String OS = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
    private static final boolean WINDOWS = OS.startsWith("windows");
    private static final boolean MAC = OS.startsWith("mac");

    private final LinkedBlockingDeque<String> queue = new LinkedBlockingDeque<>();
    private final Thread worker;
    private final Consumer<String> errorSink;
    private volatile Process current;
    private volatile boolean running = true;
    private volatile String linuxEngine;
    private volatile boolean errorReported;

    /** @param errorSink получает понятное сообщение об ошибке (не чаще одного раза, пока не сброшено). */
    public TtsEngine(Consumer<String> errorSink) {
        this.errorSink = errorSink;
        this.worker = new Thread(this::runLoop, "TYSC-TTS");
        this.worker.setDaemon(true);
        this.worker.start();
    }

    /** Кладёт фразу в очередь; при переполнении выбрасывает самые старые, чтобы озвучка не отставала от чата. */
    public void enqueue(String text, int maxQueue) {
        if (text == null || text.isBlank()) {
            return;
        }
        while (queue.size() >= Math.max(1, maxQueue)) {
            queue.pollFirst();
        }
        queue.offerLast(text);
    }

    public int pending() {
        return queue.size();
    }

    public boolean isSpeaking() {
        Process p = current;
        return p != null && p.isAlive();
    }

    /** Прерывает текущую фразу; следующая из очереди начнётся сразу. */
    public void skip() {
        Process p = current;
        if (p != null) {
            p.destroyForcibly();
        }
    }

    public void clear() {
        queue.clear();
        skip();
    }

    public void resetErrorFlag() {
        errorReported = false;
    }

    public void shutdown() {
        running = false;
        clear();
        worker.interrupt();
    }

    public String describe() {
        if (WINDOWS) {
            return "Windows SAPI";
        }
        if (MAC) {
            return "macOS say";
        }
        String engine = linuxEngine();
        return engine.isEmpty() ? "Linux: no engine found (install espeak-ng)" : "Linux " + engine;
    }

    // ------------------------------------------------------------------ worker

    private void runLoop() {
        while (running) {
            try {
                String text = queue.take();
                speak(text);
            } catch (InterruptedException e) {
                return;
            } catch (Exception e) {
                Logger.warning("TTS failed: " + e);
                if (!errorReported) {
                    errorReported = true;
                    errorSink.accept(e.getMessage() != null ? e.getMessage() : e.toString());
                }
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException ie) {
                    return;
                }
            }
        }
    }

    private void speak(String text) throws IOException, InterruptedException {
        ModConfigData c = ModConfig.getCurrentConfig();
        Process p = WINDOWS ? startWindows(text, c) : MAC ? startMac(text, c) : startLinux(text, c);
        current = p;
        try {
            if (!p.waitFor(90, TimeUnit.SECONDS)) {
                p.destroyForcibly();
            }
        } finally {
            current = null;
        }
    }

    // ------------------------------------------------------------------ launchers

    private Process startWindows(String text, ModConfigData c) throws IOException {
        ProcessBuilder pb = new ProcessBuilder(
            "powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", "-");
        // Текст идёт через переменные окружения, а не в скрипте: чат не может внедрить команды.
        pb.environment().put("TYSC_TTS_TEXT", text);
        pb.environment().put("TYSC_TTS_VOICE", c.getTtsVoice());
        pb.environment().put("TYSC_TTS_RATE", Integer.toString(c.getTtsRate()));
        pb.environment().put("TYSC_TTS_VOLUME", Integer.toString(c.getTtsVolume()));
        pb.redirectErrorStream(true);
        pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);
        Process p = pb.start();
        String script = String.join("\n",
            "Add-Type -AssemblyName System.Speech",
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer",
            "$s.Rate = [int]$env:TYSC_TTS_RATE",
            "$s.Volume = [int]$env:TYSC_TTS_VOLUME",
            "if ($env:TYSC_TTS_VOICE) { try { $s.SelectVoice($env:TYSC_TTS_VOICE) } catch { } }",
            "$s.Speak($env:TYSC_TTS_TEXT)",
            "$s.Dispose()",
            "");
        writeAndClose(p, script);
        return p;
    }

    private Process startMac(String text, ModConfigData c) throws IOException {
        List<String> cmd = new ArrayList<>();
        cmd.add("say");
        cmd.add("-r");
        cmd.add(Integer.toString(wordsPerMinute(c.getTtsRate())));
        if (!c.getTtsVoice().isBlank()) {
            cmd.add("-v");
            cmd.add(c.getTtsVoice());
        }
        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.redirectErrorStream(true);
        pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);
        Process p = pb.start();
        writeAndClose(p, text); // say читает stdin, если текст не передан аргументом
        return p;
    }

    private Process startLinux(String text, ModConfigData c) throws IOException {
        String engine = linuxEngine();
        if (engine.isEmpty()) {
            throw new IOException("No speech engine found. Install espeak-ng (sudo apt install espeak-ng).");
        }
        List<String> cmd = new ArrayList<>();
        cmd.add(engine);
        boolean spd = engine.equals("spd-say");
        if (spd) {
            cmd.add("-w");
            cmd.add("-r");
            cmd.add(Integer.toString(c.getTtsRate() * 10));
            cmd.add("-i");
            cmd.add(Integer.toString(c.getTtsVolume() * 2 - 100));
            cmd.add("--");
            cmd.add(text);
        } else {
            cmd.add("-s");
            cmd.add(Integer.toString(wordsPerMinute(c.getTtsRate())));
            cmd.add("-a");
            cmd.add(Integer.toString(c.getTtsVolume() * 2));
            if (!c.getTtsVoice().isBlank()) {
                cmd.add("-v");
                cmd.add(c.getTtsVoice());
            }
            cmd.add("--stdin");
        }
        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.redirectErrorStream(true);
        pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);
        Process p = pb.start();
        if (!spd) {
            writeAndClose(p, text);
        }
        return p;
    }

    private static int wordsPerMinute(int rate) {
        return 175 + rate * 15;
    }

    private static void writeAndClose(Process p, String text) throws IOException {
        try (OutputStream os = p.getOutputStream()) {
            os.write(text.getBytes(StandardCharsets.UTF_8));
        }
    }

    private String linuxEngine() {
        String cached = linuxEngine;
        if (cached != null) {
            return cached;
        }
        String found = "";
        for (String name : new String[] {"espeak-ng", "espeak", "spd-say"}) {
            if (onPath(name)) {
                found = name;
                break;
            }
        }
        linuxEngine = found;
        return found;
    }

    private static boolean onPath(String exe) {
        String path = System.getenv("PATH");
        if (path == null) {
            return false;
        }
        for (String dir : path.split(File.pathSeparator)) {
            if (dir.isBlank()) {
                continue;
            }
            Path candidate = Path.of(dir, exe);
            if (Files.isRegularFile(candidate) && Files.isExecutable(candidate)) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ голоса

    /** Названия установленных голосов. Блокирующий вызов — не из игрового потока. */
    public List<String> listVoices() {
        List<String> out = new ArrayList<>();
        try {
            ProcessBuilder pb;
            if (WINDOWS) {
                pb = new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive", "-Command",
                    "Add-Type -AssemblyName System.Speech; "
                        + "(New-Object System.Speech.Synthesis.SpeechSynthesizer).GetInstalledVoices() "
                        + "| ForEach-Object { $_.VoiceInfo.Name }");
            } else if (MAC) {
                pb = new ProcessBuilder("say", "-v", "?");
            } else {
                String engine = linuxEngine();
                if (!engine.equals("espeak-ng") && !engine.equals("espeak")) {
                    return out;
                }
                pb = new ProcessBuilder(engine, "--voices");
            }
            pb.redirectErrorStream(true);
            Process p = pb.start();
            p.getOutputStream().close();
            String raw;
            try (InputStream in = p.getInputStream()) {
                raw = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
            p.waitFor(15, TimeUnit.SECONDS);
            boolean header = true;
            for (String line : raw.split("\\R")) {
                String l = line.strip();
                if (l.isEmpty()) {
                    continue;
                }
                if (WINDOWS) {
                    out.add(l);
                } else if (MAC) {
                    int sep = l.indexOf("  ");
                    out.add(sep > 0 ? l.substring(0, sep).strip() : l);
                } else {
                    if (header) { // шапка таблицы espeak
                        header = false;
                        continue;
                    }
                    String[] cols = l.split("\\s+");
                    if (cols.length >= 4) {
                        out.add(cols[3]);
                    }
                }
            }
        } catch (Exception e) {
            Logger.warning("Could not list TTS voices: " + e);
        }
        return out;
    }
}
