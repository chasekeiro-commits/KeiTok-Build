package takeyourminestream.ijustseen.messages;

import net.minecraft.client.MinecraftClient;

/** Заглушка: для этой версии Minecraft тосты не реализованы, сообщения остаются в HUD. */
public final class MessageToast {
    private MessageToast() {}

    public static boolean isSupported() {
        return false;
    }

    public static void show(MinecraftClient client, Message message) {
    }
}
