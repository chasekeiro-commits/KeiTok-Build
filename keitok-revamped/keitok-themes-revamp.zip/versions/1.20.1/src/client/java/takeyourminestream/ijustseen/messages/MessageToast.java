package takeyourminestream.ijustseen.messages;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.toast.Toast;
import net.minecraft.client.toast.ToastManager;
import takeyourminestream.ijustseen.core.MessagePanelConstants;
import takeyourminestream.ijustseen.core.text.ChatMessageParser;
import takeyourminestream.ijustseen.filtering.BlockedUsernameManager;
import takeyourminestream.ijustseen.config.ModConfig;
import takeyourminestream.ijustseen.ui.gui.MessageCardLayout;
import takeyourminestream.ijustseen.ui.gui.MessageCardRenderer;

/**
 * Сообщение чата в виде ванильного тоста (ToastManager): та же карточка, что и в HUD —
 * иконка платформы, ник и текст. Тосты рисуются самим Minecraft отдельно от HUD-слоя,
 * поэтому другие моды, трогающие HUD, на них не влияют.
 */
public final class MessageToast implements Toast {
    private static final int SLOT = 32;
    private static final long FADE_MS = 400L;

    private final Message message;
    private final ChatMessageParser.ParsedMessage parsed;
    private final MessageCardLayout.Layout layout;
    private final long visibleMs;
    private final BlockedUsernameManager blocked = BlockedUsernameManager.getInstance();
    

    private MessageToast(Message message, TextRenderer textRenderer) {
        this.message = message;
        this.parsed = ChatMessageParser.parse(message.getText());
        int maxWidth = MessagePanelLayout.wrapWidth() + MessagePanelConstants.PADDING_X * 2;
        this.layout = message.getHudLayout(textRenderer, maxWidth);
        this.visibleMs = Math.max(1000L, ModConfig.getMESSAGE_LIFETIME_TICKS() * 50L) + FADE_MS;
    }

    /** Есть ли в этой версии Minecraft реализация тостов. */
    public static boolean isSupported() {
        return true;
    }

    public static void show(MinecraftClient client, Message message) {
        if (client == null || message == null || client.getToastManager() == null) {
            return;
        }
        client.getToastManager().add(new MessageToast(message, client.textRenderer));
    }

    // Без @Override намеренно: в старых версиях часть этих методов может отсутствовать в интерфейсе.
    public int getWidth() {
        return layout.width();
    }

    public int getHeight() {
        // кратно слоту тоста (32 px), чтобы стопка не налезала сама на себя
        return Math.max(SLOT, ((layout.height() + SLOT - 1) / SLOT) * SLOT);
    }

    public int getRequiredSpaceCount() {
        return getHeight() / SLOT;
    }

    private float alphaAt(long elapsedMs) {
        long fadeStart = visibleMs - FADE_MS;
        if (elapsedMs <= fadeStart) {
            return 1.0f;
        }
        return Math.max(0.0f, 1.0f - (elapsedMs - fadeStart) / (float) FADE_MS);
    }

    private void drawCard(DrawContext context, TextRenderer textRenderer, long elapsedMs) {
        MessageCardRenderer.drawHudCard(context, textRenderer, blocked, message, parsed, layout, 0, 0, alphaAt(elapsedMs));
    }

    // --- Toast API Minecraft 1.20.1 - 1.21.1 (draw(DrawContext, ToastManager, long) -> Visibility) ---

    @Override
    public Toast.Visibility draw(DrawContext context, ToastManager manager, long startTime) {
        drawCard(context, MinecraftClient.getInstance().textRenderer, startTime);
        return startTime < visibleMs ? Toast.Visibility.SHOW : Toast.Visibility.HIDE;
    }
}
