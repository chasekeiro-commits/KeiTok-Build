# KeiTok

Live chat from **Twitch, YouTube, Kick & TikTok** in Minecraft — as 3D billboards or a HUD overlay. For streamers and players who want chat in the game, not in a second monitor.

## Features

- Multi-platform chat (enable any combination in settings)
- 3D messages in the world or HUD overlay (visible in inventory)
- Twitch & 7TV emotes, platform-colored borders
- Pin messages, chat history, replay, username blocklist
- Banwords, regex filters, role filter (subs / VIP / mods)
- **Text-to-speech**: reads chat and events aloud with the system voice (Windows, macOS, Linux with `espeak-ng`)
- Lightweight client-side mod (Fabric)

## Compatibility

Minecraft **1.20.1**, **1.21**, **1.21.1**, **1.21.4**, **1.21.8**, **1.21.10**, **1.21.11**, **26.1**, **26.2**, **26.3** (Fabric) — one jar per game version. The 1.20.1 jar needs Java 17.

Requires Fabric Loader ≥0.16.14 and Fabric API. Mod Menu optional.

## Installation

1. Install [Fabric](https://fabricmc.net/) for your Minecraft version
2. Download the matching jar (e.g. `keitok-2.2.0+1.21.10.jar`)
3. Place in `mods/` and launch
4. Press **`]`** → enable platforms, enter channels, save

## Commands

- `/streamchat test <text>` — test message
- `/streamchat chat start` | `chat stop` — connect / disconnect
- `/streamchat banword` / `blockuser` — moderation
- `/streamchat tts on` | `off` | `status` | `skip` | `clear` — chat text-to-speech
- `/streamchat tts test <text>` | `voices` | `voice <name|default>` | `rate <-10..10>` | `volume <0..100>`
- `/keitok` — alias (same commands); `/minestream` — legacy alias

Keybinds: **`]`** settings, **`[`** quick chat toggle, **`\`** chat history

## Text-to-speech

Enable it in settings (**Messages** tab → *Chat Text-to-Speech*) or with `/streamchat tts on`. It uses the voices already installed on your system, so there is nothing extra to download:

- **Windows** — built-in SAPI voices (add more in Settings → Time & language → Speech)
- **macOS** — `say` (volume is not adjustable; use the system volume)
- **Linux** — install `espeak-ng` (`sudo apt install espeak-ng`); `espeak` / `spd-say` are fallbacks

TTS runs *after* all existing filters (username blocklist, role filter, regexps, banwords), so it only reads what viewers would actually see. Links become "link", emoji are dropped, repeated letters are shortened, and long messages are trimmed. Events (gifts, follows, subs, raids) are read too unless you turn *Read Events* off. If chat is faster than speech, the oldest queued lines are dropped so it stays current; `/streamchat tts skip` cuts the current line.

Settings are stored in the mod's JSON config (`enableTts`, `ttsVoice`, `ttsRate`, `ttsVolume`, `ttsReadNames`, `ttsReadEvents`, `ttsMaxChars`, `ttsMaxQueue`).

## Build from source

See [BUILD.md](BUILD.md). Uses [Stonecutter](https://stonecutter.kikugie.dev/) for multi-version builds.

```bash
./gradlew build buildAndCollect
```

## License

MIT — see [LICENSE](LICENSE).

## Links

- [Modrinth](https://modrinth.com/mod/take-your-stream-chat) (project page)
- [GitHub](https://github.com/ijustseen/take-your-minestream)
