package takeyourminestream.ijustseen.messages;

import net.minecraft.client.MinecraftClient;
import takeyourminestream.ijustseen.utils.ScreenNavigationCompat;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;

/**
 * Когда показывать HUD-сообщения поверх экрана.
 * Инвентарь, контейнеры и визуальный редактор — да; ESC-меню, чат, настройки — нет.
 */
public final class MessageHudVisibility {
    private MessageHudVisibility() {}

    public static boolean shouldRender(MinecraftClient client) {
        if (client == null || client.player == null || client.world == null) {
            return false;
        }
        Screen screen = ScreenNavigationCompat.current(client);
        if (screen == null) {
            return true;
        }
        return screen instanceof HandledScreen
            || screen instanceof takeyourminestream.ijustseen.ui.screen.MessageEditorScreen;
    }
}
