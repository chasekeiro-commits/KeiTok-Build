package takeyourminestream.ijustseen.messages;

import net.minecraft.client.MinecraftClient;
import takeyourminestream.ijustseen.config.MessageSpawnMode;
import takeyourminestream.ijustseen.config.ModConfig;

/** Когда HUD-сообщения показываются тостами вместо HUD-оверлея. */
public final class MessageToasts {
    private MessageToasts() {}

    public static boolean isActive() {
        return ModConfig.isHUD_AS_TOAST()
            && ModConfig.getMESSAGE_SPAWN_MODE() == MessageSpawnMode.HUD_WIDGET
            && MessageToast.isSupported();
    }

    public static void show(MinecraftClient client, Message message) {
        MessageToast.show(client, message);
    }
}
