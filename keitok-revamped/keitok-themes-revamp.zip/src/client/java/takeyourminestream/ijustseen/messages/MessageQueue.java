package takeyourminestream.ijustseen.messages;

import java.util.Comparator;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Очередь сообщений перед показом в мире/HUD.
 * Размер ограничен: при переполнении отбрасываются сообщения с самым поздним показом.
 * Поддерживает отложенный показ ({@code readyAtTick}) — для пачек YouTube по timestamp.
 */
public class MessageQueue {
    public static class QueuedMessage {
        public final String text;
        public final Integer authorColorRgb;
        public final java.util.List<MessageEmote> emotes;
        public final takeyourminestream.ijustseen.integration.chat.ChatEventType eventType;
        /** Тик, начиная с которого сообщение можно показать. */
        public final int readyAtTick;
        /** Не ждать текстуры дольше этого тика — иначе чат встанет на мёртвом CDN. */
        public final int textureDeadlineTick;
        final long sequence;

        public QueuedMessage(
            String text,
            Integer authorColorRgb,
            java.util.List<MessageEmote> emotes,
            takeyourminestream.ijustseen.integration.chat.ChatEventType eventType,
            int readyAtTick,
            int textureDeadlineTick,
            long sequence
        ) {
            this.text = text;
            this.authorColorRgb = authorColorRgb;
            this.emotes = emotes == null ? java.util.Collections.emptyList() : java.util.List.copyOf(emotes);
            this.eventType = eventType != null
                ? eventType
                : takeyourminestream.ijustseen.integration.chat.ChatEventType.CHAT;
            this.readyAtTick = readyAtTick;
            this.textureDeadlineTick = textureDeadlineTick;
            this.sequence = sequence;
        }
    }

    private static final Comparator<QueuedMessage> ORDER = Comparator
        .comparingInt((QueuedMessage m) -> m.readyAtTick)
        .thenComparingLong(m -> m.sequence);

    /** Макс. ожидающих сообщений; лишние (с самым поздним показом) отбрасываются. */
    private static final int MAX_QUEUE_SIZE = 16;

    private final PriorityBlockingQueue<QueuedMessage> messageQueue = new PriorityBlockingQueue<>(11, ORDER);
    private final AtomicLong sequence = new AtomicLong();

    public void enqueueMessage(
        String message,
        Integer authorColorRgb,
        java.util.List<MessageEmote> emotes,
        int readyAtTick,
        int textureDeadlineTick
    ) {
        enqueueMessage(message, authorColorRgb, emotes, takeyourminestream.ijustseen.integration.chat.ChatEventType.CHAT, readyAtTick, textureDeadlineTick);
    }

    public void enqueueMessage(
        String message,
        Integer authorColorRgb,
        java.util.List<MessageEmote> emotes,
        takeyourminestream.ijustseen.integration.chat.ChatEventType eventType,
        int readyAtTick,
        int textureDeadlineTick
    ) {
        offerWithCap(new QueuedMessage(
            message,
            authorColorRgb,
            emotes,
            eventType,
            readyAtTick,
            textureDeadlineTick,
            sequence.getAndIncrement()
        ));
    }

    private void offerWithCap(QueuedMessage message) {
        messageQueue.offer(message);
        trimToMaxSize();
    }

    private void trimToMaxSize() {
        while (messageQueue.size() > MAX_QUEUE_SIZE) {
            QueuedMessage toDrop = messageQueue.stream()
                .max(Comparator.comparingInt((QueuedMessage m) -> m.readyAtTick).thenComparingLong(m -> m.sequence))
                .orElse(null);
            if (toDrop == null) {
                break;
            }
            messageQueue.remove(toDrop);
        }
    }

    public QueuedMessage pollReady(int currentTick) {
        QueuedMessage head = messageQueue.peek();
        if (head == null || head.readyAtTick > currentTick) {
            return null;
        }
        if (currentTick >= head.textureDeadlineTick || TwitchEmoteTextureCache.areEmotesReady(head.emotes)) {
            return messageQueue.poll();
        }
        return null;
    }

    public void clear() {
        messageQueue.clear();
    }

    public boolean isEmpty() {
        return messageQueue.isEmpty();
    }

    public int pendingCount() {
        return messageQueue.size();
    }
}
