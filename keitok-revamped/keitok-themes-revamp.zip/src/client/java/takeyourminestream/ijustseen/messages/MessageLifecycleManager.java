package takeyourminestream.ijustseen.messages;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.util.math.MathHelper;
import takeyourminestream.ijustseen.config.ConfigManager;
import takeyourminestream.ijustseen.config.MessageSpawnMode;
import takeyourminestream.ijustseen.config.ModConfig;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.util.math.Vec3d;
import java.util.HashSet;
import java.util.Set;

/**
 * Управляет жизненным циклом сообщений
 */
public class MessageLifecycleManager {
    private final List<Message> activeMessages = new ArrayList<>();
    private final List<Message> messageHistory = new ArrayList<>();
    /** Сообщения визуального редактора; пока он открыт, рендер видит только их. */
    private final List<Message> previewMessages = new ArrayList<>();
    private boolean previewActive = false;
    private int tickCounter = 0;
    private final MessageParticleManager particleManager;
    private final Set<Message> spawnedParticlesForMessages = new HashSet<>();
    
    public MessageLifecycleManager(MessageParticleManager particleManager) {
        this.particleManager = particleManager;
    }
    
    /**
     * Обновляет состояние всех активных сообщений
     * @param client Minecraft клиент
     */
    public void updateMessages(MinecraftClient client) {
        if (particleManager != null) {
            particleManager.tick();
        }
        if (client.player == null || client.world == null) return;
        
        tickCounter++;
        // Плавное следование за игроком (только для 3D режимов)
        if (takeyourminestream.ijustseen.config.ModConfig.isFOLLOW_PLAYER()
                && takeyourminestream.ijustseen.config.ModConfig.getMESSAGE_SPAWN_MODE() != takeyourminestream.ijustseen.config.MessageSpawnMode.HUD_WIDGET) {
            var eyePos = client.player.getEyePos();
            // Время сглаживания (в тиках)
            float positionSmoothTime = 14.0f;   // больше инерции
            float yawSmoothTime = 12.0f;
            float pitchSmoothTime = 12.0f;

            // Коэффициенты экспон. сглаживания на тик
            float positionLerp = clamp01(1.0f - (float)Math.exp(-1.0f / positionSmoothTime));
            float yawLerp = clamp01(1.0f - (float)Math.exp(-1.0f / yawSmoothTime));
            float pitchLerp = clamp01(1.0f - (float)Math.exp(-1.0f / pitchSmoothTime));

            for (Message message : activeMessages) {
                if (message.isPinned()) {
                    continue;
                }
                Vec3d local = message.getTargetOffsetFromEye();
                if (local == null) continue; // для HUD или старых сообщений

                // Целевая мировая позиция = глаза игрока + фиксированное мировое смещение (НЕ зависящее от yaw)
                Vec3d targetWorld = eyePos.add(local);

                // Плавное сближение к цели с нарастающей/затухающей скоростью (без клипа скорости)
                Vec3d currentPos = message.getPosition();
                Vec3d toTarget = targetWorld.subtract(currentPos);
                Vec3d newPos = currentPos.add(toTarget.multiply(positionLerp));
                message.setPosition(newPos);

                // Ориентация: не мгновенно, а сглаженно смотрит на глаза игрока
                double dx = eyePos.x - newPos.x;
                double dy = eyePos.y - newPos.y;
                double dz = eyePos.z - newPos.z;
                double distXZ = Math.sqrt(dx * dx + dz * dz);
                float targetYaw = (float)(MathHelper.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
                float targetPitch = (float)-(MathHelper.atan2(dy, distXZ) * (180.0 / Math.PI));
                message.setYaw(lerpAngleDegrees(message.getYaw(), targetYaw, yawLerp));
                message.setPitch(lerpAngleDegrees(message.getPitch(), targetPitch, pitchLerp));
            }
        }
        
        boolean hudMode = ModConfig.getMESSAGE_SPAWN_MODE() == MessageSpawnMode.HUD_WIDGET;

        // Обновляем замороженное время для всех сообщений (только в 3D-режимах)
        if (!hudMode && ModConfig.isENABLE_FREEZING_ON_VIEW()) {
            for (Message message : activeMessages) {
                if (message.isPinned()) {
                    continue;
                }
                if (MessageViewDetector.isPlayerLookingAtMessage(client, message, tickCounter)) {
                    message.incrementFrozenTicks();
                }
            }
        }
        
        // Удаляем старые сообщения с учетом замороженного времени
        int fallTicks = ModConfig.getMESSAGE_FALL_TICKS();
        int removeAfter = ModConfig.getMESSAGE_LIFETIME_TICKS() + fallTicks;
        if (ModConfig.isENABLE_FREEZING_ON_VIEW()) {
            activeMessages.removeIf(message -> {
                if (message.isPinned()) {
                    return false;
                }
                int effectiveAge = message.getEffectiveAge(tickCounter);
                trySpawnBreakParticles(message, client, effectiveAge, removeAfter, hudMode);
                if (effectiveAge > removeAfter) {
                    spawnedParticlesForMessages.remove(message);
                    return true;
                }
                return false;
            });
        } else {
            activeMessages.removeIf(message -> {
                if (message.isPinned()) {
                    return false;
                }
                int effectiveAge = tickCounter - (int) message.getSpawnTick();
                trySpawnBreakParticles(message, client, effectiveAge, removeAfter, hudMode);
                if (effectiveAge > removeAfter) {
                    spawnedParticlesForMessages.remove(message);
                    return true;
                }
                return false;
            });
        }
    }

    private void trySpawnBreakParticles(
        Message message,
        MinecraftClient client,
        int effectiveAge,
        int removeAfter,
        boolean hudMode
    ) {
        if (hudMode || particleManager == null || spawnedParticlesForMessages.contains(message)) {
            return;
        }
        // Партиклы — в конце падения, когда панель «разбивается» (последний кадр fall-анимации).
        if (effectiveAge < removeAfter - 1) {
            return;
        }
        int shatterAge = removeAfter - 1;
        Vec3d panelCenter = MessageViewDetector.calculateFallingPosition(
            message.getPosition(),
            shatterAge,
            message.getYaw(),
            message.getPitch()
        );
        MessageParticleSpawner.spawnParticlesForMessage(
            message, particleManager, client, panelCenter, shatterAge
        );
        spawnedParticlesForMessages.add(message);
    }
    
    /**
     * Добавляет новое сообщение в список активных
     * @param message сообщение для добавления
     */
    public void addMessage(Message message) {
        activeMessages.add(message);
        
        // Добавляем в историю
        messageHistory.add(message);
        MinecraftClient client = MinecraftClient.getInstance();
        if (client != null && client.textRenderer != null) {
            message.warmHistoryLayout(client.textRenderer);
        }
        
        // Ограничиваем размер истории
        enforceHistoryLimit();
    }

    public void enforceHistoryLimit() {
        int maxSize = getMaxHistorySize();
        while (messageHistory.size() > maxSize) {
            messageHistory.remove(0);
        }
    }

    private int getMaxHistorySize() {
        Object value = ConfigManager.getInstance().getConfigValue("messageHistoryMaxSize");
        if (value instanceof Integer size && size > 0) {
            return size;
        }
        return 100;
    }
    
    public void addReplayMessage(Message message) {
        activeMessages.add(message);
    }

    public Message findPinnedForHistory(Message historyMessage) {
        if (historyMessage == null) {
            return null;
        }
        long sourceId = historyMessage.getId();
        for (Message active : activeMessages) {
            Long linkedId = active.getHistorySourceId();
            if (active.isPinned() && linkedId != null && linkedId == sourceId) {
                return active;
            }
        }
        return null;
    }

    public boolean isVisibleInWorld(Message historyMessage) {
        if (historyMessage == null) {
            return false;
        }
        for (Message active : activeMessages) {
            if (active == historyMessage) {
                return true;
            }
            Long linkedId = active.getHistorySourceId();
            if (active.isPinned() && linkedId != null && historyMessage.getId() == linkedId) {
                return true;
            }
        }
        return false;
    }

    public boolean isPinnedInWorld(Message historyMessage) {
        if (historyMessage == null) {
            return false;
        }
        if (historyMessage.isPinned() && activeMessages.contains(historyMessage)) {
            return true;
        }
        return findPinnedForHistory(historyMessage) != null;
    }

    /** Все сообщения, закреплённые в мире (включая те, что уже вышли из истории). */
    public List<Message> getAllPinnedMessages() {
        List<Message> pinned = new ArrayList<>();
        for (Message message : activeMessages) {
            if (message.isPinned()) {
                pinned.add(message);
            }
        }
        return pinned;
    }

    /**
     * Очищает все активные сообщения
     */
    public void clearAllMessages() {
        activeMessages.clear();
        tickCounter = 0;
    }

    public void clearTransientMessages() {
        activeMessages.removeIf(message -> !message.isPinned());
        spawnedParticlesForMessages.removeIf(message -> !message.isPinned());
    }

    public void removeMessagesOutsideDimension(String dimensionKey) {
        if (dimensionKey == null || dimensionKey.isBlank()) {
            return;
        }
        activeMessages.removeIf(message -> !message.isInDimension(dimensionKey));
        spawnedParticlesForMessages.removeIf(message -> !message.isInDimension(dimensionKey));
    }
    
    /**
     * Сообщения для отображения: во время предпросмотра редактора — только пробные.
     * Для сохранения и изменения реальных сообщений используйте {@link #getLiveMessages()}.
     */
    public List<Message> getActiveMessages() {
        return previewActive ? previewMessages : activeMessages;
    }

    /** Реальные сообщения чата, независимо от предпросмотра редактора. */
    public List<Message> getLiveMessages() {
        return activeMessages;
    }

    public void startPreview(List<Message> messages) {
        previewMessages.clear();
        for (Message message : messages) {
            message.setPreview(true);
            previewMessages.add(message);
        }
        previewActive = true;
    }

    public void stopPreview() {
        previewActive = false;
        previewMessages.clear();
    }

    public boolean isPreviewActive() {
        return previewActive;
    }
    
    /**
     * Возвращает текущий счетчик тиков
     * @return текущий счетчик тиков
     */
    public int getTickCounter() {
        return tickCounter;
    }
    
    /**
     * Возвращает все сообщения из истории
     * @return список всех сообщений в истории
     */
    public List<Message> getAllMessages() {
        return List.copyOf(messageHistory);
    }

    public void warmHistoryLayouts(TextRenderer textRenderer) {
        if (textRenderer == null) {
            return;
        }
        for (Message message : messageHistory) {
            message.warmHistoryLayout(textRenderer);
        }
        for (Message message : getAllPinnedMessages()) {
            message.warmHistoryLayout(textRenderer);
        }
    }

    public void warmPendingHistoryLayouts(TextRenderer textRenderer, int limit) {
        if (textRenderer == null || limit <= 0) {
            return;
        }
        int remaining = limit;
        for (Message message : messageHistory) {
            if (message.hasWarmedHistoryLayout()) {
                continue;
            }
            message.warmHistoryLayout(textRenderer);
            if (--remaining <= 0) {
                return;
            }
        }
    }

    public long peekHistoryFirstId() {
        return messageHistory.isEmpty() ? -1L : messageHistory.get(0).getId();
    }

    public long peekHistoryLastId() {
        return messageHistory.isEmpty() ? -1L : messageHistory.get(messageHistory.size() - 1).getId();
    }
    
    /**
     * Возвращает размер истории сообщений
     * @return количество сообщений в истории
     */
    public int getMessageHistorySize() {
        return messageHistory.size();
    }
    
    /**
     * Очищает историю сообщений
     */
    public void clearMessageHistory() {
        messageHistory.clear();
    }
    
    /**
     * Удаляет сообщение с немедленным спавном партиклов
     * @param message Сообщение для удаления
     * @param client Minecraft клиент
     */
    public void removeMessageWithParticles(Message message, MinecraftClient client) {
        if (activeMessages.contains(message)) {
            // Спавним партиклы на текущей позиции
            if (particleManager != null) {
                int age = message.getEffectiveAge(tickCounter);
                MessageParticleSpawner.spawnParticlesForMessage(
                    message, particleManager, client, message.getPosition(), age
                );
            }
            
            // Удаляем сообщение
            activeMessages.remove(message);
            spawnedParticlesForMessages.remove(message);
        }
    }

    public void removeMessageWithoutParticles(Message message) {
        activeMessages.remove(message);
        spawnedParticlesForMessages.remove(message);
    }

    public void addPinnedMessage(Message message) {
        message.setPinned(true);
        activeMessages.add(message);
    }

    public Message unpinMessage(Message message, MinecraftClient client) {
        if (message == null || !activeMessages.contains(message)) {
            return null;
        }

        Vec3d targetOffset = Vec3d.ZERO;
        if (client != null && client.player != null) {
            targetOffset = message.getPosition().subtract(client.player.getEyePos());
        }

        Message replacement = new Message(
            message.getText(),
            message.getPosition(),
            tickCounter,
            message.getYaw(),
            message.getPitch(),
            message.getAuthorColorRgb(),
            targetOffset,
            message.getEmotes()
        );
        replacement.setPinned(false);
        replacement.setDimensionKey(message.getDimensionKey());
        replacement.setEventType(message.getEventType());

        int idx = activeMessages.indexOf(message);
        activeMessages.set(idx, replacement);
        spawnedParticlesForMessages.remove(message);
        return replacement;
    }

    private static float lerpAngleDegrees(float a, float b, float t) {
        float delta = MathHelper.wrapDegrees(b - a);
        return a + delta * MathHelper.clamp(t, 0.0f, 1.0f);
    }

    private static float clamp01(float v) {
        return v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v);
    }
} 