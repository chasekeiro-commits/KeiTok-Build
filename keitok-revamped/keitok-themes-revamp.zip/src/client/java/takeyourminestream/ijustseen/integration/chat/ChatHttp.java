package takeyourminestream.ijustseen.integration.chat;

import takeyourminestream.ijustseen.TakeYourMineStreamClient;
import takeyourminestream.ijustseen.integration.tiktok.TikTokSessionCookies;

import java.io.IOException;
import java.net.CookieManager;
import java.net.CookiePolicy;
import java.net.HttpCookie;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * HTTP-утилиты чат-интеграций. Использует java.net.http.HttpClient:
 * legacy HttpURLConnection блокируется анти-бот защитой некоторых платформ (Kick).
 */
public final class ChatHttp {
    private static final String USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36";
    private static final Duration TIMEOUT = Duration.ofSeconds(15);
    /**
     * Хост {@code ttwid.bytedance.com} отвечает 200 и {@code parse params fail} без Set-Cookie.
     * Тот же union register на {@code www.tiktok.com} выставляет {@code ttwid}.
     */
    private static final String TTWID_REGISTER_URL = "https://www.tiktok.com/ttwid/union/register/";
    private static final String TTWID_REGISTER_BODY =
        "{\"region\":\"us\",\"aid\":1988,\"needFid\":false,\"service\":\"www.tiktok.com\","
            + "\"migrate_info\":{\"ticket\":\"\",\"source\":\"node\"},\"cbUrlProtocol\":\"https\",\"union\":true}";

    private static final CookieManager COOKIE_MANAGER = new CookieManager(null, CookiePolicy.ACCEPT_ALL);

    static {
        presetYouTubeConsentCookies();
    }

    private static final HttpClient CLIENT = HttpClient.newBuilder()
        .version(HttpClient.Version.HTTP_1_1)
        .followRedirects(HttpClient.Redirect.NORMAL)
        .connectTimeout(TIMEOUT)
        .cookieHandler(COOKIE_MANAGER)
        .build();

    private ChatHttp() {}

    /**
     * EU/EEA YouTube отдаёт страницу cookie-consent вместо watch/live chat,
     * если в запросе нет CONSENT/SOCS. Предзасев пропускает interstitial
     * (тот же приём, что у yt-dlp и Invidious).
     */
    private static void presetYouTubeConsentCookies() {
        try {
            addCookie("https://www.youtube.com", ".youtube.com", "CONSENT", "YES+cb.20240101-17-p0.en+FX+678");
            addCookie("https://www.youtube.com", ".youtube.com", "SOCS", "CAI");
        } catch (IllegalArgumentException e) {
            addCookie("https://www.youtube.com", "youtube.com", "CONSENT", "YES+cb.20240101-17-p0.en+FX+678");
            addCookie("https://www.youtube.com", "youtube.com", "SOCS", "CAI");
        }
    }

    private static void addCookie(String url, String domain, String name, String value) {
        HttpCookie cookie = new HttpCookie(name, value);
        cookie.setVersion(0);
        cookie.setDomain(domain);
        cookie.setPath("/");
        cookie.setMaxAge(60L * 60 * 24 * 365 * 10);
        COOKIE_MANAGER.getCookieStore().add(URI.create(url), cookie);
    }

    /**
     * Кладёт в jar сессию TikTok из поля настроек (или чистит её, если строка пустая).
     * Нужно вызывать до room/fetch/WSS.
     */
    public static void applyTikTokSessionCookies(String raw) {
        clearTikTokSessionCookies();
        for (Map.Entry<String, String> entry : TikTokSessionCookies.parse(raw).entrySet()) {
            addCookie("https://www.tiktok.com", ".tiktok.com", entry.getKey(), entry.getValue());
        }
    }

    public static boolean hasTikTokSessionCookie() {
        for (HttpCookie cookie : COOKIE_MANAGER.getCookieStore().getCookies()) {
            String name = cookie.getName();
            if (("sessionid".equalsIgnoreCase(name) || "sessionid_ss".equalsIgnoreCase(name))
                && cookie.getValue() != null
                && !cookie.getValue().isBlank()) {
                return true;
            }
        }
        return false;
    }

    private static void clearTikTokSessionCookies() {
        List<HttpCookie> snapshot = new ArrayList<>(COOKIE_MANAGER.getCookieStore().getCookies());
        URI tiktok = URI.create("https://www.tiktok.com");
        for (HttpCookie cookie : snapshot) {
            if (TikTokSessionCookies.isSessionName(cookie.getName())) {
                COOKIE_MANAGER.getCookieStore().remove(tiktok, cookie);
            }
        }
    }

    /** Cookie-заголовок из jar для указанного URL (все подходящие пары name=value). */
    public static String cookieHeader(String url) {
        StringBuilder header = new StringBuilder();
        for (HttpCookie cookie : COOKIE_MANAGER.getCookieStore().get(URI.create(url))) {
            if (cookie.getName() == null || cookie.getValue() == null || cookie.hasExpired()) {
                continue;
            }
            if (!header.isEmpty()) {
                header.append("; ");
            }
            header.append(cookie.getName()).append('=').append(cookie.getValue());
        }
        return header.toString();
    }

    public static String get(String url) throws IOException {
        return get(url, null);
    }

    public static String get(String url, String referer) throws IOException {
        HttpRequest.Builder builder = baseBuilder(url, referer).GET();
        return sendForBody(builder.build(), url);
    }

    /** Бинарный GET (protobuf TikTok IM fetch). Не гоняет тело через String. */
    public static byte[] getBytes(String url, String referer, Map<String, String> extraHeaders) throws IOException {
        HttpRequest.Builder builder = HttpRequest.newBuilder(URI.create(url))
            .timeout(TIMEOUT)
            .header("User-Agent", USER_AGENT)
            .header("Accept", "application/x-protobuf, application/protobuf, */*")
            .header("Accept-Language", "en-US,en;q=0.9")
            .GET();
        if (referer != null && !referer.isBlank()) {
            builder.header("Referer", referer);
        }
        for (Map.Entry<String, String> header : extraHeaders.entrySet()) {
            builder.header(header.getKey(), header.getValue());
        }
        try {
            HttpResponse<byte[]> response = CLIENT.send(builder.build(), HttpResponse.BodyHandlers.ofByteArray());
            byte[] body = response.body();
            if (response.statusCode() >= 400) {
                throw new IOException("HTTP " + response.statusCode() + " for " + url);
            }
            return body != null ? body : new byte[0];
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted while requesting " + url, e);
        }
    }

    public static String fetchTtwidCookie() throws IOException {
        return fetchTtwidCookie(null);
    }

    /**
     * Получает {@code ttwid} для TikTok WebSocket.
     * Сначала прогревает сессию через страницу TikTok (с cookie jar на редиректах),
     * затем при необходимости запрашивает cookie через union register на www.tiktok.com.
     */
    public static String fetchTtwidCookie(String tiktokUsername) throws IOException {
        warmUpTikTokSession("https://www.tiktok.com/");
        String ttwid = findTtwidInCookieJar();
        if (ttwid != null) {
            return ttwid;
        }

        if (tiktokUsername != null && !tiktokUsername.isBlank()) {
            String user = tiktokUsername.trim().replace("@", "");
            warmUpTikTokSession(
                "https://www.tiktok.com/@"
                    + URLEncoder.encode(user, StandardCharsets.UTF_8)
                    + "/live"
            );
            ttwid = findTtwidInCookieJar();
            if (ttwid != null) {
                return ttwid;
            }
        }

        ttwid = fetchTtwidFromRegisterApi();
        if (ttwid != null) {
            return ttwid;
        }

        throw new IOException("ttwid cookie missing in TikTok response");
    }

    public static String postJson(String url, String jsonBody) throws IOException {
        return postJson(url, jsonBody, Map.of());
    }

    public static String postJson(String url, String jsonBody, Map<String, String> extraHeaders) throws IOException {
        HttpRequest.Builder builder = HttpRequest.newBuilder(URI.create(url))
            .timeout(TIMEOUT)
            .header("User-Agent", USER_AGENT)
            .header("Content-Type", "application/json")
            .header("Accept", "application/json")
            .POST(HttpRequest.BodyPublishers.ofString(jsonBody));
        for (Map.Entry<String, String> header : extraHeaders.entrySet()) {
            builder.header(header.getKey(), header.getValue());
        }
        return sendForBody(builder.build(), url);
    }

    private static void warmUpTikTokSession(String url) throws IOException {
        HttpRequest request = tiktokDocumentBuilder(url).GET().build();
        HttpResponse<String> response = send(request, url);
        if (response.statusCode() >= 400) {
            TakeYourMineStreamClient.LOGGER.debug("TikTok warm-up HTTP {} for {}", response.statusCode(), url);
            return;
        }
        for (String header : response.headers().allValues("set-cookie")) {
            String ttwid = parseTtwidFromSetCookieHeader(header);
            if (ttwid != null) {
                storeTtwidCookie(url, ttwid);
                return;
            }
        }
    }

    private static String fetchTtwidFromRegisterApi() throws IOException {
        HttpRequest request = HttpRequest.newBuilder(URI.create(TTWID_REGISTER_URL))
            .timeout(TIMEOUT)
            .header("User-Agent", USER_AGENT)
            .header("Content-Type", "application/json")
            .header("Accept", "application/json")
            .header("Origin", "https://www.tiktok.com")
            .header("Referer", "https://www.tiktok.com/")
            .POST(HttpRequest.BodyPublishers.ofString(TTWID_REGISTER_BODY))
            .build();

        HttpResponse<String> response = send(request, TTWID_REGISTER_URL);
        if (response.statusCode() >= 400) {
            TakeYourMineStreamClient.LOGGER.debug("TikTok ttwid register HTTP {}", response.statusCode());
            return null;
        }

        String body = response.body();
        if (body != null && body.contains("\"status_code\"") && !body.contains("\"status_code\":0")) {
            TakeYourMineStreamClient.LOGGER.debug("TikTok ttwid register rejected: {}", body);
        }

        for (String header : response.headers().allValues("set-cookie")) {
            String ttwid = parseTtwidFromSetCookieHeader(header);
            if (ttwid != null) {
                storeTtwidCookie(TTWID_REGISTER_URL, ttwid);
                return ttwid;
            }
        }
        return findTtwidInCookieJar();
    }

    private static void storeTtwidCookie(String url, String value) {
        HttpCookie cookie = new HttpCookie("ttwid", value);
        cookie.setVersion(0);
        cookie.setDomain(".tiktok.com");
        cookie.setPath("/");
        COOKIE_MANAGER.getCookieStore().add(URI.create(url), cookie);
    }

    private static String findTtwidInCookieJar() {
        for (HttpCookie cookie : COOKIE_MANAGER.getCookieStore().getCookies()) {
            if ("ttwid".equalsIgnoreCase(cookie.getName()) && cookie.getValue() != null && !cookie.getValue().isBlank()) {
                return cookie.getValue();
            }
        }
        return null;
    }

    private static String parseTtwidFromSetCookieHeader(String header) {
        if (header == null || header.isBlank()) {
            return null;
        }
        try {
            for (HttpCookie cookie : HttpCookie.parse(header)) {
                if ("ttwid".equalsIgnoreCase(cookie.getName()) && cookie.getValue() != null && !cookie.getValue().isBlank()) {
                    return cookie.getValue();
                }
            }
        } catch (IllegalArgumentException ignored) {
            // SameSite=None и прочие атрибуты иногда ломают HttpCookie.parse
        }

        String lower = header.toLowerCase(Locale.ROOT);
        int idx = lower.indexOf("ttwid=");
        if (idx < 0) {
            return null;
        }
        int start = idx + "ttwid=".length();
        int end = header.indexOf(';', start);
        String value = end < 0 ? header.substring(start) : header.substring(start, end);
        value = value.trim();
        return value.isEmpty() ? null : value;
    }

    private static HttpRequest.Builder baseBuilder(String url, String referer) {
        HttpRequest.Builder builder = HttpRequest.newBuilder(URI.create(url))
            .timeout(TIMEOUT)
            .header("User-Agent", USER_AGENT)
            .header("Accept", "application/json, text/html, */*")
            .header("Accept-Language", "en-US,en;q=0.9");
        if (referer != null && !referer.isBlank()) {
            builder.header("Referer", referer);
        }
        return builder;
    }

    private static HttpRequest.Builder tiktokDocumentBuilder(String url) {
        HttpRequest.Builder builder = baseBuilder(url, "https://www.tiktok.com/");
        builder.header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
        builder.header("Sec-Fetch-Dest", "document");
        builder.header("Sec-Fetch-Mode", "navigate");
        builder.header("Sec-Fetch-Site", "none");
        builder.header("Upgrade-Insecure-Requests", "1");
        return builder;
    }

    private static String sendForBody(HttpRequest request, String url) throws IOException {
        HttpResponse<String> response = send(request, url);
        String body = response.body();
        if (response.statusCode() >= 400 && (body == null || body.isBlank())) {
            throw new IOException("HTTP " + response.statusCode() + " for " + url);
        }
        return body;
    }

    private static HttpResponse<String> send(HttpRequest request, String url) throws IOException {
        try {
            return CLIENT.send(request, HttpResponse.BodyHandlers.ofString());
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Interrupted while requesting " + url, e);
        }
    }
}
