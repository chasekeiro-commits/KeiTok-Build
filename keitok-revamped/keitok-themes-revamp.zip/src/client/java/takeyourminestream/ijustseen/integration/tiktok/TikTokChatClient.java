package takeyourminestream.ijustseen.integration.tiktok;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.text.Text;
import takeyourminestream.ijustseen.TakeYourMineStreamClient;
import takeyourminestream.ijustseen.config.ModConfig;
import takeyourminestream.ijustseen.integration.chat.ChatConnection;
import takeyourminestream.ijustseen.integration.chat.ChatEventType;
import takeyourminestream.ijustseen.integration.chat.ChatHttp;
import takeyourminestream.ijustseen.integration.chat.ChatMessagePipeline;
import takeyourminestream.ijustseen.integration.chat.ChatPlatform;
import takeyourminestream.ijustseen.integration.chat.IncomingChatMessage;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TikTokChatClient implements ChatConnection {
    private static final Pattern ROOM_ID_PATTERN = Pattern.compile("\"roomId\"\\s*:\\s*\"?(\\d+)\"?");
    private static final Pattern ROOM_ID_ALT = Pattern.compile("room_id=(\\d+)");

    private static final int MAX_SEEN_MESSAGE_IDS = 5000;
    private static final long HANDSHAKE_TIMEOUT_MS = 20_000L;
    private static final long RECONNECT_DELAY_MS = 3_000L;

    private final String username;
    private final ChatMessagePipeline pipeline;
    private volatile boolean running;
    private volatile Thread workerThread;
    private volatile Thread fetchThread;
    private volatile TikTokWebSocket webSocket;
    private String roomId;
    private volatile String fetchCursor = "";
    private final Set<Long> seenMessageIds = new LinkedHashSet<>();

    public TikTokChatClient(String username, ChatMessagePipeline pipeline) {
        this.username = username.trim().replace("@", "");
        this.pipeline = pipeline;
        this.running = true;
        start();
    }

    private void start() {
        workerThread = new Thread(this::connectLoop, "TikTokChat-" + username);
        workerThread.setDaemon(true);
        workerThread.start();
    }

    private void connectLoop() {
        while (running) {
            try {
                if (roomId == null) {
                    roomId = resolveRoomId(username);
                    TakeYourMineStreamClient.LOGGER.info("TikTok room resolved for @{}: {}", username, roomId);
                    takeyourminestream.ijustseen.integration.chat.ChatErrorReporter.clear(ChatPlatform.TIKTOK);
                }

                ChatHttp.applyTikTokSessionCookies(TikTokSessionCookies.compose(
                    ModConfig.getTIKTOK_SESSION_ID(),
                    ModConfig.getTIKTOK_TARGET_IDC()
                ));
                String ttwid = ChatHttp.fetchTtwidCookie(username);
                connectWebSocket(ttwid);

                long handshakeStarted = System.currentTimeMillis();
                while (running && webSocket != null && webSocket.isRunning()) {
                    if (webSocket.isConnecting()
                        && System.currentTimeMillis() - handshakeStarted > HANDSHAKE_TIMEOUT_MS) {
                        TakeYourMineStreamClient.LOGGER.warn("TikTok WSS handshake timed out for @{}", username);
                        break;
                    }
                    Thread.sleep(1000);
                }
                if (running) {
                    disconnectWebSocket();
                    sleepQuietly(RECONNECT_DELAY_MS);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                break;
            } catch (Exception e) {
                if (!running || Thread.currentThread().isInterrupted() || isInterruption(e)) {
                    break;
                }
                TakeYourMineStreamClient.LOGGER.warn("TikTok chat error for @{}: {}", username, e.getMessage());
                takeyourminestream.ijustseen.integration.chat.ChatErrorReporter.report(ChatPlatform.TIKTOK, e);
                disconnectWebSocket();
                roomId = null;
                seenMessageIds.clear();
                sleepQuietly(10000);
            }
        }
    }

    private void connectWebSocket(String ttwid) {
        String currentRoomId = roomId;
        webSocket = new TikTokWebSocket(currentRoomId, ttwid, new TikTokWebSocket.ChatHandler() {
            @Override
            public void onChat(long msgId, String uniqueId, String displayName, String text,
                takeyourminestream.ijustseen.integration.chat.ChatAuthorRoles roles,
                java.util.List<takeyourminestream.ijustseen.messages.MessageEmote> emotes) {
                if (!markSeen(msgId)) {
                    return;
                }
                pipeline.process(IncomingChatMessage.builder(ChatPlatform.TIKTOK)
                    .authorLogin(uniqueId)
                    .displayName(displayName)
                    .text(text)
                    .roles(roles)
                    .emotes(emotes)
                    .build());
            }

            @Override
            public void onGift(long msgId, String uniqueId, String displayName, String giftName, int repeatCount) {
                if (!markSeen(msgId)) {
                    return;
                }
                Text text = giftName == null || giftName.isBlank()
                    ? Text.translatable("takeyourstreamchat.event.tiktok.gift_unknown")
                    : Text.translatable("takeyourstreamchat.event.tiktok.gift", giftName, repeatCount);
                submitEvent(uniqueId, displayName, text, ChatEventType.GIFT);
            }

            @Override
            public void onFollow(long msgId, String uniqueId, String displayName) {
                if (!markSeen(msgId)) {
                    return;
                }
                submitEvent(
                    uniqueId,
                    displayName,
                    Text.translatable("takeyourstreamchat.event.tiktok.follow"),
                    ChatEventType.FOLLOW
                );
            }

            @Override
            public void onSubscribe(long msgId, String uniqueId, String displayName) {
                if (!markSeen(msgId)) {
                    return;
                }
                submitEvent(
                    uniqueId,
                    displayName,
                    Text.translatable("takeyourstreamchat.event.tiktok.subscribe"),
                    ChatEventType.SUBSCRIBE
                );
            }

            private void submitEvent(String uniqueId, String displayName, Text text, ChatEventType eventType) {
                pipeline.process(IncomingChatMessage.builder(ChatPlatform.TIKTOK)
                    .authorLogin(uniqueId)
                    .displayName(displayName)
                    .text(text.getString())
                    .eventType(eventType)
                    .build());
            }

            @Override
            public void onLiveEnded() {
                TakeYourMineStreamClient.LOGGER.info("TikTok live ended for @{}", username);
                roomId = null;
                seenMessageIds.clear();
                disconnectWebSocket();
            }
        });
        TikTokImFetch.Result bootstrap = TikTokImFetch.tryFetch(currentRoomId, "");
        if (bootstrap != null) {
            fetchCursor = bootstrap.cursor();
            webSocket.ingest(bootstrap.messages());
            TakeYourMineStreamClient.LOGGER.info(
                "TikTok IM fetch for @{}: {} messages",
                username,
                bootstrap.messages().size()
            );
        }
        webSocket.connect(TikTokWssUrl.build(
            currentRoomId,
            bootstrap != null ? bootstrap.cursor() : "",
            bootstrap != null ? bootstrap.internalExt() : "",
            bootstrap != null && bootstrap.hasPushServer() ? bootstrap.pushServer() : null
        ));
        startFetchPoll(currentRoomId, webSocket, bootstrap);
    }

    private void startFetchPoll(String currentRoomId, TikTokWebSocket socket, TikTokImFetch.Result bootstrap) {
        stopFetchPoll();
        if (bootstrap == null) {
            return;
        }
        fetchThread = new Thread(() -> {
            long intervalMs = bootstrap.fetchIntervalMs();
            while (running && webSocket == socket && socket.isRunning()) {
                sleepQuietly(intervalMs);
                if (!running || webSocket != socket) {
                    break;
                }
                TikTokImFetch.Result next = TikTokImFetch.tryFetch(currentRoomId, fetchCursor);
                if (next == null) {
                    continue;
                }
                if (next.hasCursor()) {
                    fetchCursor = next.cursor();
                }
                intervalMs = next.fetchIntervalMs();
                socket.ingest(next.messages());
            }
        }, "TikTokFetch-" + username);
        fetchThread.setDaemon(true);
        fetchThread.start();
    }

    private void stopFetchPoll() {
        Thread thread = fetchThread;
        fetchThread = null;
        if (thread != null) {
            thread.interrupt();
        }
    }

    /** Отсекает дубли сообщений и событий по msgId; false — уже видели. */
    private boolean markSeen(long msgId) {
        if (msgId != 0 && !seenMessageIds.add(msgId)) {
            return false;
        }
        while (seenMessageIds.size() > MAX_SEEN_MESSAGE_IDS) {
            var iterator = seenMessageIds.iterator();
            if (!iterator.hasNext()) {
                break;
            }
            iterator.next();
            iterator.remove();
        }
        return true;
    }

    private void disconnectWebSocket() {
        stopFetchPoll();
        TikTokWebSocket ws = webSocket;
        webSocket = null;
        if (ws != null) {
            ws.disconnect();
        }
    }

    private static String resolveRoomId(String user) throws IOException {
        // Основной способ: api-live (страница /live теперь закрыта WAF-заглушкой).
        // sourceType=54 обязателен, без него API возвращает params_error.
        String apiUrl = "https://www.tiktok.com/api-live/user/room/?aid=1988&sourceType=54&uniqueId="
            + URLEncoder.encode(user, StandardCharsets.UTF_8);
        String apiBody = ChatHttp.get(apiUrl, "https://www.tiktok.com/");
        String roomId = null;
        Integer status = null;
        try {
            JsonObject json = JsonParser.parseString(apiBody).getAsJsonObject();
            if (json.has("data") && json.get("data").isJsonObject()) {
                JsonObject data = json.getAsJsonObject("data");
                if (data.has("user") && data.get("user").isJsonObject()) {
                    JsonObject userObj = data.getAsJsonObject("user");
                    if (userObj.has("roomId") && !userObj.get("roomId").isJsonNull()) {
                        roomId = userObj.get("roomId").getAsString();
                    }
                    if (userObj.has("status") && !userObj.get("status").isJsonNull()) {
                        status = userObj.get("status").getAsInt();
                    }
                }
            }
        } catch (Exception ignored) {
            // не-JSON ответ: пробуем запасной способ ниже
        }

        // Статус 2 = идёт эфир; 4 = эфир завершён/оффлайн
        if (status != null && status != 2) {
            throw new takeyourminestream.ijustseen.integration.chat.ChatConnectException(
                "takeyourstreamchat.chat.error.not_live",
                "@" + user + " is not live right now (status " + status + ")",
                "TikTok", "@" + user
            );
        }
        if (roomId != null && !roomId.isBlank() && !"0".equals(roomId)) {
            return roomId;
        }

        // Запасной способ: парсинг HTML страницы /live (может быть закрыт WAF)
        String liveUrl = "https://www.tiktok.com/@" + URLEncoder.encode(user, StandardCharsets.UTF_8) + "/live";
        String html = ChatHttp.get(liveUrl, "https://www.tiktok.com/");
        roomId = firstMatch(ROOM_ID_PATTERN, html);
        if (roomId == null) {
            roomId = firstMatch(ROOM_ID_ALT, html);
        }
        if (roomId == null || roomId.isBlank()) {
            throw new takeyourminestream.ijustseen.integration.chat.ChatConnectException(
                "takeyourstreamchat.chat.error.no_live_room",
                "No live room found for @" + user + " (user not found or not live)",
                "TikTok", "@" + user
            );
        }
        return roomId;
    }

    private static String firstMatch(Pattern pattern, String text) {
        Matcher matcher = pattern.matcher(text);
        return matcher.find() ? matcher.group(1) : null;
    }

    /** Смена ника прерывает HTTP-запрос и заворачивает это в IOException. Это остановка, не ошибка. */
    private static boolean isInterruption(Throwable error) {
        for (Throwable current = error; current != null; current = current.getCause()) {
            if (current instanceof InterruptedException) {
                return true;
            }
        }
        return false;
    }

    private static void sleepQuietly(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    @Override
    public ChatPlatform getPlatform() {
        return ChatPlatform.TIKTOK;
    }

    @Override
    public void connect(ChatMessagePipeline pipeline) {
        // Connected in constructor
    }

    @Override
    public void disconnect() {
        running = false;
        disconnectWebSocket();
        Thread thread = workerThread;
        if (thread != null) {
            thread.interrupt();
        }
    }

    @Override
    public boolean isConnected() {
        return running;
    }
}
