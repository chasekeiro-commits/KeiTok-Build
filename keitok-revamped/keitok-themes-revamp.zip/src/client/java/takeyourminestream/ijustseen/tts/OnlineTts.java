package takeyourminestream.ijustseen.tts;

import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Онлайн-голос: скачивает MP3 для нужного языка и проигрывает системным плеером (JDK не умеет MP3). */
final class OnlineTts {
    /** Сервис не знает такой язык (HTTP 400/404): это не сбой сети, повторять и отключать онлайн не нужно. */
    static final class UnsupportedLanguage extends IOException {
        UnsupportedLanguage(String lang) {
            super("Online voice has no " + lang + " voice");
        }
    }

    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(5)).build();
    private static final int CHUNK = 180;
    private static final boolean WINDOWS = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).startsWith("windows");
    private static final boolean MAC = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).startsWith("mac");

    private OnlineTts() {}

    static List<String> chunks(String text) {
        List<String> out = new ArrayList<>();
        String rest = text.strip();
        while (rest.length() > CHUNK) {
            int cut = -1;
            for (char c : new char[] {'.', '!', '?', ',', ' ', '。', '、'}) {
                cut = Math.max(cut, rest.lastIndexOf(c, CHUNK - 1));
            }
            if (cut < CHUNK / 3) {
                cut = CHUNK - 1;
            }
            out.add(rest.substring(0, cut + 1).strip());
            rest = rest.substring(cut + 1).strip();
        }
        if (!rest.isEmpty()) {
            out.add(rest);
        }
        out.removeIf(String::isBlank);
        return out;
    }

    /** Скачивает озвучку в временный mp3 (куски склеиваются). */
    static Path fetch(String text, String lang, TtsSettings s) throws IOException, InterruptedException {
        Path file = Files.createTempFile("keitok-tts-", ".mp3");
        try (OutputStream os = Files.newOutputStream(file)) {
            for (String part : chunks(text)) {
                String sep = s.endpoint.contains("?") ? "&" : "?";
                URI uri = URI.create(s.endpoint + sep + "ie=UTF-8&client=tw-ob&tl="
                    + URLEncoder.encode(lang, StandardCharsets.UTF_8)
                    + "&q=" + URLEncoder.encode(part, StandardCharsets.UTF_8));
                HttpRequest req = HttpRequest.newBuilder(uri)
                    .timeout(Duration.ofSeconds(s.timeoutSeconds))
                    .header("User-Agent", "Mozilla/5.0 (KeiTok TTS)")
                    .GET().build();
                HttpResponse<byte[]> res = HTTP.send(req, HttpResponse.BodyHandlers.ofByteArray());
                if (res.statusCode() == 400 || res.statusCode() == 404) {
                    throw new UnsupportedLanguage(lang);
                }
                if (res.statusCode() != 200 || res.body().length < 100) {
                    throw new IOException("Online voice returned HTTP " + res.statusCode());
                }
                os.write(res.body());
            }
        } catch (IOException | InterruptedException | RuntimeException e) {
            Files.deleteIfExists(file);
            throw e;
        }
        return file;
    }

    static Process play(Path file, int volume, int rate) throws IOException {
        String path = file.toAbsolutePath().toString();
        double speed = Math.max(0.5, Math.min(2.0, 1.0 + rate * 0.05));
        ProcessBuilder pb;
        if (WINDOWS) {
            pb = new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", "-");
            pb.environment().put("TYSC_TTS_FILE", path);
            pb.environment().put("TYSC_TTS_VOLUME", Integer.toString(volume));
            pb.environment().put("TYSC_TTS_SPEED", String.format(Locale.ROOT, "%.2f", speed));
            pb.redirectErrorStream(true);
            pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);
            Process p = pb.start();
            String script = String.join("\n",
                "Add-Type -AssemblyName presentationCore",
                "$p = New-Object System.Windows.Media.MediaPlayer",
                "$p.Open([Uri]$env:TYSC_TTS_FILE)",
                "$p.Volume = [double]$env:TYSC_TTS_VOLUME / 100",
                "$p.SpeedRatio = [double]::Parse($env:TYSC_TTS_SPEED, [Globalization.CultureInfo]::InvariantCulture)",
                "$p.Play()",
                "$n = 0",
                "while (-not $p.NaturalDuration.HasTimeSpan -and $n -lt 100) { Start-Sleep -Milliseconds 100; $n++ }",
                "if ($p.NaturalDuration.HasTimeSpan) { Start-Sleep -Milliseconds ([int]($p.NaturalDuration.TimeSpan.TotalMilliseconds / $p.SpeedRatio) + 300) }",
                "$p.Close()",
                "");
            try (OutputStream os = p.getOutputStream()) {
                os.write(script.getBytes(StandardCharsets.UTF_8));
            }
            return p;
        }
        if (MAC) {
            pb = new ProcessBuilder("afplay", "-v", String.format(Locale.ROOT, "%.2f", volume / 100.0),
                "-r", String.format(Locale.ROOT, "%.2f", speed), path);
        } else {
            String player = firstOnPath("mpg123", "mpg321", "ffplay", "mpv", "cvlc", "vlc", "mplayer", "gst-play-1.0", "play", "pw-play", "paplay");
            if (player == null) {
                throw new IOException("No MP3 player found. Install one of: mpg123, ffmpeg (ffplay), mpv or vlc.");
            }
            pb = switch (player) {
                case "mpg123" -> new ProcessBuilder("mpg123", "-q", "-f", Integer.toString(volume * 327), path);
                case "ffplay" -> new ProcessBuilder("ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet",
                    "-volume", Integer.toString(volume), path);
                case "mpv" -> new ProcessBuilder("mpv", "--no-video", "--really-quiet", "--volume=" + volume, path);
                case "mpg321" -> new ProcessBuilder("mpg321", "-q", path);
                case "cvlc", "vlc" -> new ProcessBuilder(player, "--intf", "dummy", "--play-and-exit", "--quiet", path);
                case "mplayer" -> new ProcessBuilder("mplayer", "-really-quiet", "-volume", Integer.toString(volume), path);
                case "gst-play-1.0" -> new ProcessBuilder("gst-play-1.0", "--quiet", path);
                case "pw-play", "paplay" -> new ProcessBuilder(player, path);
                default -> new ProcessBuilder("play", "-q", path);
            };
        }
        pb.redirectErrorStream(true);
        pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);
        return pb.start();
    }

    private static String firstOnPath(String... names) {
        String path = System.getenv("PATH");
        if (path == null) {
            return null;
        }
        for (String name : names) {
            for (String dir : path.split(java.io.File.pathSeparator)) {
                if (!dir.isBlank() && Files.isExecutable(Path.of(dir, name))) {
                    return name;
                }
            }
        }
        return null;
    }
}
