package takeyourminestream.ijustseen.tts;

import net.minecraft.client.MinecraftClient;
import takeyourminestream.ijustseen.config.ModConfig;
import takeyourminestream.ijustseen.config.ModConfigData;
import takeyourminestream.ijustseen.integration.chat.ChatEventType;
import takeyourminestream.ijustseen.utils.Logger;

import java.util.List;
import java.util.regex.Pattern;

/**
 * Озвучка чата (TTS). Точка входа для {@code ChatMessagePipeline}: вызывается уже после всех фильтров мода
 * (ники, роли, regexp, банворды), так что читается ровно то, что видит зритель.
 */
public final class TtsManager {
    private static final Pattern URL = Pattern.compile("(?i)(https?://\\S+|www\\.\\S+)");
    /** Эмодзи и прочие пиктограммы: синтезатор читает их длинными описаниями. */
    private static final Pattern SYMBOLS = Pattern.compile("[\\p{So}\\p{Sk}\\p{Cs}\\u200d\\ufe0f\\uFFFC]");
    private static final Pattern SECTION_CODES = Pattern.compile("§.");
    private static final Pattern REPEATS = Pattern.compile("(.)\\1{3,}");
    private static final Pattern WHITESPACE = Pattern.compile("\\s+");
    private static final Pattern NAME_SEPARATORS = Pattern.compile("[_.]+");

    private static volatile TtsEngine engine;

    private TtsManager() {}

    private static TtsEngine engine() {
        TtsEngine e = engine;
        if (e == null) {
            synchronized (TtsManager.class) {
                e = engine;
                if (e == null) {
                    e = new TtsEngine(TtsManager::reportError);
                    engine = e;
                    Runtime.getRuntime().addShutdownHook(new Thread(TtsManager::shutdown, "TYSC-TTS-Shutdown"));
                }
            }
        }
        return e;
    }

    /** Движок создаётся лениво, поэтому при выключенной озвучке мод не запускает лишних потоков. */
    public static void onMessage(String displayName, String text, ChatEventType type) {
        try {
            handle(displayName, text, type);
        } catch (Throwable t) {
            // озвучка вторична: любая её ошибка не должна убрать сообщение с экрана
            Logger.warning("TTS skipped a message: " + t);
        }
    }

    private static void handle(String displayName, String text, ChatEventType type) {
        ModConfigData c = ModConfig.getCurrentConfig();
        if (!c.isEnableTts()) {
            return;
        }
        boolean isEvent = type != null && type.isEvent();
        if (isEvent && !c.isTtsReadEvents()) {
            return;
        }

        String body = cleanText(text, c.getTtsMaxChars());
        if (body == null) {
            return;
        }
        String name = cleanName(displayName);

        String phrase;
        if (isEvent) {
            phrase = name + " " + body;
        } else if (c.isTtsReadNames()) {
            phrase = name + ": " + body;
        } else {
            phrase = body;
        }
        engine().enqueue(phrase, c.getTtsMaxQueue());
    }

    /** Для {@code /streamchat tts test}: произнести текст как есть (без фильтров). */
    public static void speakRaw(String text) {
        ModConfigData c = ModConfig.getCurrentConfig();
        engine().resetErrorFlag();
        engine().enqueue(text, c.getTtsMaxQueue());
    }

    public static void skip() {
        TtsEngine e = engine;
        if (e != null) {
            e.skip();
        }
    }

    public static void clear() {
        TtsEngine e = engine;
        if (e != null) {
            e.clear();
        }
    }

    public static String describe() {
        TtsEngine e = engine();
        return e.describe() + (e.isSpeaking() ? ", speaking" : "") + ", queue " + e.pending();
    }

    /** Блокирующий вызов: список голосов. */
    public static List<String> listVoices() {
        return engine().listVoices();
    }

    public static void shutdown() {
        TtsEngine e = engine;
        if (e != null) {
            e.shutdown();
        }
    }

    // ------------------------------------------------------------------ очистка текста

    /** Текст для озвучки или {@code null}, если сообщение читать не нужно. */
    static String cleanText(String raw, int maxChars) {
        if (raw == null) {
            return null;
        }
        String text = SECTION_CODES.matcher(raw).replaceAll("");
        text = URL.matcher(text).replaceAll(" link ");
        text = SYMBOLS.matcher(text).replaceAll("");
        text = REPEATS.matcher(text).replaceAll("$1$1$1");
        text = WHITESPACE.matcher(text).replaceAll(" ").strip();
        if (text.isEmpty() || text.codePoints().noneMatch(Character::isLetterOrDigit)) {
            return null;
        }
        if (text.length() > maxChars) {
            int cut = text.lastIndexOf(' ', maxChars);
            text = text.substring(0, cut > maxChars / 2 ? cut : maxChars).strip();
        }
        return text;
    }

    static String cleanName(String raw) {
        String name = raw == null ? "" : raw;
        name = SECTION_CODES.matcher(name).replaceAll("");
        name = SYMBOLS.matcher(name).replaceAll("");
        name = NAME_SEPARATORS.matcher(name).replaceAll(" ");
        name = WHITESPACE.matcher(name).replaceAll(" ").strip();
        if (name.length() > 30) {
            name = name.substring(0, 30).strip();
        }
        return name.isEmpty() ? "someone" : name;
    }

    private static void reportError(String message) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null) {
            return;
        }
        client.execute(() -> Logger.sendErrorToPlayer("TTS: " + message));
    }

}
