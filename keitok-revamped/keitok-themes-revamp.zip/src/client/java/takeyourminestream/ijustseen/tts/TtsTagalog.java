package takeyourminestream.ijustseen.tts;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Приводит тагальский чат (сленг, сокращения, "hahaha", Taglish) к виду, который голос читает естественно:
 * "tlga po ung gnda" -> "talaga po yung ganda".
 */
final class TtsTagalog {
    private static final Pattern WORD = Pattern.compile("[\\p{L}']+");
    private static final Pattern LAUGH = Pattern.compile("(?i)\\b(?:(?:ha|he|hi|ho|hu){2,}|w?a?h(?:a){2,}h?|ahaha+h*|ehe(?:he)*)\\b");
    private static final Pattern ELONG = Pattern.compile("(?i)([aeiou])\\1{2,}");
    private static final Pattern DIGIT = Pattern.compile("(?<![\\p{L}\\p{N}.,])([0-9]|10)(?![\\p{L}\\p{N}.,])");
    private static final String[] NUM = {"zero", "isa", "dalawa", "tatlo", "apat", "lima", "anim", "pito", "walo", "siyam", "sampu"};
    private static final Map<String, String> SLANG = new LinkedHashMap<>();

    static {
        String[][] pairs = {
            // сокращения и text-speak
            {"tlga", "talaga"}, {"tlg", "talaga"}, {"talga", "talaga"}, {"nmn", "naman"}, {"nman", "naman"},
            {"lng", "lang"}, {"lang", "lang"}, {"dn", "din"}, {"rn", "ngayon"}, {"di", "hindi"}, {"hnd", "hindi"},
            {"hndi", "hindi"}, {"d", "hindi"}, {"wag", "huwag"}, {"wg", "huwag"}, {"kc", "kasi"}, {"kse", "kasi"},
            {"ksi", "kasi"}, {"pano", "paano"}, {"sn", "saan"}, {"sya", "siya"}, {"cya", "siya"},
            {"sia", "siya"}, {"aq", "ako"}, {"ko", "ko"}, {"ikw", "ikaw"}, {"ka", "ka"}, {"ung", "yung"},
            {"yun", "yun"}, {"yan", "iyan"}, {"ganun", "ganoon"}, {"ganon", "ganoon"}, {"ganyan", "ganiyan"},
            {"dto", "dito"}, {"dyan", "diyan"}, {"dun", "doon"}, {"sge", "sige"}, {"ge", "sige"}, {"sg", "sige"}, {"mga", "mga"}, {"pra", "para"}, {"pr", "para"},
            {"pde", "puwede"}, {"pwde", "puwede"}, {"pwede", "puwede"}, {"pde", "puwede"}, {"po", "po"},
            {"tnx", "salamat"}, {"thnx", "salamat"}, {"thx", "salamat"}, {"tnk", "salamat"}, {"ty", "salamat"},
            {"salamat", "salamat"}, {"tysm", "maraming salamat"}, {"pls", "please"}, {"plss", "please"},
            {"plz", "please"}, {"pkiusap", "pakiusap"}, {"pki", "paki"}, {"nga", "nga"}, {"ngl", "honestly"},
            {"idk", "hindi ko alam"}, {"ikr", "oo nga"}, {"imo", "sa tingin ko"}, {"btw", "nga pala"},
            {"brb", "babalik ako"}, {"afk", "wala muna ako"}, {"omw", "papunta na ako"}, {"hbd", "happy birthday"},
            {"gm", "good morning"}, {"gn", "good night"}, {"ggs", "good game"}, {"gg", "good game"},
            {"wp", "well played"}, {"ez", "easy"}, {"nt", "nice try"}, {"sml", "sana all"}, {"sana", "sana"},
            {"charot", "charot"}, {"char", "charot"}, {"chz", "charot"}, {"jk", "joke lang"}, {"jklang", "joke lang"},
            {"lodi", "lodi"}, {"lods", "lodi"}, {"idol", "idol"}, {"pre", "pare"}, {"pri", "pare"}, {"pards", "pare"}, {"bro", "bro"}, {"sis", "sis"}, {"kuys", "kuya"}, {"kuy", "kuya"},
            {"mhal", "mahal"}, {"mahal", "mahal"}, {"mhl", "mahal"}, {"iloveyou", "I love you"}, {"ily", "I love you"},
            {"u", "ikaw"}, {"ur", "your"}, {"ya", "ikaw"}, {"wla", "wala"}, {"wlang", "walang"}, {"mron", "mayroon"},
            {"meron", "mayroon"}, {"mron", "mayroon"}, {"mgnda", "maganda"}, {"gnda", "ganda"}, {"gnda", "ganda"},
            {"pogi", "pogi"}, {"ngyon", "ngayon"}, {"ngaun", "ngayon"}, {"nyo", "ninyo"}, {"nyu", "ninyo"},
            {"namn", "naman"}, {"cge", "sige"}, {"sbi", "sabi"}, {"sbhn", "sabihin"}, {"lgi", "lagi"},
            {"palagi", "palagi"}, {"bkt", "bakit"}, {"bkit", "bakit"}, {"kelan", "kailan"},
            {"kelan", "kailan"}, {"knina", "kanina"}, {"mmya", "mamaya"}, {"mamya", "mamaya"}, {"bka", "baka"},
            {"b4", "bago"}, {"2day", "ngayon"}, {"2mrw", "bukas"}, {"bukas", "bukas"},
            {"tlaga", "talaga"}, {"alm", "alam"}, {"alm", "alam"}, {"xa", "siya"}, {"xempre", "syempre"},
            {"syempre", "siyempre"}, {"sympre", "siyempre"}, {"skl", "share ko lang"}, {"gets", "gets"},
            {"oks", "okay"}, {"ok", "okay"}, {"okie", "okay"}, {"okiii", "okay"}, {"yes", "oo"}, {"opo", "opo"},
            {"oo", "oo"}, {"hnde", "hindi"}, {"hinde", "hindi"}, {"hindi", "hindi"}, {"ewan", "ewan"},
            {"ewn", "ewan"}, {"nkakatawa", "nakakatawa"}, {"nkakainis", "nakakainis"}, {"nkakaloka", "nakakaloka"},
            {"lmao", "ha ha ha"}, {"lmfao", "ha ha ha"}, {"lol", "ha ha"}, {"lols", "ha ha"}, {"rofl", "ha ha ha"},
            {"xd", "ha ha"}, {"omg", "oh my god"}, {"omfg", "oh my god"}, {"wtf", "ano ba"}, {"wth", "ano ba"},
            {"smh", "naku"}, {"tbh", "sa totoo lang"}, {"fyi", "para alam mo"}, {"asap", "agad"}, {"hbu", "ikaw naman"},
            {"hru", "kumusta ka"}, {"wbu", "ikaw naman"}, {"ayos", "ayos"}, {"ayus", "ayos"}, {"astig", "astig"},
            {"petmalu", "petmalu"}, {"werpa", "power"}, {"waley", "wala"}, {"eme", "eme"}, {"echos", "echos"},
            {"nkkta", "nakita"}, {"nkita", "nakita"}, {"nkuha", "nakuha"}, {"nka", "naka"}, {"mkita", "makita"},
            {"mkpag", "makapag"}, {"pkiusap", "pakiusap"}, {"pkiramdam", "pakiramdam"}, {"gling", "galing"},
            {"glng", "galing"}, {"gling", "galing"}, {"mgaling", "magaling"}, {"mgling", "magaling"},
            {"nkktuwa", "nakakatuwa"}, {"nkktwa", "nakakatawa"}, {"gnun", "ganoon"}, {"gnon", "ganoon"},
            {"gnyn", "ganiyan"}, {"ngyn", "ngayon"}, {"tska", "tsaka"}, {"tsaka", "tsaka"}, {"tas", "tapos"},
            {"tpos", "tapos"}, {"tapus", "tapos"}, {"hirap", "hirap"}, {"hrp", "hirap"}, {"dmi", "dami"},
            {"mdami", "marami"}, {"mrami", "marami"}, {"kunti", "konti"}, {"kti", "konti"}, {"gabi", "gabi"},
            {"umaga", "umaga"}, {"tanghali", "tanghali"}, {"hapon", "hapon"}, {"magandang", "magandang"},
            {"mgandang", "magandang"}, {"mgndng", "magandang"}, {"gud", "good"}, {"gudmorning", "good morning"},
            {"gdmorning", "good morning"}, {"gdnyt", "good night"}, {"gnyt", "good night"}, {"gudnyt", "good night"},
            {"gdluck", "good luck"}, {"gl", "good luck"}, {"hf", "have fun"}, {"glhf", "good luck have fun"},
            {"ingat", "ingat"}, {"ingatz", "ingat"}, {"tc", "take care"}, {"ntg", "nothing"}, {"ntn", "ano ba"},
            {"anu", "ano"}, {"nu", "ano"}, {"sino", "sino"}, {"cno", "sino"}, {"kaylan", "kailan"},
            {"bkit", "bakit"}, {"bkt", "bakit"}, {"pnu", "paano"}, {"pno", "paano"}, {"pano", "paano"},
            {"cguro", "siguro"}, {"sguro", "siguro"}, {"siguro", "siguro"}, {"cgurado", "sigurado"},
            {"sgurado", "sigurado"}, {"lamg", "lang"}, {"lmg", "lang"}, {"kme", "kami"}, {"tyo", "tayo"},
            {"kyo", "kayo"}, {"sla", "sila"}, {"kmi", "kami"}, {"cla", "sila"}, {"aku", "ako"}, {"akoh", "ako"},
            {"mo", "mo"}, {"nyan", "niyan"}, {"nito", "nito"}, {"nun", "noon"}, {"nung", "noong"}, {"noong", "noong"},
            {"pag", "pag"}, {"kpag", "kapag"}, {"kpg", "kapag"}, {"pg", "pag"}, {"hnggang", "hanggang"},
            {"hanggang", "hanggang"}, {"hngga", "hanggang"}, {"mgsimula", "magsimula"}, {"simula", "simula"},
            {"gawa", "gawa"}, {"gwa", "gawa"}, {"gwin", "gawin"}, {"gawin", "gawin"}, {"mgdasal", "magdasal"},
            {"pray", "pray"}, {"godbless", "God bless"}, {"gbu", "God bless you"}, {"gb", "God bless"},
            {"jowa", "jowa"}, {"bes", "bes"}, {"bhie", "babe"}, {"bhe", "babe"}, {"mhie", "mahal"},
        };
        for (String[] p : pairs) {
            SLANG.put(p[0], p[1]);
        }
    }

    private TtsTagalog() {}

    static String normalize(String text) {
        String t = LAUGH.matcher(text).replaceAll(" ha ha ha ");
        // "gandaaaa" -> "ganda" (3+ одинаковых гласных подряд сводим к одной)
        t = ELONG.matcher(t).replaceAll("$1");
        Matcher dm = DIGIT.matcher(t);
        StringBuilder ds = new StringBuilder();
        while (dm.find()) {
            dm.appendReplacement(ds, NUM[Integer.parseInt(dm.group(1))]);
        }
        dm.appendTail(ds);
        t = ds.toString();
        Matcher m = WORD.matcher(t);
        StringBuilder sb = new StringBuilder();
        while (m.find()) {
            String word = m.group();
            String repl = SLANG.get(word.toLowerCase(Locale.ROOT));
            if (repl == null) {
                repl = word;
            } else if (Character.isUpperCase(word.charAt(0)) && !repl.isEmpty()) {
                repl = Character.toUpperCase(repl.charAt(0)) + repl.substring(1);
            }
            m.appendReplacement(sb, Matcher.quoteReplacement(repl));
        }
        m.appendTail(sb);
        return sb.toString().replaceAll("\\s+", " ").strip();
    }
}
