package takeyourminestream.ijustseen.tts;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import java.util.regex.Pattern;

/**
 * Определение языка сообщения без внешних библиотек: сначала по письменности
 * (хангыль, кана, тайский, кириллица...), для латиницы — по частотным словам и диакритике.
 * Возвращает код языка в формате Google TTS: en, tl, ko, ja, th, zh-CN, es, ...
 */
public final class TtsLanguage {
    private static final Pattern WORD_SPLIT = Pattern.compile("[^\\p{L}']+");
    private static final Map<String, Set<String>> WORDS = new LinkedHashMap<>();

    static {
        words("en", "the and is you are this that with for not have what how your just like good lol omg yes no hello hi "
            + "thanks thank please love game play nice cool im it's i'm don't can will would my me we they he she was be on at "
            + "to of in it so but all out up one get got going know see look wow bro dude guys stream chat");
        words("tl", "naku nako talaga pare pards lodi idol hehe haha pogi ganda galing husay tawa saya sana ayos astig bes beh wala meron mayroon walang kasi kaya kung kapag pag yata siguro baka pwede puwede dapat gusto ayaw alam akala sabi ewan ayan eto heto yan iyon yun mo ko niyo ninyo natin namin nito niyan noon mamaya kanina bukas kahapon lagi minsan isa dalawa tatlo apat lima po opo ho oo hindi di huwag wag ang ng sa na ako ikaw ka mo ko siya niya natin namin nila po opo hindi wala mayroon may gusto salamat "
            + "kumusta kamusta naman lang yung yun ito iyan mga ba pa din rin daw raw talaga sobra pre tara sige oo bakit "
            + "paano saan ano sino ganda galing laro ate kuya mahal kain tulog bukas ngayon dito diyan doon aba ay "
            + "kayo tayo kami sila ba nga nang kasi pero tapos");
        words("es", "el la los las de que y es en un una por con para no te lo se me mi tu su pero como más mas muy hola "
            + "gracias bien qué esto está son yo eres soy vamos jaja buenas");
        words("fr", "le la les des est une un et en que qui pour pas je tu il nous vous dans sur avec bonjour merci très "
            + "c'est salut oui non mais comme");
        words("de", "der die das und ist nicht ich du wir sie ein eine mit für auf aber auch hallo danke gut ja nein "
            + "was wie wer sehr");
        words("pt", "o a os as de que e é em um uma para com não nao eu você voce muito olá ola obrigado obrigada bem isso "
            + "está esta tudo");
        words("id", "yang dan di ini itu dengan untuk tidak saya kamu aku apa kenapa halo terima kasih bagus banget ya sih "
            + "dong nih gak nggak udah belum");
        words("it", "il lo la gli le di che e è un una per con non mi ti ciao grazie bene molto sono sei siamo anche "
            + "come più questo questa buongiorno prego");
        words("nl", "de het een en van ik je jij we ze is niet dat dit met voor ook maar hallo dank bedankt goed heel "
            + "wat hoe zijn wij");
        words("tr", "ve bir bu da de ben sen biz evet hayır merhaba teşekkürler çok iyi güzel nasıl neden ne için ama "
            + "değil selam");
        words("pl", "i w nie to jest się na że z do jak co tak ale cześć dzięki dobrze bardzo ja ty my dziękuję");
        words("ms", "yang dan di ini itu dengan untuk tidak saya awak aku apa kenapa hai terima kasih bagus sangat "
            + "boleh jom");
        words("sv", "och i att det som en är på jag du vi inte med för hej tack bra mycket men");
        // дополнительные частотные слова
        words("es", "bueno buena buenos buenas todo todos todas está estoy estás gracias amigo amiga jugar juego saludos "
            + "directo vamos genial excelente tengo quiero puedo porque cuando donde quién nada algo siempre también ahora");
        words("nl", "allemaal dank wel hoi goedemorgen alsjeblieft leuk gezellig vandaag nu ook nog hier daar jullie");
        words("en", "hey guys everyone welcome stream streamer playing watching thanks following subscribe awesome amazing "
            + "really very much more them there their here where when why who because about would could should");
        words("fr", "bonsoir merci beaucoup tout monde très bien super génial vraiment aussi encore toujours maintenant");
        words("de", "zusammen alle sehr gut danke bitte heute jetzt auch noch immer wirklich toll schön");
        words("pt", "pessoal obrigado obrigada muito bem hoje agora também sempre realmente legal incrível");
        words("it", "tutti grazie mille oggi adesso anche ancora sempre davvero bello fantastico buonasera");
        words("id", "semua terima kasih banyak hari ini sekarang juga masih selalu benar keren mantap kak bang");
        words("vi", "và là của có không tôi bạn xin chào cảm ơn rất được những một anh em chị ơi nhé nha nhỉ đây này đó vậy "
            + "rồi thì mình tao mày ông bà con cái đẹp hay quá lắm vui buồn yêu thương cười");
        words("ro", "și este nu eu tu noi voi ei ce cum da mulțumesc bună salut foarte bine mai pentru care dar sau");
        words("cs", "a je to se na že ne ano ahoj děkuji dobrý moc jsem jsi jak co ale nebo");
        words("hu", "és a az egy nem igen szia köszönöm nagyon jó vagyok vagy hogy mit de vagy");
        words("fi", "ja on ei minä sinä me te he mitä kuinka kyllä moi kiitos hyvä todella mutta tai");
        words("da", "og er det jeg du vi ikke en et med til hej tak godt meget men eller");
        words("no", "og er det jeg du vi ikke en et med til hei takk bra veldig men eller");
        words("ca", "i és el la de que no jo tu nosaltres hola gràcies molt bé però o");
        words("sw", "na ni ya wa kwa hii hapana ndiyo habari asante sana nzuri mimi wewe sisi");
        words("hr", "i je da ne ja ti mi vi on ona što kako hvala bok dobro vrlo ali ili");
    }

    private TtsLanguage() {}

    private static void words(String lang, String list) {
        WORDS.computeIfAbsent(lang, k -> new HashSet<>()).addAll(List.of(list.split("\\s+")));
    }

    /** Язык текста; если определить нечем (цифры, смайлы, одно слово) — {@code fallback}. */
    public static String detect(String text, String fallback) {
        if (text == null || text.isBlank()) {
            return fallback;
        }
        int letters = 0, hangul = 0, kana = 0, han = 0, thai = 0, cyr = 0, arab = 0, deva = 0, greek = 0, hebrew = 0;
        for (int i = 0; i < text.length(); ) {
            int cp = text.codePointAt(i);
            i += Character.charCount(cp);
            if (!Character.isLetter(cp)) {
                continue;
            }
            letters++;
            switch (Character.UnicodeScript.of(cp)) {
                case HANGUL -> hangul++;
                case HIRAGANA, KATAKANA -> kana++;
                case HAN -> han++;
                case THAI -> thai++;
                case CYRILLIC -> cyr++;
                case ARABIC -> arab++;
                case DEVANAGARI -> deva++;
                case GREEK -> greek++;
                case HEBREW -> hebrew++;
                default -> { }
            }
        }
        if (letters == 0) {
            return fallback;
        }
        double threshold = 0.3 * letters;
        // японский текст почти всегда содержит кану; одни иероглифы — китайский
        if (kana > 0 && kana + han >= threshold) return "ja";
        if (hangul >= threshold) return "ko";
        if (han >= threshold) return chineseVariant(text);
        if (thai >= threshold) return "th";
        if (cyr >= threshold) return "ru";
        if (arab >= threshold) return "ar";
        if (deva >= threshold) return "hi";
        if (greek >= threshold) return "el";
        if (hebrew >= threshold) return "iw";
        return detectLatin(text, fallback);
    }

    private static final Pattern NOISE = Pattern.compile("(?i)(https?://\\S+|www\\.\\S+|[@#]\\w+)");
    private static final Pattern REPEAT = Pattern.compile("(\\p{L})\\1{2,}");
    private static final Pattern MARKS = Pattern.compile("\\p{M}+");
    /** Сколько языков содержат слово: общие слова (de, no, me...) весят меньше. */
    private static Map<String, Integer> shared;
    private static Map<String, Set<String>> strippedWords;

    private static synchronized void prepare() {
        if (shared != null) {
            return;
        }
        Map<String, Integer> count = new LinkedHashMap<>();
        Map<String, Set<String>> stripped = new LinkedHashMap<>();
        for (Map.Entry<String, Set<String>> e : WORDS.entrySet()) {
            Set<String> st = new HashSet<>();
            for (String w : e.getValue()) {
                st.add(strip(w));
            }
            stripped.put(e.getKey(), st);
            for (String w : st) {
                count.merge(w, 1, Integer::sum);
            }
        }
        strippedWords = stripped;
        shared = count;
    }

    private static String strip(String word) {
        return MARKS.matcher(java.text.Normalizer.normalize(word, java.text.Normalizer.Form.NFD)).replaceAll("");
    }

    private static String detectLatin(String text, String fallback) {
        prepare();
        String lower = NOISE.matcher(text).replaceAll(" ").toLowerCase(Locale.ROOT);
        Map<String, Integer> score = new LinkedHashMap<>();
        for (String raw : WORD_SPLIT.split(lower)) {
            if (raw.isEmpty()) {
                continue;
            }
            // "hellooo" -> "hello", "kumustaaa" -> "kumusta"; проверяем и как есть, и без диакритики
            String word = strip(raw);
            String collapsed = REPEAT.matcher(word).replaceAll("$1");
            for (Map.Entry<String, Set<String>> e : strippedWords.entrySet()) {
                Set<String> set = e.getValue();
                String hit = set.contains(word) ? word : set.contains(collapsed) ? collapsed : null;
                if (hit != null) {
                    int base = hit.length() >= 5 ? 15 : 10; // длинные слова надёжнее
                    score.merge(e.getKey(), Math.max(3, base / shared.getOrDefault(hit, 1)), Integer::sum);
                }
            }
        }
        hint(score, lower, "ñ¿¡", "es", 20);
        hint(score, lower, "ãõ", "pt", 20);
        hint(score, lower, "ß", "de", 20);
        hint(score, lower, "äöü", "de", 10);
        hint(score, lower, "èêàœ", "fr", 10);
        hint(score, lower, "ảãạằắẳẵặầấẩẫậẻẽẹềếểễệỉĩịỏọồốổỗộơờớởỡợụưừứửữựỳỷỹỵđă", "vi", 40);
        hint(score, lower, "ăâîșț", "ro", 30);
        hint(score, lower, "řěůčšž", "cs", 20);
        hint(score, lower, "őű", "hu", 30);
        hint(score, lower, "æ", "da", 20);
        hint(score, lower, "ğışİ", "tr", 20);
        hint(score, lower, "ąęłńśźż", "pl", 20);
        hint(score, lower, "åø", "sv", 10);
        hint(score, lower, "çéû", "fr", 10);
        hint(score, lower, "ìò", "it", 10);

        int best = 0;
        List<String> top = new ArrayList<>();
        for (Map.Entry<String, Integer> e : score.entrySet()) {
            if (e.getValue() > best) {
                best = e.getValue();
                top.clear();
                top.add(e.getKey());
            } else if (e.getValue() == best && best > 0) {
                top.add(e.getKey());
            }
        }
        if (best < 3) {
            return fallback;
        }
        // Taglish: заметная доля тагальских слов — читаем тагальским голосом
        int tl = score.getOrDefault("tl", 0);
        if (tl >= 10 && tl * 2 >= best) {
            return "tl";
        }
        // близкие по очкам языки (разница < 5): остаёмся на языке по умолчанию, если он среди них
        if (score.getOrDefault(fallback, 0) + 5 > best && score.getOrDefault(fallback, 0) > 0) {
            return fallback;
        }
        return top.get(0);
    }

    /** Язык латинского фрагмента или {@code null}, если признаков нет. */
    private static String detectLatinOrNull(String text) {
        String r = detectLatin(text, "\u0000");
        return r.equals("\u0000") ? null : r;
    }

    /** Фрагмент текста на одном языке. */
    public record Segment(String lang, String text) {}

    private enum Kind { NEUTRAL, LATIN, KO, KANA, HAN, TH, CYR, AR, HI, EL, HE, BN, TA, TE, ML, KN, GU, PA, MY, KM, LO, KA, HY, SI, AM }

    private static Kind kindOf(int cp) {
        if (!Character.isLetter(cp)) {
            return Kind.NEUTRAL;
        }
        return switch (Character.UnicodeScript.of(cp)) {
            case HANGUL -> Kind.KO;
            case HIRAGANA, KATAKANA -> Kind.KANA;
            case HAN -> Kind.HAN;
            case THAI -> Kind.TH;
            case CYRILLIC -> Kind.CYR;
            case ARABIC -> Kind.AR;
            case DEVANAGARI -> Kind.HI;
            case GREEK -> Kind.EL;
            case HEBREW -> Kind.HE;
            case BENGALI -> Kind.BN;
            case TAMIL -> Kind.TA;
            case TELUGU -> Kind.TE;
            case MALAYALAM -> Kind.ML;
            case KANNADA -> Kind.KN;
            case GUJARATI -> Kind.GU;
            case GURMUKHI -> Kind.PA;
            case MYANMAR -> Kind.MY;
            case KHMER -> Kind.KM;
            case LAO -> Kind.LO;
            case GEORGIAN -> Kind.KA;
            case ARMENIAN -> Kind.HY;
            case SINHALA -> Kind.SI;
            case ETHIOPIC -> Kind.AM;
            case LATIN -> Kind.LATIN;
            default -> Kind.NEUTRAL;
        };
    }

    /**
     * Разбивает сообщение на языковые фрагменты: «hi всем 안녕 kumusta» читается тремя голосами.
     * Цифры и знаки прилипают к соседнему фрагменту; латиница без признаков языка — к соседнему же.
     */
    public static List<Segment> segments(String text, String fallback) {
        return segments(text, fallback, "auto");
    }

    public static List<Segment> segments(String text, String fallback, String latinLang) {
        List<Segment> out = new ArrayList<>();
        if (text == null || text.isBlank()) {
            return out;
        }
        boolean hasKana = false;
        for (int i = 0; i < text.length(); ) {
            int cp = text.codePointAt(i);
            i += Character.charCount(cp);
            if (kindOf(cp) == Kind.KANA) {
                hasKana = true;
                break;
            }
        }
        // 1. прогоны по письменности
        List<Kind> kinds = new ArrayList<>();
        List<StringBuilder> runs = new ArrayList<>();
        Kind cur = null;
        StringBuilder sb = null;
        StringBuilder pending = new StringBuilder(); // нейтральные символы до первого прогона
        for (int i = 0; i < text.length(); ) {
            int cp = text.codePointAt(i);
            i += Character.charCount(cp);
            Kind k = kindOf(cp);
            if (k == Kind.HAN && hasKana) {
                k = Kind.KANA;
            }
            if (k == Kind.NEUTRAL) {
                if (sb == null) {
                    pending.appendCodePoint(cp);
                } else {
                    sb.appendCodePoint(cp);
                }
                continue;
            }
            if (cur != k) {
                cur = k;
                sb = new StringBuilder(pending);
                pending.setLength(0);
                kinds.add(k);
                runs.add(sb);
            }
            sb.appendCodePoint(cp);
        }
        if (runs.isEmpty()) {
            return out; // только цифры и знаки
        }
        // 1b. двуязычный режим: латиницу режем на фразы, каждая читается своим голосом (английский / тагальский)
        if ("auto".equalsIgnoreCase(latinLang)) {
            List<Kind> k2 = new ArrayList<>();
            List<StringBuilder> r2 = new ArrayList<>();
            for (int i = 0; i < runs.size(); i++) {
                if (kinds.get(i) != Kind.LATIN) {
                    k2.add(kinds.get(i));
                    r2.add(runs.get(i));
                    continue;
                }
                StringBuilder acc = new StringBuilder();
                for (String clause : runs.get(i).toString().split("(?<=[.!?,;:\\n])")) {
                    acc.append(clause);
                    if (acc.length() >= 15) {
                        k2.add(Kind.LATIN);
                        r2.add(acc);
                        acc = new StringBuilder();
                    }
                }
                if (acc.length() > 0) {
                    k2.add(Kind.LATIN);
                    r2.add(acc);
                }
            }
            kinds = k2;
            runs = r2;
        }
        // 2. язык каждого прогона (null = неизвестно, латиница без признаков)
        List<String> langs = new ArrayList<>();
        for (int i = 0; i < runs.size(); i++) {
            String t = runs.get(i).toString();
            langs.add(switch (kinds.get(i)) {
                case KO -> "ko";
                case KANA -> "ja";
                case HAN -> chineseVariant(t);
                case TH -> "th";
                case CYR -> t.matches("(?s).*[іїєґІЇЄҐ].*") ? "uk" : "ru";
                case AR -> t.matches("(?s).*[ٹڈڑںےھ].*") ? "ur" : t.matches("(?s).*[پچژگ].*") ? "fa" : "ar";
                case BN -> "bn";
                case TA -> "ta";
                case TE -> "te";
                case ML -> "ml";
                case KN -> "kn";
                case GU -> "gu";
                case PA -> "pa";
                case MY -> "my";
                case KM -> "km";
                case LO -> "lo";
                case KA -> "ka";
                case HY -> "hy";
                case SI -> "si";
                case AM -> "am";
                case HI -> "hi";
                case EL -> "el";
                case HE -> "iw";
                default -> {
                    String d = detectLatinOrNull(t);
                    yield (!"auto".equalsIgnoreCase(latinLang) && (d == null || d.equals("en"))) ? latinLang : d;
                }
            });
        }
        // 3. неопознанные прогоны присоединяем к соседу (сначала к предыдущему)
        for (int i = 0; i < langs.size(); i++) {
            if (langs.get(i) == null) {
                String neighbor = i > 0 ? langs.get(i - 1) : null;
                for (int j = i + 1; neighbor == null && j < langs.size(); j++) {
                    neighbor = langs.get(j);
                }
                langs.set(i, neighbor != null ? neighbor : fallback);
            }
        }
        // 4. склеиваем соседние прогоны одного языка
        for (int i = 0; i < runs.size(); i++) {
            String lang = langs.get(i);
            String t = runs.get(i).toString();
            if (!out.isEmpty() && out.get(out.size() - 1).lang().equals(lang)) {
                Segment prev = out.remove(out.size() - 1);
                t = prev.text() + t;
            }
            out.add(new Segment(lang, t));
        }
        out.removeIf(seg -> seg.text().codePoints().noneMatch(Character::isLetterOrDigit));
        return out;
    }

    private static void hint(Map<String, Integer> score, String text, String chars, String lang, int points) {
        for (int i = 0; i < chars.length(); i++) {
            if (text.indexOf(chars.charAt(i)) >= 0) {
                score.merge(lang, points, Integer::sum);
                return;
            }
        }
    }

    private static final String TRADITIONAL = "們這個為說會學國後對與開來時電點體關麼嗎還應該從過進現裡愛謝讓聽見話請問歡臺灣";
    private static final String SIMPLIFIED = "们这个为说会学国后对与开来时电点体关么吗还应该从过进现里爱谢让听见话请问欢台湾";

    /** zh-TW, если больше традиционных иероглифов, иначе zh-CN. */
    private static String chineseVariant(String text) {
        int trad = 0, simp = 0;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (TRADITIONAL.indexOf(c) >= 0 && SIMPLIFIED.indexOf(c) < 0) trad++;
            else if (SIMPLIFIED.indexOf(c) >= 0 && TRADITIONAL.indexOf(c) < 0) simp++;
        }
        return trad > simp ? "zh-TW" : "zh-CN";
    }

    /** Двухбуквенный код семейства языка: zh-CN -> zh. */
    public static String base(String lang) {
        int dash = lang.indexOf('-');
        return (dash > 0 ? lang.substring(0, dash) : lang).toLowerCase(Locale.ROOT);
    }
}
