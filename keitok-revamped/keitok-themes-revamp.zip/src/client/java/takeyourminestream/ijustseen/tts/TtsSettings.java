package takeyourminestream.ijustseen.tts;

import takeyourminestream.ijustseen.utils.Logger;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;

/** Настройки многоязычной озвучки: файл config/keitok-tts.properties (создаётся при первом запуске). */
public final class TtsSettings {
    private static final String DEFAULT_FILE = """
        # KeiTok TTS - multilingual voice settings
        #
        # online: true = use an online neural/standard voice per message language (needs internet, no install).
        #         Message text is sent to the service. false = only local system voices.
        online=true
        # Language used when a message's language can't be detected, and for the voice chosen with /streamchat tts voice
        defaultLanguage=en
        # How Latin-script text is read. auto = English phrases in English and Tagalog phrases in Tagalog (both voices).
        # tl = read all English/unknown Latin text with the Tagalog voice. en = always English for unknown text.
        latinMode=auto
        # Comma-separated languages to read (others are skipped). Empty = read everything.
        # Auto-detected: en, tl, ko, ja, zh-CN, th, vi, es, ar, fa, ur, hi, bn, ta, te, ml, kn, gu, pa, my, km, lo, ka, hy, si, am,
        #   ru, uk, el, iw, fr, de, pt, it, nl, tr, pl, id, ms, sv, da, no, fi, cs, hu, ro, hr, ca, sw
        # A language the online voice can't speak is read with a local OS voice instead (the chat message always still appears).
        languages=
        # Speech service endpoint (Google-Translate-compatible: ?tl=<lang>&q=<text>, returns MP3)
        endpoint=https://translate.google.com/translate_tts
        timeoutSeconds=8
        """;

    public final boolean online;
    public final String defaultLanguage;
    public final String latinLanguage;
    public final Set<String> languages;
    public final String endpoint;
    public final int timeoutSeconds;

    private static volatile TtsSettings cached;
    private static volatile long cachedStamp = Long.MIN_VALUE;
    private static volatile long lastCheck;

    private TtsSettings(Properties p) {
        this.online = Boolean.parseBoolean(p.getProperty("online", "true").strip());
        String def = p.getProperty("defaultLanguage", "en").strip();
        this.defaultLanguage = def.isEmpty() ? "en" : def;
        String latin = p.getProperty("latinMode", "auto").strip();
        this.latinLanguage = latin.isEmpty() ? "auto" : latin;
        Set<String> langs = new LinkedHashSet<>();
        for (String part : p.getProperty("languages", "").split(",")) {
            String l = part.strip();
            if (!l.isEmpty()) {
                langs.add(l);
            }
        }
        this.languages = langs;
        String ep = p.getProperty("endpoint", "https://translate.google.com/translate_tts").strip();
        this.endpoint = ep.isEmpty() ? "https://translate.google.com/translate_tts" : ep;
        int timeout = 8;
        try {
            timeout = Integer.parseInt(p.getProperty("timeoutSeconds", "8").strip());
        } catch (NumberFormatException ignored) {
            // keep default
        }
        this.timeoutSeconds = Math.max(2, Math.min(60, timeout));
    }

    public boolean allows(String lang) {
        if (languages.isEmpty()) {
            return true;
        }
        String base = TtsLanguage.base(lang);
        for (String allowed : languages) {
            if (TtsLanguage.base(allowed).equals(base)) {
                return true;
            }
        }
        return false;
    }

    static Path path() {
        return Path.of(System.getProperty("user.dir", "."), "config", "keitok-tts.properties");
    }

    /** Текущие настройки; файл перечитывается, если его изменили (проверка не чаще раза в 3 секунды). */
    public static TtsSettings get() {
        long now = System.currentTimeMillis();
        TtsSettings c = cached;
        if (c != null && now - lastCheck < 3000) {
            return c;
        }
        lastCheck = now;
        Path file = path();
        long stamp;
        try {
            if (!Files.exists(file)) {
                Files.createDirectories(file.getParent());
                Files.writeString(file, DEFAULT_FILE, StandardCharsets.UTF_8);
            }
            stamp = Files.getLastModifiedTime(file).toMillis();
        } catch (IOException e) {
            stamp = -1;
        }
        if (c != null && stamp == cachedStamp) {
            return c;
        }
        Properties props = new Properties();
        try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            props.load(reader);
        } catch (Exception e) {
            Logger.warning("Could not read " + file + ": " + e);
        }
        TtsSettings loaded = new TtsSettings(props);
        cached = loaded;
        cachedStamp = stamp;
        return loaded;
    }

    /** Меняет одну настройку в config/keitok-tts.properties (остальные строки и комментарии сохраняются). */
    public static synchronized void update(String key, String value) {
        Path file = path();
        try {
            get(); // гарантирует, что файл создан
            java.util.List<String> lines = new java.util.ArrayList<>(Files.readAllLines(file, StandardCharsets.UTF_8));
            boolean found = false;
            for (int i = 0; i < lines.size(); i++) {
                String l = lines.get(i).strip();
                if (!l.startsWith("#") && l.startsWith(key + "=")) {
                    lines.set(i, key + "=" + value);
                    found = true;
                }
            }
            if (!found) {
                lines.add(key + "=" + value);
            }
            Files.write(file, lines, StandardCharsets.UTF_8);
            lastCheck = 0; // перечитать сразу
            cachedStamp = Long.MIN_VALUE;
        } catch (IOException e) {
            Logger.warning("Could not save " + file + ": " + e);
        }
    }

    @Override
    public String toString() {
        return "online=" + online + ", default=" + defaultLanguage + ", languages=" + Arrays.toString(languages.toArray())
            + String.format(Locale.ROOT, ", timeout=%ds", timeoutSeconds);
    }
}
