package takeyourminestream.ijustseen.tts;

import takeyourminestream.ijustseen.config.ModConfig;
import takeyourminestream.ijustseen.config.ModConfigData;
import takeyourminestream.ijustseen.utils.Logger;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Озвучка очереди текста средствами ОС, без нативных библиотек:
 * Windows — SAPI через PowerShell, macOS — {@code say}, Linux — espeak-ng / espeak / spd-say.
 * Читает голос, скорость и громкость из {@link ModConfigData} при каждой фразе.
 * Намеренно не использует классы Minecraft (общий исходник для всех версий).
 */
public final class TtsEngine {
    private static final String OS = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
    private static final boolean WINDOWS = OS.startsWith("windows");
    private static final boolean MAC = OS.startsWith("mac");

    private final LinkedBlockingDeque<String> queue = new LinkedBlockingDeque<>();
    private final Thread worker;
    private final Consumer<String> errorSink;
    private volatile Process current;
    private volatile boolean running = true;
    private volatile String linuxEngine;
    private volatile boolean errorReported;

    /** @param errorSink получает понятное сообщение об ошибке (не чаще одного раза, пока не сброшено). */
    public TtsEngine(Consumer<String> errorSink) {
        this.errorSink = errorSink;
        this.worker = new Thread(this::runLoop, "TYSC-TTS");
        this.worker.setDaemon(true);
        this.worker.start();
    }

    /** Кладёт фразу в очередь; при переполнении выбрасывает самые старые, чтобы озвучка не отставала от чата. */
    public void enqueue(String text, int maxQueue) {
        try {
            if (text == null || text.isBlank()) {
                return;
            }
            while (queue.size() >= Math.max(1, maxQueue)) {
                queue.pollFirst();
            }
            queue.offerLast(text);
        } catch (Throwable t) {
            // озвучка вторична: ошибка здесь не должна убрать сообщение с экрана
            Logger.warning("TTS enqueue failed: " + t);
        }
    }

    public int pending() {
        return queue.size();
    }

    public boolean isSpeaking() {
        Process p = current;
        return p != null && p.isAlive();
    }

    /** Прерывает текущую фразу; следующая из очереди начнётся сразу. */
    public void skip() {
        generation++;
        Process p = current;
        if (p != null) {
            p.destroyForcibly();
        }
    }

    public void clear() {
        queue.clear();
        skip();
    }

    public void resetErrorFlag() {
        errorReported = false;
    }

    public void shutdown() {
        running = false;
        clear();
        worker.interrupt();
    }

    public String describe() {
        TtsSettings s = TtsSettings.get();
        return (s.online ? "Online multilingual voices (" + s.defaultLanguage + " default) + local " : "Local ") + describeLocal();
    }

    private String describeLocal() {
        if (WINDOWS) {
            return "Windows SAPI";
        }
        if (MAC) {
            return "macOS say";
        }
        String engine = linuxEngine();
        return engine.isEmpty() ? "Linux: no engine found (install espeak-ng)" : "Linux " + engine;
    }

    // ------------------------------------------------------------------ worker

    private void runLoop() {
        while (running) {
            try {
                String text = queue.take();
                speak(text);
            } catch (InterruptedException e) {
                return;
            } catch (Exception e) {
                Logger.warning("TTS failed: " + e);
                if (!errorReported) {
                    errorReported = true;
                    errorSink.accept(e.getMessage() != null ? e.getMessage() : e.toString());
                }
                try {
                    Thread.sleep(2000);
                } catch (InterruptedException ie) {
                    return;
                }
            }
        }
    }

    private final java.util.Set<String> unsupported = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private volatile int generation;
    private volatile int onlineFailures;
    private volatile long onlineDisabledUntil;

    private void speak(String text) throws IOException, InterruptedException {
        TtsSettings s = TtsSettings.get();
        int gen = generation;
        for (TtsLanguage.Segment seg : TtsLanguage.segments(text, s.defaultLanguage, s.latinLanguage)) {
            if (!running || gen != generation) {
                return;
            }
            speakSegment(seg.text(), seg.lang(), s);
        }
    }

    private void speakSegment(String text, String lang, TtsSettings s) throws IOException, InterruptedException {
        if (TtsLanguage.base(lang).equals("tl")) {
            text = TtsTagalog.normalize(text);
            if (text.isBlank()) {
                return;
            }
        }
        ModConfigData c = ModConfig.getCurrentConfig();
        if (!s.allows(lang)) {
            return;
        }
        if (s.online && System.currentTimeMillis() >= onlineDisabledUntil && !unsupported.contains(TtsLanguage.base(lang))) {
            Path file = null;
            try {
                file = OnlineTts.fetch(text, lang, s);
                Process p = OnlineTts.play(file, c.getTtsVolume(), c.getTtsRate());
                onlineFailures = 0;
                wait(p);
                return;
            } catch (OnlineTts.UnsupportedLanguage e) {
                // язык без онлайн-голоса: читаем локальным голосом ОС, но сообщение не теряем
                unsupported.add(TtsLanguage.base(lang));
                Logger.warning("Online TTS: " + e.getMessage() + "; using the local voice for it.");
            } catch (IOException e) {
                Logger.warning("Online TTS failed (" + lang + "): " + e);
                if (++onlineFailures >= 3) {
                    onlineFailures = 0;
                    onlineDisabledUntil = System.currentTimeMillis() + 300_000L;
                    if (!errorReported) {
                        errorReported = true;
                        errorSink.accept("Online voice unavailable (" + e.getMessage() + "); using local voices for 5 minutes.");
                    }
                }
            } finally {
                if (file != null) {
                    try {
                        Files.deleteIfExists(file);
                    } catch (IOException ignored) {
                        // temp file
                    }
                }
            }
        }
        try {
            wait(WINDOWS ? startWindows(text, c, lang) : MAC ? startMac(text, c, lang) : startLinux(text, c, lang));
        } catch (IOException e) {
            Logger.warning("Local voice failed (" + lang + "): " + e.getMessage());
        }
    }

    private void wait(Process p) throws InterruptedException {
        current = p;
        try {
            if (!p.waitFor(90, TimeUnit.SECONDS)) {
                p.destroyForcibly();
            }
        } finally {
            current = null;
        }
    }

    private static final java.util.Map<String, String> MAC_VOICES = java.util.Map.ofEntries(
        java.util.Map.entry("ko", "Yuna"),
        java.util.Map.entry("ja", "Kyoko"),
        java.util.Map.entry("th", "Kanya"),
        java.util.Map.entry("zh", "Tingting"),
        java.util.Map.entry("es", "Monica"),
        java.util.Map.entry("fr", "Thomas"),
        java.util.Map.entry("de", "Anna"),
        java.util.Map.entry("pt", "Luciana"),
        java.util.Map.entry("ru", "Milena"),
        java.util.Map.entry("id", "Damayanti"),
        java.util.Map.entry("ar", "Maged"),
        java.util.Map.entry("hi", "Lekha"),
        java.util.Map.entry("vi", "Linh"),
        java.util.Map.entry("it", "Alice"),
        java.util.Map.entry("nl", "Xander"),
        java.util.Map.entry("tr", "Yelda"),
        java.util.Map.entry("pl", "Zosia"),
        java.util.Map.entry("sv", "Alva"),
        java.util.Map.entry("da", "Sara"),
        java.util.Map.entry("fi", "Satu"),
        java.util.Map.entry("el", "Melina"),
        java.util.Map.entry("iw", "Carmit"),
        java.util.Map.entry("ro", "Ioana"),
        java.util.Map.entry("cs", "Zuzana"),
        java.util.Map.entry("hu", "Mariska"),
        java.util.Map.entry("uk", "Lesya"));
    private static final java.util.Map<String, String> ESPEAK = java.util.Map.of("tl", "fil", "zh", "cmn", "iw", "he", "ur", "hi", "bn", "bn", "ne", "ne", "si", "si");

    // ------------------------------------------------------------------ launchers

    private Process startWindows(String text, ModConfigData c, String lang) throws IOException {
        ProcessBuilder pb = new ProcessBuilder(
            "powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-Command", "-");
        // Текст идёт через переменные окружения, а не в скрипте: чат не может внедрить команды.
        pb.environment().put("TYSC_TTS_TEXT", text);
        pb.environment().put("TYSC_TTS_VOICE", c.getTtsVoice());
        pb.environment().put("TYSC_TTS_LANG", TtsLanguage.base(lang));
        pb.environment().put("TYSC_TTS_RATE", Integer.toString(c.getTtsRate()));
        pb.environment().put("TYSC_TTS_VOLUME", Integer.toString(c.getTtsVolume()));
        pb.redirectErrorStream(true);
        pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);
        Process p = pb.start();
        String script = String.join("\n",
            "Add-Type -AssemblyName System.Speech",
            "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer",
            "$s.Rate = [int]$env:TYSC_TTS_RATE",
            "$s.Volume = [int]$env:TYSC_TTS_VOLUME",
            "if ($env:TYSC_TTS_VOICE) { try { $s.SelectVoice($env:TYSC_TTS_VOICE) } catch { } }",
            "else { $v = $s.GetInstalledVoices() | Where-Object { $_.Enabled -and $_.VoiceInfo.Culture.TwoLetterISOLanguageName -eq $env:TYSC_TTS_LANG } | Select-Object -First 1; if ($v) { $s.SelectVoice($v.VoiceInfo.Name) } }",
            "$s.Speak($env:TYSC_TTS_TEXT)",
            "$s.Dispose()",
            "");
        writeAndClose(p, script);
        return p;
    }

    private Process startMac(String text, ModConfigData c, String lang) throws IOException {
        List<String> cmd = new ArrayList<>();
        cmd.add("say");
        cmd.add("-r");
        cmd.add(Integer.toString(wordsPerMinute(c.getTtsRate())));
        String macVoice = !c.getTtsVoice().isBlank() ? c.getTtsVoice() : MAC_VOICES.get(TtsLanguage.base(lang));
        if (macVoice != null) {
            cmd.add("-v");
            cmd.add(macVoice);
        }
        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.redirectErrorStream(true);
        pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);
        Process p = pb.start();
        writeAndClose(p, text); // say читает stdin, если текст не передан аргументом
        return p;
    }

    private Process startLinux(String text, ModConfigData c, String lang) throws IOException {
        String engine = linuxEngine();
        if (engine.isEmpty()) {
            throw new IOException("No speech engine found. Install espeak-ng (sudo apt install espeak-ng).");
        }
        List<String> cmd = new ArrayList<>();
        cmd.add(engine);
        boolean spd = engine.equals("spd-say");
        if (spd) {
            cmd.add("-w");
            cmd.add("-r");
            cmd.add(Integer.toString(c.getTtsRate() * 10));
            cmd.add("-i");
            cmd.add(Integer.toString(c.getTtsVolume() * 2 - 100));
            cmd.add("--");
            cmd.add(text);
        } else {
            cmd.add("-s");
            cmd.add(Integer.toString(wordsPerMinute(c.getTtsRate())));
            cmd.add("-a");
            cmd.add(Integer.toString(c.getTtsVolume() * 2));
            String b = TtsLanguage.base(lang);
            String voice = !c.getTtsVoice().isBlank() ? c.getTtsVoice() : ESPEAK.getOrDefault(b, b);
            cmd.add("-v");
            cmd.add(voice);
            cmd.add("--stdin");
        }
        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.redirectErrorStream(true);
        pb.redirectOutput(ProcessBuilder.Redirect.DISCARD);
        Process p = pb.start();
        if (!spd) {
            writeAndClose(p, text);
        }
        return p;
    }

    private static int wordsPerMinute(int rate) {
        return 175 + rate * 15;
    }

    private static void writeAndClose(Process p, String text) throws IOException {
        try (OutputStream os = p.getOutputStream()) {
            os.write(text.getBytes(StandardCharsets.UTF_8));
        }
    }

    private String linuxEngine() {
        String cached = linuxEngine;
        if (cached != null) {
            return cached;
        }
        String found = "";
        for (String name : new String[] {"espeak-ng", "espeak", "spd-say"}) {
            if (onPath(name)) {
                found = name;
                break;
            }
        }
        linuxEngine = found;
        return found;
    }

    private static boolean onPath(String exe) {
        String path = System.getenv("PATH");
        if (path == null) {
            return false;
        }
        for (String dir : path.split(File.pathSeparator)) {
            if (dir.isBlank()) {
                continue;
            }
            Path candidate = Path.of(dir, exe);
            if (Files.isRegularFile(candidate) && Files.isExecutable(candidate)) {
                return true;
            }
        }
        return false;
    }

    // ------------------------------------------------------------------ голоса

    /** Названия установленных голосов. Блокирующий вызов — не из игрового потока. */
    public List<String> listVoices() {
        List<String> out = new ArrayList<>();
        try {
            ProcessBuilder pb;
            if (WINDOWS) {
                pb = new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive", "-Command",
                    "Add-Type -AssemblyName System.Speech; "
                        + "(New-Object System.Speech.Synthesis.SpeechSynthesizer).GetInstalledVoices() "
                        + "| ForEach-Object { $_.VoiceInfo.Name }");
            } else if (MAC) {
                pb = new ProcessBuilder("say", "-v", "?");
            } else {
                String engine = linuxEngine();
                if (!engine.equals("espeak-ng") && !engine.equals("espeak")) {
                    return out;
                }
                pb = new ProcessBuilder(engine, "--voices");
            }
            pb.redirectErrorStream(true);
            Process p = pb.start();
            p.getOutputStream().close();
            String raw;
            try (InputStream in = p.getInputStream()) {
                raw = new String(in.readAllBytes(), StandardCharsets.UTF_8);
            }
            p.waitFor(15, TimeUnit.SECONDS);
            boolean header = true;
            for (String line : raw.split("\\R")) {
                String l = line.strip();
                if (l.isEmpty()) {
                    continue;
                }
                if (WINDOWS) {
                    out.add(l);
                } else if (MAC) {
                    int sep = l.indexOf("  ");
                    out.add(sep > 0 ? l.substring(0, sep).strip() : l);
                } else {
                    if (header) { // шапка таблицы espeak
                        header = false;
                        continue;
                    }
                    String[] cols = l.split("\\s+");
                    if (cols.length >= 4) {
                        out.add(cols[3]);
                    }
                }
            }
        } catch (Exception e) {
            Logger.warning("Could not list TTS voices: " + e);
        }
        return out;
    }
}
