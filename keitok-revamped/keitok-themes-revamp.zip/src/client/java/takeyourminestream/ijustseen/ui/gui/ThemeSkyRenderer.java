package takeyourminestream.ijustseen.ui.gui;

import net.minecraft.client.gui.DrawContext;

/** Lightweight animated backgrounds for the additional menu palettes. */
public final class ThemeSkyRenderer {
    private ThemeSkyRenderer() {}

    public static void draw(DrawContext c, int x0, int y0, int x1, int y1, String theme, double t) {
        int w=x1-x0, h=y1-y0;
        if (w<=0 || h<=0) return;
        int top, mid, bottom, accent;
        switch (theme) {
            case "ocean_depths" -> { top=0x03111E; mid=0x075064; bottom=0x0C8790; accent=0x55EAF0; }
            case "sakura_bloom" -> { top=0x21101F; mid=0x71334F; bottom=0xB85C7D; accent=0xFFC0D7; }
            case "emerald_grove" -> { top=0x061811; mid=0x124C32; bottom=0x28764B; accent=0x83F0B0; }
            case "solar_flare" -> { top=0x1B0D08; mid=0x71300F; bottom=0xB85A19; accent=0xFFD078; }
            case "midnight_blue" -> { top=0x050D20; mid=0x142D59; bottom=0x315B91; accent=0x9CCBFF; }
            default -> { top=0x100820; mid=0x38205C; bottom=0x713B91; accent=0x5CFFE1; }
        }
        c.enableScissor(x0,y0,x1,y1);
        for (int i=0;i<32;i++) {
            float f=i/31f;
            int rgb=f<0.58f?lerp(top,mid,f/0.58f):lerp(mid,bottom,(f-0.58f)/0.42f);
            c.fill(x0,y0+h*i/32,x1,y0+h*(i+1)/32,0xF0000000|rgb);
        }
        // Subtle moving light ribbons and tiny particles.
        for (int band=0;band<4;band++) {
            int yy=y0+(int)((((t*(5+band*2))+band*h/4.0)%(h+24))-12);
            int a=18+band*5;
            c.fill(x0,yy,x1,yy+1,(a<<24)|accent);
        }
        for (int i=0;i<42;i++) {
            double phase=(t*(0.035+(i%5)*0.009)+i*0.173)%1.0;
            int px=x0+(int)(((i*0.6180339)%1.0)*w);
            int py=y0+h-(int)(phase*h);
            int a=(int)(35+100*Math.sin(phase*Math.PI));
            int col=(a<<24)|accent;
            c.fill(px,py,px+(i%9==0?2:1),py+(i%9==0?2:1),col);
        }
        c.disableScissor();
    }

    private static int lerp(int a,int b,float f) {
        int r=(int)(((a>>16)&255)+(((b>>16)&255)-((a>>16)&255))*f);
        int g=(int)(((a>>8)&255)+(((b>>8)&255)-((a>>8)&255))*f);
        int bl=(int)((a&255)+((b&255)-(a&255))*f);
        return (r<<16)|(g<<8)|bl;
    }
}
