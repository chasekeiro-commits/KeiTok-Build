package takeyourminestream.ijustseen.ui.gui;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gl.RenderPipelines;
import takeyourminestream.ijustseen.core.MessagePanelConstants;
import takeyourminestream.ijustseen.core.render.MessagePanel9Slice;

/** Рендер 9-slice панели сообщений в GUI. */
public final class MessagePanelGuiRenderer {
    private MessagePanelGuiRenderer() {}

    public static void drawPanel(DrawContext context, int x, int y, int width, int height) {
        drawPanel(context, x, y, width, height, 1.0f);
    }

    public static void drawPinIcon(DrawContext context, int panelX, int panelY, int panelWidth, float alpha) {
        int pinX = panelX + panelWidth - MessagePanelConstants.PADDING_X
            - (MessagePanelConstants.PIN_ICON_SIZE / 2)
            + MessagePanelConstants.PIN_ICON_MARGIN;
        int pinY = panelY - (MessagePanelConstants.PIN_ICON_SIZE / 2) - MessagePanelConstants.PIN_ICON_MARGIN;
        int color = alpha >= 1.0f ? -1 : ((int) (alpha * 255.0f) << 24) | 0xFFFFFF;
        context.drawTexture(
            RenderPipelines.GUI_TEXTURED,
            MessagePanelConstants.PIN_TEXTURE,
            pinX,
            pinY,
            0,
            0,
            MessagePanelConstants.PIN_ICON_SIZE,
            MessagePanelConstants.PIN_ICON_SIZE,
            MessagePanelConstants.PIN_ICON_SIZE,
            MessagePanelConstants.PIN_ICON_SIZE,
            MessagePanelConstants.PIN_ICON_SIZE,
            MessagePanelConstants.PIN_ICON_SIZE,
            color
        );
    }

    public static void drawPanel(DrawContext context, int x, int y, int width, int height, float alpha) {
        drawPanel(context, x, y, width, height, alpha, MessagePanelConstants.DEFAULT_BORDER_RGB);
    }

    public static void drawPanel(DrawContext context, int x, int y, int width, int height, float alpha, int borderRgb) {
        int alphaBits = ((int) (Math.min(1.0f, alpha) * 255.0f)) << 24;
        int baseRgb = takeyourminestream.ijustseen.core.MessagePanelColors.baseRgb();
        int resolvedBorderRgb = takeyourminestream.ijustseen.core.MessagePanelColors.borderRgb(borderRgb);
        drawSlices(context, takeyourminestream.ijustseen.core.render.MessagePanelTextures.panel(), x, y, width, height, alphaBits | baseRgb);
        drawSlices(context, takeyourminestream.ijustseen.core.render.MessagePanelTextures.border(), x, y, width, height, alphaBits | resolvedBorderRgb);
    }

    private static void drawSlices(
        DrawContext context,
        net.minecraft.util.Identifier texture,
        int x,
        int y,
        int width,
        int height,
        int color
    ) {
        int texSize = takeyourminestream.ijustseen.core.render.MessagePanelTextures.sizeOf(texture);
        for (MessagePanel9Slice.GuiSlice slice : MessagePanel9Slice.guiSlices(x, y, width, height, texSize)) {
            context.drawTexture(
                RenderPipelines.GUI_TEXTURED,
                texture,
                slice.x(),
                slice.y(),
                slice.texU(),
                slice.texV(),
                slice.width(),
                slice.height(),
                slice.regionWidth(),
                slice.regionHeight(),
                texSize,
                texSize,
                color
            );
        }
    }
}
