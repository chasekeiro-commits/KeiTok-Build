package takeyourminestream.ijustseen.ui.gui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

/** Единый визуальный стиль GUI мода: тёмная "стримерская" тема с фиолетовым акцентом. */
public final class ModUiTheme {
    /** Главный акцентный цвет (фиолетовый, как у панелей сообщений). */
    public static int ACCENT = 0xFF9146FF;
    public static int ACCENT_DARK = 0xFF5A2D99;

    public static int PANEL_BG = 0xE0100C18;
    public static int PANEL_BORDER = 0xFF453465;
    public static int BUTTON_BG = 0xFF352F45;
    public static int BUTTON_BG_HOVER = 0xFF4C4263;
    public static int BUTTON_BORDER_HOVER = 0xFFB07CFF;
    public static int BUTTON_BG_SELECTED = 0xFF5A2D99;
    public static int ROW_BG = 0x402A2438;
    public static int ROW_BG_HOVER = 0x90413457;
    public static int INPUT_BG = 0x901C1828;
    public static final int DANGER_BG = 0x90604040;
    public static final int DANGER_BG_HOVER = 0xC0805050;
    public static int ACCENT_BG = 0x905A2D99;
    public static int ACCENT_BG_HOVER = 0xC07C4DD9;
    /** Фон кнопки «чат подключён». */
    public static final int CONNECTION_ON_BG = 0xB0287040;
    public static final int CONNECTION_ON_BG_HOVER = 0xD0359050;
    public static final int CONNECTION_ON_BORDER = 0xFF55AA66;
    /** Фон кнопки «чат отключён». */
    public static final int CONNECTION_OFF_BG = 0xB0702828;
    public static final int CONNECTION_OFF_BG_HOVER = 0xD0903535;
    public static final int CONNECTION_OFF_BORDER = 0xFFAA5555;
    public static final int TEXT_PRIMARY = 0xFFFFFFFF;
    public static final int TEXT_SECONDARY = 0xFFDDDDDD;
    public static final int TEXT_MUTED = 0xFFAAAAAA;
    public static final int TEXT_DIM = 0xFF666666;
    public static final int TEXT_HINT = 0xFF888888;
    public static final int OVERLAY_DIM = 0x60000000;
    /** Fully opaque panel for modal popups (avoids batched text bleeding through on 1.21). */
    public static int POPUP_PANEL_BG = 0xFF100C18;
    public static int SCROLL_TRACK = 0x40453465;
    public static int SCROLL_THUMB = 0xC08A5CF5;

    public enum ButtonVariant {
        NEUTRAL,
        DANGER,
        ACCENT
    }

    private static boolean moon;
    private static boolean lokal;
    private static String activeTheme = "default";

    public static String getActiveTheme() { return activeTheme; }

    private ModUiTheme() {}

    /** Тема "purple_moon" включена: фон меню рисуется анимированным ночным небом. */
    public static boolean isMoon() {
        return moon;
    }

    /** Тема "lokalhost": чёрно-красная, с надписью LOKALHOST GAMING. */
    public static boolean isLokal() {
        return lokal;
    }

    /** Применяет палитру темы меню. Влияет только на экраны настроек (на пузыри чата не влияет). */
    public static void applyTheme(String id) {
        activeTheme = id == null ? "default" : id;
        moon = "purple_moon".equals(activeTheme);
        lokal = "lokalhost".equals(activeTheme);

        // Safe, high-contrast defaults. Each palette keeps white text readable.
        ACCENT = 0xFFB58CFF; ACCENT_DARK = 0xFF6840A0;
        PANEL_BG = 0xE0100C18; PANEL_BORDER = 0xFF453465;
        BUTTON_BG = 0xFF292536; BUTTON_BG_HOVER = 0xFF403852;
        BUTTON_BORDER_HOVER = 0xFFD2B5FF; BUTTON_BG_SELECTED = 0xFF5A3B83;
        ROW_BG = 0x502A2438; ROW_BG_HOVER = 0x90413457; INPUT_BG = 0x901C1828;
        ACCENT_BG = 0x905A2D99; ACCENT_BG_HOVER = 0xC07C4DD9;
        POPUP_PANEL_BG = 0xFF100C18; SCROLL_TRACK = 0x40453465; SCROLL_THUMB = 0xC08A5CF5;

        switch (activeTheme) {
            case "lokalhost" -> {
                ACCENT=0xFFFF4968; ACCENT_DARK=0xFF8A0A24; PANEL_BG=0xF009070B; PANEL_BORDER=0xFF8E2037;
                BUTTON_BG=0xE0201017; BUTTON_BG_HOVER=0xFF401522; BUTTON_BORDER_HOVER=0xFFFF7188;
                BUTTON_BG_SELECTED=0xFF851D36; ROW_BG=0x70200A10; ROW_BG_HOVER=0xB040101C;
                INPUT_BG=0xE012080D; ACCENT_BG=0xC0501425; ACCENT_BG_HOVER=0xFFE0103A;
                POPUP_PANEL_BG=0xFF0A0507; SCROLL_TRACK=0x607A0F22; SCROLL_THUMB=0xFFE0103A;
            }
            case "purple_moon" -> {
                ACCENT=0xFFFFD98A; ACCENT_DARK=0xFF8E6BD8; PANEL_BG=0xF01B1238; PANEL_BORDER=0xFF8E6BD8;
                BUTTON_BG=0xE02B2055; BUTTON_BG_HOVER=0xFF493578; BUTTON_BORDER_HOVER=0xFFFFD98A;
                BUTTON_BG_SELECTED=0xFF6749A8; ROW_BG=0x7035247A; ROW_BG_HOVER=0xB0503A96;
                INPUT_BG=0xD0170F36; ACCENT_BG=0xA06B4BC0; ACCENT_BG_HOVER=0xD08E6BD8;
                POPUP_PANEL_BG=0xFF1B1240; SCROLL_TRACK=0x608E6BD8; SCROLL_THUMB=0xFFFFD98A;
            }
            case "ocean_depths" -> {
                ACCENT=0xFF48DDEB; ACCENT_DARK=0xFF087F91; PANEL_BG=0xF0061722; PANEL_BORDER=0xFF167D91;
                BUTTON_BG=0xE00C2A39; BUTTON_BG_HOVER=0xFF124456; BUTTON_BORDER_HOVER=0xFF66F1F4;
                BUTTON_BG_SELECTED=0xFF086A7A; ROW_BG=0x70409AAA; ROW_BG_HOVER=0xB0126070;
                INPUT_BG=0xD008202C; ACCENT_BG=0xA0086070; ACCENT_BG_HOVER=0xD0129BAC;
                POPUP_PANEL_BG=0xFF061722; SCROLL_TRACK=0x60167D91; SCROLL_THUMB=0xFF48DDEB;
            }
            case "sakura_bloom" -> {
                ACCENT=0xFFFFA9C8; ACCENT_DARK=0xFF9D496B; PANEL_BG=0xF022101D; PANEL_BORDER=0xFFB75E83;
                BUTTON_BG=0xE03A1D30; BUTTON_BG_HOVER=0xFF583047; BUTTON_BORDER_HOVER=0xFFFFC3D8;
                BUTTON_BG_SELECTED=0xFF9D496B; ROW_BG=0x704F2940; ROW_BG_HOVER=0xB0783B5C;
                INPUT_BG=0xD0251422; ACCENT_BG=0xA06E3450; ACCENT_BG_HOVER=0xD0B75E83;
                POPUP_PANEL_BG=0xFF22101D; SCROLL_TRACK=0x60B75E83; SCROLL_THUMB=0xFFFFA9C8;
            }
            case "emerald_grove" -> {
                ACCENT=0xFF69E6A3; ACCENT_DARK=0xFF24764B; PANEL_BG=0xF0091C17; PANEL_BORDER=0xFF287C55;
                BUTTON_BG=0xE0123024; BUTTON_BG_HOVER=0xFF1D4935; BUTTON_BORDER_HOVER=0xFF8CFFC0;
                BUTTON_BG_SELECTED=0xFF236B46; ROW_BG=0x70305D43; ROW_BG_HOVER=0xB02C7950;
                INPUT_BG=0xD00B241A; ACCENT_BG=0xA01C6944; ACCENT_BG_HOVER=0xD02B9B61;
                POPUP_PANEL_BG=0xFF091C17; SCROLL_TRACK=0x60287C55; SCROLL_THUMB=0xFF69E6A3;
            }
            case "solar_flare" -> {
                ACCENT=0xFFFFC15C; ACCENT_DARK=0xFF99531C; PANEL_BG=0xF0201208; PANEL_BORDER=0xFF99531C;
                BUTTON_BG=0xE0392410; BUTTON_BG_HOVER=0xFF593719; BUTTON_BORDER_HOVER=0xFFFFD58A;
                BUTTON_BG_SELECTED=0xFF8B4B19; ROW_BG=0x704B3018; ROW_BG_HOVER=0xB06A401B;
                INPUT_BG=0xD024160A; ACCENT_BG=0xA06A3A16; ACCENT_BG_HOVER=0xD09B571C;
                POPUP_PANEL_BG=0xFF201208; SCROLL_TRACK=0x6099531C; SCROLL_THUMB=0xFFFFC15C;
            }
            case "midnight_blue" -> {
                ACCENT=0xFF83B9FF; ACCENT_DARK=0xFF315D9A; PANEL_BG=0xF0091428; PANEL_BORDER=0xFF315D9A;
                BUTTON_BG=0xE0142542; BUTTON_BG_HOVER=0xFF20395F; BUTTON_BORDER_HOVER=0xFFA9D0FF;
                BUTTON_BG_SELECTED=0xFF315D9A; ROW_BG=0x70304B75; ROW_BG_HOVER=0xB03B6096;
                INPUT_BG=0xD00C1B34; ACCENT_BG=0xA0254B80; ACCENT_BG_HOVER=0xD03C70B8;
                POPUP_PANEL_BG=0xFF091428; SCROLL_TRACK=0x60315D9A; SCROLL_THUMB=0xFF83B9FF;
            }
            case "cyberpunk" -> {
                ACCENT=0xFF5CFFE1; ACCENT_DARK=0xFF8A35B8; PANEL_BG=0xF00D0A1B; PANEL_BORDER=0xFF8A35B8;
                BUTTON_BG=0xE01D1532; BUTTON_BG_HOVER=0xFF30204F; BUTTON_BORDER_HOVER=0xFF5CFFE1;
                BUTTON_BG_SELECTED=0xFF5C287D; ROW_BG=0x70351D55; ROW_BG_HOVER=0xB04D2A70;
                INPUT_BG=0xD0120D26; ACCENT_BG=0xA04A2675; ACCENT_BG_HOVER=0xD08A35B8;
                POPUP_PANEL_BG=0xFF0D0A1B; SCROLL_TRACK=0x608A35B8; SCROLL_THUMB=0xFF5CFFE1;
            }
        }
    }

    public static void drawThemeBackground(DrawContext context, int width, int height) {
        String id = activeTheme;
        if ("purple_moon".equals(id)) {
            MoonSkyRenderer.draw(context, 0, 0, width, height, 0xE8, System.nanoTime()/1.0e9);
        } else if ("lokalhost".equals(id)) {
            LokalSkyRenderer.draw(context, 0, 0, width, height, 0xEC, System.nanoTime()/1.0e9);
        } else if (!"default".equals(id)) {
            ThemeSkyRenderer.draw(context, 0, 0, width, height, id, System.nanoTime()/1.0e9);
        } else {
            drawWorldDim(context, width, height);
        }
    }

    /** Затемнение мира без анимации blur — иначе экраны вспыхивают при открытии и смене. */
    public static void drawWorldDim(DrawContext context, int width, int height) {
        context.fill(0, 0, width, height, 0xB0000000);
    }

    public static void drawBorderedPanel(DrawContext context, int x, int y, int width, int height) {
        context.fill(x, y, x + width, y + height, PANEL_BG);
        context.fill(x, y, x + width, y + 1, PANEL_BORDER);
        context.fill(x, y + height - 1, x + width, y + height, PANEL_BORDER);
        context.fill(x, y, x + 1, y + height, PANEL_BORDER);
        context.fill(x + width - 1, y, x + width, y + height, PANEL_BORDER);
        if (moon || lokal) {
            double t = System.nanoTime() / 1.0e9;
            if (lokal) {
                ThemeDecor.watermark(context, x, y, width, height, t);
            }
            ThemeDecor.frame(context, x, y, width, height, t);
        }
    }

    public static void drawButtonWidget(
        DrawContext context,
        TextRenderer textRenderer,
        ButtonWidget button,
        boolean selected
    ) {
        drawButton(
            context,
            textRenderer,
            button.getX(),
            button.getY(),
            button.getWidth(),
            button.getHeight(),
            button.getMessage(),
            button.isHovered(),
            button.active,
            selected,
            true
        );
    }

    public static void drawButton(
        DrawContext context,
        TextRenderer textRenderer,
        int x,
        int y,
        int width,
        int height,
        Text label,
        boolean hovered,
        boolean enabled,
        boolean selected
    ) {
        drawButton(context, textRenderer, x, y, width, height, label, hovered, enabled, selected, true);
    }

    public static void drawButton(
        DrawContext context,
        TextRenderer textRenderer,
        int x,
        int y,
        int width,
        int height,
        Text label,
        boolean hovered,
        boolean enabled,
        boolean selected,
        boolean hoverBorders
    ) {
        drawButtonInternal(context, textRenderer, x, y, width, height, label, hovered, enabled, selected, hoverBorders, false);
    }

    /** Popup menu button — uses overlay render layer on Minecraft 1.21. */
    public static void drawPopupButton(
        DrawContext context,
        TextRenderer textRenderer,
        int x,
        int y,
        int width,
        int height,
        Text label,
        boolean hovered,
        boolean enabled,
        boolean selected
    ) {
        drawButtonInternal(context, textRenderer, x, y, width, height, label, hovered, enabled, selected, true, true);
    }

    private static void drawButtonInternal(
        DrawContext context,
        TextRenderer textRenderer,
        int x,
        int y,
        int width,
        int height,
        Text label,
        boolean hovered,
        boolean enabled,
        boolean selected,
        boolean hoverBorders,
        boolean overlayLayer
    ) {
        int bg = selected ? BUTTON_BG_SELECTED : (hovered && enabled ? BUTTON_BG_HOVER : BUTTON_BG);
        if (!enabled) {
            bg = 0x60404040;
        }
        if (overlayLayer) {
            PopupGuiRenderer.fill(context, x, y, x + width, y + height, bg);
            if (hovered && enabled && hoverBorders) {
                PopupGuiRenderer.fill(context, x, y, x + width, y + 1, BUTTON_BORDER_HOVER);
                PopupGuiRenderer.fill(context, x, y + height - 1, x + width, y + height, BUTTON_BORDER_HOVER);
            }
            if (selected) {
                PopupGuiRenderer.fill(context, x, y + height - 2, x + width, y + height, ACCENT);
            }
        } else {
            context.fill(x, y, x + width, y + height, bg);
            if (hovered && enabled && hoverBorders) {
                context.fill(x, y, x + width, y + 1, BUTTON_BORDER_HOVER);
                context.fill(x, y + height - 1, x + width, y + height, BUTTON_BORDER_HOVER);
            }
            if (selected) {
                context.fill(x, y + height - 2, x + width, y + height, ACCENT);
            }
        }
        int textColor = enabled ? (hovered || selected ? TEXT_PRIMARY : TEXT_SECONDARY) : TEXT_HINT;
        String fitted = fit(textRenderer, label.getString(), Math.max(4, width - 8));
        int labelWidth = textRenderer.getWidth(fitted);
        int textX = x + Math.max(4, (width - labelWidth) / 2);
        int textY = centeredTextY(y, height, textRenderer.fontHeight);
        int color = label.getStyle().getColor() != null ? 0xFFFFFFFF : textColor;
        context.drawTextWithShadow(textRenderer, fitted, textX, textY, color);
    }

    /** Обрезает строку по ширине, чтобы подпись не вылезала из кнопки на крупном GUI scale. */
    public static String fit(TextRenderer textRenderer, String text, int maxWidth) {
        if (text == null || text.isEmpty() || maxWidth <= 0) {
            return "";
        }
        if (textRenderer.getWidth(text) <= maxWidth) {
            return text;
        }
        String ellipsis = "...";
        int ellipsisWidth = textRenderer.getWidth(ellipsis);
        if (maxWidth <= ellipsisWidth) {
            return textRenderer.trimToWidth(text, maxWidth);
        }
        return textRenderer.trimToWidth(text, maxWidth - ellipsisWidth) + ellipsis;
    }

    public static void drawConnectionToggleButton(
        DrawContext context,
        TextRenderer textRenderer,
        ButtonWidget button,
        boolean connected,
        boolean hovered
    ) {
        drawConnectionToggleButton(
            context,
            textRenderer,
            button.getX(),
            button.getY(),
            button.getWidth(),
            button.getHeight(),
            button.getMessage(),
            connected,
            hovered,
            button.active
        );
    }

    public static void drawConnectionToggleButton(
        DrawContext context,
        TextRenderer textRenderer,
        int x,
        int y,
        int width,
        int height,
        Text label,
        boolean connected,
        boolean hovered,
        boolean enabled
    ) {
        int bg = connected
            ? (hovered && enabled ? CONNECTION_ON_BG_HOVER : CONNECTION_ON_BG)
            : (hovered && enabled ? CONNECTION_OFF_BG_HOVER : CONNECTION_OFF_BG);
        int border = connected ? CONNECTION_ON_BORDER : CONNECTION_OFF_BORDER;
        if (!enabled) {
            bg = 0x60404040;
            border = PANEL_BORDER;
        }
        context.fill(x, y, x + width, y + height, bg);
        context.fill(x, y, x + width, y + 1, border);
        context.fill(x, y + height - 1, x + width, y + height, border);
        context.fill(x, y, x + 1, y + height, border);
        context.fill(x + width - 1, y, x + width, y + height, border);
        int textColor = enabled ? TEXT_PRIMARY : TEXT_HINT;
        int labelWidth = textRenderer.getWidth(label);
        int textX = x + Math.max(6, (width - labelWidth) / 2);
        int textY = centeredTextY(y, height, textRenderer.fontHeight);
        context.drawTextWithShadow(textRenderer, label, textX, textY, textColor);
    }

    public static void drawCompactButton(
        DrawContext context,
        TextRenderer textRenderer,
        int x,
        int y,
        int width,
        int height,
        Text label,
        boolean hovered,
        ButtonVariant variant
    ) {
        int bg = switch (variant) {
            case DANGER -> hovered ? DANGER_BG_HOVER : DANGER_BG;
            case ACCENT -> hovered ? ACCENT_BG_HOVER : ACCENT_BG;
            case NEUTRAL -> hovered ? BUTTON_BG_HOVER : BUTTON_BG;
        };
        context.fill(x, y, x + width, y + height, bg);
        if (hovered) {
            context.fill(x, y, x + width, y + 1, BUTTON_BORDER_HOVER);
            context.fill(x, y + height - 1, x + width, y + height, BUTTON_BORDER_HOVER);
        }
        int labelWidth = textRenderer.getWidth(label);
        int textX = x + (width - labelWidth) / 2;
        int textY = centeredTextY(y, height, textRenderer.fontHeight);
        context.drawTextWithShadow(textRenderer, label, textX, textY, hovered ? TEXT_PRIMARY : TEXT_SECONDARY);
    }

    public static void drawListRow(DrawContext context, int left, int top, int right, int bottom, boolean hovered) {
        context.fill(left, top, right, bottom, hovered ? ROW_BG_HOVER : ROW_BG);
    }

    public static void drawInputFrame(DrawContext context, int x, int y, int width, int height, boolean focused) {
        context.fill(x, y, x + width, y + height, INPUT_BG);
        int border = focused ? ACCENT : PANEL_BORDER;
        context.fill(x, y, x + width, y + 1, border);
        context.fill(x, y + height - 1, x + width, y + height, border);
        context.fill(x, y, x + 1, y + height, border);
        context.fill(x + width - 1, y, x + width, y + height, border);
    }

    public static void drawTitle(DrawContext context, TextRenderer textRenderer, Text title, int screenWidth) {
        drawTitle(context, textRenderer, title, screenWidth, 6);
    }

    public static void drawTitle(DrawContext context, TextRenderer textRenderer, Text title, int screenWidth, int y) {
        context.drawCenteredTextWithShadow(textRenderer, title, screenWidth / 2, y, TEXT_PRIMARY);
        int titleWidth = textRenderer.getWidth(title);
        int centerX = screenWidth / 2;
        context.fill(centerX - titleWidth / 2, y + textRenderer.fontHeight + 2, centerX + titleWidth / 2, y + textRenderer.fontHeight + 3, ACCENT);
    }

    public static void drawScreenDim(DrawContext context, int screenWidth, int screenHeight) {
        context.fill(0, 0, screenWidth, screenHeight, OVERLAY_DIM);
    }

    public static int centeredTextY(int y, int height, int fontHeight) {
        return y + (height - fontHeight) / 2;
    }

    public static boolean isHovered(int mouseX, int mouseY, int x, int y, int width, int height) {
        return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
    }
}
