package takeyourminestream.ijustseen.ui.gui;

import net.minecraft.client.gui.DrawContext;

/**
 * Анимированное ночное небо для темы "Purple Moon": фиолетовый градиент, мерцающие звёзды,
 * плывущие облака, полумесяц и золотые искорки. Только context.fill — работает во всех версиях.
 * Рисуется в прямоугольнике (x0,y0)-(x1,y1), поэтому подходит и для фона экрана, и для превью.
 */
public final class MoonSkyRenderer {
    private static final int BANDS = 40;
    private static final int STARS = 70;
    private static final int SPARKS = 18;
    private static final int CLOUDS = 5;

    // детерминированные "случайные" значения (без Random: одинаковое небо при каждом открытии)
    private static final float[] STAR_X = new float[STARS];
    private static final float[] STAR_Y = new float[STARS];
    private static final float[] STAR_PHASE = new float[STARS];
    private static final float[] STAR_SPEED = new float[STARS];

    static {
        long seed = 0x4D4F4F4EL;
        for (int i = 0; i < STARS; i++) {
            seed = seed * 6364136223846793005L + 1442695040888963407L;
            STAR_X[i] = ((seed >>> 40) & 0xFFFF) / 65535f;
            seed = seed * 6364136223846793005L + 1442695040888963407L;
            STAR_Y[i] = ((seed >>> 40) & 0xFFFF) / 65535f;
            seed = seed * 6364136223846793005L + 1442695040888963407L;
            STAR_PHASE[i] = ((seed >>> 40) & 0xFFFF) / 65535f * 6.2831855f;
            seed = seed * 6364136223846793005L + 1442695040888963407L;
            STAR_SPEED[i] = 0.6f + ((seed >>> 40) & 0xFFFF) / 65535f * 1.4f;
        }
    }

    private MoonSkyRenderer() {}

    /** @param alpha прозрачность фона 0..255 (чуть меньше 255 — мир за меню слегка виден) */
    public static void draw(DrawContext context, int x0, int y0, int x1, int y1, int alpha, double t) {
        int w = x1 - x0;
        int h = y1 - y0;
        if (w <= 0 || h <= 0) {
            return;
        }
        context.enableScissor(x0, y0, x1, y1);
        drawGradient(context, x0, y0, x1, y1, alpha);
        drawStars(context, x0, y0, w, h, t);
        drawClouds(context, x0, y0, w, h, t);
        drawMoon(context, x0, y0, w, h, t);
        drawSparks(context, x0, y0, w, h, t);
        context.disableScissor();
    }

    // ------------------------------------------------------------------ небо

    private static void drawGradient(DrawContext context, int x0, int y0, int x1, int y1, int alpha) {
        // верх: глубокий индиго, середина: фиолетовый, низ: светлая лаванда у "земли"
        int h = y1 - y0;
        int a = (alpha & 0xFF) << 24;
        for (int i = 0; i < BANDS; i++) {
            float f = i / (float) (BANDS - 1);
            int rgb = f < 0.55f
                ? lerp(0x120A33, 0x3A2680, f / 0.55f)
                : lerp(0x3A2680, 0x7A5CC4, (f - 0.55f) / 0.45f);
            int top = y0 + h * i / BANDS;
            int bottom = y0 + h * (i + 1) / BANDS;
            context.fill(x0, top, x1, bottom, a | rgb);
        }
    }

    private static void drawStars(DrawContext context, int x0, int y0, int w, int h, double t) {
        for (int i = 0; i < STARS; i++) {
            float twinkle = 0.5f + 0.5f * (float) Math.sin(t * STAR_SPEED[i] + STAR_PHASE[i]);
            int a = (int) (60 + 195 * twinkle);
            int x = x0 + (int) (STAR_X[i] * (w - 2));
            int y = y0 + (int) (STAR_Y[i] * (h * 0.8f));
            int color = (a << 24) | (i % 5 == 0 ? 0xFFE9A8 : 0xFFFFFF);
            context.fill(x, y, x + 1, y + 1, color);
            if (i % 7 == 0 && twinkle > 0.6f) { // крупные звёзды-крестики
                int soft = ((a / 2) << 24) | 0xFFFFFF;
                context.fill(x - 1, y, x, y + 1, soft);
                context.fill(x + 1, y, x + 2, y + 1, soft);
                context.fill(x, y - 1, x + 1, y, soft);
                context.fill(x, y + 1, x + 1, y + 2, soft);
            }
        }
    }

    private static void drawClouds(DrawContext context, int x0, int y0, int w, int h, double t) {
        for (int i = 0; i < CLOUDS; i++) {
            int cw = Math.max(40, w / 6) + i * 12;
            int ch = Math.max(8, cw / 5);
            double speed = 3.0 + i * 1.7; // пикселей в секунду
            double span = w + cw * 2.0;
            int x = x0 + (int) ((i * 97.0 + t * speed) % span) - cw;
            int y = y0 + (int) (h * (0.55 + 0.1 * i)) % Math.max(1, h - ch);
            int lavender = 0x9C84E0;
            // облако из двух округлых "куполов" с плоским низом
            puff(context, x + cw / 2, y + ch, cw / 2, ch, (0x40 << 24) | lavender);
            puff(context, x + cw * 3 / 4, y + ch, cw * 3 / 10, ch * 7 / 10, (0x38 << 24) | lavender);
            context.fill(x + cw / 10, y + ch - 1, x + cw * 9 / 10, y + ch, (0x30 << 24) | 0xE5D9FF);
        }
    }

    /** Купол: ширина растёт сверху вниз по дуге эллипса; (cx, bottom) — центр основания. */
    private static void puff(DrawContext context, int cx, int bottom, int halfWidth, int height, int color) {
        for (int k = 0; k < height; k++) {
            float f = (k + 1) / (float) height;
            int half = (int) (halfWidth * Math.sqrt(1 - (1 - f) * (1 - f)));
            int y = bottom - height + k;
            context.fill(cx - half, y, cx + half, y + 1, color);
        }
    }

    private static void drawMoon(DrawContext context, int x0, int y0, int w, int h, double t) {
        int r = Math.max(10, Math.min(w, h) / 9);
        int cx = x0 + w - r * 3;
        int cy = y0 + r * 2 + (int) (Math.sin(t * 0.5) * 3); // плавно "парит"
        int cutDx = r * 2 / 5;
        int cutDy = -r / 6;
        int cutR = r * 9 / 10;
        // мягкое свечение
        for (int g = 3; g >= 1; g--) {
            int gr = r + g * 3;
            fillCircle(context, cx, cy, gr, ((0x14 / g) << 24) | 0xFFE9A8);
        }
        // диск, затем вычитаем вторую окружность -> полумесяц
        for (int dy = -r; dy <= r; dy++) {
            int half = (int) Math.sqrt(r * r - dy * dy);
            int ay = cy + dy;
            int byRel = dy - cutDy;
            int bHalf = Math.abs(byRel) <= cutR ? (int) Math.sqrt(cutR * cutR - byRel * byRel) : -1;
            int bl = cx + cutDx - bHalf;
            int br = cx + cutDx + bHalf;
            int left = cx - half;
            int right = cx + half;
            int color = 0xFFFFF0C8;
            if (bHalf < 0) {
                context.fill(left, ay, right, ay + 1, color);
            } else {
                if (bl > left) {
                    context.fill(left, ay, Math.min(bl, right), ay + 1, color);
                }
                if (br < right) {
                    context.fill(Math.max(br, left), ay, right, ay + 1, color);
                }
            }
        }
    }

    private static void fillCircle(DrawContext context, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int half = (int) Math.sqrt(r * r - dy * dy);
            context.fill(cx - half, cy + dy, cx + half, cy + dy + 1, color);
        }
    }

    /** Золотые искорки медленно поднимаются вверх, как огоньки на картинке. */
    private static void drawSparks(DrawContext context, int x0, int y0, int w, int h, double t) {
        for (int i = 0; i < SPARKS; i++) {
            double life = (t * (0.05 + (i % 5) * 0.012) + i * 0.173) % 1.0; // 0..1
            int x = x0 + (int) (((i * 0.6180339) % 1.0) * w + Math.sin(t * 0.7 + i) * 6);
            int y = y0 + h - (int) (life * h);
            float fade = (float) Math.sin(life * Math.PI);
            float tw = 0.6f + 0.4f * (float) Math.sin(t * 3 + i * 1.7);
            int a = (int) (200 * fade * tw);
            if (a < 8) {
                continue;
            }
            int color = (a << 24) | 0xFFD98A;
            context.fill(x, y, x + 2, y + 2, color);
            context.fill(x - 1, y, x, y + 2, (a / 3 << 24) | 0xFFD98A);
            context.fill(x + 2, y, x + 3, y + 2, (a / 3 << 24) | 0xFFD98A);
        }
    }

    private static int lerp(int a, int b, float f) {
        f = Math.max(0f, Math.min(1f, f));
        int r = (int) (((a >> 16) & 0xFF) + (((b >> 16) & 0xFF) - ((a >> 16) & 0xFF)) * f);
        int g = (int) (((a >> 8) & 0xFF) + (((b >> 8) & 0xFF) - ((a >> 8) & 0xFF)) * f);
        int bl = (int) ((a & 0xFF) + ((b & 0xFF) - (a & 0xFF)) * f);
        return (r << 16) | (g << 8) | bl;
    }
}
