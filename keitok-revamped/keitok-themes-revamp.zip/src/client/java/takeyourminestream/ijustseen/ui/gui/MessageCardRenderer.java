package takeyourminestream.ijustseen.ui.gui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.MutableText;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import takeyourminestream.ijustseen.core.MessagePanelConstants;
import takeyourminestream.ijustseen.core.text.ChatMessageParser;
import takeyourminestream.ijustseen.config.ModConfig;
import takeyourminestream.ijustseen.filtering.BlockedUsernameManager;
import takeyourminestream.ijustseen.messages.EmoteTextLayout;
import takeyourminestream.ijustseen.messages.Message;
import takeyourminestream.ijustseen.messages.MessageEmote;
import takeyourminestream.ijustseen.messages.RoleBadges;

/** Отрисовка одной карточки сообщения в GUI-истории. */
public final class MessageCardRenderer {
    public record UsernameHitbox(int x, int y, int width, int height) {}

    public record DrawResult(UsernameHitbox usernameHitbox) {}

    private MessageCardRenderer() {}

    public static DrawResult draw(
        DrawContext context,
        TextRenderer textRenderer,
        BlockedUsernameManager blockedUsernameManager,
        Message message,
        ChatMessageParser.ParsedMessage parsed,
        MessageCardLayout.Layout layout,
        int x,
        int y,
        float alpha,
        boolean hovered,
        boolean visibleInWorld,
        boolean pinnedInWorld
    ) {
        float panelAlpha = visibleInWorld ? alpha : alpha * 0.55f;
        takeyourminestream.ijustseen.core.MessagePanelColors.bindEvent(message.getEventType());
        try {
            MessagePanelGuiRenderer.drawPanel(context, x, y, layout.width(), layout.height(), panelAlpha, borderColorFor(message));
        } finally {
            takeyourminestream.ijustseen.core.MessagePanelColors.unbindEvent();
        }

        int innerX = x + MessagePanelConstants.PADDING_X;
        int innerY = y + MessagePanelConstants.PADDING_Y;
        UsernameHitbox usernameHitbox = null;

        if (parsed.username() != null) {
            boolean blocked = blockedUsernameManager.isBlocked(parsed.username(), parsed.username());
            MutableText usernameLabel = Text.empty().append(parsed.usernameText());
            if (blocked) {
                usernameLabel.formatted(Formatting.DARK_RED, Formatting.STRIKETHROUGH);
            } else if (hovered) {
                usernameLabel.formatted(Formatting.YELLOW, Formatting.UNDERLINE);
            }

            int usernameX = drawIconRow(context, message, innerX, innerY);
            Text blockedBadge = blocked
                ? Text.translatable("takeyourstreamchat.history.blocked_badge").formatted(Formatting.RED)
                : null;
            int maxNameWidth = nameWidthLimit(x, layout.width(), usernameX, textRenderer, blockedBadge);
            usernameLabel = fitUsername(textRenderer, usernameLabel, maxNameWidth);

            context.drawTextWithShadow(textRenderer, usernameLabel, usernameX, innerY, visibleInWorld ? 0xFFFFFFFF : 0xFF888888);
            int usernameWidth = textRenderer.getWidth(usernameLabel);
            usernameHitbox = new UsernameHitbox(usernameX, innerY, usernameWidth, MessageCardLayout.USERNAME_ROW_HEIGHT);

            if (blockedBadge != null) {
                context.drawTextWithShadow(
                    textRenderer,
                    blockedBadge,
                    usernameX + usernameWidth + 4,
                    innerY,
                    0xFFFF5555
                );
            }

            innerY += MessageCardLayout.USERNAME_ROW_HEIGHT + 2;
        }

        int bodyColor = applyAlpha(visibleInWorld ? (hovered ? 0xFFFFFFAA : 0xFFFFFFFF) : 0xFF888888, alpha);
        if (layout.emoteBodyLine() != null) {
            int lineY = innerY;
            boolean sawBody = false;
            for (EmoteTextLayout.LineContent line : layout.emoteBodyLine().lines()) {
                if (line.isGifLine()) {
                    if (parsed.username() != null || sawBody) {
                        lineY += MessageEmote.GIF_LINE_GAP;
                    }
                    MessageEmoteGuiRenderer.drawLine(
                        context,
                        textRenderer,
                        line.text(),
                        line.emotes(),
                        innerX,
                        lineY,
                        bodyColor,
                        layout.gifDisplaySize(),
                        layout.contentWidth()
                    );
                    lineY += layout.gifDisplaySize();
                } else {
                    MessageEmoteGuiRenderer.drawLine(
                        context,
                        textRenderer,
                        line.text(),
                        line.emotes(),
                        innerX,
                        lineY,
                        bodyColor
                    );
                    lineY += MessageCardLayout.emoteLineAdvance(textRenderer, line);
                }
                sawBody = true;
            }
        } else {
            for (OrderedText line : layout.bodyLines()) {
                context.drawTextWithShadow(textRenderer, line, innerX, innerY, bodyColor);
                innerY += textRenderer.fontHeight;
            }
        }

        if (pinnedInWorld) {
            MessagePanelGuiRenderer.drawPinIcon(context, x, y, layout.width(), panelAlpha);
        }

        return new DrawResult(usernameHitbox);
    }

    /** Карточка для HUD-оверлея (без hover-эффектов истории). */
    public static void drawHudCard(
        DrawContext context,
        TextRenderer textRenderer,
        BlockedUsernameManager blockedUsernameManager,
        Message message,
        ChatMessageParser.ParsedMessage parsed,
        MessageCardLayout.Layout layout,
        int x,
        int y,
        float alpha
    ) {
        if (ModConfig.isSHOW_MESSAGE_BACKGROUND()) {
            takeyourminestream.ijustseen.core.MessagePanelColors.bindEvent(message.getEventType());
            try {
                MessagePanelGuiRenderer.drawPanel(context, x, y, layout.width(), layout.height(), alpha, borderColorFor(message));
            } finally {
                takeyourminestream.ijustseen.core.MessagePanelColors.unbindEvent();
            }
        }

        int innerX = x + MessagePanelConstants.PADDING_X;
        int innerY = y + MessagePanelConstants.PADDING_Y;

        if (parsed.username() != null) {
            boolean blocked = blockedUsernameManager.isBlocked(parsed.username(), parsed.username());
            MutableText usernameLabel = Text.empty().append(parsed.usernameText());
            if (blocked) {
                usernameLabel.formatted(Formatting.DARK_RED, Formatting.STRIKETHROUGH);
            }
            int usernameX = drawIconRow(context, message, innerX, innerY);
            Text blockedBadge = blocked
                ? Text.translatable("takeyourstreamchat.history.blocked_badge").formatted(Formatting.RED)
                : null;
            usernameLabel = fitUsername(
                textRenderer,
                usernameLabel,
                nameWidthLimit(x, layout.width(), usernameX, textRenderer, blockedBadge)
            );
            int usernameColor = usernameColor(message, alpha);
            context.drawTextWithShadow(textRenderer, usernameLabel, usernameX, innerY, usernameColor);
            if (blockedBadge != null) {
                context.drawTextWithShadow(
                    textRenderer,
                    blockedBadge,
                    usernameX + textRenderer.getWidth(usernameLabel) + 4,
                    innerY,
                    applyAlpha(0xFFFF5555, alpha)
                );
            }
            innerY += MessageCardLayout.USERNAME_ROW_HEIGHT + 2;
        }

        int bodyColor = applyAlpha(0xFFFFFFFF, alpha);
        if (layout.emoteBodyLine() != null) {
            int lineY = innerY;
            boolean sawBody = false;
            for (EmoteTextLayout.LineContent line : layout.emoteBodyLine().lines()) {
                if (line.isGifLine()) {
                    if (parsed.username() != null || sawBody) {
                        lineY += MessageEmote.GIF_LINE_GAP;
                    }
                    MessageEmoteGuiRenderer.drawLine(
                        context,
                        textRenderer,
                        line.text(),
                        line.emotes(),
                        innerX,
                        lineY,
                        bodyColor,
                        layout.gifDisplaySize(),
                        layout.contentWidth()
                    );
                    lineY += layout.gifDisplaySize();
                } else {
                    MessageEmoteGuiRenderer.drawLine(
                        context,
                        textRenderer,
                        line.text(),
                        line.emotes(),
                        innerX,
                        lineY,
                        bodyColor
                    );
                    lineY += MessageCardLayout.emoteLineAdvance(textRenderer, line);
                }
                sawBody = true;
            }
        } else {
            for (OrderedText line : layout.bodyLines()) {
                context.drawTextWithShadow(textRenderer, line, innerX, innerY, bodyColor);
                innerY += textRenderer.fontHeight;
            }
        }
    }

    /** Обрезает ник, который не влезает в карточку, и ставит многоточие. */
    private static MutableText fitUsername(TextRenderer textRenderer, MutableText label, int maxWidth) {
        if (maxWidth <= 0) {
            return Text.empty();
        }
        if (textRenderer.getWidth(label) <= maxWidth) {
            return label;
        }
        String ellipsis = "...";
        int budget = maxWidth - textRenderer.getWidth(ellipsis);
        String source = label.getString();
        String trimmed = budget > 0 ? textRenderer.trimToWidth(source, budget) : "";
        if (budget <= 0) {
            trimmed = textRenderer.trimToWidth(source, maxWidth);
            ellipsis = "";
        }
        MutableText fitted = Text.literal(trimmed + ellipsis);
        fitted.setStyle(label.getStyle());
        return fitted;
    }

    private static int nameWidthLimit(int cardX, int cardWidth, int usernameX, TextRenderer textRenderer, Text blockedBadge) {
        int limit = cardX + cardWidth - MessagePanelConstants.PADDING_X - usernameX;
        if (blockedBadge != null) {
            limit -= 4 + textRenderer.getWidth(blockedBadge);
        }
        return Math.max(0, limit);
    }

    /** Иконка платформы и бейджи ролей перед ником; возвращает X начала ника. */
    private static int drawIconRow(DrawContext context, Message message, int innerX, int innerY) {
        int iconX = innerX;
        String platformIconKey = message.getPlatformIconKey();
        if (platformIconKey != null) {
            iconX = MessageEmoteGuiRenderer.drawPlatformIcon(context, platformIconKey, iconX, innerY);
        }
        int badgeY = innerY + (MessageEmoteGuiRenderer.PLATFORM_ICON_SIZE - RoleBadges.ICON_SIZE) / 2;
        for (String badgeKey : message.getRoleBadgeKeys()) {
            iconX = MessageEmoteGuiRenderer.drawGuiIcon(
                context,
                RoleBadges.iconTexture(badgeKey),
                iconX,
                badgeY,
                RoleBadges.ICON_SIZE
            );
        }
        return iconX;
    }

    private static int usernameColor(Message message, float alpha) {
        Integer rgb = message.getAuthorColorRgb();
        if (rgb != null) {
            return applyAlpha(0xFF000000 | (rgb & 0xFFFFFF), alpha);
        }
        return applyAlpha(0xFFFFFFFF, alpha);
    }

    private static int borderColorFor(Message message) {
        return takeyourminestream.ijustseen.integration.chat.ChatPlatform
            .accentColorForIconKey(message.getPlatformIconKey());
    }

    private static int applyAlpha(int color, float alpha) {
        int a = (color >> 24) & 0xFF;
        if (a == 0) {
            a = 255;
        }
        return (color & 0x00FFFFFF) | (((int) (a * alpha)) << 24);
    }
}
