package takeyourminestream.ijustseen.ui.gui;

import net.minecraft.client.gui.DrawContext;

/** Фон темы "LokalHost Gaming": чёрно-красный градиент, косые лучи, искры, развёртка. Только context.fill. */
public final class LokalSkyRenderer {
    private static final int BANDS = 36;
    private static final int EMBERS = 34;

    private LokalSkyRenderer() {}

    public static void draw(DrawContext context, int x0, int y0, int x1, int y1, int alpha, double t) {
        int w = x1 - x0;
        int h = y1 - y0;
        if (w <= 0 || h <= 0) {
            return;
        }
        context.enableScissor(x0, y0, x1, y1);
        int a = (alpha & 0xFF) << 24;
        // градиент: почти чёрный сверху -> тёмно-бордовый -> тлеющий красный у низа
        for (int i = 0; i < BANDS; i++) {
            float f = i / (float) (BANDS - 1);
            int rgb = f < 0.6f ? lerp(0x050205, 0x1A040B, f / 0.6f) : lerp(0x1A040B, 0x5A0A19, (f - 0.6f) / 0.4f);
            context.fill(x0, y0 + h * i / BANDS, x1, y0 + h * (i + 1) / BANDS, a | rgb);
        }
        beams(context, x0, y0, w, h, t);
        // тонкие строки развёртки
        int scan = 0x14000000;
        for (int y = y0; y < y1; y += 3) {
            context.fill(x0, y, x1, y + 1, scan);
        }
        // бегущая яркая линия
        int sweepY = y0 + (int) ((t * 40) % (h + 60)) - 30;
        context.fill(x0, sweepY, x1, sweepY + 1, 0x28FF2D55);
        context.fill(x0, sweepY + 1, x1, sweepY + 3, 0x10FF2D55);
        embers(context, x0, y0, w, h, t);
        context.disableScissor();
    }

    /** Три косых красных луча, медленно покачиваются. */
    private static void beams(DrawContext c, int x0, int y0, int w, int h, double t) {
        for (int b = 0; b < 3; b++) {
            double base = w * (0.15 + 0.35 * b) + Math.sin(t * 0.25 + b * 2.0) * w * 0.04;
            int width = Math.max(14, w / 18) + b * 6;
            int color = (0x14 + b * 4 << 24) | 0xFF1030;
            for (int y = 0; y < h; y += 2) {
                int x = x0 + (int) (base + (y - h) * 0.45);
                c.fill(x, y0 + y, x + width, y0 + y + 2, color);
            }
        }
    }

    /** Искры поднимаются снизу, покачиваясь и мерцая. */
    private static void embers(DrawContext c, int x0, int y0, int w, int h, double t) {
        for (int i = 0; i < EMBERS; i++) {
            double life = (t * (0.06 + (i % 6) * 0.015) + i * 0.137) % 1.0;
            int x = x0 + (int) (((i * 0.7548776662) % 1.0) * w + Math.sin(t * 0.9 + i * 1.3) * 7);
            int y = y0 + h - (int) (life * h);
            float fade = (float) Math.sin(life * Math.PI);
            float flick = 0.55f + 0.45f * (float) Math.sin(t * 6 + i * 2.1);
            int al = (int) (210 * fade * flick);
            if (al < 8) {
                continue;
            }
            int rgb = i % 4 == 0 ? 0xFF8A3C : 0xFF2D55;
            int size = i % 5 == 0 ? 2 : 1;
            c.fill(x, y, x + size, y + size, (al << 24) | rgb);
            if (size == 2) {
                c.fill(x - 1, y, x, y + 2, ((al / 4) << 24) | rgb);
                c.fill(x + 2, y, x + 3, y + 2, ((al / 4) << 24) | rgb);
            }
        }
    }

    private static int lerp(int a, int b, float f) {
        f = Math.max(0f, Math.min(1f, f));
        int r = (int) (((a >> 16) & 0xFF) + (((b >> 16) & 0xFF) - ((a >> 16) & 0xFF)) * f);
        int g = (int) (((a >> 8) & 0xFF) + (((b >> 8) & 0xFF) - ((a >> 8) & 0xFF)) * f);
        int bl = (int) ((a & 0xFF) + ((b & 0xFF) - (a & 0xFF)) * f);
        return (r << 16) | (g << 8) | bl;
    }
}
