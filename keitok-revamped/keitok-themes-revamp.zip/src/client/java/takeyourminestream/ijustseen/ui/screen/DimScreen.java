package takeyourminestream.ijustseen.ui.screen;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import takeyourminestream.ijustseen.ui.gui.ModUiTheme;
import takeyourminestream.ijustseen.ui.gui.LokalSkyRenderer;
import takeyourminestream.ijustseen.ui.gui.MoonSkyRenderer;

/** Экран настроек: в мире статичное затемнение, без ванильного blur. */
public abstract class DimScreen extends Screen {
    protected DimScreen(Text title) {
        super(title);
        ModUiTheme.applyTheme(takeyourminestream.ijustseen.config.ModConfig.getMENU_THEME());
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
        ModUiTheme.drawThemeBackground(context, this.width, this.height);
    }
}
