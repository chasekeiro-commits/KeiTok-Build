package takeyourminestream.ijustseen.ui.screen;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import org.jetbrains.annotations.Nullable;
import takeyourminestream.ijustseen.config.ModConfig;
import takeyourminestream.ijustseen.ui.gui.ModUiTheme;
import takeyourminestream.ijustseen.ui.gui.ThemeDecor;
import takeyourminestream.ijustseen.ui.gui.ThemeSkyRenderer;
import takeyourminestream.ijustseen.ui.gui.ScreenUiHelper;
import takeyourminestream.ijustseen.ui.gui.MoonSkyRenderer;
import takeyourminestream.ijustseen.ui.gui.LokalSkyRenderer;
import takeyourminestream.ijustseen.utils.ScreenNavigationCompat;

/** Theme picker with a clipped, scrollable list and live palette previews. */
public class ThemesScreen extends DimScreen {
    private static final int PAD=10, PANEL_TOP=24, FOOTER_H=20, CARD_H=54, GAP=5;
    private static final int PREVIEW_W=92;
    private record Theme(String id,String nameKey,String descKey) {}
    private static final Theme[] THEMES={
        new Theme("purple_moon","takeyourstreamchat.theme.purple_moon","takeyourstreamchat.theme.purple_moon.desc"),
        new Theme("lokalhost","takeyourstreamchat.theme.lokalhost","takeyourstreamchat.theme.lokalhost.desc"),
        new Theme("ocean_depths","takeyourstreamchat.theme.ocean_depths","takeyourstreamchat.theme.ocean_depths.desc"),
        new Theme("sakura_bloom","takeyourstreamchat.theme.sakura_bloom","takeyourstreamchat.theme.sakura_bloom.desc"),
        new Theme("emerald_grove","takeyourstreamchat.theme.emerald_grove","takeyourstreamchat.theme.emerald_grove.desc"),
        new Theme("solar_flare","takeyourstreamchat.theme.solar_flare","takeyourstreamchat.theme.solar_flare.desc"),
        new Theme("midnight_blue","takeyourstreamchat.theme.midnight_blue","takeyourstreamchat.theme.midnight_blue.desc"),
        new Theme("cyberpunk","takeyourstreamchat.theme.cyberpunk","takeyourstreamchat.theme.cyberpunk.desc"),
        new Theme("default","takeyourstreamchat.theme.default","takeyourstreamchat.theme.default.desc")
    };
    private final @Nullable Screen parent;
    private final ButtonWidget[] cards=new ButtonWidget[THEMES.length];
    private ButtonWidget backButton;
    private int scrollOffset;

    public ThemesScreen(@Nullable Screen parent) {
        super(Text.translatable("takeyourstreamchat.theme.title"));
        this.parent=parent;
    }

    @Override protected void init() {
        for(int i=0;i<THEMES.length;i++) {
            final String id=THEMES[i].id();
            ButtonWidget button=ButtonWidget.builder(Text.empty(),b->{
                ModConfig.setMENU_THEME(id);
                ModUiTheme.applyTheme(id);
            }).dimensions(0,0,1,CARD_H).build();
            cards[i]=button;
            addDrawableChild(button);
        }
        Text back=Text.translatable("takeyourstreamchat.config.back");
        int bw=this.textRenderer.getWidth(back)+24;
        backButton=ButtonWidget.builder(back,b->close())
            .dimensions((width-bw)/2,height-30,bw,FOOTER_H).build();
        addDrawableChild(backButton);
        layoutCards();
    }

    private int listTop(){ return PANEL_TOP+16; }
    private int listBottom(){ return height-42; }
    private int cardWidth(){ return Math.max(120,Math.min(390,width-PAD*2-24)); }
    private int cardLeft(){ return (width-cardWidth())/2; }
    private int contentHeight(){ return THEMES.length*(CARD_H+GAP)-GAP; }
    private int maxScroll(){ return Math.max(0,contentHeight()-(listBottom()-listTop())); }
    private void layoutCards(){
        scrollOffset=Math.max(0,Math.min(scrollOffset,maxScroll()));
        for(int i=0;i<cards.length;i++){
            int y=listTop()+i*(CARD_H+GAP)-scrollOffset;
            cards[i].setPosition(cardLeft(),y);
            cards[i].setDimensions(cardWidth(),CARD_H);
            cards[i].active=y+CARD_H>listTop() && y<listBottom();
        }
        if(backButton!=null) backButton.setPosition((width-backButton.getWidth())/2,height-30);
    }

    @Override public boolean mouseScrolled(double mouseX,double mouseY,double horizontalAmount,double verticalAmount){
        if(mouseY>=listTop() && mouseY<=listBottom() && maxScroll()>0){
            scrollOffset-= (int)Math.signum(verticalAmount)*(CARD_H+GAP)*2;
            layoutCards();
            return true;
        }
        return super.mouseScrolled(mouseX,mouseY,horizontalAmount,verticalAmount);
    }

    @Override public void render(DrawContext c,int mouseX,int mouseY,float delta){
        layoutCards();
        java.util.Set<ButtonWidget> hidden=ScreenUiHelper.hideButtons(this);
        super.render(c,mouseX,mouseY,delta);
        ScreenUiHelper.restoreButtons(hidden);

        ModUiTheme.drawTitle(c,textRenderer,title,width,6);
        ModUiTheme.drawBorderedPanel(c,PAD,PANEL_TOP,width-PAD*2,height-PANEL_TOP-12);
        c.enableScissor(cardLeft(),listTop(),cardLeft()+cardWidth(),listBottom());
        String current=ModConfig.getMENU_THEME();
        double now=System.nanoTime()/1.0e9;
        for(int i=0;i<THEMES.length;i++){
            Theme theme=THEMES[i];
            int x=cardLeft(), y=listTop()+i*(CARD_H+GAP)-scrollOffset, w=cardWidth();
            boolean selected=theme.id().equals(current) ||
                ("default".equals(theme.id()) && current==null);
            boolean hovered=ModUiTheme.isHovered(mouseX,mouseY,x,y,w,CARD_H);
            ModUiTheme.drawListRow(c,x,y,x+w,y+CARD_H,hovered);
            int border=selected?ModUiTheme.ACCENT:ModUiTheme.PANEL_BORDER;
            c.fill(x,y,x+w,y+1,border); c.fill(x,y+CARD_H-1,x+w,y+CARD_H,border);
            c.fill(x,y,x+1,y+CARD_H,border); c.fill(x+w-1,y,x+w,y+CARD_H,border);

            int px=x+4, py=y+4, pr=px+PREVIEW_W, pb=y+CARD_H-4;
            if("purple_moon".equals(theme.id())) MoonSkyRenderer.draw(c,px,py,pr,pb,0xFF,now);
            else if("lokalhost".equals(theme.id())){
                LokalSkyRenderer.draw(c,px,py,pr,pb,0xFF,now);
                int tw=ThemeDecor.wordmarkWidth();
                ThemeDecor.wordmark(c,px+(PREVIEW_W-tw)/2,py+(pb-py)/2-3,1,now,1f);
            } else if("default".equals(theme.id())){
                c.fill(px,py,pr,pb,0xFF171522);
                c.fill(px+7,py+8,pr-7,py+13,0xFFB58CFF);
                c.fill(px+7,py+21,pr-7,py+25,0xFF494253);
                c.fill(px+7,py+33,pr-7,py+37,0xFF494253);
            } else ThemeSkyRenderer.draw(c,px,py,pr,pb,theme.id(),now);
            c.fill(px,py,pr,py+1,ModUiTheme.PANEL_BORDER);
            c.fill(px,pb-1,pr,pb,ModUiTheme.PANEL_BORDER);
            c.fill(px,py,px+1,pb,ModUiTheme.PANEL_BORDER);
            c.fill(pr-1,py,pr,pb,ModUiTheme.PANEL_BORDER);

            int tx=pr+9, maxText=x+w-tx-7;
            c.drawTextWithShadow(textRenderer,ModUiTheme.fit(textRenderer,Text.translatable(theme.nameKey()).getString(),maxText),tx,y+8,ModUiTheme.TEXT_PRIMARY);
            c.drawTextWithShadow(textRenderer,ModUiTheme.fit(textRenderer,Text.translatable(theme.descKey()).getString(),maxText),tx,y+22,ModUiTheme.TEXT_SECONDARY);
            if(selected) c.drawTextWithShadow(textRenderer,Text.translatable("takeyourstreamchat.theme.selected"),tx,y+37,ModUiTheme.ACCENT);
        }
        c.disableScissor();
        if(maxScroll()>0){
            int trackX=width-PAD-5, top=listTop(), bottom=listBottom();
            c.fill(trackX,top,trackX+2,bottom,ModUiTheme.SCROLL_TRACK);
            int thumbH=Math.max(24,(bottom-top)*(bottom-top)/contentHeight());
            int thumbY=top+(bottom-top-thumbH)*scrollOffset/maxScroll();
            c.fill(trackX,thumbY,trackX+2,thumbY+thumbH,ModUiTheme.SCROLL_THUMB);
        }
        ScreenUiHelper.renderButtons(c,mouseX,mouseY,java.util.List.of(backButton),null);
    }

    @Override public void close(){ ScreenNavigationCompat.open(client,parent); }
}
