package takeyourminestream.ijustseen.ui.gui;

import net.minecraft.client.gui.DrawContext;

/** Декор рамок панелей и пиксельная надпись для тем меню. Только context.fill — работает во всех версиях. */
public final class ThemeDecor {
    private static final int GLYPH_W = 5;
    private static final int GLYPH_H = 7;
    private static final String WORDMARK = "LOKALHOST GAMING";

    private ThemeDecor() {}

    // ------------------------------------------------------------------ рамка панели

    public static void frame(DrawContext c, int x, int y, int w, int h, double t) {
        if (ModUiTheme.isMoon()) {
            moonFrame(c, x, y, w, h, t);
        } else if (ModUiTheme.isLokal()) {
            lokalFrame(c, x, y, w, h, t);
        }
    }

    private static void rect(DrawContext c, int x0, int y0, int x1, int y1, int color) {
        if (x1 > x0 && y1 > y0) {
            c.fill(x0, y0, x1, y1, color);
        }
    }

    /** Угловая скобка: две линии длиной len и толщиной thick, уходящие внутрь панели из угла (cx,cy). */
    private static void bracket(DrawContext c, int cx, int cy, int sx, int sy, int len, int thick, int color) {
        int hx0 = sx > 0 ? cx : cx - len;
        int hx1 = sx > 0 ? cx + len : cx;
        int hy0 = sy > 0 ? cy : cy - thick;
        int hy1 = sy > 0 ? cy + thick : cy;
        rect(c, hx0, hy0, hx1, hy1, color);
        int vx0 = sx > 0 ? cx : cx - thick;
        int vx1 = sx > 0 ? cx + thick : cx;
        int vy0 = sy > 0 ? cy : cy - len;
        int vy1 = sy > 0 ? cy + len : cy;
        rect(c, vx0, vy0, vx1, vy1, color);
    }

    private static int alpha(int argb, float mul) {
        int a = (int) (((argb >>> 24) & 0xFF) * Math.max(0f, Math.min(1f, mul)));
        return (a << 24) | (argb & 0xFFFFFF);
    }

    // ---- Purple Moon: золотые уголки-звёзды, внутренняя линия, мерцающие точки по краям

    private static void moonFrame(DrawContext c, int x, int y, int w, int h, double t) {
        int gold = 0xFFFFD98A;
        int lav = 0xFFB9A3F0;
        int r = x + w;
        int b = y + h;
        // тонкая внутренняя линия
        int in = 3;
        int line = 0x50B9A3F0;
        rect(c, x + in, y + in, r - in, y + in + 1, line);
        rect(c, x + in, b - in - 1, r - in, b - in, line);
        rect(c, x + in, y + in, x + in + 1, b - in, line);
        rect(c, r - in - 1, y + in, r - in, b - in, line);

        // уголки: золотая скобка и четырёхлучевая звезда
        for (int i = 0; i < 4; i++) {
            int sx = (i & 1) == 0 ? 1 : -1;
            int sy = (i & 2) == 0 ? 1 : -1;
            int cx = (i & 1) == 0 ? x : r;
            int cy = (i & 2) == 0 ? y : b;
            bracket(c, cx, cy, sx, sy, 22, 2, gold);
            bracket(c, cx + sx * 4, cy + sy * 4, sx, sy, 10, 1, alpha(lav, 0.8f));
            float tw = 0.65f + 0.35f * (float) Math.sin(t * 2.0 + i * 1.3);
            star(c, cx + sx * 11, cy + sy * 11, 4, alpha(gold, tw));
            star(c, cx + sx * 20, cy + sy * 20, 1, alpha(0xFFFFFFFF, tw * 0.8f));
        }

        // мерцающие точки и ромбики вдоль краёв
        int step = 20;
        for (int px = x + 34, i = 0; px < r - 22; px += step, i++) {
            dot(c, px, y + 1, i, t, (i % 2 == 0) ? gold : lav, i % 2 == 0);
            dot(c, px + 10, b - 2, i + 3, t, (i % 2 == 1) ? gold : lav, i % 2 == 1);
        }
        for (int py = y + 26, i = 0; py < b - 22; py += step, i++) {
            dot(c, x + 1, py, i + 1, t, lav, false);
            dot(c, r - 2, py + 8, i + 2, t, lav, false);
        }
        // полумесяц по центру верхней границы
        int mx = x + w / 2;
        crescent(c, mx, y + 1, 7, gold);
        star(c, mx - 18, y + 1, 3, alpha(gold, 0.9f));
        star(c, mx + 18, y + 1, 3, alpha(gold, 0.9f));
        crescent(c, x + 3, y + h / 2, 5, alpha(gold, 0.8f));
        crescent(c, r - 3, y + h / 2, 5, alpha(gold, 0.8f));
    }

    private static void dot(DrawContext c, int px, int py, int i, double t, int color, boolean star) {
        float tw = 0.35f + 0.65f * (0.5f + 0.5f * (float) Math.sin(t * 1.7 + i * 0.9));
        if (star) {
            star(c, px, py, 2, alpha(color, tw));
        } else {
            rect(c, px, py, px + 1, py + 1, alpha(color, tw * 0.8f));
        }
    }

    /** Четырёхлучевая звезда с центром (cx,cy) и лучом r. */
    private static void star(DrawContext c, int cx, int cy, int r, int color) {
        rect(c, cx - r, cy, cx + r + 1, cy + 1, color);
        rect(c, cx, cy - r, cx + 1, cy + r + 1, color);
        rect(c, cx, cy, cx + 1, cy + 1, 0xFFFFFFFF & (color | 0xFF000000));
    }

    private static void crescent(DrawContext c, int cx, int cy, int r, int color) {
        for (int dy = -r; dy <= r; dy++) {
            int half = (int) Math.sqrt(r * r - dy * dy);
            int cut = (int) Math.sqrt(Math.max(0, (r - 1) * (r - 1) - dy * dy));
            int left = cx - half;
            int right = cx + half;
            int cl = cx + 2 - cut;
            int cr = cx + 2 + cut;
            if (cut == 0 || Math.abs(dy) > r - 1) {
                rect(c, left, cy + dy, right, cy + dy + 1, color);
            } else {
                rect(c, left, cy + dy, Math.min(cl, right), cy + dy + 1, color);
                rect(c, Math.max(cr, left), cy + dy, right, cy + dy + 1, color);
            }
        }
    }

    // ---- LokalHost Gaming: красные угловые скобы, бегущая подсветка шевронов, пульсирующий контур

    private static void lokalFrame(DrawContext c, int x, int y, int w, int h, double t) {
        lokalFrameBody(c, x, y, w, h, t);
        brandPlate(c, x, w, y + h, t);
    }

    private static void lokalFrameBody(DrawContext c, int x, int y, int w, int h, double t) {
        int red = 0xFFE0103A;
        int dark = 0xFF7A0F22;
        int r = x + w;
        int b = y + h;
        float pulse = 0.6f + 0.4f * (float) Math.sin(t * 2.4);

        int in = 3;
        int line = alpha(red, 0.28f * pulse);
        rect(c, x + in, y + in, r - in, y + in + 1, line);
        rect(c, x + in, b - in - 1, r - in, b - in, line);
        rect(c, x + in, y + in, x + in + 1, b - in, line);
        rect(c, r - in - 1, y + in, r - in, b - in, line);

        // шевроны вдоль верхней и нижней границы + бегущий блик
        int step = 12;
        int count = Math.max(1, (w - 60) / step);
        int head = (int) ((t * 16) % (count + 10));
        for (int i = 0; i < count; i++) {
            int px = x + 30 + i * step;
            float near = Math.max(0f, 1f - Math.abs(i - head) / 5f);
            int color = near > 0 ? alpha(0xFFFF3355, 0.35f + 0.65f * near) : dark;
            slash(c, px, y, color);
            slash(c, px, b - 5, color);
        }
        int vcount = Math.max(1, (h - 60) / step);
        int vhead = (int) ((t * 12) % (vcount + 8));
        for (int i = 0; i < vcount; i++) {
            int py = y + 30 + i * step;
            float near = Math.max(0f, 1f - Math.abs(i - vhead) / 4f);
            int color = near > 0 ? alpha(0xFFFF3355, 0.35f + 0.65f * near) : dark;
            rect(c, x, py, x + 4, py + 2, color);
            rect(c, r - 4, py, r, py + 2, color);
        }

        // угловые скобы с «срезом» и мягким свечением
        for (int i = 0; i < 4; i++) {
            int sx = (i & 1) == 0 ? 1 : -1;
            int sy = (i & 2) == 0 ? 1 : -1;
            int cx = (i & 1) == 0 ? x : r;
            int cy = (i & 2) == 0 ? y : b;
            bracket(c, cx, cy, sx, sy, 32, 3, red);
            // ступенчатый срез внутри угла
            for (int s = 0; s < 4; s++) {
                int ox = cx + sx * (5 + s * 2);
                int oy = cy + sy * (5 + (3 - s) * 2);
                rect(c, Math.min(ox, ox + sx * 2), Math.min(oy, oy + sy * 2), Math.max(ox, ox + sx * 2), Math.max(oy, oy + sy * 2), alpha(red, 0.55f));
            }
            // пульсирующий «огонёк» в углу
            rect(c, cx + sx * 3 - (sx > 0 ? 0 : 3), cy + sy * 3 - (sy > 0 ? 0 : 3),
                cx + sx * 3 + (sx > 0 ? 3 : 0), cy + sy * 3 + (sy > 0 ? 3 : 0), alpha(0xFFFF6A80, pulse));
        }
    }

    /** Табличка с брендом по центру нижней границы. */
    private static void brandPlate(DrawContext c, int x, int w, int bottom, double t) {
        int tw = wordmarkWidth();
        int pw = tw + 20;
        int ph = 13;
        int px = x + (w - pw) / 2;
        int py = bottom - ph / 2 - 1;
        rect(c, px, py, px + pw, py + ph, 0xFF0A0507);
        rect(c, px, py, px + pw, py + 1, 0xFFE0103A);
        rect(c, px, py + ph - 1, px + pw, py + ph, 0xFFE0103A);
        rect(c, px, py, px + 1, py + ph, 0xFFE0103A);
        rect(c, px + pw - 1, py, px + pw, py + ph, 0xFFE0103A);
        wordmark(c, px + 10, py + 3, 1, t, 1f);
    }

    /** Косая черта "/" высотой 5 пикселей. */
    private static void slash(DrawContext c, int x, int y, int color) {
        for (int i = 0; i < 5; i++) {
            rect(c, x + (4 - i), y + i, x + (4 - i) + 2, y + i + 1, color);
        }
    }

    // ------------------------------------------------------------------ пиксельная надпись

    private static final String[][] GLYPHS = {
        {"L", "X....", "X....", "X....", "X....", "X....", "X....", "XXXXX"},
        {"O", ".XXX.", "X...X", "X...X", "X...X", "X...X", "X...X", ".XXX."},
        {"K", "X...X", "X..X.", "X.X..", "XX...", "X.X..", "X..X.", "X...X"},
        {"A", ".XXX.", "X...X", "X...X", "XXXXX", "X...X", "X...X", "X...X"},
        {"H", "X...X", "X...X", "X...X", "XXXXX", "X...X", "X...X", "X...X"},
        {"S", ".XXXX", "X....", "X....", ".XXX.", "....X", "....X", "XXXX."},
        {"T", "XXXXX", "..X..", "..X..", "..X..", "..X..", "..X..", "..X.."},
        {"G", ".XXX.", "X...X", "X....", "X.XXX", "X...X", "X...X", ".XXX."},
        {"M", "X...X", "XX.XX", "X.X.X", "X...X", "X...X", "X...X", "X...X"},
        {"I", ".XXX.", "..X..", "..X..", "..X..", "..X..", "..X..", ".XXX."},
        {"N", "X...X", "XX..X", "X.X.X", "X..XX", "X...X", "X...X", "X...X"},
    };

    private static String[] glyph(char ch) {
        for (String[] g : GLYPHS) {
            if (g[0].charAt(0) == ch) {
                return g;
            }
        }
        return null;
    }

    /** Ширина надписи в «пикселях шрифта» (без масштаба). */
    public static int wordmarkWidth() {
        int cols = 0;
        for (int i = 0; i < WORDMARK.length(); i++) {
            cols += WORDMARK.charAt(i) == ' ' ? 3 : GLYPH_W + 1;
        }
        return cols - 1;
    }

    public static int wordmarkHeight() {
        return GLYPH_H;
    }

    /** Надпись LOKALHOST GAMING: красная, со свечением и лёгким мерцанием. */
    public static void wordmark(DrawContext c, int x, int y, int scale, double t, float alphaMul) {
        float flicker = 0.85f + 0.15f * (float) Math.sin(t * 5.0);
        draw(c, x, y, scale, alpha(0x40FF1030, alphaMul), 1);   // свечение
        draw(c, x, y, scale, alpha(0xFFE0103A, alphaMul * flicker), 0);
        draw(c, x, y, scale, alpha(0x60FF8A9A, alphaMul), -1);  // блик сверху (рисуется только верхним рядом)
    }

    /** mode 1 — свечение (по 4 смещениям), 0 — основной цвет, -1 — блик на верхней строке глифа. */
    private static void draw(DrawContext c, int x, int y, int scale, int color, int mode) {
        int cursor = 0;
        for (int i = 0; i < WORDMARK.length(); i++) {
            char ch = WORDMARK.charAt(i);
            if (ch == ' ') {
                cursor += 3;
                continue;
            }
            String[] g = glyph(ch);
            if (g == null) {
                continue;
            }
            for (int row = 0; row < GLYPH_H; row++) {
                if (mode == -1 && row != 0) {
                    continue;
                }
                String bits = g[row + 1];
                for (int col = 0; col < GLYPH_W; col++) {
                    if (bits.charAt(col) != 'X') {
                        continue;
                    }
                    int px = x + (cursor + col) * scale;
                    int py = y + row * scale;
                    if (mode == 1) {
                        rect(c, px - 1, py - 1, px + scale + 1, py + scale + 1, color);
                    } else {
                        rect(c, px, py, px + scale, py + scale, color);
                    }
                }
            }
            cursor += GLYPH_W + 1;
        }
    }

    /** Слабая надпись-водяной знак по центру панели (под содержимым). */
    public static void watermark(DrawContext c, int x, int y, int w, int h, double t) {
        int scale = Math.max(1, Math.min(6, (int) (w * 0.62f / wordmarkWidth())));
        int tw = wordmarkWidth() * scale;
        int th = wordmarkHeight() * scale;
        if (tw + 8 > w || th + 8 > h) {
            return;
        }
        wordmark(c, x + (w - tw) / 2, y + (h - th) / 2, scale, t, 0.30f);
    }
}
